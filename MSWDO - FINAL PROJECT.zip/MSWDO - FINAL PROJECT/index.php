<?php
session_start();
require_once 'config/database.php';

// If already logged in, redirect to appropriate dashboard
if(isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    switch($_SESSION['role']) {
        case 'resident':
            header("Location: dashboards/resident_dashboard.php");
            break;
        case 'staff':
        case 'social_worker':
        case 'encoder':
            header("Location: dashboards/mswdstaff_dashboard.php");
            break;
        case 'admin':
            header("Location: dashboards/admin_dashboard.php");
            break;
        default:
            header("Location: dashboards/resident_dashboard.php");
    }
    exit();
}

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if(!empty($username) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if($user && password_verify($password, $user['password'])) {
            // ============================================================
            // 🆕 FIX: Nuke any existing session BEFORE creating a new one
            // This guarantees no stale session data survives a user switch.
            // ============================================================
            $_SESSION = array();
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 86400,
                    $params["path"],
                    $params["domain"],
                    $params["secure"],
                    $params["httponly"]
                );
            }
            session_destroy();

            // Start a completely fresh session with a new ID
            session_start();
            session_regenerate_id(true);

            // Now set the new user's data
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role']      = $user['role'];
            $_SESSION['username']  = $user['username'];
            
            // Update last login
            $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
            $updateStmt->execute([$user['id']]);
            
            // Redirect based on role
            switch($user['role']) {
                case 'resident':
                    header("Location: dashboards/resident_dashboard.php");
                    break;
                case 'staff':
                case 'social_worker':
                case 'encoder':
                    header("Location: dashboards/mswdstaff_dashboard.php");
                    break;
                case 'admin':
                    header("Location: dashboards/admin_dashboard.php");
                    break;
                default:
                    header("Location: dashboards/resident_dashboard.php");
            }
            exit();
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>MSWDO Cantilan | Municipal Social Welfare & Development Office</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- ============================================================ -->
    <!-- PWA META TAGS -->
    <!-- ============================================================ -->
    <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0A2F6C 0%, #1E4A8C 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: radial-gradient(circle at 10% 20%, rgba(245,176,66,0.08) 2%, transparent 2.5%),
                              radial-gradient(circle at 85% 70%, rgba(211,47,47,0.05) 1.8%, transparent 2%);
            background-size: 48px 48px, 64px 64px;
            pointer-events: none;
        }
        .login-wrapper {
            width: 100%;
            max-width: 460px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
            animation: fadeSlideUp 0.45s ease-out;
        }
        @keyframes fadeSlideUp {
            0% { opacity: 0; transform: translateY(18px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .login-card {
            background: #FFFFFF;
            border-radius: 36px;
            box-shadow: 0 25px 45px -12px rgba(0,0,0,0.25), 0 4px 12px rgba(0,0,0,0.05);
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s;
        }
        .login-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 32px 55px -14px rgba(0,0,0,0.3);
        }
        .login-header {
            padding: 2rem 2rem 1.2rem 2rem;
            text-align: center;
            background: white;
            border-bottom: 1px solid #F0F2F5;
            position: relative;
        }
        .logo-container {
            width: 100px;
            height: 100px;
            margin: 0 auto 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #FFFFFF;
            border-radius: 50%;
            overflow: hidden;
            box-shadow: 0 4px 16px rgba(30, 74, 140, 0.15);
            border: 2px solid #F0F2F5;
        }
        .mswd-logo {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 8px;
        }
        .logo-fallback {
            font-size: 3rem;
            background: linear-gradient(135deg, #F5B042 25%, #D32F2F 45%, #1E4A8C 75%);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
        }
        .login-header h1 {
            font-size: 1.9rem;
            font-weight: 700;
            letter-spacing: -0.3px;
            background: linear-gradient(120deg, #0A2F6C, #1E4A8C);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            margin-bottom: 6px;
        }
        .login-header p {
            font-size: 0.85rem;
            color: #5B6E8C;
            font-weight: 500;
            margin-top: 6px;
        }
        .header-stripes {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 18px;
        }
        .stripe {
            width: 42px;
            height: 4px;
            border-radius: 4px;
        }
        .stripe-blue { background-color: #1E4A8C; }
        .stripe-red { background-color: #D32F2F; }
        .stripe-yellow { background-color: #F5B042; }
        .login-body {
            padding: 1.8rem 2rem 2rem 2rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 0.85rem;
            color: #1E2F4E;
            margin-bottom: 8px;
            cursor: pointer;
        }
        .form-label i {
            font-size: 0.95rem;
            color: #F5B042;
            width: 20px;
        }
        .form-control {
            width: 100%;
            padding: 14px 18px;
            font-size: 0.95rem;
            font-family: 'Inter', sans-serif;
            border: 1.5px solid #E2E8F0;
            border-radius: 24px;
            transition: all 0.2s;
            background-color: #FEFEFE;
            outline: none;
            color: #0F2B3D;
        }
        .form-control:focus {
            border-color: #F5B042;
            box-shadow: 0 0 0 4px rgba(245, 176, 66, 0.2);
            background-color: #fff;
        }
        .btn-primary {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            background: #1E4A8C;
            border: none;
            padding: 14px 20px;
            border-radius: 48px;
            font-weight: 700;
            font-size: 1rem;
            color: white;
            cursor: pointer;
            transition: all 0.25s;
            margin-top: 8px;
            font-family: 'Inter', sans-serif;
            box-shadow: 0 2px 6px rgba(30,74,140,0.2);
        }
        .btn-primary i {
            font-size: 1rem;
            transition: transform 0.2s;
        }
        .btn-primary:hover {
            background: #0A2F6C;
            transform: scale(1.01);
            box-shadow: 0 10px 20px -8px rgba(30,74,140,0.4);
        }
        .btn-primary:hover i {
            transform: translateX(4px);
        }
        .btn-primary:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        .alert {
            background: #FEF2F0;
            border-left: 5px solid #D32F2F;
            color: #B91C1C;
            padding: 14px 18px;
            border-radius: 24px;
            margin-bottom: 1.6rem;
            font-size: 0.85rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert i { font-size: 1rem; }
        .alert-success {
            background: #E8F5E9;
            border-left: 5px solid #2E7D32;
            color: #1E5A2E;
        }
        .text-muted {
            color: #5F7F9E;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: color 0.2s;
        }
        .text-muted:hover {
            color: #1E4A8C;
            text-decoration: underline;
        }
        .login-footer {
            background-color: #F9FBFD;
            padding: 1rem 1.5rem;
            text-align: center;
            font-size: 0.7rem;
            color: #6C86A3;
            border-top: 1px solid #EDF2F7;
            font-weight: 500;
        }
        .sync-status {
            font-size: 0.7rem;
            color: #6C86A3;
            margin-top: 12px;
            text-align: center;
        }
        a { text-decoration: none; }
        .register-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 0.8s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        @media (max-width: 480px) {
            .login-card { border-radius: 28px; }
            .login-body { padding: 1.5rem; }
            .login-header { padding: 1.5rem 1.5rem 1rem; }
            .login-header h1 { font-size: 1.6rem; }
            .btn-primary { padding: 12px 18px; }
            .logo-container { width: 80px; height: 80px; }
        }
    </style>
</head>
<body>
<div class="login-wrapper">
    <div class="login-card">
        <div class="login-header">
            <div class="logo-container">
                <img src="assets/img/mswdo_logo.jpg" 
                     alt="MSWDO Logo" 
                     class="mswd-logo"
                     onerror="this.style.display='none'; this.parentElement.innerHTML='<div class=\'logo-fallback\'><i class=\'fas fa-hand-holding-heart\'></i></div>'">
            </div>
            <h1>MSWDO Cantilan</h1>
            <p>Municipal Social Welfare & Development Office</p>
            <div class="header-stripes">
                <div class="stripe stripe-blue"></div>
                <div class="stripe stripe-red"></div>
                <div class="stripe stripe-yellow"></div>
            </div>
        </div>

        <div class="login-body">
            <div id="statusBanner" style="margin-bottom: 16px; display: none;">
                <div id="statusMessage" style="padding: 10px 14px; border-radius: 20px; font-size: 0.75rem; display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-wifi" id="statusIcon"></i>
                    <span id="statusText">Checking connection...</span>
                </div>
            </div>

            <?php if(!empty($error)): ?>
                <div class="alert">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="" id="loginForm">
                <div class="form-group">
                    <label for="username" class="form-label">
                        <i class="fas fa-user-circle"></i> Username
                    </label>
                    <input type="text" 
                           name="username" 
                           id="username" 
                           class="form-control" 
                           placeholder="Enter your username" 
                           autocomplete="username"
                           required 
                           autofocus>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock"></i> Password
                    </label>
                    <input type="password" 
                           name="password" 
                           id="password" 
                           class="form-control" 
                           placeholder="Enter your password" 
                           autocomplete="current-password"
                           required>
                </div>

                <button type="submit" class="btn-primary" id="loginBtn">
                    <span>Sign in</span> <i class="fas fa-arrow-right"></i>
                </button>
            </form>

            <div style="text-align: center; margin-top: 28px;">
                <a href="register.php" class="text-muted register-link">
                    <i class="fas fa-user-plus"></i> Don't have an account? Register here
                </a>
            </div>
            
            <div class="sync-status" id="syncStatus">
                <i class="fas fa-database"></i> <span id="syncText">Checking connection...</span>
            </div>

            <div style="margin-top: 16px; text-align: center; font-size: 0.7rem; color: #94A3B8;">
                <i class="fas fa-shield-alt"></i> Secured | MSWDO
            </div>
        </div>

        <div class="login-footer">
            <i class="fas fa-building"></i> MSWDO Mobile System | Secure Access
        </div>
    </div>
</div>

<script>
(function() {
    'use strict';

    // ============================================================
    // 1. NETWORK STATUS
    // ============================================================
    function isOnline() {
        return navigator.onLine;
    }

    function updateStatus() {
        const statusEl = document.getElementById('syncText');
        const banner = document.getElementById('statusBanner');
        const message = document.getElementById('statusMessage');
        const icon = document.getElementById('statusIcon');
        const text = document.getElementById('statusText');
        
        if (isOnline()) {
            statusEl.textContent = '🟢 Online';
            if (banner) {
                banner.style.display = 'block';
                message.style.background = '#D1FAE5';
                icon.className = 'fas fa-wifi';
                icon.style.color = '#059669';
                text.textContent = '✅ Connected to server';
            }
        } else {
            statusEl.textContent = '🔴 Offline';
            if (banner) {
                banner.style.display = 'block';
                message.style.background = '#FEF3C7';
                icon.className = 'fas fa-wifi-slash';
                icon.style.color = '#B45309';
                text.textContent = '📶 Offline Mode - Please check your connection';
            }
        }
    }

    // ============================================================
    // 2. FORM HANDLING
    // ============================================================
    function handleFormSubmit(e) {
        const btn = document.getElementById('loginBtn');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<span class="spinner"></span> Signing in...';
        btn.disabled = true;
        
        // Fallback: re-enable after 5s if navigation is blocked
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }, 5000);
    }

    // ============================================================
    // 3. INITIALIZATION
    // ============================================================
    // 🆕 FIX: Removed the localStorage auto-login block that was
    // causing wrong-user redirects. PHP sessions now handle all
    // login state — cleaner and more secure.
    //
    // Also clears any stale localStorage keys from the old version.
    // ============================================================
    function init() {
        // Clear any stale localStorage keys from previous versions
        try {
            localStorage.removeItem('mswdo_session');
            localStorage.removeItem('mswdo_token');
        } catch (e) { /* ignore */ }

        document.getElementById('loginForm').addEventListener('submit', handleFormSubmit);
        window.addEventListener('online', updateStatus);
        window.addEventListener('offline', updateStatus);
        updateStatus();
        
        console.log('✅ MSWDO Login ready');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
</script>

<!-- ============================================================ -->
<!-- PWA SERVICE WORKER REGISTRATION -->
<!-- ============================================================ -->
<?= renderPwaServiceWorker() ?>

</body>
</html>