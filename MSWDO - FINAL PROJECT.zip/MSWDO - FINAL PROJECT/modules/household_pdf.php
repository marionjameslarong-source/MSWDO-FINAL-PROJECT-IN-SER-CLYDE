<?php
// ============================================================================
// HOUSEHOLD PDF GENERATOR v3 — DomPDF with repeating header/footer
// File: modules/household_pdf.php
// ============================================================================
session_start();
require_once '../config/database.php';
require_once '../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if(!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }
$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) { header("Location: ../index.php"); exit(); }

$household_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $pdo->prepare("SELECT * FROM households WHERE id = ?");
$stmt->execute([$household_id]);
$household = $stmt->fetch();
if(!$household) die("Household not found.");

$stmt = $pdo->prepare("SELECT * FROM household_members WHERE household_id = ? ORDER BY id");
$stmt->execute([$household_id]);
$members = $stmt->fetchAll();

function classifyPovertyIncome($income) {
    if($income < 5000) return 'Extremely Poor';
    elseif($income >= 5000 && $income <= 10000) return 'Poor';
    elseif($income >= 10001 && $income <= 15000) return 'Low Income';
    elseif($income >= 15001 && $income <= 25000) return 'Lower Middle';
    else return 'Middle Income and Above';
}

$poverty_status = $household['poverty_status'] ?? classifyPovertyIncome($household['monthly_income'] ?? 0);
$doc_number = 'OSCA-HH-' . date('Y') . '-' . str_pad($household_id, 5, '0', STR_PAD_LEFT);
$date_generated = date('F d, Y');

// ----- Logos as base64 -----
function imageToBase64($path) {
    if (!$path || !file_exists($path)) return '';
    $data = file_get_contents($path);
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $mime = ($ext === 'jpg' || $ext === 'jpeg') ? 'image/jpeg' : 'image/png';
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

$cantilan_src = imageToBase64(__DIR__ . '/../assets/img/cantilan_logo.png');
$osca_src     = imageToBase64(__DIR__ . '/../assets/img/osca_logo.png');

$logo_left  = $cantilan_src ? '<img src="' . $cantilan_src . '" style="width:0.85in; height:0.85in;" alt="Cantilan">' : '';
$logo_right = $osca_src     ? '<img src="' . $osca_src . '" style="width:0.85in; height:0.85in;" alt="OSCA">' : '';

function e($t) { return htmlspecialchars($t ?? '', ENT_QUOTES, 'UTF-8'); }

$full_name = trim(($household['head_first_name'] ?? '') . ' ' . ($household['head_middle_name'] ?? '') . ' ' . ($household['head_last_name'] ?? ''));
$relation  = e($household['relation_to_head'] ?? 'Self');
$tot_mem   = count($members); // Actual member count (matches form)
$address   = e($household['address'] ?? 'Not specified');
$barangay  = e($household['barangay'] ?? 'Not specified');
$city      = e($household['city_municipality'] ?? 'Cantilan');
$province  = e($household['province'] ?? 'Surigao del Sur');
$zip_code  = e($household['zip_code'] ?? '');
$contact   = e($household['contact_number'] ?? '');
$income    = 'PHP ' . number_format($household['monthly_income'] ?? 0, 2);
$four_ps   = ($household['is_4ps_beneficiary'] ?? 0) == 1 ? 'Yes' : 'No';

$member_rows = '';
if (count($members) > 0) {
    foreach ($members as $i => $m) {
        $nm = e(trim(($m['first_name'] ?? '') . ' ' . ($m['last_name'] ?? '')));
        $member_rows .= "<tr>"
            . "<td style='text-align:center;'>" . ($i + 1) . "</td>"
            . "<td>" . $nm . "</td>"
            . "<td>" . e($m['relationship'] ?? 'N/A') . "</td>"
            . "<td style='text-align:center;'>" . e($m['age'] ?? 'N/A') . "</td>"
            . "<td>" . e($m['gender'] ?? 'N/A') . "</td>"
            . "<td>" . e($m['occupation'] ?? 'N/A') . "</td>"
            . "</tr>";
    }
} else {
    $member_rows = "<tr><td colspan='6' style='text-align:center; font-style:italic; color:#000; padding:10px;'>No household members recorded.</td></tr>";
}

// Optional rows
$contact_row = $contact ? "<tr><td class='label'>Contact Number</td><td class='value'>{$contact}</td></tr>" : "";
$zip_row     = $zip_code ? "<tr><td class='label'>ZIP Code</td><td class='value'>{$zip_code}</td></tr>" : "";

$html = <<<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
    @page { size: A4; margin: 1in 1in 1in 1in; }
    
    * { font-family: Arial, Helvetica, sans-serif; font-size: 12pt; color: #000; }
    body { font-family: Arial, Helvetica, sans-serif; font-size: 12pt; color: #000; line-height: 1.4; }
    
    .pdf-header {
        position: fixed; top: -0.75in; left: 0; right: 0;
        width: 100%; height: 0.85in;
        border-bottom: 3px double #000;
        padding-bottom: 4px;
    }
    .pdf-header table { width: 100%; border-collapse: collapse; table-layout: fixed; }
    .pdf-header td { vertical-align: middle; border: none; padding: 0; }
    .pdf-header .logo-cell { width: 1in; text-align: center; }
    .pdf-header .logo-cell img { width: 0.85in; height: 0.85in; }
    .pdf-header .center-cell { text-align: center; line-height: 1.25; }
    .pdf-header .line1 { font-family: Arial; font-size: 12pt; font-weight: normal; color: #000; }
    .pdf-header .line2 { font-family: Arial; font-size: 12pt; font-weight: bold; color: #000; }
    .pdf-header .line3 { font-family: Arial; font-size: 12pt; font-weight: bold; color: #000; }
    .pdf-header .office-title { font-family: Arial; font-size: 12pt; font-style: italic; font-weight: bold; margin-top: 2px; color: #000; }
    
    .pdf-footer {
        position: fixed; bottom: -0.75in; left: 0; right: 0;
        width: 100%; height: 0.7in;
        border-top: 2px solid #000;
        padding-top: 6px;
    }
    .pdf-footer table { width: 100%; border-collapse: collapse; }
    .pdf-footer td { border: none; padding: 0; font-family: Arial; font-size: 12pt; color: #000; vertical-align: middle; }
    .pdf-footer .footer-left { text-align: left; }
    .pdf-footer .footer-right { text-align: right; }
    .pdf-footer .stamp { text-align: center; font-family: Arial; font-size: 9pt; color: #000; font-style: italic; margin-top: 4px; }
    
    .content { margin-top: 0.2in; font-family: Arial; font-size: 12pt; color: #000; }
    
    .doc-title-block { text-align: center; margin: 12px 0 20px 0; }
    .doc-title { font-family: Arial; font-size: 14pt; font-weight: bold; text-transform: uppercase; letter-spacing: 2px; text-decoration: underline; margin-bottom: 8px; color: #000; }
    .doc-meta { font-family: Arial; font-size: 12pt; color: #000; text-align: center; }
    .doc-meta span { display: inline-block; margin: 0 15px; }
    
    /* Plain section titles - no background, no border, no blue */
    .section { margin-bottom: 14px; font-family: Arial; color: #000; }
    .section-title {
        font-family: Arial;
        font-size: 12pt;
        font-weight: bold;
        color: #000;
        background: transparent;
        border: none;
        padding: 0 0 4px 0;
        margin-bottom: 6px;
        text-transform: uppercase;
    }
    
    .info-table { width: 100%; border-collapse: collapse; font-family: Arial; color: #000; }
    .info-table td {
        font-family: Arial;
        font-size: 12pt;
        padding: 5px 4px;
        vertical-align: top;
        border-bottom: 1px solid #000;
        color: #000;
    }
    .info-table td.label { width: 32%; font-weight: normal; color: #000; }
    .info-table td.value { color: #000; }
    .info-table tr:last-child td { border-bottom: 1px solid #000; }
    
    .members-table { width: 100%; border-collapse: collapse; font-family: Arial; font-size: 12pt; color: #000; }
    .members-table th {
        font-family: Arial;
        font-size: 12pt;
        background: transparent;
        color: #000;
        padding: 6px 8px;
        text-align: left;
        font-weight: bold;
        border: 1px solid #000;
        text-transform: uppercase;
    }
    .members-table td {
        font-family: Arial;
        font-size: 12pt;
        padding: 5px 8px;
        border: 1px solid #000;
        color: #000;
        background: transparent;
    }
    
    .signature-block { margin-top: 40px; width: 100%; font-family: Arial; color: #000; }
    .signature-block table { width: 100%; border-collapse: collapse; }
    .signature-block td { width: 50%; text-align: center; border: none; padding: 0 20px; vertical-align: bottom; font-family: Arial; color: #000; }
    .sig-line { border-top: 1px solid #000; padding-top: 4px; font-family: Arial; font-size: 12pt; font-weight: bold; text-transform: uppercase; margin-top: 40px; color: #000; }
    .sig-role { font-family: Arial; font-size: 12pt; font-style: italic; color: #000; margin-top: 2px; }
    
    .section, .signature-block, .doc-title-block { page-break-inside: avoid; }
    .members-table tr { page-break-inside: avoid; }
</style>
</head>
<body>

<div class="pdf-header">
    <table>
        <tr>
            <td class="logo-cell">{$logo_left}</td>
            <td class="center-cell">
                <div class="line1">Republic of the Philippines</div>
                <div class="line2">PROVINCE OF SURIGAO DEL SUR</div>
                <div class="line3">MUNICIPALITY OF CANTILAN</div>
                <div class="office-title">OFFICE OF THE SENIOR CITIZENS AFFAIRS</div>
            </td>
            <td class="logo-cell">{$logo_right}</td>
        </tr>
    </table>
</div>

<div class="pdf-footer">
    <table>
        <tr>
            <td class="footer-left">Office for the Senior Citizens Affairs &ndash; LGU Cantilan</td>
            <td class="footer-right">oscacantilan@gmail.com</td>
        </tr>
    </table>
    <div class="stamp">
        This document is system-generated by MSWDO Portal. Unauthorized reproduction is prohibited. | Generated on {$date_generated}
    </div>
</div>

<div class="content">

    <div class="doc-title-block">
        <div class="doc-title">Household Data Record</div>
        <div class="doc-meta">
            <span><strong>Document No:</strong> {$doc_number}</span>
            <span><strong>Date Generated:</strong> {$date_generated}</span>
        </div>
    </div>

    <div class="section">
        <div class="section-title">I. HOUSEHOLD HEAD INFORMATION</div>
        <table class="info-table">
            <tr><td class="label">Full Name</td><td class="value">{$full_name}</td></tr>
            <tr><td class="label">Relation to Head</td><td class="value">{$relation}</td></tr>
            {$contact_row}
            <tr><td class="label">Total Members</td><td class="value">{$tot_mem}</td></tr>
        </table>
    </div>

    <div class="section">
        <div class="section-title">II. ADDRESS INFORMATION</div>
        <table class="info-table">
            <tr><td class="label">Street / House No.</td><td class="value">{$address}</td></tr>
            <tr><td class="label">Barangay</td><td class="value">{$barangay}</td></tr>
            <tr><td class="label">City / Municipality</td><td class="value">{$city}</td></tr>
            <tr><td class="label">Province</td><td class="value">{$province}</td></tr>
            {$zip_row}
        </table>
    </div>

    <div class="section">
        <div class="section-title">III. ECONOMIC INFORMATION</div>
        <table class="info-table">
            <tr><td class="label">Monthly Household Income</td><td class="value">{$income}</td></tr>
            <tr><td class="label">Poverty Classification</td><td class="value">{$poverty_status}</td></tr>
            <tr><td class="label">4Ps Beneficiary</td><td class="value">{$four_ps}</td></tr>
        </table>
    </div>

    <div class="section">
        <div class="section-title">IV. HOUSEHOLD MEMBERS</div>
        <table class="members-table">
            <thead>
                <tr>
                    <th style="width:7%; text-align:center;">#</th>
                    <th style="width:28%;">FULL NAME</th>
                    <th style="width:18%;">RELATIONSHIP</th>
                    <th style="width:8%; text-align:center;">AGE</th>
                    <th style="width:14%;">GENDER</th>
                    <th style="width:25%;">OCCUPATION</th>
                </tr>
            </thead>
            <tbody>
                {$member_rows}
            </tbody>
        </table>
    </div>

    <div class="signature-block">
        <table>
            <tr>
                <td>
                    <div class="sig-line">PREPARED BY:</div>
                    <div class="sig-role">MSWDO Staff / Encoder</div>
                </td>
                <td>
                    <div class="sig-line">CERTIFIED CORRECT:</div>
                    <div class="sig-role">MSWDO Officer / OSCA Head</div>
                </td>
            </tr>
        </table>
    </div>

</div>

</body>
</html>
HTML;

try {
    $options = new Options();
    $options->set('isRemoteEnabled', true);
    $options->set('isHtml5ParserEnabled', true);
    $options->set('chroot', realpath(__DIR__ . '/..'));
    $options->set('defaultFont', 'Arial');
    $options->set('dpi', 120);

    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    $filename = 'Household_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $household['head_last_name']) . '_' . $household_id . '.pdf';
    $dompdf->stream($filename, ['Attachment' => true]);
    exit();

} catch (Exception $e) {
    die("PDF Generation Error: " . $e->getMessage());
}