<?php
// ============================================================================
// HOUSEHOLD DOCX GENERATOR v8 — Footer with NO table, plain paragraphs only
// File: modules/household_docx.php
// ============================================================================
session_start();
require_once '../config/database.php';
require_once '../vendor/autoload.php';

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\SimpleType\Jc;
use PhpOffice\PhpWord\Style\Font;
use PhpOffice\PhpWord\Style\Image;
use PhpOffice\PhpWord\Style\Tab;
use PhpOffice\PhpWord\IOFactory;

if(!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }
$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) { header("Location: ../index.php"); exit(); }

$household_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $pdo->prepare("SELECT * FROM households WHERE id = ?");
$stmt->execute([$household_id]);
$household = $stmt->fetch();
if(!$household) die("Household not found.");

$stmt = $pdo->prepare("SELECT * FROM household_members WHERE household_id = ? ORDER BY id");
$stmt->execute([$household_id]);
$members = $stmt->fetchAll();

function classifyPovertyIncome($income) {
    if($income < 5000) return 'Extremely Poor';
    elseif($income >= 5000 && $income <= 10000) return 'Poor';
    elseif($income >= 10001 && $income <= 15000) return 'Low Income';
    elseif($income >= 15001 && $income <= 25000) return 'Lower Middle';
    else return 'Middle Income and Above';
}

$poverty_status = $household['poverty_status'] ?? classifyPovertyIncome($household['monthly_income'] ?? 0);
$doc_number = 'OSCA-HH-' . date('Y') . '-' . str_pad($household_id, 5, '0', STR_PAD_LEFT);
$date_generated = date('F d, Y');

// ---------- Values ----------
$full_name = trim(($household['head_first_name'] ?? '') . ' ' . ($household['head_middle_name'] ?? '') . ' ' . ($household['head_last_name'] ?? ''));
$relation  = $household['relation_to_head'] ?? 'Self';
$tot_mem   = count($members);
$address   = $household['address'] ?? 'Not specified';
$barangay  = $household['barangay'] ?? 'Not specified';
$city      = $household['city_municipality'] ?? 'Cantilan';
$province  = $household['province'] ?? 'Surigao del Sur';
$zip_code  = $household['zip_code'] ?? '';
$contact   = $household['contact_number'] ?? '';
$income    = 'PHP ' . number_format($household['monthly_income'] ?? 0, 2);
$four_ps   = ($household['is_4ps_beneficiary'] ?? 0) == 1 ? 'Yes' : 'No';

// ---------- Logos ----------
$cantilan_path = __DIR__ . '/../assets/img/cantilan_logo.png';
$osca_path     = __DIR__ . '/../assets/img/osca_logo.png';

// ==================== BUILD DOCX ====================
$phpWord = new PhpWord();
$phpWord->setDefaultFontName('Arial');
$phpWord->setDefaultFontSize(12);

$section = $phpWord->addSection([
    'marginTop'    => 720,
    'marginBottom' => 1440,
    'marginLeft'   => 1080,
    'marginRight'  => 1080,
    'footerHeight' => 720,
]);

// ============================================================
// REAL WORD FOOTER — plain paragraphs + tab stops, NO TABLE
// ============================================================
$footer = $section->addFooter();

// Separator line above footer content
$footer->addText('', ['size' => 2], [
    'borderTopSize'  => 12,
    'borderTopColor' => '000000',
    'spaceBefore'    => 0,
    'spaceAfter'     => 80,
]);

// Footer line 1: office info (left) + email (right) using tab stop
$footer->addText(
    "Office for the Senior Citizens Affairs – LGU Cantilan\toscacantilan@gmail.com",
    ['size' => 12, 'name' => 'Arial', 'color' => '000000'],
    [
        'spaceAfter' => 0,
        'tabs' => [
            new Tab('right', 9000),
        ],
    ]
);

// ============================================================
// LETTERHEAD (in body)
// ============================================================

if(file_exists($cantilan_path)) {
    $section->addImage($cantilan_path, [
        'width'            => 70,
        'height'           => 70,
        'positioning'      => Image::POSITION_ABSOLUTE,
        'posHorizontal'    => Image::POSITION_HORIZONTAL_LEFT,
        'posHorizontalRel' => 'margin',
        'posVertical'      => Image::POSITION_VERTICAL_TOP,
        'posVerticalRel'   => 'margin',
        'marginLeft'       => 0,
        'marginTop'        => 0,
        'wrappingStyle'    => 'behind',
    ]);
}

if(file_exists($osca_path)) {
    $section->addImage($osca_path, [
        'width'            => 70,
        'height'           => 70,
        'positioning'      => Image::POSITION_ABSOLUTE,
        'posHorizontal'    => Image::POSITION_HORIZONTAL_RIGHT,
        'posHorizontalRel' => 'margin',
        'posVertical'      => Image::POSITION_VERTICAL_TOP,
        'posVerticalRel'   => 'margin',
        'marginRight'      => 0,
        'marginTop'        => 0,
        'wrappingStyle'    => 'behind',
    ]);
}

$section->addText('Republic of the Philippines',
    ['size' => 12, 'name' => 'Arial', 'color' => '000000'],
    ['alignment' => Jc::CENTER, 'spaceBefore' => 0, 'spaceAfter' => 0]
);
$section->addText('PROVINCE OF SURIGAO DEL SUR',
    ['size' => 12, 'name' => 'Arial', 'bold' => true, 'color' => '000000'],
    ['alignment' => Jc::CENTER, 'spaceAfter' => 0]
);
$section->addText('MUNICIPALITY OF CANTILAN',
    ['size' => 12, 'name' => 'Arial', 'bold' => true, 'color' => '000000'],
    ['alignment' => Jc::CENTER, 'spaceAfter' => 0]
);
$section->addText('OFFICE OF THE SENIOR CITIZENS AFFAIRS',
    ['size' => 12, 'name' => 'Arial', 'italic' => true, 'bold' => true, 'color' => '000000'],
    ['alignment' => Jc::CENTER, 'spaceAfter' => 200]
);

// Header separator line
$section->addText('', ['size' => 2], [
    'borderBottomSize'  => 12,
    'borderBottomColor' => '000000',
    'spaceBefore' => 0,
    'spaceAfter'  => 120,
]);

// ============================================================
// TITLE
// ============================================================
$section->addText('HOUSEHOLD DATA RECORD', [
    'size' => 14, 'bold' => true, 'name' => 'Arial', 'color' => '000000', 'underline' => Font::UNDERLINE_SINGLE,
], ['alignment' => Jc::CENTER, 'spaceAfter' => 100]);

$section->addText(
    'Document No: ' . $doc_number . '     |     Date Generated: ' . $date_generated,
    ['size' => 12, 'name' => 'Arial', 'color' => '000000'],
    ['alignment' => Jc::CENTER, 'spaceAfter' => 200]
);

// ============ HELPERS ============
function addSectionTitle($section, $text) {
    $section->addText($text, [
        'size' => 12, 'bold' => true, 'name' => 'Arial', 'color' => '000000',
    ], ['spaceBefore' => 180, 'spaceAfter' => 60]);
}

function addInfoLine($section, $label, $value) {
    $section->addText(
        $label . ':  ' . $value,
        ['size' => 12, 'name' => 'Arial', 'color' => '000000'],
        ['spaceAfter' => 40]
    );
}

// ==================== I. HOUSEHOLD HEAD ====================
addSectionTitle($section, 'I. HOUSEHOLD HEAD INFORMATION');
addInfoLine($section, 'Full Name', $full_name);
addInfoLine($section, 'Relation to Head', $relation);
if(!empty($contact)) {
    addInfoLine($section, 'Contact Number', $contact);
}
addInfoLine($section, 'Total Members', (string)$tot_mem);

// ==================== II. ADDRESS ====================
addSectionTitle($section, 'II. ADDRESS INFORMATION');
addInfoLine($section, 'Street / House No.', $address);
addInfoLine($section, 'Barangay', $barangay);
addInfoLine($section, 'City / Municipality', $city);
addInfoLine($section, 'Province', $province);
if(!empty($zip_code)) {
    addInfoLine($section, 'ZIP Code', $zip_code);
}

// ==================== III. ECONOMIC ====================
addSectionTitle($section, 'III. ECONOMIC INFORMATION');
addInfoLine($section, 'Monthly Household Income', $income);
addInfoLine($section, 'Poverty Classification', $poverty_status);
addInfoLine($section, '4Ps Beneficiary', $four_ps);

// ==================== IV. MEMBERS ====================
addSectionTitle($section, 'IV. HOUSEHOLD MEMBERS');

$memberTable = $section->addTable([
    'borderSize'  => 6,
    'borderColor' => '000000',
    'cellMargin'  => 60,
    'width'       => 100 * 50,
    'unit'        => 'pct',
]);

$memberTable->addRow();
$headers = ['#', 'FULL NAME', 'RELATIONSHIP', 'AGE', 'GENDER', 'OCCUPATION'];
foreach ($headers as $h) {
    $cell = $memberTable->addCell(1500);
    $cell->addText($h, ['size' => 12, 'bold' => true, 'name' => 'Arial', 'color' => '000000']);
}

if(count($members) > 0) {
    foreach($members as $i => $m) {
        $memberTable->addRow();
        $memberTable->addCell(500)->addText((string)($i + 1), ['size' => 12, 'name' => 'Arial', 'color' => '000000'], ['alignment' => Jc::CENTER]);
        $memberTable->addCell(2500)->addText(trim(($m['first_name'] ?? '') . ' ' . ($m['last_name'] ?? '')), ['size' => 12, 'name' => 'Arial', 'color' => '000000']);
        $memberTable->addCell(1800)->addText($m['relationship'] ?? 'N/A', ['size' => 12, 'name' => 'Arial', 'color' => '000000']);
        $memberTable->addCell(800)->addText((string)($m['age'] ?? 'N/A'), ['size' => 12, 'name' => 'Arial', 'color' => '000000'], ['alignment' => Jc::CENTER]);
        $memberTable->addCell(1200)->addText($m['gender'] ?? 'N/A', ['size' => 12, 'name' => 'Arial', 'color' => '000000']);
        $memberTable->addCell(2200)->addText($m['occupation'] ?? 'N/A', ['size' => 12, 'name' => 'Arial', 'color' => '000000']);
    }
} else {
    $memberTable->addRow();
    $cell = $memberTable->addCell(9000, ['gridSpan' => 6]);
    $cell->addText('No household members recorded.', ['size' => 12, 'italic' => true, 'name' => 'Arial', 'color' => '000000'], ['alignment' => Jc::CENTER]);
}

// ==================== SIGNATURES — plain paragraphs, no table ====================
$section->addTextBreak(4);

$section->addText(
    "PREPARED BY:\tCERTIFIED CORRECT:",
    ['size' => 12, 'bold' => true, 'name' => 'Arial', 'color' => '000000'],
    [
        'spaceAfter' => 0,
        'tabs' => [ new Tab('left', 4500) ],
    ]
);
$section->addText(
    "_____________________________\t_____________________________",
    ['size' => 12, 'name' => 'Arial', 'color' => '000000'],
    [
        'spaceAfter' => 0,
        'tabs' => [ new Tab('left', 4500) ],
    ]
);
$section->addText(
    "MSWDO Staff / Encoder\tMSWDO Officer / OSCA Head",
    ['size' => 12, 'italic' => true, 'name' => 'Arial', 'color' => '000000'],
    [
        'spaceAfter' => 0,
        'tabs' => [ new Tab('left', 4500) ],
    ]
);

// ==================== OUTPUT ====================
$filename = 'Household_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $household['head_last_name']) . '_' . $household_id . '.docx';

if (ob_get_length()) ob_end_clean();

header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

$writer = IOFactory::createWriter($phpWord, 'Word2007');
$writer->save('php://output');
exit();