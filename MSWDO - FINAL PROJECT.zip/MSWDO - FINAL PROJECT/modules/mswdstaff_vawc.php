<?php
session_start();
require_once '../config/database.php';

// Staff only access
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder', 'admin'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];

// ============ VAWC SECURITY ENFORCEMENT ============
$is_vawc_officer = false;
$vawc_clearance_level = 'NONE';

if($role === 'admin' || $role === 'vawc_officer') {
    $is_vawc_officer = true;
    $vawc_clearance_level = 'FULL';
} elseif($role === 'social_worker' || $role === 'staff') {
    $is_vawc_officer = true;
    $vawc_clearance_level = 'READ_ONLY';
}

// Security Audit Log
function logVawcAccess($pdo, $user_id, $action, $case_id = null, $status = 'SUCCESS') {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
        
        $stmt = $pdo->prepare("
            INSERT INTO vawc_audit_logs 
            (staff_id, action_performed, target_case_id, ip_address, user_agent, status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        return $stmt->execute([$user_id, $action, $case_id, $ip, $user_agent, $status]);
    } catch(PDOException $e) {
        error_log("VAWC Audit Log Error: " . $e->getMessage());
        return false;
    }
}

// If not authorized, log and show access denied
if(!$is_vawc_officer) {
    logVawcAccess($pdo, $user_id, 'ACCESS_DENIED_ATTEMPT', null, 'DENIED');
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Access Denied</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <style>
            body { font-family: 'Inter', sans-serif; background: #F8FAFC; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .denied-box { background: white; padding: 40px; border-radius: 16px; text-align: center; max-width: 500px; border: 1px solid #FEE2E2; }
            .denied-box i { font-size: 4rem; color: #D32F2F; margin-bottom: 20px; }
            .denied-box h1 { color: #991B1B; margin-bottom: 10px; }
            .denied-box p { color: #64748B; }
        </style>
    </head>
    <body>
        <div class="denied-box">
            <i class="fas fa-shield-alt"></i>
            <h1>ACCESS DENIED</h1>
            <p><strong>CRITICAL SECURITY WARNING:</strong> You do not have the required legal clearance to view VAWC files.</p>
            <p style="margin-top: 12px; font-size: 0.9rem;">This access attempt has been logged for security audit purposes.</p>
            <p style="margin-top: 16px;"><a href="../dashboards/mswdstaff_dashboard.php" style="color: #1E4A8C;">Return to Dashboard</a></p>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// ============ HANDLE STATUS UPDATE ============
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $application_id = $_POST['application_id'];
    $status = $_POST['status'];
    $notes = $_POST['notes'] ?? '';
    
    logVawcAccess($pdo, $user_id, 'STATUS_UPDATE_' . strtoupper($status), $application_id, 'ATTEMPT');
    
    $stmt = $pdo->prepare("UPDATE welfare_applications SET status = ?, review_notes = ?, reviewed_by = ?, reviewed_at = NOW(), updated_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $notes, $user_id, $application_id]);
    
    logVawcAccess($pdo, $user_id, 'STATUS_UPDATE_' . strtoupper($status) . '_SUCCESS', $application_id, 'SUCCESS');
    $success_message = "Application has been " . ($status == 'approved' ? "approved" : ($status == 'rejected' ? "rejected" : "marked as reviewed"));
}

// ============ HANDLE MARK AS REVIEWED ============
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mark_reviewed'])) {
    $application_id = $_POST['application_id'];
    $reviewed_note = $_POST['reviewed_note'] ?? '';
    
    logVawcAccess($pdo, $user_id, 'MARK_AS_REVIEWED', $application_id, 'ATTEMPT');
    
    $stmt = $pdo->prepare("UPDATE welfare_applications SET review_notes = CONCAT(IFNULL(review_notes, ''), ?, '\n'), reviewed_by = ?, reviewed_at = NOW(), updated_at = NOW() WHERE id = ?");
    $note_prefix = '[' . date('Y-m-d H:i') . ' - Marked Reviewed by ' . $full_name . '] ';
    $stmt->execute([$note_prefix . $reviewed_note, $user_id, $application_id]);
    
    logVawcAccess($pdo, $user_id, 'MARK_AS_REVIEWED_SUCCESS', $application_id, 'SUCCESS');
    $success_message = "Case marked as reviewed. Status remains unchanged for final decision.";
}

// Get all VAWC applications - READ ONLY (red alerts sorted first)
$stmt = $pdo->prepare("
    SELECT wa.*, u.full_name, u.username, u.email, u.contact_number 
    FROM welfare_applications wa 
    JOIN users u ON wa.user_id = u.id 
    WHERE wa.program_type = 'vawc'
    ORDER BY 
        CASE WHEN JSON_EXTRACT(wa.application_data, '$.red_alert') = 1 THEN 0 ELSE 1 END,
        wa.created_at DESC
");
$stmt->execute();
$applications = $stmt->fetchAll();

// Pre-load reviewer names
$reviewer_ids = array_filter(array_unique(array_column($applications, 'reviewed_by')));
$reviewers = [];
if (!empty($reviewer_ids)) {
    $placeholders = implode(',', array_fill(0, count($reviewer_ids), '?'));
    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE id IN ($placeholders)");
    $stmt->execute(array_values($reviewer_ids));
    foreach ($stmt->fetchAll() as $r) {
        $reviewers[$r['id']] = $r['full_name'];
    }
}

// Log view
logVawcAccess($pdo, $user_id, 'VIEW_VAWC_APPLICATIONS_LIST', null, 'SUCCESS');

$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

// Count red alerts
$red_alert_count = 0;
$reviewed_pending_count = 0;
foreach($applications as $app) {
    $d = json_decode($app['application_data'], true);
    if(!empty($d['red_alert']) && $app['status'] == 'pending') {
        $red_alert_count++;
    }
    if($app['status'] == 'pending' && !empty($app['review_notes'])) {
        $reviewed_pending_count++;
    }
}

$deleted_count = 0;
if($role === 'admin') {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
        $deleted_count = $stmt->fetch()['total'];
    } catch(PDOException $e) {
        $deleted_count = 0;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>VAWC Applications - MSWD Staff (Confidential)</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .logo { display: flex; align-items: center; gap: 12px; }
        /* ============================================================
           UPDATED: MSWDO Logo Image replaces Font Awesome icon
           ============================================================ */
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 2px;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .submenu-item.active i { color: var(--accent); }
        
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 {
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .confidential-badge {
            background: #C2185B;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            letter-spacing: 0.04em;
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px;
            height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        
        /* VAWC Security Banner */
        .vawc-security-banner {
            background: linear-gradient(135deg, #1E1E1E, #2D2D2D);
            color: #FFD700;
            padding: 14px 22px;
            border-radius: var(--radius-xl);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            border-left: 4px solid #D32F2F;
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }
        .vawc-security-banner .security-icon { font-size: 1.2rem; color: #FFD700; }
        .vawc-security-banner .security-text { font-size: 0.8rem; font-weight: 600; }
        .vawc-security-banner .clearance-badge {
            background: #D32F2F;
            color: white;
            padding: 5px 16px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            letter-spacing: 0.05em;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        /* Red Alert Banner */
        .red-alert-banner {
            background: linear-gradient(135deg, #7F1D1D, #991B1B);
            color: white;
            padding: 18px 22px;
            border-radius: var(--radius-xl);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 14px;
            animation: pulse-alert 2s infinite;
            border-left: 5px solid #FCD34D;
            box-shadow: 0 12px 24px -8px rgba(127, 29, 29, 0.4);
        }
        @keyframes pulse-alert {
            0%, 100% { box-shadow: 0 0 0 0 rgba(211, 47, 47, 0.4); }
            50% { box-shadow: 0 0 0 8px rgba(211, 47, 47, 0); }
        }
        .red-alert-banner .alert-icon { font-size: 1.9rem; color: #FCD34D; }
        .red-alert-banner .alert-text h3 { font-size: 1rem; font-weight: 700; margin-bottom: 2px; }
        .red-alert-banner .alert-text p { font-size: 0.78rem; opacity: 0.9; }
        
        .program-header {
            background: linear-gradient(135deg, #FCE4EC, #F8BBD0);
            padding: 28px;
            border-radius: var(--radius-xl);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 18px;
            box-shadow: 0 12px 24px -8px rgba(194, 24, 91, 0.2);
            border: 1px solid rgba(194, 24, 91, 0.3);
        }
        .program-icon {
            width: 64px;
            height: 64px;
            background: #C2185B;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 20px rgba(194, 24, 91, 0.3);
            flex-shrink: 0;
        }
        .program-icon i { font-size: 1.8rem; color: white; }
        .program-title h2 { font-size: 1.5rem; color: #880E4F; font-weight: 800; letter-spacing: -0.02em; }
        .program-title p { color: #AD1457; font-size: 0.82rem; margin-top: 4px; }
        
        .stats-row {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-box {
            background: white;
            padding: 20px;
            border-radius: var(--radius-xl);
            text-align: center;
            border: 1px solid var(--gray-200);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .stat-box::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), #3B82F6);
        }
        .stat-box:nth-child(1)::before { background: linear-gradient(90deg, #F5B042, #FCD34D); }
        .stat-box:nth-child(2)::before { background: linear-gradient(90deg, #6366F1, #818CF8); }
        .stat-box:nth-child(3)::before { background: linear-gradient(90deg, #059669, #34D399); }
        .stat-box:nth-child(4)::before { background: linear-gradient(90deg, #DC2626, #F87171); }
        .stat-box:nth-child(5)::before { background: linear-gradient(90deg, #7F1D1D, #991B1B); }
        .stat-box:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); border-color: transparent; }
        .stat-box.red-alert { border: 2px solid #D32F2F; background: linear-gradient(135deg, #FEF2F2, #FEE2E2); }
        .stat-box.reviewed { border: 2px solid #6366F1; background: linear-gradient(135deg, #EEF2FF, #E0E7FF); }
        .stat-number { font-size: 2rem; font-weight: 800; color: var(--gray-800); letter-spacing: -0.03em; }
        .stat-box:nth-child(1) .stat-number { color: #B45309; }
        .stat-box:nth-child(2) .stat-number { color: #4338CA; }
        .stat-box:nth-child(3) .stat-number { color: #059669; }
        .stat-box:nth-child(4) .stat-number { color: #DC2626; }
        .stat-box.red-alert .stat-number { color: #991B1B; }
        .stat-label { font-size: 0.68rem; color: var(--gray-500); font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 6px; }
        
        .filter-bar {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            background: white;
            padding: 6px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .filter-btn {
            padding: 9px 20px;
            border-radius: var(--radius-md);
            background: transparent;
            border: none;
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--gray-600);
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .filter-btn:hover { background: var(--gray-100); color: var(--primary); }
        .filter-btn.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        
        .success-alert {
            background: #D1FAE5;
            color: #065F46;
            padding: 14px 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.85rem;
            font-weight: 500;
            border-left: 4px solid #059669;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
            box-shadow: var(--shadow-sm);
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 1050px;
        }
        .table th {
            text-align: left;
            padding: 14px 16px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            color: var(--gray-600);
            border-bottom: 2px solid var(--accent);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 0.68rem;
        }
        .table td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .table tr.row-red-alert { background: #FEF2F2; border-left: 4px solid #D32F2F; }
        .table tr.row-red-alert:hover td { background: #FEE2E2; }
        .table tr.row-reviewed { background: #EEF2FF; }
        .table tr.row-reviewed:hover td { background: #E0E7FF; }
        .table tr:hover td { background: var(--gray-50); }
        
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .status-pending { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .status-approved { background: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7; }
        .status-rejected { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        
        .red-alert-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: #D32F2F;
            color: white;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.62rem;
            font-weight: 700;
            animation: blink-badge 1.5s infinite;
            margin-top: 4px;
        }
        @keyframes blink-badge {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
        }
        
        .reviewed-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: #6366F1;
            color: white;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.62rem;
            font-weight: 700;
            margin-top: 4px;
        }
        
        .risk-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .risk-low { background: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7; }
        .risk-moderate { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .risk-high { background: #FED7AA; color: #9A3412; border: 1px solid #FB923C; }
        .risk-immediate { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; font-weight: 800; }
        
        .action-group {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
        }
        
        .btn-approve {
            background: #059669;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-approve:hover { background: #047857; transform: translateY(-1px); }
        .btn-reject {
            background: #D32F2F;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-reject:hover { background: #B71C1C; transform: translateY(-1px); }
        .btn-view {
            background: var(--primary);
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-view:hover { background: var(--primary-dark); transform: translateY(-1px); }
        .btn-review {
            background: #6366F1;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-review:hover { background: #4F46E5; transform: translateY(-1px); }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            z-index: 1100;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 820px;
            width: 100%;
            padding: 24px;
            max-height: 88vh;
            overflow-y: auto;
            box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.2);
        }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 6px; color: var(--gray-700); text-transform: uppercase; letter-spacing: 0.04em; }
        .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: inherit;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        .form-group select:focus, .form-group textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
        }
        .btn-submit {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border: none;
            padding: 12px 22px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 700;
            font-size: 0.85rem;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-submit.review-btn { background: linear-gradient(135deg, #6366F1, #4F46E5); }
        .btn-submit.review-btn:hover { box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4); }
        .btn-cancel {
            background: var(--gray-200);
            color: var(--gray-700);
            border: none;
            padding: 12px 22px;
            border-radius: var(--radius-md);
            cursor: pointer;
            margin-left: 10px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        .btn-cancel:hover { background: var(--gray-300); }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        .empty-state i { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; display: block; }
        
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-decoration: none;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        
        /* Detail sections inside the modal */
        .detail-section {
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--gray-200);
        }
        .detail-section:last-child { border-bottom: none; margin-bottom: 0; }
        .detail-section h4 {
            font-size: 0.85rem;
            color: #C2185B;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 8px;
            border-bottom: 1px dashed var(--gray-200);
            font-weight: 700;
        }
        .detail-section h4 i { color: #C2185B; }
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
        }
        .detail-item { padding: 6px 0; }
        .detail-label {
            font-weight: 700;
            color: var(--gray-500);
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .detail-label .lock-icon { color: #C2185B; font-size: 0.6rem; }
        .detail-value {
            font-size: 0.8rem;
            margin-top: 2px;
            color: var(--gray-800);
            word-break: break-word;
        }
        .detail-value.sensitive {
            background: #FEF2F2;
            color: #991B1B;
            padding: 6px 10px;
            border-radius: 6px;
            border-left: 3px solid #D32F2F;
            font-size: 0.78rem;
        }
        .doc-link {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
            text-decoration: none;
            margin: 2px 4px 2px 0;
            transition: all 0.2s;
        }
        .doc-link:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(30, 74, 140, 0.3); }
        .id-photo, .signature-photo {
            max-width: 200px;
            max-height: 160px;
            border-radius: 8px;
            border: 2px solid var(--gray-200);
            margin-top: 6px;
            object-fit: cover;
        }
        .case-summary {
            background: linear-gradient(135deg, #FCE4EC, #F8BBD0);
            padding: 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            border: 1px solid #F8BBD0;
            border-left: 4px solid #C2185B;
        }
        .case-summary.red-alert-summary {
            background: linear-gradient(135deg, #7F1D1D, #991B1B);
            color: white;
            border: 2px solid #FCD34D;
        }
        .case-summary.red-alert-summary .case-no,
        .case-summary.red-alert-summary .ref-code,
        .case-summary.red-alert-summary .submitted-at { color: white; }
        .case-summary .case-no {
            font-size: 1.2rem;
            font-weight: 800;
            color: #880E4F;
            font-family: monospace;
            margin-bottom: 4px;
            letter-spacing: 0.02em;
        }
        .case-summary .ref-code {
            font-size: 0.8rem;
            color: var(--gray-600);
            font-family: monospace;
        }
        .case-summary .submitted-at {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin-top: 8px;
        }
        .case-summary .red-alert-header {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #FCD34D;
            color: #7F1D1D;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .badge-list {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 4px;
        }
        .badge-item {
            display: inline-block;
            background: var(--gray-100);
            color: var(--gray-700);
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .badge-item.abuse {
            background: #FCE4EC;
            color: #880E4F;
            font-weight: 700;
        }
        .badge-item.referral {
            background: #DBEAFE;
            color: #1E40AF;
            font-weight: 700;
        }
        .safety-box {
            background: #FEF2F2;
            border: 1px solid #FCA5A5;
            border-radius: 8px;
            padding: 12px;
            margin-top: 10px;
        }
        .safety-box h5 {
            font-size: 0.7rem;
            color: #991B1B;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
            font-weight: 700;
        }
        .safety-box .safety-items {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }
        .safety-box .safety-item {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: white;
            border: 1px solid #FCA5A5;
            color: #991B1B;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 700;
        }
        .review-history-box {
            background: #EEF2FF;
            border: 1px solid #C7D2FE;
            border-radius: 8px;
            padding: 12px;
            margin-top: 12px;
            white-space: pre-wrap;
            font-size: 0.75rem;
            color: #3730A3;
            font-family: monospace;
        }
        @media (max-width: 480px) { .detail-grid { grid-template-columns: 1fr; } }
        
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .top-bar { flex-wrap: wrap; gap: 12px; }
            .page-title h1 { font-size: 1.1rem; }
            .vawc-security-banner { flex-direction: column; text-align: center; }
        }
        @media (max-width: 480px) { .stats-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

   <!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <!-- ============================================================
                 UPDATED: MSWDO Logo Image replaces Font Awesome icon
                 ============================================================ -->
            <div class="logo-icon">
                <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
            </div>
            <div class="logo-text">
                <h1>MSWDO Cantilan</h1>
                <p>Staff Portal</p>
            </div>
        </div>
    </div>
    <nav class="nav-menu">
        <div class="nav-section">
            <div class="nav-label">Main</div>
            <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i> <span>Dashboard</span>
            </a>
            <a href="mswdstaff_communityservice.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
            </a>
            <a href="household.php" class="nav-item">
                <i class="fas fa-users"></i> <span>Household Records</span>
            </a>
        </div>
        <div class="nav-section">
            <div class="nav-label">Applications</div>
            <div class="nav-item collapsible" id="programToggle">
                <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                <i class="fas fa-chevron-right chevron" id="programIcon"></i>
            </div>
            <div class="submenu" id="programSubmenu">
                <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                <a href="mswdstaff_vawc.php" class="submenu-item active"><i class="fas fa-shield-alt"></i> VAWC</a>
            </div>
            <a href="mswdstaff_idapplication.php" class="nav-item">
                <i class="fas fa-id-card"></i> <span>ID Applications</span>
            </a>
            <a href="staff_eligibility_engine.php" class="nav-item">
                <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
            </a>
            <a href="reports.php" class="nav-item">
                <i class="fas fa-chart-bar"></i> <span>Reports</span>
            </a>
        </div>
        <div class="nav-section">
            <div class="nav-label">Account</div>
            <a href="mswdstaff_profile.php" class="nav-item">
                <i class="fas fa-user-circle"></i> <span>Profile</span>
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </div>
    </nav>
</aside>

    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>VAWC Program Applications <span class="confidential-badge"><i class="fas fa-lock"></i> CONFIDENTIAL</span></h1>
                <p>View and manage VAWC (Violence Against Women and Children) applications - Strictly Confidential</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- VAWC Security Banner -->
        <div class="vawc-security-banner">
            <div style="display: flex; align-items: center; gap: 12px;">
                <span class="security-icon"><i class="fas fa-shield-alt"></i></span>
                <span class="security-text">
                    <i class="fas fa-lock" style="margin-right: 6px;"></i> 
                    SECURE ACCESS: This data is protected by RA 9262 confidentiality laws
                </span>
            </div>
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 0.7rem; color: #999;">
                    <i class="fas fa-user-check"></i> Clearance: <?php echo $vawc_clearance_level; ?>
                </span>
                <span class="clearance-badge">
                    <i class="fas fa-check-circle"></i> VAWC OFFICER
                </span>
            </div>
        </div>

        <!-- RED ALERT BANNER -->
        <?php if($red_alert_count > 0): ?>
        <div class="red-alert-banner">
            <div class="alert-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="alert-text">
                <h3>🚨 RED ALERT: <?php echo $red_alert_count; ?> Case<?php echo $red_alert_count > 1 ? 's' : ''; ?> Require Immediate Attention</h3>
                <p>These cases report life-threatening danger. Please prioritize for immediate intervention.</p>
            </div>
        </div>
        <?php endif; ?>

        <?php if(isset($success_message)): ?>
        <div class="success-alert"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div>
        <?php endif; ?>

        <div class="program-header">
            <div class="program-icon"><i class="fas fa-shield-alt"></i></div>
            <div class="program-title">
                <h2>VAWC Program</h2>
                <p>Republic Act No. 9262 - Anti-Violence Against Women and Their Children Act</p>
            </div>
        </div>

        <?php
        $pending_count = count(array_filter($applications, fn($a) => $a['status'] == 'pending'));
        $approved_count = count(array_filter($applications, fn($a) => $a['status'] == 'approved'));
        $rejected_count = count(array_filter($applications, fn($a) => $a['status'] == 'rejected'));
        ?>
        <div class="stats-row">
            <div class="stat-box"><div class="stat-number"><?php echo $pending_count; ?></div><div class="stat-label">Pending Review</div></div>
            <div class="stat-box reviewed"><div class="stat-number"><?php echo $reviewed_pending_count; ?></div><div class="stat-label">👁️ Awaiting Decision</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $approved_count; ?></div><div class="stat-label">Approved</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $rejected_count; ?></div><div class="stat-label">Rejected</div></div>
            <div class="stat-box red-alert"><div class="stat-number"><?php echo $red_alert_count; ?></div><div class="stat-label">🚨 Red Alerts</div></div>
        </div>

        <div class="filter-bar">
            <a href="?status=all" class="filter-btn <?php echo $status_filter == 'all' ? 'active' : ''; ?>">
                <i class="fas fa-list"></i> All
            </a>
            <a href="?status=pending" class="filter-btn <?php echo $status_filter == 'pending' ? 'active' : ''; ?>">
                <i class="fas fa-clock"></i> Pending
            </a>
            <a href="?status=approved" class="filter-btn <?php echo $status_filter == 'approved' ? 'active' : ''; ?>">
                <i class="fas fa-check-circle"></i> Approved
            </a>
            <a href="?status=rejected" class="filter-btn <?php echo $status_filter == 'rejected' ? 'active' : ''; ?>">
                <i class="fas fa-times-circle"></i> Rejected
            </a>
        </div>

        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Case No.</th>
                        <th>Applicant</th>
                        <th>Abuse Type</th>
                        <th>Risk Level</th>
                        <th>Date Applied</th>
                        <th>Status</th>
                        <th>Reviewed By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $filtered = array_filter($applications, fn($app) => $status_filter == 'all' || $app['status'] == $status_filter);
                    if(count($filtered) == 0): ?>
                    <tr>
                        <td colspan="9" class="empty-state">
                            <i class="fas fa-folder-open"></i>
                            <p>No VAWC applications found</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach($filtered as $app): 
                        $app_data = json_decode($app['application_data'], true);
                        $display_case_no = $app_data['case_no'] ?? 'N/A';
                        $red_alert = !empty($app_data['red_alert']) ? 1 : 0;
                        $risk_level = $app_data['risk_level'] ?? 'Moderate';
                        $risk_class = 'risk-moderate';
                        if(strtolower($risk_level) === 'low') $risk_class = 'risk-low';
                        elseif(strtolower($risk_level) === 'high') $risk_class = 'risk-high';
                        elseif(strtolower($risk_level) === 'immediate danger') $risk_class = 'risk-immediate';
                        
                        $abuse_types = $app_data['abuse_types'] ?? [];
                        if(!is_array($abuse_types)) $abuse_types = [];
                        
                        $is_reviewed = ($app['status'] == 'pending' && !empty($app['review_notes']));
                        
                        $row_class = '';
                        if($red_alert) $row_class = 'row-red-alert';
                        elseif($is_reviewed) $row_class = 'row-reviewed';
                    ?>
                    <tr class="<?php echo $row_class; ?>">
                        <td><strong>#<?php echo $app['id']; ?></strong></td>
                        <td><small style="font-family: monospace; color: #C2185B; font-weight: 700;"><?php echo htmlspecialchars($display_case_no); ?></small></td>
                        <td>
                            <strong><?php echo htmlspecialchars($app['full_name']); ?></strong>
                            <br><small style="color: var(--gray-400);"><?php echo htmlspecialchars($app['username']); ?></small>
                            <?php if($red_alert): ?>
                                <br><span class="red-alert-badge"><i class="fas fa-exclamation-triangle"></i> RED ALERT</span>
                            <?php endif; ?>
                            <?php if($is_reviewed && !$red_alert): ?>
                                <br><span class="reviewed-badge"><i class="fas fa-eye"></i> REVIEWED</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(count($abuse_types) > 0): ?>
                                <div class="badge-list">
                                    <?php foreach($abuse_types as $type): ?>
                                        <span class="badge-item abuse"><?php echo htmlspecialchars($type); ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <span style="color: #94A3B8;">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="risk-badge <?php echo $risk_class; ?>"><?php echo htmlspecialchars($risk_level); ?></span></td>
                        <td><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                        <td><span class="status-badge status-<?php echo $app['status']; ?>"><?php echo ucfirst($app['status']); ?></span></td>
                        <td><?php echo htmlspecialchars($reviewers[$app['reviewed_by']] ?? '-'); ?></td>
                        <td>
                            <div class="action-group">
                                <button class="btn-view" onclick='viewDetails(<?php echo $app['id']; ?>, <?php echo json_encode($app_data, JSON_HEX_APOS | JSON_HEX_QUOT); ?>, <?php echo json_encode($app["review_notes"] ?? "", JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <?php if($app['status'] == 'pending'): ?>
                                    <button class="btn-review" onclick="openReviewModal(<?php echo $app['id']; ?>)">
                                        <i class="fas fa-eye"></i> Mark Reviewed
                                    </button>
                                    <button class="btn-approve" onclick="openActionModal(<?php echo $app['id']; ?>, 'approve')">
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                    <button class="btn-reject" onclick="openActionModal(<?php echo $app['id']; ?>, 'reject')">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Security Audit Notice -->
        <div style="margin-top: 16px; padding: 14px 18px; background: #FEF3C7; border-radius: var(--radius-lg); border-left: 4px solid #D32F2F; font-size: 0.78rem; color: #78350F; display: flex; align-items: flex-start; gap: 10px;">
            <i class="fas fa-info-circle" style="color: #D32F2F; font-size: 1rem; margin-top: 2px;"></i>
            <div>
                <strong>Security Notice:</strong> All VAWC data access and modifications are logged for audit purposes. 
                Unauthorized access attempts are reported to system administrators.
            </div>
        </div>
    </main>

    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_idapplication.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Apps</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <!-- Modal for View Details -->
    <div id="viewModal" class="modal">
        <div class="modal-content">
            <h3 style="margin-bottom: 16px; color: #C2185B; font-weight: 800;">
                VAWC Application Details 
                <span class="confidential-badge"><i class="fas fa-lock"></i> Confidential</span>
            </h3>
            <div id="modalContent"></div>
            <div style="margin-top: 20px; text-align: right;">
                <button type="button" class="btn-cancel" onclick="closeModal('viewModal')">Close</button>
            </div>
        </div>
    </div>

    <!-- Modal for Approve/Reject Action -->
    <div id="actionModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <h3 id="actionTitle" style="margin-bottom: 16px; color: #C2185B; font-weight: 800;">Update Application Status</h3>
            <form method="POST">
                <input type="hidden" name="application_id" id="actionAppId">
                <input type="hidden" name="update_status" value="1">
                <input type="hidden" name="status" id="actionStatus">
                <div class="form-group">
                    <label>Review Notes</label>
                    <textarea name="notes" id="actionNotes" rows="3" placeholder="Add your review notes here..."></textarea>
                </div>
                <button type="submit" class="btn-submit" id="actionSubmitBtn">Confirm</button>
                <button type="button" class="btn-cancel" onclick="closeModal('actionModal')">Cancel</button>
            </form>
        </div>
    </div>

    <!-- Modal for Mark as Reviewed -->
    <div id="reviewModal" class="modal">
        <div class="modal-content" style="max-width: 600px;">
            <h3 style="margin-bottom: 16px; color: #4338CA; font-weight: 800;">
                <i class="fas fa-eye"></i> Mark Case as Reviewed
                <span class="confidential-badge" style="background: #6366F1; font-size: 0.6rem;"><i class="fas fa-lock"></i> Confidential</span>
            </h3>
            <div style="background: #EEF2FF; border-radius: 8px; padding: 14px 16px; margin-bottom: 16px; font-size: 0.8rem; color: #3730A3; display: flex; align-items: flex-start; gap: 10px;">
                <i class="fas fa-info-circle" style="font-size: 1rem; margin-top: 2px;"></i>
                <div>
                    <strong>Important:</strong> Marking a case as reviewed <u>does not change its status</u>. 
                    It only records that you have acknowledged reading the case file. The case will remain in 
                    <strong>Pending</strong> status until you Approve or Reject it.
                </div>
            </div>
            <form method="POST">
                <input type="hidden" name="application_id" id="reviewAppId">
                <input type="hidden" name="mark_reviewed" value="1">
                <div class="form-group">
                    <label>Optional Notes (why marking as reviewed?)</label>
                    <textarea name="reviewed_note" id="reviewedNote" rows="3" placeholder="e.g., Coordinated with PNP-WCPD, awaiting case file transfer..."></textarea>
                </div>
                <button type="submit" class="btn-submit review-btn" id="reviewSubmitBtn">
                    <i class="fas fa-eye"></i> Confirm - Mark as Reviewed
                </button>
                <button type="button" class="btn-cancel" onclick="closeModal('reviewModal')">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) {
            menuToggle.addEventListener('click', () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); });
        }
        if(overlay) {
            overlay.addEventListener('click', () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); });
        }

        // Collapsible Program Menu
        const programToggle = document.getElementById('programToggle');
        const programSubmenu = document.getElementById('programSubmenu');
        const programIcon = document.getElementById('programIcon');
        if(programToggle) {
            programSubmenu.classList.add('show');
            programIcon.classList.add('rotated');
            programToggle.addEventListener('click', () => { 
                programSubmenu.classList.toggle('show'); 
                programIcon.classList.toggle('rotated'); 
            });
        }

        // ============================================================
        // VIEW DETAILS
        // ============================================================
        function viewDetails(id, d, reviewNotes) {
            let html = '';
            
            try {
                if (typeof d === 'string') {
                    d = JSON.parse(d);
                }
                
                const redAlert = d.red_alert == 1;

                // ==================== CASE SUMMARY ====================
                html += '<div class="case-summary ' + (redAlert ? 'red-alert-summary' : '') + '">';
                if (redAlert) {
                    html += '<div class="red-alert-header"><i class="fas fa-exclamation-triangle"></i> RED ALERT - IMMEDIATE ATTENTION REQUIRED</div><br>';
                }
                html += '<div class="case-no"><i class="fas fa-hashtag" style="font-size: 0.9rem;"></i> ' + escapeHtml(d.case_no || 'N/A') + '</div>';
                if (d.reference_code) {
                    html += '<div class="ref-code"><i class="fas fa-key"></i> Reference Code: ' + escapeHtml(d.reference_code) + '</div>';
                }
                html += '<div class="submitted-at"><i class="fas fa-clock"></i> Submitted: ' + escapeHtml(d.submission_date || 'N/A') + '</div>';
                html += '</div>';

                // ==================== STEP 1 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-info-circle"></i> Step 1: Submission Info</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Case No.</div><div class="detail-value">' + escapeHtml(d.case_no || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Reference Code</div><div class="detail-value"><code>' + escapeHtml(d.reference_code || 'N/A') + '</code></div></div>';
                html += '<div class="detail-item"><div class="detail-label">Submission Date</div><div class="detail-value">' + escapeHtml(d.submission_date || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Verification Code</div><div class="detail-value"><code>' + escapeHtml(d.verification_code || 'N/A') + '</code></div></div>';
                if (d.gps_latitude || d.gps_longitude) {
                    html += '<div class="detail-item"><div class="detail-label">GPS (legacy)</div><div class="detail-value">' + escapeHtml(d.gps_latitude || 'N/A') + ', ' + escapeHtml(d.gps_longitude || 'N/A') + '</div></div>';
                }
                html += '</div></div>';

                // ==================== STEP 2 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-user-lock"></i> Step 2: Client Profile (Confidential)</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Full Name <i class="fas fa-lock lock-icon"></i></div><div class="detail-value sensitive">' + escapeHtml((d.first_name || '') + ' ' + (d.middle_name || '') + ' ' + (d.last_name || '')).trim() + ' ' + escapeHtml(d.suffix || '') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Birthdate</div><div class="detail-value">' + escapeHtml(d.birthdate || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Age</div><div class="detail-value">' + escapeHtml(d.age || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Sex</div><div class="detail-value">' + escapeHtml(d.sex || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Civil Status</div><div class="detail-value">' + escapeHtml(d.civil_status || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Religion</div><div class="detail-value">' + escapeHtml(d.religion || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Barangay</div><div class="detail-value">' + escapeHtml(d.barangay || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Municipality</div><div class="detail-value">' + escapeHtml(d.municipality || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Province</div><div class="detail-value">' + escapeHtml(d.province || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Contact No. <i class="fas fa-lock lock-icon"></i></div><div class="detail-value sensitive">' + escapeHtml(d.contact_no || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Occupation</div><div class="detail-value">' + escapeHtml(d.occupation || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Monthly Income</div><div class="detail-value">₱' + escapeHtml(d.monthly_income || '0') + '</div></div>';
                html += '</div>';

                if (d.has_children === 'yes' || (Array.isArray(d.children_details) && count(d.children_details) > 0)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#FCE4EC; border-radius:8px; border-left:3px solid #C2185B;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#880E4F; margin-bottom:8px;"><i class="fas fa-child"></i> CHILDREN INFORMATION</div>';
                    if (Array.isArray(d.children_details) && count(d.children_details) > 0) {
                        d.children_details.forEach(function(c, i) {
                            html += '<div style="padding:6px 0; border-bottom: 1px dashed #F8BBD0; font-size:0.78rem;">';
                            html += '<strong>Child ' + (i+1) + ':</strong> ' + escapeHtml(c.name || 'N/A') + ' (' + escapeHtml(c.age || '?') + ' yrs, ' + escapeHtml(c.sex || '?') + ')';
                            if (c.relation) html += ' — ' + escapeHtml(c.relation);
                            html += '</div>';
                        });
                    }
                    if (d.children_affected) {
                        html += '<div style="margin-top:8px; font-size:0.78rem;"><strong>Children Affected:</strong><br>' + escapeHtml(d.children_affected) + '</div>';
                    }
                    html += '</div>';
                }
                html += '</div>';

                // ==================== STEP 3 ====================
                let abuseDisplay = 'N/A';
                if (Array.isArray(d.abuse_types) && d.abuse_types.length > 0) {
                    abuseDisplay = '<div class="badge-list">';
                    d.abuse_types.forEach(function(t) {
                        abuseDisplay += '<span class="badge-item abuse">' + escapeHtml(t) + '</span>';
                    });
                    abuseDisplay += '</div>';
                } else if (typeof d.abuse_types === 'string' && d.abuse_types.length > 0) {
                    abuseDisplay = escapeHtml(d.abuse_types);
                }

                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-hand-holding-heart"></i> Step 3: VAWC Program Details</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Perpetrator Relation</div><div class="detail-value">' + escapeHtml(d.perpetrator_relation || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Incident Frequency</div><div class="detail-value">' + escapeHtml(d.incident_frequency || 'N/A') + '</div></div>';
                html += '<div class="detail-item" style="grid-column: 1 / -1;"><div class="detail-label">Type of Abuse Experienced</div><div class="detail-value">' + abuseDisplay + '</div></div>';
                html += '</div>';

                html += '<div class="safety-box">';
                html += '<h5><i class="fas fa-shield-alt"></i> Safety Assessment</h5>';
                html += '<div class="safety-items">';
                html += '<span class="safety-item">' + (d.in_immediate_danger == 1 ? '<i class="fas fa-check-circle"></i> IN IMMEDIATE DANGER' : '<i class="fas fa-times-circle"></i> Not in immediate danger') + '</span>';
                html += '<span class="safety-item">' + (d.children_as_witnesses == 1 ? '<i class="fas fa-check-circle"></i> Children as witnesses' : '<i class="fas fa-times-circle"></i> No child witnesses') + '</span>';
                if (d.current_safe_location) {
                    html += '<span class="safety-item"><i class="fas fa-map-marker-alt"></i> ' + escapeHtml(d.current_safe_location) + '</span>';
                }
                html += '</div></div>';

                html += '<div style="margin-top:12px;">';
                html += '<div class="detail-item"><div class="detail-label">Incident Date</div><div class="detail-value">' + escapeHtml(d.incident_date || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Incident Time</div><div class="detail-value">' + escapeHtml(d.incident_time || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Incident Location</div><div class="detail-value">' + escapeHtml(d.incident_location || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Incident Description <i class="fas fa-lock lock-icon"></i></div><div class="detail-value sensitive">' + escapeHtml(d.incident_description || 'N/A') + '</div></div>';
                html += '</div>';

                html += '<div style="margin-top:12px; padding:12px; background:#FEE2E2; border-radius:8px; border-left:3px solid #991B1B;">';
                html += '<div style="font-size:0.7rem; font-weight:700; color:#991B1B; margin-bottom:8px;"><i class="fas fa-user-slash"></i> PERPETRATOR INFORMATION <i class="fas fa-lock" style="font-size:0.6rem;"></i></div>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Name</div><div class="detail-value sensitive">' + escapeHtml(d.perpetrator_name || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Age</div><div class="detail-value">' + escapeHtml(d.perpetrator_age || 'N/A') + '</div></div>';
                html += '<div class="detail-item" style="grid-column: 1 / -1;"><div class="detail-label">Address</div><div class="detail-value sensitive">' + escapeHtml(d.perpetrator_address || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Has Weapon</div><div class="detail-value">' + escapeHtml(d.perpetrator_has_weapon || 'N/A') + '</div></div>';
                html += '</div></div>';

                if (d.physical_injuries === 'yes') {
                    html += '<div style="margin-top:12px; padding:12px; background:#FEF3C7; border-radius:8px; border-left:3px solid #D97706;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#92400E; margin-bottom:8px;"><i class="fas fa-band-aid"></i> PHYSICAL INJURIES</div>';
                    html += '<div style="font-size:0.78rem;"><strong>Injuries Sustained:</strong> Yes</div>';
                    html += '</div>';
                }

                if (d.has_protection_order === 'yes' || d.has_blotter === 'yes') {
                    html += '<div style="margin-top:12px; padding:12px; background:#DBEAFE; border-radius:8px; border-left:3px solid #1E40AF;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#1E3A8A; margin-bottom:8px;"><i class="fas fa-gavel"></i> LEGAL & PROTECTION RECORDS</div>';
                    if (d.has_protection_order === 'yes') {
                        html += '<div style="font-size:0.78rem; margin-bottom:4px;"><strong>Protection Order:</strong> ' + escapeHtml(d.protection_order_type || 'Yes') + '</div>';
                    }
                    if (d.has_blotter === 'yes') {
                        html += '<div style="font-size:0.78rem;"><strong>Barangay Blotter / Police Report:</strong> Yes</div>';
                    }
                    html += '</div>';
                }

                html += '<div class="detail-item" style="margin-top:12px;">';
                html += '<div class="detail-label">Problem Presented</div>';
                html += '<div class="detail-value">' + escapeHtml(d.problem_presented || 'N/A') + '</div>';
                html += '</div>';

                let rehabDisplay = 'N/A';
                if (Array.isArray(d.rehabilitation_goals) && d.rehabilitation_goals.length > 0) {
                    rehabDisplay = '<div class="badge-list">';
                    d.rehabilitation_goals.forEach(function(g) {
                        rehabDisplay += '<span class="badge-item">' + escapeHtml(g) + '</span>';
                    });
                    rehabDisplay += '</div>';
                }
                html += '<div class="detail-item" style="margin-top:8px;">';
                html += '<div class="detail-label">Rehabilitation Goals</div>';
                html += '<div class="detail-value">' + rehabDisplay + '</div>';
                html += '</div>';

                let referralDisplay = 'N/A';
                if (Array.isArray(d.action_taken_referral) && d.action_taken_referral.length > 0) {
                    referralDisplay = '<div class="badge-list">';
                    d.action_taken_referral.forEach(function(r) {
                        referralDisplay += '<span class="badge-item referral">' + escapeHtml(r) + '</span>';
                    });
                    referralDisplay += '</div>';
                }
                html += '<div class="detail-item" style="margin-top:8px;">';
                html += '<div class="detail-label">Action Taken / Immediate Referral</div>';
                html += '<div class="detail-value">' + referralDisplay + '</div>';
                html += '</div>';
                html += '</div>';

                // ==================== STEP 4 ====================
                let riskDisplay = escapeHtml(d.risk_level || 'N/A');
                if (d.risk_level) {
                    let rc = 'risk-moderate';
                    const rl = d.risk_level.toLowerCase();
                    if (rl === 'low') rc = 'risk-low';
                    else if (rl === 'high') rc = 'risk-high';
                    else if (rl === 'immediate danger') rc = 'risk-immediate';
                    riskDisplay = '<span class="risk-badge ' + rc + '">' + escapeHtml(d.risk_level) + '</span>';
                }
                
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-chart-line"></i> Step 4: Risk Assessment</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Life Threatened</div><div class="detail-value">' + (d.life_threatened === 'yes' ? '<span style="color:#991B1B; font-weight:700;">YES - LIFE IN DANGER</span>' : escapeHtml(d.life_threatened || 'N/A')) + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Risk Level</div><div class="detail-value">' + riskDisplay + '</div></div>';
                html += '</div>';

                html += '<div class="safety-box" style="margin-top:10px;">';
                html += '<h5><i class="fas fa-hand-holding-medical"></i> Immediate Needs</h5>';
                html += '<div class="safety-items">';
                html += '<span class="safety-item">' + (d.needs_emergency_shelter == 1 ? '<i class="fas fa-check-circle"></i> Emergency Shelter' : '<i class="fas fa-times-circle" style="opacity:0.4;"></i> Emergency Shelter') + '</span>';
                html += '<span class="safety-item">' + (d.needs_medical_care == 1 ? '<i class="fas fa-check-circle"></i> Immediate Medical Care' : '<i class="fas fa-times-circle" style="opacity:0.4;"></i> Medical Care') + '</span>';
                html += '<span class="safety-item">' + (d.needs_psychological_support == 1 ? '<i class="fas fa-check-circle"></i> Psychological Support' : '<i class="fas fa-times-circle" style="opacity:0.4;"></i> Psychological Support') + '</span>';
                html += '</div></div>';
                html += '</div>';

                // ==================== STEP 5 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-shield-alt"></i> Step 5: Digital Verification</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Client Consent</div><div class="detail-value">' + (d.client_consent == 1 ? '<span style="color:#059669;">✓ Given</span>' : '<span style="color:#D32F2F;">✗ Not given</span>') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Caseworker</div><div class="detail-value">' + escapeHtml(d.caseworker_name || 'N/A') + ' (ID #' + escapeHtml(d.caseworker_id || 'N/A') + ')</div></div>';
                html += '</div>';

                if (d.identity_photo) {
                    html += '<div class="detail-item" style="margin-top:12px;">';
                    html += '<div class="detail-label">Identity Photo <i class="fas fa-lock lock-icon"></i></div>';
                    html += '<div class="detail-value"><img src="../' + escapeHtml(d.identity_photo) + '" class="id-photo" alt="Identity"></div>';
                    html += '</div>';
                }

                if (d.client_signature && d.client_signature.length > 100) {
                    html += '<div class="detail-item" style="margin-top:12px;">';
                    html += '<div class="detail-label">Client Signature</div>';
                    html += '<div class="detail-value"><img src="' + d.client_signature + '" class="signature-photo" alt="Signature"></div>';
                    html += '</div>';
                }
                html += '</div>';

                // ==================== REVIEW HISTORY ====================
                if (reviewNotes && reviewNotes.length > 0) {
                    html += '<div class="detail-section">';
                    html += '<h4><i class="fas fa-history"></i> Review History</h4>';
                    html += '<div class="review-history-box">' + escapeHtml(reviewNotes) + '</div>';
                    html += '</div>';
                }

                // ==================== CONFIDENTIALITY NOTICE ====================
                html += '<div style="margin-top: 16px; padding: 12px 16px; background: #1E1E1E; color: #FFD700; border-radius: 8px; font-size: 0.72rem; border-left: 4px solid #D32F2F;">';
                html += '<i class="fas fa-shield-alt"></i> <strong>STRICT CONFIDENTIALITY NOTICE:</strong> This information is protected under RA 9262 and RA 10173. Unauthorized disclosure is punishable by law. All access to this record is logged and monitored.';
                html += '</div>';

            } catch(e) {
                html = '<p style="text-align:center;color:var(--gray-500);padding:20px;">Error parsing application data: ' + e.message + '</p>';
                console.error('View details error:', e);
            }
            
            document.getElementById('modalContent').innerHTML = html;
            document.getElementById('viewModal').style.display = 'flex';
        }

        function escapeHtml(text) {
            if (text === null || text === undefined) return '';
            return String(text)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function openActionModal(id, action) {
            document.getElementById('actionAppId').value = id;
            document.getElementById('actionStatus').value = action;
            const title = action == 'approve' ? '✅ Approve VAWC Application' : '❌ Reject VAWC Application';
            const btnText = action == 'approve' ? 'Approve' : 'Reject';
            const btnColor = action == 'approve' ? '#059669' : '#D32F2F';
            document.getElementById('actionTitle').innerHTML = title + ' <span class="confidential-badge" style="font-size:0.6rem;"><i class="fas fa-lock"></i> Confidential</span>';
            const btn = document.getElementById('actionSubmitBtn');
            btn.innerHTML = btnText;
            btn.style.background = btnColor;
            document.getElementById('actionModal').style.display = 'flex';
        }

        function openReviewModal(id) {
            document.getElementById('reviewAppId').value = id;
            document.getElementById('reviewedNote').value = '';
            document.getElementById('reviewModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        window.onclick = (e) => { 
            if(e.target.classList.contains('modal')) closeModal(e.target.id); 
        }
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>