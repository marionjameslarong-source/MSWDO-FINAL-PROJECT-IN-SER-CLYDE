<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$error = '';
$success = '';

// Get sidebar household ID for dynamic navigation
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get unread notification count for sidebar badge
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

// Handle cancellation of application (resident only)
if(isset($_GET['cancel']) && is_numeric($_GET['cancel']) && $role == 'resident') {
    $app_id = $_GET['cancel'];
    
    $stmt = $pdo->prepare("SELECT id, status FROM welfare_applications WHERE id = ? AND user_id = ?");
    $stmt->execute([$app_id, $user_id]);
    $app = $stmt->fetch();
    
    if($app && $app['status'] == 'pending') {
        $stmt = $pdo->prepare("UPDATE welfare_applications SET status = 'cancelled', updated_at = NOW() WHERE id = ?");
        $stmt->execute([$app_id]);
        $success = "Application cancelled successfully.";
        
        try {
            $log_stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, created_at) VALUES (?, 'cancel_application', ?, ?, NOW())");
            $log_stmt->execute([$user_id, "Cancelled application ID: $app_id", $_SERVER['REMOTE_ADDR']]);
        } catch(PDOException $e) {}
    } else {
        $error = "Unable to cancel this application.";
    }
}

// Get all applications for the user
$query = "
    SELECT wa.*, 
           h.barangay,
           h.address
    FROM welfare_applications wa
    LEFT JOIN households h ON wa.household_id = h.id
    WHERE wa.user_id = ?
    ORDER BY wa.created_at DESC
";

$stmt = $pdo->prepare($query);
$stmt->execute([$user_id]);
$applications = $stmt->fetchAll();

// Get statistics
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
    FROM welfare_applications 
    WHERE user_id = ?
");
$stmt->execute([$user_id]);
$stats = $stmt->fetch();

// Program icons and colors
$program_icons = [
    'solo_parent' => ['icon' => 'fas fa-female', 'color' => '#e74c3c', 'name' => 'Solo Parent Program'],
    'senior_citizen' => ['icon' => 'fas fa-user-graduate', 'color' => '#3498db', 'name' => 'Senior Citizen Program'],
    'pwd' => ['icon' => 'fas fa-wheelchair', 'color' => '#27ae60', 'name' => 'PWD Program'],
    'aics' => ['icon' => 'fas fa-coins', 'color' => '#f39c12', 'name' => 'AICS Program'],
    'vawc' => ['icon' => 'fas fa-shield-alt', 'color' => '#9C27B0', 'name' => 'VAWC Program'],
    'financial_assistance' => ['icon' => 'fas fa-hand-holding-usd', 'color' => '#16a085', 'name' => 'Financial Assistance'],
    'id_application' => ['icon' => 'fas fa-id-card', 'color' => '#2980b9', 'name' => 'ID Application']
];

// Status badges configuration
$status_config = [
    'pending' => ['class' => 'status-pending', 'text' => 'Pending Review', 'icon' => 'fas fa-clock'],
    'approved' => ['class' => 'status-approved', 'text' => 'Approved', 'icon' => 'fas fa-check-circle'],
    'rejected' => ['class' => 'status-rejected', 'text' => 'Rejected', 'icon' => 'fas fa-times-circle'],
    'cancelled' => ['class' => 'status-cancelled', 'text' => 'Cancelled', 'icon' => 'fas fa-ban']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>My Applications - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   
   <?= renderPwaMetaTags() ?>
   <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #3B6CB0;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --radius-2xl: 2rem;
        }
        .app { display: flex; min-height: 100vh; }

        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0; left: 0; bottom: 0;
            overflow-y: auto;
            z-index: 40;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--gray-400); margin-bottom: 12px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; margin-bottom: 4px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; transition: all 0.2s ease; cursor: pointer; position: relative; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge { margin-left: auto; background: var(--secondary); color: white; font-size: 0.65rem; font-weight: 700; padding: 2px 8px; border-radius: 20px; line-height: 1.4; }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 16px; margin-bottom: 2px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; transition: all 0.2s ease; font-size: 0.8rem; }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .submenu-item.active i { color: white; }

        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid var(--gray-200); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--gray-50); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        .stats-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 20px; margin-bottom: 32px; }
        .stat-card { background: var(--white); padding: 20px; border-radius: var(--radius-lg); text-align: center; border: 1px solid var(--gray-200); transition: all 0.2s ease; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
        .stat-number { font-size: 1.8rem; font-weight: 700; margin-bottom: 8px; }
        .stat-label { font-size: 0.7rem; font-weight: 600; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-total .stat-number { color: var(--primary); }
        .stat-pending .stat-number { color: var(--accent); }
        .stat-approved .stat-number { color: #059669; }
        .stat-rejected .stat-number { color: var(--secondary); }
        .stat-cancelled .stat-number { color: var(--gray-500); }

        .applications-list { display: flex; flex-direction: column; gap: 20px; }
        .application-card { background: var(--white); border-radius: var(--radius-xl); border: 1px solid var(--gray-200); overflow: hidden; transition: all 0.2s ease; border-left: 4px solid; }
        .application-card:hover { box-shadow: var(--shadow-md); }
        .card-pending { border-left-color: var(--accent); }
        .card-approved { border-left-color: #059669; }
        .card-rejected { border-left-color: var(--secondary); }
        .card-cancelled { border-left-color: var(--gray-400); }
        .card-header { padding: 20px 24px; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
        .program-info { display: flex; align-items: center; gap: 14px; }
        .program-icon { width: 48px; height: 48px; background: var(--gray-100); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; }
        .program-icon i { font-size: 1.4rem; }
        .program-details h3 { font-size: 1rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .app-id { font-size: 0.7rem; color: var(--gray-500); }
        .status-badge { display: inline-flex; align-items: center; gap: 8px; padding: 6px 14px; border-radius: 40px; font-size: 0.7rem; font-weight: 600; }
        .status-pending { background: #FEF3C7; color: #B45309; }
        .status-approved { background: #ECFDF5; color: #065F46; }
        .status-rejected { background: #FEF2F2; color: #991B1B; }
        .status-cancelled { background: var(--gray-100); color: var(--gray-600); }
        .card-body { padding: 24px; }
        .info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 20px; }
        .info-item { display: flex; flex-direction: column; gap: 6px; }
        .info-label { font-size: 0.7rem; font-weight: 600; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; }
        .info-value { font-size: 0.85rem; font-weight: 500; color: var(--gray-800); }
        .application-data { background: var(--gray-50); padding: 16px 20px; border-radius: var(--radius-lg); margin: 20px 0; border: 1px solid var(--gray-200); }
        .application-data h4 { font-size: 0.85rem; font-weight: 600; color: var(--primary); margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
        .review-notes { background: #FFF9EF; padding: 16px 20px; border-radius: var(--radius-lg); margin: 20px 0; border-left: 3px solid var(--accent); }
        .review-notes h4 { font-size: 0.85rem; font-weight: 600; color: #B45309; margin-bottom: 10px; display: flex; align-items: center; gap: 8px; }
        .action-buttons { display: flex; gap: 12px; margin-top: 20px; }
        .btn-cancel { background: transparent; border: 1.5px solid var(--secondary); color: var(--secondary); padding: 8px 20px; border-radius: 40px; font-size: 0.75rem; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease; }
        .btn-cancel:hover { background: #FEF2F2; }
        .card-footer { padding: 16px 24px; background: var(--gray-50); border-top: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; font-size: 0.7rem; color: var(--gray-500); }

        .empty-state { text-align: center; padding: 60px 20px; background: var(--white); border-radius: var(--radius-2xl); border: 1px solid var(--gray-200); }
        .empty-icon { font-size: 4rem; color: var(--gray-400); margin-bottom: 16px; }
        .empty-state h3 { font-size: 1.2rem; color: var(--gray-700); margin-bottom: 8px; }
        .empty-state p { color: var(--gray-500); font-size: 0.85rem; }
        .btn-primary { background: var(--primary); color: white; padding: 12px 24px; border-radius: 40px; text-decoration: none; font-weight: 600; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease; margin-top: 20px; }
        .btn-primary:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: var(--shadow-md); }

        .help-section { background: #EFF6FF; border-radius: var(--radius-xl); padding: 24px; margin-top: 32px; border: 1px solid #DBEAFE; }
        .help-section h4 { font-size: 0.9rem; font-weight: 600; color: var(--primary); margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
        .help-section p { font-size: 0.8rem; color: var(--gray-600); line-height: 1.5; }
        .steps { margin-top: 12px; padding-left: 20px; }
        .steps li { font-size: 0.75rem; color: var(--gray-600); margin-bottom: 6px; }

        .alert { padding: 16px 20px; border-radius: var(--radius-lg); margin-bottom: 24px; font-size: 0.85rem; display: flex; align-items: center; gap: 12px; }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }

        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .menu-toggle:hover { background: var(--gray-100); }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
            .info-grid { grid-template-columns: 1fr; gap: 12px; }
            .card-header { flex-direction: column; align-items: flex-start; }
        }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Municipal Social Welfare</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/resident_dashboard.php" class="nav-item">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo ($sidebar_household_id) ? 'household_data.php?view=' . $sidebar_household_id : 'household_form.php'; ?>" class="nav-item">
                    <i class="fas fa-users"></i>
                    <span>Household Profile</span>
                </a>
                <a href="my_applications.php" class="nav-item active">
                    <i class="fas fa-file-alt"></i>
                    <span>My Applications</span>
                </a>
                <a href="../notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i>
                    <span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="../soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="../seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="../pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="../aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="../vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="survey_form.php" class="nav-item">
                    <i class="fas fa-chart-line"></i>
                    <span>Community Survey</span>
                </a>
                <a href="../id_application.php" class="nav-item">
                    <i class="fas fa-id-card"></i>
                    <span>ID Application</span>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../profile_settings.php" class="nav-item">
                    <i class="fas fa-user-circle"></i>
                    <span>Profile Settings</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>My Applications</h1>
                    <p>Track and manage your welfare program applications</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Resident</small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <?php if($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card stat-total">
                <div class="stat-number"><?php echo $stats['total'] ?? 0; ?></div>
                <div class="stat-label">Total Applications</div>
            </div>
            <div class="stat-card stat-pending">
                <div class="stat-number"><?php echo $stats['pending'] ?? 0; ?></div>
                <div class="stat-label">Pending</div>
            </div>
            <div class="stat-card stat-approved">
                <div class="stat-number"><?php echo $stats['approved'] ?? 0; ?></div>
                <div class="stat-label">Approved</div>
            </div>
            <div class="stat-card stat-rejected">
                <div class="stat-number"><?php echo $stats['rejected'] ?? 0; ?></div>
                <div class="stat-label">Rejected</div>
            </div>
            <div class="stat-card stat-cancelled">
                <div class="stat-number"><?php echo $stats['cancelled'] ?? 0; ?></div>
                <div class="stat-label">Cancelled</div>
            </div>
        </div>
        
        <?php if(count($applications) == 0): ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <i class="fas fa-folder-open"></i>
                </div>
                <h3>No Applications Yet</h3>
                <p>You haven't submitted any welfare program applications.</p>
                <a href="../dashboards/resident_dashboard.php" class="btn-primary">
                    <i class="fas fa-arrow-left"></i> Browse Welfare Programs
                </a>
            </div>
        <?php else: ?>
            <div class="applications-list">
                <?php foreach($applications as $app): 
                    $program = $program_icons[$app['program_type']] ?? ['icon' => 'fas fa-file', 'color' => '#7f8c8d', 'name' => ucfirst(str_replace('_', ' ', $app['program_type']))];
                    $status = $status_config[$app['status']] ?? ['class' => 'status-pending', 'text' => ucfirst($app['status']), 'icon' => 'fas fa-question'];
                    $app_data = json_decode($app['application_data'], true);
                ?>
                    <div class="application-card card-<?php echo $app['status']; ?>">
                        <div class="card-header">
                            <div class="program-info">
                                <div class="program-icon">
                                    <i class="<?php echo $program['icon']; ?>" style="color: <?php echo $program['color']; ?>;"></i>
                                </div>
                                <div class="program-details">
                                    <h3><?php echo $program['name']; ?></h3>
                                    <div class="app-id">
                                        Application #<?php echo str_pad($app['id'], 6, '0', STR_PAD_LEFT); ?>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <span class="status-badge status-<?php echo $app['status']; ?>">
                                    <i class="<?php echo $status['icon']; ?>"></i> <?php echo $status['text']; ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="card-body">
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label"><i class="fas fa-calendar-alt"></i> Date Applied</span>
                                    <span class="info-value"><?php echo date('F d, Y', strtotime($app['created_at'])); ?> at <?php echo date('h:i A', strtotime($app['created_at'])); ?></span>
                                </div>
                                
                                <?php if($app['barangay']): ?>
                                <div class="info-item">
                                    <span class="info-label"><i class="fas fa-map-marker-alt"></i> Barangay</span>
                                    <span class="info-value"><?php echo htmlspecialchars($app['barangay']); ?></span>
                                </div>
                                <?php endif; ?>
                                
                                <?php if($app['updated_at'] != $app['created_at']): ?>
                                <div class="info-item">
                                    <span class="info-label"><i class="fas fa-clock"></i> Last Updated</span>
                                    <span class="info-value"><?php echo date('F d, Y', strtotime($app['updated_at'])); ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if($app_data && (isset($app_data['needs_assessment']) || isset($app_data['assistance_needed']) || isset($app_data['problem_presented']) || isset($app_data['reason']))): ?>
                                <div class="application-data">
                                    <h4><i class="fas fa-info-circle"></i> Application Details</h4>
                                    
                                    <?php if(isset($app_data['reason']) && $app_data['reason']): ?>
                                    <div class="info-item" style="margin-bottom: 12px;">
                                        <span class="info-label">Reason for Application</span>
                                        <span class="info-value"><?php echo nl2br(htmlspecialchars(substr($app_data['reason'], 0, 200))); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if(isset($app_data['needs_assessment']) && $app_data['needs_assessment']): ?>
                                    <div class="info-item" style="margin-bottom: 12px;">
                                        <span class="info-label">Needs Assessment</span>
                                        <span class="info-value"><?php echo nl2br(htmlspecialchars(substr($app_data['needs_assessment'], 0, 200))); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if(isset($app_data['assistance_needed']) && $app_data['assistance_needed']): ?>
                                    <div class="info-item" style="margin-bottom: 12px;">
                                        <span class="info-label">Assistance Needed</span>
                                        <span class="info-value"><?php echo nl2br(htmlspecialchars(substr($app_data['assistance_needed'], 0, 200))); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if(isset($app_data['problem_presented']) && $app_data['problem_presented']): ?>
                                    <div class="info-item">
                                        <span class="info-label">Problem Presented</span>
                                        <span class="info-value"><?php echo nl2br(htmlspecialchars(substr($app_data['problem_presented'], 0, 200))); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if(isset($app_data['description']) && $app_data['description']): ?>
                                    <div class="info-item">
                                        <span class="info-label">Description</span>
                                        <span class="info-value"><?php echo nl2br(htmlspecialchars(substr($app_data['description'], 0, 200))); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if($app['review_notes']): ?>
                                <div class="review-notes">
                                    <h4><i class="fas fa-comment-dots"></i> Review Notes from MSWDO</h4>
                                    <p style="font-size: 0.85rem; color: var(--gray-700);"><?php echo nl2br(htmlspecialchars($app['review_notes'])); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if($app['status'] == 'pending' && $role == 'resident'): ?>
                                <div class="action-buttons">
                                    <a href="?cancel=<?php echo $app['id']; ?>" 
                                       class="btn-cancel" 
                                       onclick="return confirm('Are you sure you want to cancel this application? This action cannot be undone.')">
                                        <i class="fas fa-times-circle"></i> Cancel Application
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="card-footer">
                            <span><i class="fas fa-calendar-plus"></i> Created: <?php echo date('M d, Y', strtotime($app['created_at'])); ?></span>
                            <?php if($app['status'] != 'pending' && $app['status'] != 'cancelled'): ?>
                                <span><i class="fas fa-check-circle"></i> Processed: <?php echo date('M d, Y', strtotime($app['updated_at'])); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="help-section">
            <h4><i class="fas fa-info-circle"></i> Application Process Guide</h4>
            <p>Follow these steps to track your welfare program applications:</p>
            <ul class="steps">
                <li><strong>1. Submit Application</strong> - Fill out the application form for your chosen welfare program</li>
                <li><strong>2. Pending Review</strong> - MSWDO staff will review your application within 3-5 business days</li>
                <li><strong>3. Status Update</strong> - You will receive an update once your application is approved or rejected</li>
                <li><strong>4. Approved</strong> - Proceed to MSWDO office with required documents for final processing</li>
            </ul>
            <p style="margin-top: 12px;">
                <strong><i class="fas fa-phone-alt"></i> For inquiries, contact:</strong> MSWDO Office at (02) 1234 5678
            </p>
        </div>
    </main>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    
    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
        });
    }
    
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
    
    setTimeout(function() {
        const alert = document.querySelector('.alert-success');
        if(alert) {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(function() {
                if(alert) alert.remove();
            }, 500);
        }
    }, 5000);
</script>
<?= renderPwaServiceWorker() ?>
</body>
</html>