<?php
// ============================================================================
// submit_location.php - RESIDENT GPS SUBMISSION PAGE
// ============================================================================
session_start();
require_once '../config/database.php';

// Resident only
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'resident') {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'Resident';

// Get household record for this user
$household = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $household = $stmt->fetch();
} catch(PDOException $e) {
    $household = null;
}

$existing_lat = $household['latitude'] ?? '';
$existing_lng = $household['longitude'] ?? '';
$existing_address = $household['physical_address'] ?? ($household['address'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit GPS Location - MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-500: #64748B;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        .main-content { max-width: 900px; margin: 0 auto; padding: 16px; }

        .top-bar {
            background: var(--white);
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-title h1 { font-size: 1.2rem; font-weight: 600; color: var(--gray-800); }
        .page-title p { font-size: 0.75rem; color: var(--gray-500); margin-top: 2px; }

        .card {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 20px;
        }
        .card-header {
            padding: 16px 20px;
            background: linear-gradient(135deg, #1E4A8C, #0A2F6C);
            color: white;
        }
        .card-header h2 { font-size: 1rem; display: flex; align-items: center; gap: 8px; }
        .card-body { padding: 20px; }

        .alert {
            padding: 12px 16px;
            border-radius: var(--radius-md);
            margin-bottom: 16px;
            font-size: 0.85rem;
            display: none;
        }
        .alert.show { display: block; }
        .alert.success { background: #D1FAE5; color: #065F46; border: 1px solid #34D399; }
        .alert.error { background: #FEE2E2; color: #991B1B; border: 1px solid #F87171; }

        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-500);
            margin-bottom: 6px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.9rem;
            font-family: inherit;
        }
        .form-group input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(30,74,140,0.1);
        }

        .btn {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            border: none;
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); }
        .btn-success { background: var(--success); color: white; }
        .btn-success:hover { background: #047857; }
        .btn-secondary { background: var(--gray-100); color: var(--gray-700); }
        .btn-secondary:hover { background: var(--gray-200); }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .btn-row { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 16px; }

        #map { height: 400px; width: 100%; border-radius: 0; z-index: 1; }
        .map-wrap { position: relative; }

        .coord-display {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 16px;
        }
        .coord-item {
            background: var(--gray-100);
            padding: 10px 14px;
            border-radius: var(--radius-md);
        }
        .coord-item .label {
            font-size: 0.65rem;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .coord-item .value {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--gray-800);
            margin-top: 2px;
        }

        @media (max-width: 600px) {
            .coord-display { grid-template-columns: 1fr; }
            #map { height: 300px; }
        }
    </style>
</head>
<body>
    <main class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h1>📍 Submit Your GPS Location</h1>
                <p>Pin your household location on the map for MSWDO records</p>
            </div>
            <a href="../dashboards/resident_dashboard.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>

        <div class="alert" id="alertBox"></div>

        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-map-marked-alt"></i> Pin Your Location</h2>
            </div>
            <div class="card-body">
                <p style="font-size:0.85rem;color:var(--gray-500);margin-bottom:16px;">
                    Click on the map or use the <strong>"Use My Current Location"</strong> button to set your household position.
                    Then click <strong>"Save Location"</strong> to submit.
                </p>

                <div class="btn-row" style="margin-top:0;margin-bottom:16px;">
                    <button type="button" class="btn btn-primary" id="btnLocate">
                        <i class="fas fa-location-crosshairs"></i> Use My Current Location
                    </button>
                    <button type="button" class="btn btn-secondary" id="btnReset">
                        <i class="fas fa-redo"></i> Reset Pin
                    </button>
                </div>

                <div class="map-wrap">
                    <div id="map"></div>
                </div>

                <div class="coord-display">
                    <div class="coord-item">
                        <div class="label">Latitude</div>
                        <div class="value" id="displayLat">—</div>
                    </div>
                    <div class="coord-item">
                        <div class="label">Longitude</div>
                        <div class="value" id="displayLng">—</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-home"></i> Address Details</h2>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="address">Household Address / Landmark</label>
                    <input type="text" id="address" placeholder="e.g. Purok 3, Brgy. Cantilan Centro" value="<?php echo htmlspecialchars($existing_address); ?>">
                </div>

                <div class="btn-row">
                    <button type="button" class="btn btn-success" id="btnSave">
                        <i class="fas fa-save"></i> Save Location
                    </button>
                </div>
            </div>
        </div>
    </main>

    <script>
        // ====================================================================
        // MAP INITIALIZATION
        // ====================================================================
        const DEFAULT_CENTER = [9.3333, 125.9667]; // Cantilan, Surigao del Sur
        const existingLat = <?php echo json_encode($existing_lat); ?>;
        const existingLng = <?php echo json_encode($existing_lng); ?>;

        let map = L.map('map').setView(DEFAULT_CENTER, 14);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(map);

        let marker = null;

        // If existing location, place marker
        if (existingLat && existingLng && existingLat != 0 && existingLng != 0) {
            placeMarker(parseFloat(existingLat), parseFloat(existingLng));
        }

        // Click on map to place marker
        map.on('click', function(e) {
            placeMarker(e.latlng.lat, e.latlng.lng);
        });

        function placeMarker(lat, lng) {
            if (marker) {
                marker.setLatLng([lat, lng]);
            } else {
                marker = L.marker([lat, lng], { draggable: true }).addTo(map);
                marker.on('dragend', function(e) {
                    const pos = e.target.getLatLng();
                    updateCoords(pos.lat, pos.lng);
                });
            }
            updateCoords(lat, lng);
            map.setView([lat, lng], Math.max(map.getZoom(), 16));
        }

        function updateCoords(lat, lng) {
            document.getElementById('displayLat').textContent = lat.toFixed(8);
            document.getElementById('displayLng').textContent = lng.toFixed(8);
        }

        // ====================================================================
        // USE CURRENT LOCATION BUTTON
        // ====================================================================
        document.getElementById('btnLocate').addEventListener('click', function() {
            if (!navigator.geolocation) {
                showAlert('error', 'Geolocation is not supported by your browser.');
                return;
            }

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Getting location...';

            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    placeMarker(pos.coords.latitude, pos.coords.longitude);
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-location-crosshairs"></i> Use My Current Location';
                    showAlert('success', 'Location found! Click "Save Location" to submit.');
                },
                (err) => {
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-location-crosshairs"></i> Use My Current Location';
                    showAlert('error', 'Could not get your location: ' + err.message);
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        });

        // ====================================================================
        // RESET BUTTON
        // ====================================================================
        document.getElementById('btnReset').addEventListener('click', function() {
            if (marker) {
                map.removeLayer(marker);
                marker = null;
            }
            document.getElementById('displayLat').textContent = '—';
            document.getElementById('displayLng').textContent = '—';
            map.setView(DEFAULT_CENTER, 14);
        });

        // ====================================================================
        // SAVE BUTTON
        // ====================================================================
        document.getElementById('btnSave').addEventListener('click', function() {
            if (!marker) {
                showAlert('error', 'Please pin your location on the map first.');
                return;
            }

            const address = document.getElementById('address').value.trim();
            if (!address) {
                showAlert('error', 'Please enter your address or landmark.');
                return;
            }

            const pos = marker.getLatLng();

            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

            const formData = new FormData();
            formData.append('address', address);
            formData.append('latitude', pos.lat);
            formData.append('longitude', pos.lng);

            fetch('submit_location.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                this.disabled = false;
                this.innerHTML = '<i class="fas fa-save"></i> Save Location';
                if (data.success) {
                    showAlert('success', '✅ ' + data.message);
                } else {
                    showAlert('error', '❌ ' + data.message);
                }
            })
            .catch(err => {
                this.disabled = false;
                this.innerHTML = '<i class="fas fa-save"></i> Save Location';
                showAlert('error', 'Network error: ' + err.message);
            });
        });

        // ====================================================================
        // SHOW ALERT
        // ====================================================================
        function showAlert(type, msg) {
            const box = document.getElementById('alertBox');
            box.className = 'alert show ' + type;
            box.textContent = msg;
            box.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => { box.classList.remove('show'); }, 6000);
        }
    </script>
</body>
</html>