<?php
session_start();
require_once '../config/database.php';

// Only allow staff access
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

echo "<h1>Household Table Diagnostic</h1>";

// Check if table exists
try {
    $result = $pdo->query("SHOW TABLES LIKE 'households'");
    if($result->rowCount() > 0) {
        echo "<p style='color:green'>✓ households table exists</p>";
        
        // Show column structure
        $columns = $pdo->query("DESCRIBE households");
        echo "<h2>Table Columns:</h2>";
        echo "<table border='1' cellpadding='8'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        while($col = $columns->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . $col['Field'] . "</td>";
            echo "<td>" . $col['Type'] . "</td>";
            echo "<td>" . $col['Null'] . "</td>";
            echo "<td>" . $col['Key'] . "</td>";
            echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Show data count
        $count = $pdo->query("SELECT COUNT(*) FROM households")->fetchColumn();
        echo "<p>Total records: <strong>$count</strong></p>";
        
        // Show sample data
        if($count > 0) {
            $sample = $pdo->query("SELECT * FROM households LIMIT 3");
            echo "<h2>Sample Data (first 3 rows):</h2>";
            echo "<table border='1' cellpadding='8'>";
            // Get column names
            $firstRow = $sample->fetch(PDO::FETCH_ASSOC);
            if($firstRow) {
                echo "<tr>";
                foreach(array_keys($firstRow) as $col) {
                    echo "<th>$col</th>";
                }
                echo "</tr>";
                echo "<tr>";
                foreach($firstRow as $value) {
                    echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
                }
                echo "</tr>";
                // Get remaining rows
                while($row = $sample->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    foreach($row as $value) {
                        echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
                    }
                    echo "</tr>";
                }
            }
            echo "</table>";
        } else {
            echo "<p style='color:orange'>⚠ The households table is EMPTY. No data found.</p>";
        }
        
        // Fix button
        echo "<hr>";
        echo "<h2>Fix Options:</h2>";
        echo "<a href='?fix_structure=1' style='background:green; color:white; padding:10px; text-decoration:none; display:inline-block; margin:5px;'>Fix Table Structure (Add missing columns)</a>";
        echo "<a href='?add_sample=1' style='background:blue; color:white; padding:10px; text-decoration:none; display:inline-block; margin:5px;'>Add Sample Data</a>";
        echo "<a href='household.php' style='background:gray; color:white; padding:10px; text-decoration:none; display:inline-block; margin:5px;'>Back to Household Page</a>";
        
        // Fix structure
        if(isset($_GET['fix_structure'])) {
            $alter_queries = [
                "ALTER TABLE households ADD COLUMN IF NOT EXISTS household_no VARCHAR(50) AFTER id",
                "ALTER TABLE households ADD COLUMN IF NOT EXISTS head_of_family VARCHAR(100) AFTER household_no",
                "ALTER TABLE households ADD COLUMN IF NOT EXISTS contact_number VARCHAR(20) AFTER address",
                "ALTER TABLE households ADD COLUMN IF NOT EXISTS barangay VARCHAR(100) AFTER head_of_family",
                "ALTER TABLE households ADD COLUMN IF NOT EXISTS address TEXT AFTER barangay",
                "ALTER TABLE households ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active' AFTER contact_number",
            ];
            
            echo "<h3>Running fixes:</h3>";
            foreach($alter_queries as $query) {
                try {
                    $pdo->exec($query);
                    echo "<p style='color:green'>✓ Executed: " . htmlspecialchars($query) . "</p>";
                } catch(PDOException $e) {
                    echo "<p style='color:orange'>⚠ " . htmlspecialchars($query) . " - " . $e->getMessage() . "</p>";
                }
            }
            echo "<p><a href='check_household_table.php'>Refresh</a></p>";
        }
        
        // Add sample data
        if(isset($_GET['add_sample'])) {
            // First check what columns exist
            $existing_cols = [];
            $col_check = $pdo->query("DESCRIBE households");
            while($col = $col_check->fetch(PDO::FETCH_ASSOC)) {
                $existing_cols[] = $col['Field'];
            }
            
            $samples = [
                ['HH-2024-001', 'Juan Dela Cruz', 'Barangay 1', '123 Main St, Barangay 1', '09123456789'],
                ['HH-2024-002', 'Maria Santos', 'Barangay 2', '456 Rizal St, Barangay 2', '09234567890'],
                ['HH-2024-003', 'Jose Reyes', 'Barangay 3', '789 Mabini St, Barangay 3', '09345678901'],
                ['HH-2024-004', 'Ana Garcia', 'Barangay 1', '321 Luna St', '09456789012'],
                ['HH-2024-005', 'Pedro Cruz', 'Barangay 2', '654 Bonifacio St', '09567890123'],
            ];
            
            $inserted = 0;
            foreach($samples as $sample) {
                // Build dynamic insert query based on existing columns
                $insert_cols = [];
                $insert_vals = [];
                
                if(in_array('household_no', $existing_cols)) {
                    $insert_cols[] = 'household_no';
                    $insert_vals[] = $sample[0];
                }
                if(in_array('head_of_family', $existing_cols)) {
                    $insert_cols[] = 'head_of_family';
                    $insert_vals[] = $sample[1];
                }
                if(in_array('barangay', $existing_cols)) {
                    $insert_cols[] = 'barangay';
                    $insert_vals[] = $sample[2];
                }
                if(in_array('address', $existing_cols)) {
                    $insert_cols[] = 'address';
                    $insert_vals[] = $sample[3];
                }
                if(in_array('contact_number', $existing_cols)) {
                    $insert_cols[] = 'contact_number';
                    $insert_vals[] = $sample[4];
                }
                
                if(!empty($insert_cols)) {
                    $placeholders = implode(',', array_fill(0, count($insert_cols), '?'));
                    $sql = "INSERT INTO households (" . implode(',', $insert_cols) . ") VALUES ($placeholders)";
                    try {
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute($insert_vals);
                        $inserted++;
                    } catch(PDOException $e) {
                        echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
                    }
                }
            }
            echo "<p style='color:green'>✓ Added $inserted sample records!</p>";
            echo "<p><a href='check_household_table.php'>Refresh</a></p>";
        }
        
    } else {
        echo "<p style='color:red'>✗ households table does NOT exist</p>";
        echo "<a href='?create_table=1' style='background:green; color:white; padding:10px; text-decoration:none;'>Create households table</a>";
        
        if(isset($_GET['create_table'])) {
            $create_sql = "CREATE TABLE households (
                id INT AUTO_INCREMENT PRIMARY KEY,
                household_no VARCHAR(50) NOT NULL,
                head_of_family VARCHAR(100) NOT NULL,
                barangay VARCHAR(100),
                address TEXT,
                contact_number VARCHAR(20),
                status VARCHAR(20) DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )";
            try {
                $pdo->exec($create_sql);
                echo "<p style='color:green'>✓ Table created successfully!</p>";
                echo "<p><a href='check_household_table.php'>Refresh</a></p>";
            } catch(PDOException $e) {
                echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
            }
        }
    }
    
} catch(PDOException $e) {
    echo "<p style='color:red'>Database error: " . $e->getMessage() . "</p>";
}
?>