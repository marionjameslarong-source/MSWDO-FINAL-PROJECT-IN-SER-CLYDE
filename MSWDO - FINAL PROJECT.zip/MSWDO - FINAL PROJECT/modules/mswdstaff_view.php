<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];

// Get application ID from URL
$application_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if($application_id <= 0) {
    header("Location: ../dashboards/mswdstaff_dashboard.php");
    exit();
}

// Handle Approve/Reject directly in this page (not redirecting to dashboard)
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['approve_application'])) {
        $app_id = $_POST['application_id'] ?? 0;
        $review_notes = $_POST['review_notes'] ?? '';
        
        if($app_id > 0) {
            $stmt = $pdo->prepare("UPDATE welfare_applications SET status = 'approved', review_notes = ?, reviewed_by = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$review_notes, $user_id, $app_id]);
            $success_message = "Application approved successfully!";
            // Refresh the page to show updated status
            header("Location: mswdstaff_view.php?id=" . $app_id . "&success=approved");
            exit();
        }
    }
    
    if(isset($_POST['reject_application'])) {
        $app_id = $_POST['application_id'] ?? 0;
        $review_notes = $_POST['review_notes'] ?? '';
        
        if($app_id > 0) {
            $stmt = $pdo->prepare("UPDATE welfare_applications SET status = 'rejected', review_notes = ?, reviewed_by = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$review_notes, $user_id, $app_id]);
            $success_message = "Application rejected successfully!";
            header("Location: mswdstaff_view.php?id=" . $app_id . "&success=rejected");
            exit();
        }
    }
}

// Fetch application details
$stmt = $pdo->prepare("
    SELECT wa.*, u.full_name as applicant_name, u.username, u.email, u.contact_number 
    FROM welfare_applications wa 
    LEFT JOIN users u ON wa.user_id = u.id 
    WHERE wa.id = ?
");
$stmt->execute([$application_id]);
$application = $stmt->fetch();

if(!$application) {
    header("Location: ../dashboards/mswdstaff_dashboard.php");
    exit();
}

// Check for success message
$success_message = '';
if(isset($_GET['success'])) {
    if($_GET['success'] == 'approved') {
        $success_message = "Application has been approved successfully!";
    } elseif($_GET['success'] == 'rejected') {
        $success_message = "Application has been rejected successfully!";
    }
}

// Parse application data
$app_data = json_decode($application['application_data'], true);

// Program names mapping
$program_names = [
    'solo_parent' => 'Solo Parent',
    'senior_citizen' => 'Senior Citizen',
    'pwd' => 'PWD',
    'aics' => 'AICS',
    'vawc' => 'VAWC',
    'financial_assistance' => 'Financial Assistance',
    'id_application' => 'ID Application'
];

// Get program display name
$program_display = $program_names[$application['program_type']] ?? ucfirst(str_replace('_', ' ', $application['program_type']));

// Get status badge class
function getStatusClass($status) {
    switch($status) {
        case 'pending': return 'status-pending';
        case 'approved': return 'status-approved';
        case 'rejected': return 'status-rejected';
        case 'cancelled': return 'status-cancelled';
        default: return 'status-pending';
    }
}

// Get status icon
function getStatusIcon($status) {
    switch($status) {
        case 'pending': return 'fa-clock';
        case 'approved': return 'fa-check-circle';
        case 'rejected': return 'fa-times-circle';
        case 'cancelled': return 'fa-ban';
        default: return 'fa-question-circle';
    }
}

// Helper to format field names
function formatFieldName($key) {
    $names = [
        'full_name' => 'Full Name',
        'birthdate' => 'Birthdate',
        'age' => 'Age',
        'birthplace' => 'Birthplace',
        'sex' => 'Sex',
        'civil_status' => 'Civil Status',
        'religion' => 'Religion',
        'address' => 'Address',
        'barangay' => 'Barangay',
        'contact_no' => 'Contact Number',
        'email' => 'Email Address',
        'occupation' => 'Occupation',
        'monthly_income' => 'Monthly Income',
        'income_source' => 'Source of Income',
        'educational_attainment' => 'Educational Attainment',
        'household_members' => 'Total Household Members',
        'dependent_children' => 'Dependent Children',
        'crisis_type' => 'Crisis Type',
        'crisis_description' => 'Crisis Description',
        'crisis_date' => 'Date of Crisis',
        'crisis_location' => 'Location of Incident',
        'incident_report_number' => 'Incident Report Number',
        'medical_diagnosis' => 'Medical Diagnosis',
        'hospital_name' => 'Hospital Name',
        'medical_bill_amount' => 'Medical Bill Amount',
        'doctor_name' => 'Attending Doctor',
        'medicine_list' => 'Medicines Needed',
        'medicine_cost' => 'Medicine Cost',
        'deceased_name' => 'Name of Deceased',
        'cause_of_death' => 'Cause of Death',
        'date_of_death' => 'Date of Death',
        'funeral_home' => 'Funeral Home',
        'disaster_type' => 'Disaster Type',
        'property_damage_estimate' => 'Property Damage Estimate',
        'house_damage_status' => 'House Damage Status',
        'evacuation_center' => 'Evacuation Center',
        'has_blotter' => 'Has Barangay Blotter',
        'blotter_number' => 'Blotter Number',
        'police_station' => 'Police Station',
        'perpetrator_name' => 'Perpetrator Name',
        'perpetrator_relation' => 'Perpetrator Relation',
        'assistance_type' => 'Type of Assistance',
        'amount_requested' => 'Amount Requested',
        'reason' => 'Reason for Request',
        'urgency_level' => 'Urgency Level',
        'problem_presented' => 'Problem Presented',
        'additional_notes' => 'Additional Notes',
        'id_type' => 'ID Type Requested',
        'reason_for_application' => 'Reason for Application'
    ];
    return $names[$key] ?? ucfirst(str_replace('_', ' ', $key));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Application Details - MSWDO Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }

        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --radius-2xl: 2rem;
        }

        /* Layout */
        .app {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Navigation */
        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            overflow-y: auto;
            z-index: 40;
            transition: transform 0.3s ease;
        }

        .sidebar-header {
            padding: 28px 24px;
            border-bottom: 1px solid var(--gray-200);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-icon i {
            font-size: 1.3rem;
            color: var(--accent);
        }

        .logo-text h1 {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--primary);
        }

        .logo-text p {
            font-size: 0.65rem;
            color: var(--gray-500);
        }

        .nav-menu {
            padding: 24px 16px;
        }

        .nav-section {
            margin-bottom: 28px;
        }

        .nav-label {
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--gray-400);
            margin-bottom: 12px;
            padding-left: 12px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            margin-bottom: 4px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-item i {
            width: 20px;
            font-size: 1rem;
            color: var(--gray-400);
        }

        .nav-item span {
            font-size: 0.85rem;
            font-weight: 500;
        }

        .nav-item:hover {
            background: var(--gray-100);
            color: var(--primary);
        }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active {
            background: var(--primary);
            color: white;
        }
        .nav-item.active i { color: white; }

        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        
        .submenu {
            margin-left: 36px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 300px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            margin-bottom: 2px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
        }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 32px 40px 80px 40px;
        }

        /* Top Header */
        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--gray-200);
        }

        .page-title h1 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 4px;
        }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 16px;
            background: var(--gray-50);
            padding: 8px 16px 8px 20px;
            border-radius: 40px;
            border: 1px solid var(--gray-200);
        }

        .user-avatar {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        /* Alert */
        .alert {
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85rem;
        }
        .alert-success {
            background: #ECFDF5;
            border-left: 4px solid #059669;
            color: #065F46;
        }

        /* View Card */
        .view-card {
            background: var(--white);
            border-radius: var(--radius-2xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }

        .view-header {
            background: var(--gray-100);
            padding: 24px 28px;
            border-bottom: 1px solid var(--gray-200);
        }

        .view-header h2 {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 40px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .status-pending { background: #FEF3C7; color: #B45309; }
        .status-approved { background: #D1FAE5; color: #065F46; }
        .status-rejected { background: #FEE2E2; color: #991B1B; }
        .status-cancelled { background: var(--gray-100); color: var(--gray-600); }

        .section {
            padding: 24px 28px;
            border-bottom: 1px solid var(--gray-200);
        }
        .section:last-child { border-bottom: none; }

        .section-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 16px;
            border-left: 3px solid var(--secondary);
            padding-left: 12px;
        }

        .section-title i { color: var(--secondary); }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }

        .info-item {
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .info-icon {
            width: 28px;
            height: 28px;
            background: var(--gray-100);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--secondary);
            font-size: 0.75rem;
        }

        .info-content { flex: 1; }
        .info-label {
            font-size: 0.65rem;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 3px;
        }
        .info-value {
            font-size: 0.85rem;
            font-weight: 500;
            color: var(--gray-800);
            word-break: break-word;
        }

        .review-notes {
            background: #FFF9EF;
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            margin-top: 8px;
            border-left: 3px solid var(--accent);
        }

        .btn-group {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--white);
            color: var(--primary);
            padding: 8px 18px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.8rem;
            border: 1px solid var(--gray-200);
            transition: all 0.2s ease;
        }
        .btn-back:hover { background: var(--gray-50); }

        .btn-approve {
            background: #059669;
            color: white;
            padding: 8px 18px;
            border-radius: 40px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-approve:hover { background: #047857; }

        .btn-reject {
            background: #D32F2F;
            color: white;
            padding: 8px 18px;
            border-radius: 40px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-reject:hover { background: #B71C1C; }

        .btn-primary {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
        }
        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
            padding: 8px 16px;
            border-radius: var(--radius-md);
            font-weight: 500;
            cursor: pointer;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1100;
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 500px;
            width: 90%;
            padding: 24px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 4px; }
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: inherit;
        }

        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 39;
            display: none;
        }
        .sidebar-overlay.active { display: block; }

        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.7rem;
            color: var(--gray-600);
            text-decoration: none;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 1.3rem;
            color: var(--gray-700);
            cursor: pointer;
            padding: 8px;
            border-radius: var(--radius-md);
        }
        .menu-toggle:hover { background: var(--gray-100); }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
                box-shadow: var(--shadow-lg);
            }
            .sidebar.open { transform: translateX(0); }
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            .menu-toggle { display: block; }
            .top-header {
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            .info-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }
            .view-header { padding: 16px 20px; }
            .section { padding: 16px 20px; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app">
    <!-- Sidebar Navigation - CORRECTED PATHS for modules folder -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-hand-holding-heart"></i></div>
                <div class="logo-text">
                    <h1>MSWDO Portal</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="household.php" class="nav-item">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <i class="fas fa-file-alt"></i> <span>Reports</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Programs</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="id_applications.php" class="nav-item"><i class="fas fa-id-card"></i> ID Applications</a>
                <a href="financial_assistance.php" class="nav-item"><i class="fas fa-hand-holding-usd"></i> Financial Assistance</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile.php" class="nav-item"><i class="fas fa-user-circle"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Application Details</h1>
                    <p>View complete application information</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small><?php echo ucfirst(str_replace('_', ' ', $role)); ?></small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <!-- Success Message -->
        <?php if($success_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <!-- Action Buttons -->
        <div class="btn-group">
            <a href="../dashboards/mswdstaff_dashboard.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
            <?php if($application['status'] == 'pending'): ?>
                <button onclick="openApproveModal(<?php echo $application['id']; ?>)" class="btn-approve">
                    <i class="fas fa-check-circle"></i> Approve Application
                </button>
                <button onclick="openRejectModal(<?php echo $application['id']; ?>)" class="btn-reject">
                    <i class="fas fa-times-circle"></i> Reject Application
                </button>
            <?php endif; ?>
        </div>

        <!-- View Card -->
        <div class="view-card">
            <div class="view-header">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                    <h2>
                        <i class="fas fa-file-alt"></i> 
                        <?php echo $program_display; ?> Application
                        <small style="font-size: 0.7rem; color: var(--gray-500);">#<?php echo str_pad($application['id'], 6, '0', STR_PAD_LEFT); ?></small>
                    </h2>
                    <span class="status-badge <?php echo getStatusClass($application['status']); ?>">
                        <i class="fas <?php echo getStatusIcon($application['status']); ?>"></i> 
                        <?php echo ucfirst($application['status']); ?>
                    </span>
                </div>
            </div>

            <!-- Applicant Information -->
            <div class="section">
                <div class="section-title">
                    <i class="fas fa-user-circle"></i>
                    <span>Applicant Information</span>
                </div>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-user"></i></div>
                        <div class="info-content">
                            <div class="info-label">Full Name</div>
                            <div class="info-value"><?php echo htmlspecialchars($application['applicant_name'] ?? 'N/A'); ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-user-circle"></i></div>
                        <div class="info-content">
                            <div class="info-label">Username</div>
                            <div class="info-value"><?php echo htmlspecialchars($application['username'] ?? 'N/A'); ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-envelope"></i></div>
                        <div class="info-content">
                            <div class="info-label">Email</div>
                            <div class="info-value"><?php echo htmlspecialchars($application['email'] ?? 'N/A'); ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-phone"></i></div>
                        <div class="info-content">
                            <div class="info-label">Contact Number</div>
                            <div class="info-value"><?php echo htmlspecialchars($application['contact_number'] ?? 'N/A'); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Application Data -->
            <?php if($app_data && is_array($app_data) && count($app_data) > 0): ?>
            <div class="section">
                <div class="section-title">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Application Details</span>
                </div>
                <div class="info-grid">
                    <?php foreach($app_data as $key => $value): ?>
                        <?php if(!empty($value) && $value !== 'null' && $value !== '[]'): ?>
                            <div class="info-item">
                                <div class="info-icon"><i class="fas fa-info-circle"></i></div>
                                <div class="info-content">
                                    <div class="info-label"><?php echo formatFieldName($key); ?></div>
                                    <div class="info-value">
                                        <?php 
                                        if(is_array($value)) {
                                            echo '<pre style="font-size:0.75rem; margin:0;">' . htmlspecialchars(json_encode($value, JSON_PRETTY_PRINT)) . '</pre>';
                                        } else {
                                            echo nl2br(htmlspecialchars($value));
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Review Notes -->
            <?php if($application['review_notes']): ?>
            <div class="section">
                <div class="section-title">
                    <i class="fas fa-comment-dots"></i>
                    <span>Review Notes</span>
                </div>
                <div class="review-notes">
                    <p><?php echo nl2br(htmlspecialchars($application['review_notes'])); ?></p>
                    <?php if($application['reviewed_by']): ?>
                        <small style="display: block; margin-top: 8px; color: var(--gray-500);">
                            <i class="fas fa-user-check"></i> Reviewed by: Staff ID #<?php echo $application['reviewed_by']; ?>
                        </small>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Timestamps -->
            <div class="section">
                <div class="section-title">
                    <i class="fas fa-history"></i>
                    <span>Record Information</span>
                </div>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-calendar-plus"></i></div>
                        <div class="info-content">
                            <div class="info-label">Submitted Date</div>
                            <div class="info-value"><?php echo date('F d, Y h:i A', strtotime($application['created_at'])); ?></div>
                        </div>
                    </div>
                    <?php if($application['updated_at'] != $application['created_at']): ?>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-calendar-edit"></i></div>
                        <div class="info-content">
                            <div class="info-label">Last Updated</div>
                            <div class="info-value"><?php echo date('F d, Y h:i A', strtotime($application['updated_at'])); ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>
</div>

<!-- Approve Modal -->
<div id="approveModal" class="modal">
    <div class="modal-content">
        <h3><i class="fas fa-check-circle" style="color: #059669;"></i> Approve Application</h3>
        <form method="POST" action="">
            <input type="hidden" name="application_id" id="approveAppId">
            <div class="form-group">
                <label>Approval Notes (Optional)</label>
                <textarea name="review_notes" id="approveNotes" rows="3" placeholder="Add any notes about this approval..."></textarea>
            </div>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button type="button" class="btn-secondary" onclick="closeModal('approveModal')">Cancel</button>
                <button type="submit" name="approve_application" class="btn-primary" style="background: #059669;">Confirm Approval</button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal">
    <div class="modal-content">
        <h3><i class="fas fa-times-circle" style="color: #D32F2F;"></i> Reject Application</h3>
        <form method="POST" action="">
            <input type="hidden" name="application_id" id="rejectAppId">
            <div class="form-group">
                <label>Reason for Rejection <span style="color: #D32F2F;">*</span></label>
                <textarea name="review_notes" id="rejectNotes" rows="4" required placeholder="Please provide the reason for rejecting this application..."></textarea>
            </div>
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button type="button" class="btn-secondary" onclick="closeModal('rejectModal')">Cancel</button>
                <button type="submit" name="reject_application" class="btn-primary" style="background: #D32F2F;">Confirm Rejection</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Mobile menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
        });
    }
    if(overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
    }
    
    // Collapsible Program Menu
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
    
    // Modal functions
    function openApproveModal(id) {
        document.getElementById('approveAppId').value = id;
        document.getElementById('approveModal').style.display = 'flex';
    }
    
    function openRejectModal(id) {
        document.getElementById('rejectAppId').value = id;
        document.getElementById('rejectModal').style.display = 'flex';
    }
    
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
    
    // Close modals when clicking outside
    window.onclick = function(event) {
        if(event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    }
</script>
</body>
</html>