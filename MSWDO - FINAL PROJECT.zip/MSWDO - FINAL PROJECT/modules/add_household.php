<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

// Function to classify poverty
function classifyPovertyIncome($income) {
    if($income < 5000) return 'Extremely Poor';
    elseif($income >= 5000 && $income <= 10000) return 'Poor';
    elseif($income >= 10001 && $income <= 15000) return 'Low Income';
    elseif($income >= 15001 && $income <= 25000) return 'Lower Middle';
    elseif($income > 25000) return 'Middle Income and Above';
    else return 'Not Classified';
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $barangay = trim($_POST['barangay'] ?? '');
    $monthly_income = floatval($_POST['monthly_income'] ?? 0);
    $total_members = intval($_POST['total_members'] ?? 1);
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $province = trim($_POST['province'] ?? '');
    $is_4ps = isset($_POST['is_4ps']) ? 1 : 0;
    $poverty_status = classifyPovertyIncome($monthly_income);
    
    $errors = [];
    if(empty($first_name)) $errors[] = "First name is required";
    if(empty($last_name)) $errors[] = "Last name is required";
    if(empty($barangay)) $errors[] = "Barangay is required";
    
    if(empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO households (
                    head_first_name, head_last_name, address, barangay, 
                    city_municipality, province, total_members, monthly_income, 
                    is_4ps_beneficiary, poverty_status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            $stmt->execute([
                $first_name, $last_name, $address, $barangay,
                $city, $province, $total_members, $monthly_income,
                $is_4ps, $poverty_status
            ]);
            $_SESSION['upload_success'] = "Household record added successfully!";
        } catch(PDOException $e) {
            $_SESSION['upload_error'] = "Database error: " . $e->getMessage();
        }
    } else {
        $_SESSION['upload_error'] = implode(", ", $errors);
    }
}

header("Location: household.php");
exit();
?>