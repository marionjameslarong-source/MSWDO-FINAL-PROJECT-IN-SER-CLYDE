<?php
// ============================================================================
// admin_gps_map.php - ADMIN GPS MAP VIEWER
// ============================================================================
// Purpose: Admin verification tool to view all resident-submitted GPS
//          coordinates strictly within Cantilan, Surigao del Sur bounds.
// ============================================================================
session_start();
require_once '../config/database.php';

// Admin only
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];

// ============================================================================
// FETCH HOUSEHOLDS WITH GPS COORDINATES
// ============================================================================
$households = [];
try {
    $stmt = $pdo->query("
        SELECT 
            h.id,
            h.user_id,
            h.head_first_name,
            h.head_last_name,
            h.barangay,
            h.physical_address,
            h.address,
            h.latitude,
            h.longitude,
            h.monthly_income,
            h.poverty_status,
            h.total_members,
            h.created_at,
            u.contact_number,
            u.full_name AS user_name,
            u.email AS user_email
        FROM households h
        LEFT JOIN users u ON h.user_id = u.id
        WHERE h.latitude IS NOT NULL 
        AND h.longitude IS NOT NULL
        AND h.latitude != 0
        AND h.longitude != 0
        ORDER BY h.created_at DESC
    ");
    $households = $stmt->fetchAll();
} catch(PDOException $e) {
    $households = [];
}

// ============================================================================
// GET BARANGAY LIST - 17 Official Cantilan Barangays (Fallback List)
// ============================================================================
$cantilan_barangays = [
    'Bugsukan', 'Cantilan Centro', 'Consuelo', 'Gamuton', 'Lobo',
    'Magsilom', 'Pag-antan', 'Pantukan', 'Parang', 'Quirino',
    'Adlay', 'Bon-ot', 'Cagdianao', 'General Island', 'San Juan',
    'Carrascal', 'Panikian'
];

$barangays = [];
try {
    $stmt = $pdo->query("
        SELECT DISTINCT barangay 
        FROM households 
        WHERE barangay IS NOT NULL AND barangay != ''
        ORDER BY barangay
    ");
    $db_barangays = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Merge with official list, remove duplicates
    $barangays = array_unique(array_merge($db_barangays, $cantilan_barangays));
    sort($barangays);
} catch(PDOException $e) {
    $barangays = $cantilan_barangays;
}

// ============================================================================
// STATISTICS
// ============================================================================
$total_with_gps = count($households);
$total_households = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM households");
    $total_households = $stmt->fetch()['total'];
} catch(PDOException $e) {}

$coverage = $total_households > 0 ? round(($total_with_gps / $total_households) * 100, 1) : 0;

// Deleted count for recycle bin badge
$deleted_count = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
    $deleted_count = $stmt->fetch()['total'];
} catch(PDOException $e) {}

// Count by poverty status
$poor_count = 0;
$middle_count = 0;
$rich_count = 0;
foreach($households as $h) {
    $status = strtoupper($h['poverty_status'] ?? '');
    if($status === 'POOR' || $status === 'SUBSISTENCE_POOR') $poor_count++;
    elseif($status === 'MIDDLE_CLASS') $middle_count++;
    elseif($status === 'RICH') $rich_count++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GPS Household Locator - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        /* ====================================================================
           SIDEBAR
           ==================================================================== */
        .sidebar {
            position: fixed;
            top: 0; left: 0;
            height: 100%; width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed; inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999; display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 10px; }
        .logo-icon {
            width: 40px; height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
        }
        .logo-icon i { font-size: 1.2rem; color: var(--accent); }
        .logo-text h1 { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.6rem; color: var(--gray-500); }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.65rem; font-weight: 600; text-transform: uppercase;
            color: var(--gray-500); margin-bottom: 8px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 12px; border-radius: var(--radius-md);
            color: var(--gray-600); text-decoration: none;
            font-size: 0.85rem; transition: all 0.2s ease;
        }
        .nav-item i { width: 20px; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }

        /* ====================================================================
           MAIN CONTENT
           ==================================================================== */
        .main-content {
            width: 100%; min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); width: 260px; }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }

        /* Top Bar */
        .top-bar {
            background: var(--white);
            padding: 12px 20px;
            border-radius: var(--radius-lg);
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px; border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm); flex-wrap: wrap; gap: 12px;
        }
        .menu-toggle {
            background: none; border: none;
            font-size: 1.3rem; cursor: pointer;
            padding: 8px; color: var(--gray-600);
        }
        .page-title h1 { font-size: 1.3rem; font-weight: 600; color: var(--gray-800); }
        .page-title p { font-size: 0.7rem; color: var(--gray-500); margin-top: 2px; }
        .cantilan-badge {
            display: inline-block;
            background: var(--primary); color: white;
            padding: 2px 12px; border-radius: 20px;
            font-size: 0.65rem; font-weight: 600;
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px;
            background: var(--gray-50); padding: 6px 12px;
            border-radius: 40px; text-decoration: none; color: inherit;
        }
        .user-avatar {
            width: 32px; height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 500; }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }

        /* Info Banner */
        .cantilan-info {
            background: linear-gradient(135deg, #1E4A8C, #0A2F6C);
            color: white;
            padding: 16px 20px;
            border-radius: var(--radius-xl);
            margin-bottom: 20px;
            display: flex; justify-content: space-between;
            align-items: center; flex-wrap: wrap; gap: 12px;
        }
        .cantilan-info .info-title {
            font-size: 1.1rem; font-weight: 700;
            display: flex; align-items: center; gap: 10px;
        }
        .cantilan-info .info-stats {
            display: flex; gap: 20px; font-size: 0.8rem; flex-wrap: wrap;
        }
        .cantilan-info .info-stats span {
            background: rgba(255,255,255,0.15);
            padding: 4px 14px; border-radius: 20px;
        }

        /* Stats Row */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 12px; margin-bottom: 20px;
        }
        .stat-box {
            background: white; padding: 14px 16px;
            border-radius: var(--radius-lg); border: 1px solid var(--gray-200);
            display: flex; align-items: center; gap: 12px;
        }
        .stat-icon {
            width: 42px; height: 42px;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem; flex-shrink: 0;
        }
        .stat-icon.blue { background: #DBEAFE; color: #1E40AF; }
        .stat-icon.green { background: #D1FAE5; color: #065F46; }
        .stat-icon.red { background: #FEE2E2; color: #991B1B; }
        .stat-icon.orange { background: #FEF3C7; color: #B45309; }
        .stat-content .num { font-size: 1.3rem; font-weight: 700; color: var(--gray-800); line-height: 1.2; }
        .stat-content .lbl { font-size: 0.65rem; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.3px; }

        /* Filter Bar */
        .filter-bar {
            background: white; padding: 14px 16px;
            border-radius: var(--radius-lg); border: 1px solid var(--gray-200);
            margin-bottom: 16px;
            display: flex; gap: 12px; flex-wrap: wrap; align-items: center;
        }
        .filter-bar label {
            font-size: 0.75rem; font-weight: 600;
            color: var(--gray-500); text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .filter-bar select,
        .filter-bar input {
            padding: 8px 12px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.85rem; font-family: inherit;
            min-width: 150px;
        }
        .filter-bar select:focus,
        .filter-bar input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(30,74,140,0.1);
        }
        .btn {
            padding: 8px 18px;
            border-radius: var(--radius-md);
            border: none; font-weight: 600;
            font-size: 0.8rem; cursor: pointer;
            display: inline-flex; align-items: center; gap: 6px;
            transition: all 0.2s;
        }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); }
        .btn-secondary { background: var(--gray-100); color: var(--gray-700); }
        .btn-secondary:hover { background: var(--gray-200); }

        /* Map Container */
        .map-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            position: relative;
            margin-bottom: 20px;
        }
        #adminMap {
            height: 620px;
            width: 100%;
            background: #E8EDF2;
        }
        .map-header {
            padding: 12px 20px;
            background: linear-gradient(135deg, #1E4A8C, #0A2F6C);
            color: white;
            display: flex; justify-content: space-between;
            align-items: center; flex-wrap: wrap; gap: 12px;
        }
        .map-header h4 {
            font-size: 0.9rem;
            display: flex; align-items: center; gap: 8px;
        }
        .map-header .pin-count {
            font-size: 0.75rem;
            background: rgba(255,255,255,0.15);
            padding: 4px 12px; border-radius: 20px;
        }

        /* Legend */
        .legend {
            background: white;
            padding: 12px 16px;
            border-radius: var(--radius-md);
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
            font-size: 0.75rem;
            line-height: 1.8;
            border: 1px solid var(--gray-200);
        }
        .legend b {
            color: var(--gray-800);
            display: block;
            margin-bottom: 6px;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .legend .dot {
            display: inline-block;
            width: 10px; height: 10px;
            border-radius: 50%;
            margin-right: 8px;
            vertical-align: middle;
            border: 2px solid white;
            box-shadow: 0 0 3px rgba(0,0,0,0.2);
        }
        .legend .dot.poor { background: #D32F2F; }
        .legend .dot.middle { background: #1E4A8C; }
        .legend .dot.rich { background: #F5B042; }
        .legend .dot.unknown { background: #94A3B8; }
        .legend .dot.center { background: #7C3AED; }

        /* Popup Custom Styles */
        .leaflet-popup-content-wrapper {
            border-radius: 12px !important;
            padding: 0 !important;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15) !important;
        }
        .leaflet-popup-content {
            margin: 0 !important;
            padding: 16px !important;
            min-width: 240px;
            font-family: 'Inter', sans-serif;
        }
        .popup-header {
            font-weight: 700;
            font-size: 0.95rem;
            color: #1E293B;
            margin-bottom: 8px;
            padding-bottom: 8px;
            border-bottom: 1px solid #E2E8F0;
        }
        .popup-row {
            font-size: 0.8rem;
            color: #475569;
            padding: 3px 0;
            display: flex;
            align-items: flex-start;
            gap: 6px;
        }
        .popup-row i {
            color: #94A3B8;
            font-size: 0.75rem;
            width: 14px;
            margin-top: 3px;
        }
        .popup-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            margin-top: 6px;
        }
        .popup-badge.poor { background: #FEE2E2; color: #991B1B; }
        .popup-badge.middle { background: #DBEAFE; color: #1E40AF; }
        .popup-badge.rich { background: #FEF3C7; color: #B45309; }
        .popup-badge.unknown { background: #F1F5F9; color: #475569; }

        /* Empty State */
        .empty-map {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        .empty-map i {
            font-size: 4rem;
            color: var(--gray-300);
            margin-bottom: 16px;
        }

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            background: var(--white);
            display: flex; justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex; flex-direction: column;
            align-items: center;
            font-size: 0.7rem; color: var(--gray-600);
            text-decoration: none;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        @media (max-width: 768px) {
            #adminMap { height: 450px; }
            .filter-bar { flex-direction: column; align-items: stretch; }
            .filter-bar select, .filter-bar input { width: 100%; }
            .filter-bar .btn { width: 100%; justify-content: center; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ====================================================================
    SIDEBAR
    ==================================================================== -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-hand-holding-heart"></i></div>
                <div class="logo-text">
                    <h1>MSWDO Portal</h1>
                    <p>Administrator</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="manage_users.php" class="nav-item">
                    <i class="fas fa-users-cog"></i> <span>User Management</span>
                </a>
                <a href="admin_household.php" class="nav-item">
                    <i class="fas fa-home"></i> <span>All Households</span>
                </a>
                <a href="admin_povertyanalysis.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Poverty Analysis</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="admin_gps_map.php" class="nav-item active">
                    <i class="fas fa-map-marker-alt"></i> <span>GPS</span>
                </a>
                <a href="admin_reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
                <a href="../admin/recycle_bin.php" class="nav-item">
                    <i class="fas fa-trash-restore"></i> <span>Recycle Bin</span>
                    <?php if($deleted_count > 0): ?>
                        <span style="margin-left: auto; background: var(--secondary); color: white; padding: 0px 8px; border-radius: 20px; font-size: 0.65rem;"><?php echo $deleted_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="admin_profile.php" class="nav-item">
                    <i class="fas fa-user-cog"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- ====================================================================
    MAIN CONTENT
    ==================================================================== -->
    <main class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>GPS Household Locator <span class="cantilan-badge">📍 Cantilan</span></h1>
                    <p>Verify and navigate resident-submitted household coordinates</p>
                </div>
            </div>
            <a href="admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Cantilan Info Banner -->
        <div class="cantilan-info">
            <div class="info-title">
                <i class="fas fa-map-pin"></i> Cantilan, Surigao del Sur
            </div>
            <div class="info-stats">
                <span><i class="fas fa-dot-circle"></i> <?php echo $total_with_gps; ?> Mapped Households</span>
                <span><i class="fas fa-lock"></i> Geofenced Boundary</span>
                <span><i class="fas fa-chart-line"></i> <?php echo $coverage; ?>% Coverage</span>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="stats-row">
            <div class="stat-box">
                <div class="stat-icon blue"><i class="fas fa-map-marker-alt"></i></div>
                <div class="stat-content">
                    <div class="num"><?php echo $total_with_gps; ?></div>
                    <div class="lbl">Mapped</div>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-icon green"><i class="fas fa-home"></i></div>
                <div class="stat-content">
                    <div class="num"><?php echo $total_households; ?></div>
                    <div class="lbl">Total Households</div>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-icon red"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-content">
                    <div class="num"><?php echo $poor_count; ?></div>
                    <div class="lbl">Poor</div>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-icon orange"><i class="fas fa-map"></i></div>
                <div class="stat-content">
                    <div class="num"><?php echo count($barangays); ?></div>
                    <div class="lbl">Barangays</div>
                </div>
            </div>
        </div>

        <!-- Filter Bar -->
        <div class="filter-bar">
            <label><i class="fas fa-filter"></i> Filter:</label>
            
            <select id="filterBarangay">
                <option value="">All Barangays</option>
                <?php foreach($barangays as $b): ?>
                    <option value="<?php echo htmlspecialchars($b); ?>">
                        <?php echo htmlspecialchars($b); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select id="filterPoverty">
                <option value="">All Poverty Status</option>
                <option value="POOR">Poor</option>
                <option value="MIDDLE_CLASS">Middle-Class</option>
                <option value="RICH">Rich</option>
            </select>

            <input type="text" id="filterSearch" placeholder="Search household head...">

            <button class="btn btn-primary" onclick="applyFilters()">
                <i class="fas fa-search"></i> Apply
            </button>
            <button class="btn btn-secondary" onclick="resetFilters()">
                <i class="fas fa-redo"></i> Reset
            </button>
        </div>

        <!-- Map Container -->
        <div class="map-container">
            <div class="map-header">
                <h4><i class="fas fa-map-marked-alt"></i> Household Locations</h4>
                <div class="pin-count">
                    <i class="fas fa-dot-circle"></i> <span id="visibleCount"><?php echo $total_with_gps; ?></span> pins visible
                </div>
            </div>
            <div id="adminMap"></div>
        </div>

        <!-- Empty state if no data -->
        <?php if($total_with_gps == 0): ?>
        <div class="empty-map">
            <i class="fas fa-map-marked-alt"></i>
            <h3 style="color:var(--gray-700);margin-bottom:8px;">No GPS Data Yet</h3>
            <p>No residents have submitted GPS coordinates yet.</p>
            <p style="font-size:0.8rem;margin-top:8px;">Residents can submit their location from the resident dashboard.</p>
        </div>
        <?php endif; ?>
    </main>

    <!-- ====================================================================
    BOTTOM NAVIGATION (Mobile)
    ==================================================================== -->
    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="admin_gps_map.php" class="nav-item active"><i class="fas fa-map-marker-alt"></i><span>GPS</span></a>
        <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <script>
        // ====================================================================
        // CANTILAN GEOFENCE CONFIGURATION
        // ====================================================================
        const CANTILAN_CENTER = [9.3348, 125.9757];  // Cantilan Town Proper
        const ZOOM_LEVEL = 14;

        // Strict Bounding Box Constraints
        const CANTILAN_BOUNDS = L.latLngBounds(
            [9.2000, 125.8000],  // South, West
            [9.4500, 126.1000]   // North, East
        );

        // Household data from PHP
        const households = <?php echo json_encode($households); ?>;

        // ====================================================================
        // INITIALIZE MAP WITH RESTRICTIONS
        // ====================================================================
        const map = L.map('adminMap', {
            center: CANTILAN_CENTER,
            zoom: ZOOM_LEVEL,
            maxBounds: CANTILAN_BOUNDS,
            maxBoundsViscosity: 1.0,
            minZoom: 12,
            maxZoom: 18
        });

        // OpenStreetMap tiles (no API key needed)
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(map);

        // ====================================================================
        // CANTILAN BOUNDARY OUTLINE
        // ====================================================================
        // Approximate Cantilan municipal boundary polygon
        const cantilanBoundary = [
            [9.2000, 125.8000], // SW corner
            [9.2000, 126.1000], // SE corner
            [9.4500, 126.1000], // NE corner
            [9.4500, 125.8000], // NW corner
            [9.2000, 125.8000]  // close
        ];

        // Draw boundary outline
        L.polygon(cantilanBoundary, {
            color: '#1E4A8C',
            weight: 3,
            opacity: 0.7,
            fillColor: '#1E4A8C',
            fillOpacity: 0.03,
            dashArray: '10, 5',
            interactive: false
        }).addTo(map);

        // Add center marker for Cantilan
        const centerMarker = L.marker(CANTILAN_CENTER, {
            icon: L.divIcon({
                className: 'cantilan-center-marker',
                html: `<div style="background: #7C3AED; width: 28px; height: 28px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 10px rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; font-size: 13px; color: white;">🏛️</div>`,
                iconSize: [28, 28],
                iconAnchor: [14, 14]
            }),
            zIndexOffset: 1000
        }).addTo(map);

        centerMarker.bindPopup(`
            <div style="text-align:center;">
                <div style="font-weight:700;font-size:1rem;color:#1E293B;">🏛️ Cantilan Town Proper</div>
                <div style="font-size:0.75rem;color:#64748B;margin-top:4px;">
                    Center: ${CANTILAN_CENTER[0]}, ${CANTILAN_CENTER[1]}<br>
                    Barangays: <?php echo count($barangays); ?> mapped
                </div>
            </div>
        `);

        // ====================================================================
        // MARKER LAYER
        // ====================================================================
        const markerLayer = L.layerGroup().addTo(map);

        // ====================================================================
        // LEGEND
        // ====================================================================
        const legend = L.control({ position: 'bottomright' });
        legend.onAdd = function() {
            const div = L.DomUtil.create('div', 'legend');
            div.innerHTML = `
                <b>Poverty Status</b>
                <span class="dot poor"></span> Poor<br>
                <span class="dot middle"></span> Middle-Class<br>
                <span class="dot rich"></span> Rich<br>
                <span class="dot unknown"></span> Not Classified<br>
                <span class="dot center"></span> Town Center
            `;
            return div;
        };
        legend.addTo(map);

        // Scale control
        L.control.scale({
            position: 'bottomleft',
            metric: true,
            imperial: false
        }).addTo(map);

        // ====================================================================
        // HELPER FUNCTIONS
        // ====================================================================
        function getPovertyColor(status) {
            const s = String(status || '').toUpperCase();
            if (s === 'POOR' || s === 'SUBSISTENCE_POOR') return '#D32F2F';
            if (s === 'MIDDLE_CLASS') return '#1E4A8C';
            if (s === 'RICH') return '#F5B042';
            return '#94A3B8';
        }

        function getPovertyBadgeClass(status) {
            const s = String(status || '').toUpperCase();
            if (s === 'POOR' || s === 'SUBSISTENCE_POOR') return 'poor';
            if (s === 'MIDDLE_CLASS') return 'middle';
            if (s === 'RICH') return 'rich';
            return 'unknown';
        }

        function getPovertyLabel(status) {
            const s = String(status || '').toUpperCase();
            if (s === 'POOR' || s === 'SUBSISTENCE_POOR') return 'Poor';
            if (s === 'MIDDLE_CLASS') return 'Middle-Class';
            if (s === 'RICH') return 'Rich';
            return 'Not Classified';
        }

        function escapeHtml(t) {
            if (!t) return '';
            return String(t).replace(/[&<>"']/g, m => ({
                '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
            }[m]));
        }

        function formatMoney(n) {
            return '₱' + Number(n || 0).toLocaleString('en-PH', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        // ====================================================================
        // CHECK IF POINT IS WITHIN CANTILAN BOUNDS
        // ====================================================================
        function isWithinCantilan(lat, lng) {
            return CANTILAN_BOUNDS.contains([lat, lng]);
        }

        // ====================================================================
        // RENDER MARKERS
        // ====================================================================
        function renderMarkers(data) {
            markerLayer.clearLayers();
            let rendered = 0;
            let outOfBounds = 0;

            data.forEach(h => {
                const lat = parseFloat(h.latitude);
                const lng = parseFloat(h.longitude);
                
                if (isNaN(lat) || isNaN(lng)) return;
                
                // Skip if outside Cantilan bounds (safety check)
                if (!isWithinCantilan(lat, lng)) {
                    outOfBounds++;
                    return;
                }

                const color = getPovertyColor(h.poverty_status);
                const badgeClass = getPovertyBadgeClass(h.poverty_status);
                const badgeLabel = getPovertyLabel(h.poverty_status);

                // Create custom marker
                const marker = L.circleMarker([lat, lng], {
                    radius: 8,
                    fillColor: color,
                    color: 'white',
                    weight: 2.5,
                    opacity: 1,
                    fillOpacity: 0.9
                });

                const name = ((h.head_first_name || '') + ' ' + (h.head_last_name || '')).trim() || 'Unknown Household';
                const address = h.physical_address || h.address || 'No address provided';
                const householdId = h.id || 'N/A';

                marker.bindPopup(`
                    <div class="popup-header">${escapeHtml(name)}</div>
                    <div class="popup-row">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${escapeHtml(h.barangay || 'N/A')}</span>
                    </div>
                    <div class="popup-row">
                        <i class="fas fa-home"></i>
                        <span>${escapeHtml(address)}</span>
                    </div>
                    <div class="popup-row">
                        <i class="fas fa-users"></i>
                        <span>${h.total_members || 0} members</span>
                    </div>
                    <div class="popup-row">
                        <i class="fas fa-money-bill-wave"></i>
                        <span>${formatMoney(h.monthly_income)}</span>
                    </div>
                    <div class="popup-row">
                        <i class="fas fa-phone"></i>
                        <span>${escapeHtml(h.contact_number || 'N/A')}</span>
                    </div>
                    <div class="popup-row">
                        <i class="fas fa-hashtag"></i>
                        <span>HH ID: ${householdId}</span>
                    </div>
                    <span class="popup-badge ${badgeClass}">${badgeLabel}</span>
                `);

                markerLayer.addLayer(marker);
                rendered++;
            });

            // Update visible count
            document.getElementById('visibleCount').textContent = rendered;

            // Fit map to visible markers if any
            if (rendered > 0 && rendered < households.length) {
                const pts = data
                    .filter(h => h.latitude && h.longitude)
                    .filter(h => isWithinCantilan(parseFloat(h.latitude), parseFloat(h.longitude)))
                    .map(h => [parseFloat(h.latitude), parseFloat(h.longitude)]);
                
                if (pts.length > 0) {
                    map.fitBounds(pts, { 
                        padding: [50, 50], 
                        maxZoom: 16 
                    });
                }
            }

            return { rendered, outOfBounds };
        }

        // ====================================================================
        // FILTERS
        // ====================================================================
        function applyFilters() {
            const brgy = document.getElementById('filterBarangay').value;
            const pov = document.getElementById('filterPoverty').value;
            const search = document.getElementById('filterSearch').value.toLowerCase().trim();

            let filtered = households.filter(h => {
                // Barangay filter
                if (brgy && h.barangay !== brgy) return false;
                
                // Poverty filter
                if (pov) {
                    const status = String(h.poverty_status || '').toUpperCase();
                    if (pov === 'POOR' && status !== 'POOR' && status !== 'SUBSISTENCE_POOR') return false;
                    if (pov === 'MIDDLE_CLASS' && status !== 'MIDDLE_CLASS') return false;
                    if (pov === 'RICH' && status !== 'RICH') return false;
                }
                
                // Search filter
                if (search) {
                    const name = ((h.head_first_name || '') + ' ' + (h.head_last_name || '')).toLowerCase();
                    const address = String(h.address || h.physical_address || '').toLowerCase();
                    if (!name.includes(search) && !address.includes(search)) return false;
                }
                
                return true;
            });

            renderMarkers(filtered);
        }

        function resetFilters() {
            document.getElementById('filterBarangay').value = '';
            document.getElementById('filterPoverty').value = '';
            document.getElementById('filterSearch').value = '';
            renderMarkers(households);
            map.setView(CANTILAN_CENTER, ZOOM_LEVEL);
        }

        // Live search on input change
        document.getElementById('filterSearch').addEventListener('input', applyFilters);
        document.getElementById('filterBarangay').addEventListener('change', applyFilters);
        document.getElementById('filterPoverty').addEventListener('change', applyFilters);

        // ====================================================================
        // INITIAL RENDER
        // ====================================================================
        const result = renderMarkers(households);
        
        console.log('✅ Cantilan GPS Map loaded');
        console.log('📍 Center:', CANTILAN_CENTER);
        console.log('🔒 Bounds:', CANTILAN_BOUNDS.toBBoxString());
        console.log('🏘️ Households with GPS:', households.length);
        console.log('📌 Pins rendered:', result.rendered);
        if (result.outOfBounds > 0) {
            console.warn('⚠️ ' + result.outOfBounds + ' households outside Cantilan bounds (skipped)');
        }

        // ====================================================================
        // SIDEBAR TOGGLE
        // ====================================================================
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        if(menuToggle) menuToggle.onclick = () => {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
        };
        if(overlay) overlay.onclick = () => {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        };

        // Close sidebar on desktop resize
        window.addEventListener('resize', function() {
            if (window.innerWidth >= 992) {
                sidebar.classList.remove('open');
                overlay.classList.remove('active');
            }
        });
    </script>
</body>
</html>