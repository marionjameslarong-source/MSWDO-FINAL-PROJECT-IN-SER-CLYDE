<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$error = '';
$success = '';
$new_household_id = null;

// Get sidebar household ID for dynamic navigation
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get unread notification count for sidebar badge
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

// Function to classify poverty based on income
function classifyPoverty($income) {
    if($income < 5000) return 'Extremely Poor';
    elseif($income >= 5000 && $income <= 10000) return 'Poor';
    elseif($income >= 10001 && $income <= 15000) return 'Low Income';
    elseif($income >= 15001 && $income <= 25000) return 'Lower Middle';
    elseif($income > 25000) return 'Middle Income and Above';
    else return 'Not Classified';
}

// Handle form submission - NEW HOUSEHOLD REGISTRATION
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_household'])) {
    $errors = [];
    
    $head_first_name = trim($_POST['head_first_name'] ?? '');
    $head_middle_name = trim($_POST['head_middle_name'] ?? '');
    $head_last_name = trim($_POST['head_last_name'] ?? '');
    $head_suffix = trim($_POST['head_suffix'] ?? '');
    $barangay = trim($_POST['barangay'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city_municipality = trim($_POST['city_municipality'] ?? '');
    $province = trim($_POST['province'] ?? '');
    $zip_code = trim($_POST['zip_code'] ?? '');
    $monthly_income = floatval($_POST['monthly_income'] ?? 0);
    $total_members = intval($_POST['total_members'] ?? 1);
    $is_4ps_beneficiary = isset($_POST['is_4ps_beneficiary']) ? 1 : 0;
    $contact_number = trim($_POST['contact_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $head_birthdate = $_POST['head_birthdate'] ?? null;
    $head_age = intval($_POST['head_age'] ?? 0);
    $head_sex = $_POST['head_sex'] ?? '';
    $civil_status = $_POST['civil_status'] ?? '';
    $income_source = trim($_POST['income_source'] ?? '');
    $housing_type = $_POST['housing_type'] ?? '';
    $water_source = $_POST['water_source'] ?? '';
    $toilet_type = $_POST['toilet_type'] ?? '';
    
    $latitude = !empty($_POST['latitude']) ? $_POST['latitude'] : null;
    $longitude = !empty($_POST['longitude']) ? $_POST['longitude'] : null;
    
    $poverty_status = classifyPoverty($monthly_income);
    
    if(empty($head_first_name)) $errors[] = "Head of family first name is required.";
    if(empty($head_last_name)) $errors[] = "Head of family last name is required.";
    if(empty($barangay)) $errors[] = "Barangay is required.";
    if(empty($address)) $errors[] = "Address is required.";
    
    $affidavit_photo_path = null;
    if(isset($_FILES['affidavit_photo']) && $_FILES['affidavit_photo']['error'] == 0) {
        $upload_dir = '../uploads/affidavits/';
        if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $affidavit_photo_path = $upload_dir . time() . '_' . $user_id . '_affidavit.jpg';
        move_uploaded_file($_FILES['affidavit_photo']['tmp_name'], $affidavit_photo_path);
    } else {
        $errors[] = "Please capture the photo-affidavit (client holding ID).";
    }
    
    if(empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->query("SHOW COLUMNS FROM households");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $insert_fields = [
                'head_first_name', 'head_middle_name', 'head_last_name', 'head_suffix',
                'barangay', 'address', 'city_municipality', 'province', 'zip_code',
                'monthly_income', 'total_members', 'is_4ps_beneficiary',
                'latitude', 'longitude', 'poverty_status', 'affidavit_photo',
                'contact_number', 'email', 'head_birthdate', 'head_age', 'head_sex',
                'civil_status', 'income_source', 'housing_type', 'water_source', 'toilet_type',
                'user_id', 'created_at'
            ];
            
            $placeholders = implode(', ', array_fill(0, count($insert_fields), '?'));
            $field_names = implode(', ', $insert_fields);
            
            $stmt = $pdo->prepare("INSERT INTO households ($field_names) VALUES ($placeholders)");
            
            $values = [
                $head_first_name,
                $head_middle_name,
                $head_last_name,
                $head_suffix,
                $barangay,
                $address,
                $city_municipality,
                $province,
                $zip_code,
                $monthly_income,
                $total_members,
                $is_4ps_beneficiary,
                $latitude,
                $longitude,
                $poverty_status,
                $affidavit_photo_path,
                $contact_number,
                $email,
                $head_birthdate,
                $head_age,
                $head_sex,
                $civil_status,
                $income_source,
                $housing_type,
                $water_source,
                $toilet_type,
                $user_id,
                date('Y-m-d H:i:s')
            ];
            
            $stmt->execute($values);
            $new_household_id = $pdo->lastInsertId();
            
            $eligibility_alerts = [];
            
            if($head_age >= 60) {
                $eligibility_alerts[] = [
                    'program' => 'Senior Citizen',
                    'message' => 'Household head is eligible for Senior Citizen program.',
                    'link' => '../seniorcitizen.php'
                ];
            }
            
            if(($civil_status == 'Widowed' || $civil_status == 'Separated' || $civil_status == 'Single') && isset($_POST['has_children']) && $_POST['has_children'] == 1) {
                $eligibility_alerts[] = [
                    'program' => 'Solo Parent',
                    'message' => 'Household head may be eligible for Solo Parent program.',
                    'link' => '../soloparent.php'
                ];
            }
            
            if($poverty_status == 'Extremely Poor' || $poverty_status == 'Poor') {
                $eligibility_alerts[] = [
                    'program' => 'AICS',
                    'message' => 'Household qualifies for Assistance to Individuals in Crisis Situation.',
                    'link' => '../aics.php'
                ];
            }
            
            $_SESSION['survey_eligibility'] = $eligibility_alerts;
            $_SESSION['new_household_id'] = $new_household_id;
            
            $pdo->commit();
            
            header("Location: household_data.php?view=" . $new_household_id . "&new=1");
            exit();
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = implode("<br>", $errors);
    }
}

$current_step = isset($_SESSION['survey_step']) ? $_SESSION['survey_step'] : 1;
if(isset($_POST['next_step'])) {
    $_SESSION['survey_step'] = $_POST['current_step'] + 1;
    $current_step = $_SESSION['survey_step'];
    $_SESSION['survey_data'] = $_POST;
}
if(isset($_POST['prev_step'])) {
    $_SESSION['survey_step'] = $_POST['current_step'] - 1;
    $current_step = $_SESSION['survey_step'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Community Survey - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <?= renderPwaMetaTags() ?>
  
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F5F7FB;
            color: #1E2F4E;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        /* Layout */
        .app {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            overflow-y: auto;
            z-index: 40;
            transition: transform 0.3s ease;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--gray-400);
            margin-bottom: 12px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            margin-bottom: 4px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
            position: relative;
        }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge {
            margin-left: auto;
            background: var(--secondary);
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 20px;
            line-height: 1.4;
        }
        .submenu {
            margin-left: 36px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 300px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            margin-bottom: 2px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 0.8rem;
        }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 32px 40px 80px 40px;
        }

        /* Top Header */
        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 16px;
            background: var(--gray-50);
            padding: 8px 16px 8px 20px;
            border-radius: 40px;
            border: 1px solid var(--gray-200);
        }
        .user-avatar {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        /* Menu Toggle */
        .menu-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 1.3rem;
            color: var(--gray-700);
            cursor: pointer;
            padding: 8px;
            border-radius: var(--radius-md);
        }
        .menu-toggle:hover { background: var(--gray-100); }

        /* Step Progress */
        .step-progress {
            display: flex;
            justify-content: space-between;
            margin-bottom: 32px;
            padding: 0 20px;
            position: relative;
        }
        .step-progress::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 10%;
            right: 10%;
            height: 2px;
            background: var(--gray-200);
            z-index: 1;
        }
        .step {
            text-align: center;
            position: relative;
            z-index: 2;
            flex: 1;
        }
        .step-circle {
            width: 40px;
            height: 40px;
            background: var(--gray-200);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 8px;
            font-weight: 700;
            color: var(--gray-600);
            transition: all 0.3s;
        }
        .step.active .step-circle { background: var(--secondary); color: white; }
        .step.completed .step-circle { background: var(--success); color: white; }
        .step-label { font-size: 0.65rem; color: var(--gray-500); }
        .step.active .step-label { color: var(--secondary); font-weight: 600; }

        /* Form Card */
        .form-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 24px;
        }
        .form-header {
            padding: 20px 24px;
            background: var(--gray-50);
            border-bottom: 1px solid var(--gray-200);
        }
        .form-header h2 { font-size: 1.1rem; font-weight: 600; color: var(--gray-800); display: flex; align-items: center; gap: 10px; }
        .form-header p { font-size: 0.8rem; color: var(--gray-500); margin-top: 4px; }
        .form-body { padding: 24px; }
        .form-section { display: none; animation: fadeIn 0.3s ease; }
        .form-section.active-section { display: block; }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
        }
        .section-icon {
            width: 36px;
            height: 36px;
            background: var(--gray-100);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .section-icon i { font-size: 1rem; color: var(--secondary); }
        .section-title h3 { font-size: 1rem; font-weight: 600; color: var(--gray-800); }
        .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 16px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.7rem; font-weight: 600; color: var(--gray-600); margin-bottom: 4px; }
        .form-group label i { margin-right: 6px; color: var(--secondary); }
        .required { color: var(--secondary); }
        input, select, textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        input:focus, select:focus, textarea:focus { border-color: var(--accent); outline: none; }
        .radio-group { display: flex; gap: 16px; margin-top: 8px; flex-wrap: wrap; }
        .radio-group label { display: flex; align-items: center; gap: 6px; font-weight: normal; cursor: pointer; }
        
        /* Camera/Upload Button */
        .camera-btn {
            background: var(--gray-100);
            border: 2px dashed var(--gray-300);
            padding: 16px;
            border-radius: var(--radius-md);
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            touch-action: manipulation;
        }
        .camera-btn:hover, .camera-btn:active {
            border-color: var(--primary);
            background: var(--gray-50);
            transform: scale(1.02);
        }
        .camera-btn i { 
            font-size: 2rem; 
            color: var(--primary); 
            margin-bottom: 8px; 
            display: block;
        }
        .camera-btn span { 
            font-size: 0.8rem; 
            color: var(--gray-500);
            display: block;
        }
        .camera-btn .sub-text {
            font-size: 0.65rem;
            color: var(--gray-400);
            margin-top: 4px;
        }
        .file-name { 
            font-size: 0.7rem; 
            color: var(--gray-500); 
            margin-top: 8px; 
            text-align: center;
            padding: 6px;
            background: var(--gray-50);
            border-radius: var(--radius-sm);
        }
        .photo-preview {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: var(--radius-md);
            margin-top: 10px;
            border: 2px solid var(--gray-200);
        }
        .photo-preview-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        .nav-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 24px;
            gap: 16px;
        }
        .btn-prev, .btn-next, .btn-submit {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-prev { background: var(--gray-100); color: var(--gray-700); border: 1px solid var(--gray-200); }
        .btn-prev:hover { background: var(--gray-200); }
        .btn-next, .btn-submit { background: var(--primary); color: white; }
        .btn-next:hover, .btn-submit:hover { background: var(--primary-dark); transform: translateY(-1px); }
        
        .alert {
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85rem;
        }
        .alert-success { background: #D1FAE5; color: #065F46; border-left: 4px solid #059669; }
        .alert-danger { background: #FEE2E2; color: #991B1B; border-left: 4px solid #D32F2F; }
        .alert-info { background: #EFF6FF; color: #1E40AF; border-left: 4px solid #1E4A8C; }
        
        /* GPS Status Indicator */
        .gps-status {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            margin-top: 8px;
            font-size: 0.75rem;
        }
        .gps-status.success { background: #D1FAE5; color: #065F46; }
        .gps-status.error { background: #FEE2E2; color: #991B1B; }
        .gps-status.pending { background: #FEF3C7; color: #B45309; }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .form-body { padding: 20px; }
            .step-label { font-size: 0.5rem; }
            .step-circle { width: 30px; height: 30px; font-size: 0.8rem; }
        }
    </style>
</head>
<body>
<div class="app">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Municipal Social Welfare</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/resident_dashboard.php" class="nav-item">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo ($sidebar_household_id) ? 'household_data.php?view=' . $sidebar_household_id : 'household_form.php'; ?>" class="nav-item">
                    <i class="fas fa-users"></i>
                    <span>Household Profile</span>
                </a>
                <a href="my_applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i>
                    <span>My Applications</span>
                </a>
                <a href="../notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Services</div>
                
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i>
                    <span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="../soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="../seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="../pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="../aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="../vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>

                <a href="survey_form.php" class="nav-item active">
                    <i class="fas fa-chart-line"></i>
                    <span>Community Survey</span>
                </a>
                <a href="../id_application.php" class="nav-item">
                    <i class="fas fa-id-card"></i>
                    <span>ID Application</span>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../profile_settings.php" class="nav-item">
                    <i class="fas fa-user-circle"></i>
                    <span>Profile Settings</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Community Survey</h1>
                    <p>Door-to-Door Household Mapping & Registration</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small><?php echo ucfirst($role); ?></small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <h2><i class="fas fa-home"></i> New Household Registration</h2>
                <p>Fill out the form below to register a new household. Fields marked with <span class="required">*</span> are required.</p>
            </div>

            <div class="form-body">
                <?php if($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                <?php endif; ?>

                <div class="step-progress">
                    <div class="step <?php echo $current_step >= 1 ? 'active' : ''; ?>">
                        <div class="step-circle">1</div>
                        <div class="step-label">Household Head</div>
                    </div>
                    <div class="step <?php echo $current_step >= 2 ? 'active' : ''; ?>">
                        <div class="step-circle">2</div>
                        <div class="step-label">Location & GPS</div>
                    </div>
                    <div class="step <?php echo $current_step >= 3 ? 'active' : ''; ?>">
                        <div class="step-circle">3</div>
                        <div class="step-label">Socio-Economic</div>
                    </div>
                    <div class="step <?php echo $current_step >= 4 ? 'active' : ''; ?>">
                        <div class="step-circle">4</div>
                        <div class="step-label">Poverty ID</div>
                    </div>
                </div>

                <form method="POST" enctype="multipart/form-data" id="householdForm">
                    <input type="hidden" name="register_household" value="1">
                    <input type="hidden" name="current_step" id="currentStep" value="<?php echo $current_step; ?>">
                    
                    <input type="hidden" name="latitude" id="gps_latitude">
                    <input type="hidden" name="longitude" id="gps_longitude">
                    
                    <input type="hidden" name="network_status" id="network_status" value="online">

                    <!-- STEP 1: HOUSEHOLD HEAD -->
                    <div class="form-section <?php echo $current_step == 1 ? 'active-section' : ''; ?>" id="step1">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-user-circle"></i></div><h3>Step 1: Household Head Information</h3></div>
                        <div class="form-row">
                            <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="head_first_name" required></div>
                            <div class="form-group"><label>Middle Name</label><input type="text" name="head_middle_name"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="head_last_name" required></div>
                            <div class="form-group"><label>Suffix</label><input type="text" name="head_suffix" placeholder="Jr., Sr., III"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthdate</label><input type="date" name="head_birthdate" id="head_birthdate" onchange="calculateAge()"></div>
                            <div class="form-group"><label>Age</label><input type="number" name="head_age" id="head_age" readonly></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Sex</label><select name="head_sex"><option value="">Select</option><option>Male</option><option>Female</option></select></div>
                            <div class="form-group"><label>Civil Status</label><select name="civil_status" id="civil_status"><option value="">Select</option><option>Single</option><option>Married</option><option>Widowed</option><option>Separated</option><option>Annulled</option></select></div>
                        </div>
                        <div class="form-group"><label>Contact Number</label><input type="text" name="contact_number" placeholder="09XX-XXX-XXXX"></div>
                        <div class="form-group"><label>Email Address</label><input type="email" name="email" placeholder="email@example.com"></div>
                        <div class="form-group"><label>Number of Household Members <span class="required">*</span></label><input type="number" name="total_members" min="1" value="1" required></div>
                        <div class="form-group"><label>Has Dependent Children?</label><div class="radio-group"><label><input type="radio" name="has_children" value="1"> Yes</label><label><input type="radio" name="has_children" value="0" checked> No</label></div></div>
                    </div>

                    <!-- STEP 2: LOCATION & GPS -->
                    <div class="form-section <?php echo $current_step == 2 ? 'active-section' : ''; ?>" id="step2">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-map-marker-alt"></i></div><h3>Step 2: Location & GPS Coordinates</h3></div>
                        <div class="form-group"><label>Street/Address <span class="required">*</span></label><input type="text" name="address" required placeholder="e.g., 123 Rizal Street"></div>
                        <div class="form-group"><label>Barangay <span class="required">*</span></label><input type="text" name="barangay" required></div>
                        <div class="form-row">
                            <div class="form-group"><label>City/Municipality</label><input type="text" name="city_municipality"></div>
                            <div class="form-group"><label>Province</label><input type="text" name="province"></div>
                        </div>
                        <div class="form-group"><label>ZIP Code</label><input type="text" name="zip_code" placeholder="e.g., 8400"></div>
                        <div class="form-group">
                            <label><i class="fas fa-satellite-dish"></i> GPS Coordinates</label>
                            <div class="camera-btn" onclick="captureGPS()">
                                <i class="fas fa-map-marker-alt"></i>
                                <span>📍 Capture Current Location</span>
                                <span class="sub-text">Tap to get GPS coordinates for the poverty heatmap</span>
                            </div>
                            <div id="gps_display" class="file-name">No GPS captured yet</div>
                            <div id="gpsStatus" class="gps-status pending" style="display:none;">
                                <i class="fas fa-spinner fa-pulse"></i> <span id="gpsStatusText">Fetching GPS...</span>
                            </div>
                        </div>
                    </div>

                    <!-- STEP 3: SOCIO-ECONOMIC -->
                    <div class="form-section <?php echo $current_step == 3 ? 'active-section' : ''; ?>" id="step3">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-chart-line"></i></div><h3>Step 3: Socio-Economic Assessment</h3></div>
                        <div class="form-group"><label>Monthly Household Income (₱) <span class="required">*</span></label><input type="number" name="monthly_income" step="500" required placeholder="e.g., 15000"></div>
                        <div class="form-group"><label>Primary Source of Income</label><input type="text" name="income_source" placeholder="e.g., Employment, Business, Farming"></div>
                        <div class="form-group"><label>Housing Type</label><select name="housing_type"><option value="">Select</option><option>Owned</option><option>Rented</option><option>Shared/Relative's</option><option>Informal Settler</option></select></div>
                        <div class="form-group"><label>Water Source</label><select name="water_source"><option value="">Select</option><option>Level 1 (Faucets/Spring)</option><option>Level 2 (Communal)</option><option>Level 3 (Private Pipe)</option><option>Deep Well</option></select></div>
                        <div class="form-group"><label>Toilet Type</label><select name="toilet_type"><option value="">Select</option><option>Flush</option><option>Antipolo/Pit</option><option>None</option></select></div>
                        <div class="form-group"><label>4Ps Beneficiary?</label><div class="radio-group"><label><input type="checkbox" name="is_4ps_beneficiary" value="1"> Yes</label></div></div>
                    </div>

                    <!-- STEP 4: POVERTY ID -->
                    <div class="form-section <?php echo $current_step == 4 ? 'active-section' : ''; ?>" id="step4">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-camera"></i></div><h3>Step 4: Poverty Identification</h3></div>
                        <div class="alert alert-info"><i class="fas fa-info-circle"></i> Mandatory: Take a photo of the household head holding a valid ID or a signed affidavit.</div>
                        <div class="form-group">
                            <label>Photo-Affidavit (Client holding ID) <span class="required">*</span></label>
                            <div class="camera-btn" onclick="document.getElementById('affidavit_photo').click()">
                                <i class="fas fa-camera"></i>
                                <span>📸 Capture Photo</span>
                                <span class="sub-text">Tap to open camera or choose from gallery</span>
                            </div>
                            <input type="file" id="affidavit_photo" name="affidavit_photo" accept="image/*" style="display:none" onchange="previewPhoto(this)" capture="environment">
                            <div id="photoPreview" class="photo-preview-container"></div>
                            <div class="file-name" id="photoFileName">No photo captured</div>
                        </div>
                    </div>

                    <div class="nav-buttons">
                        <button type="button" class="btn-prev" id="prevBtn" onclick="changeStep(-1)" style="<?php echo $current_step == 1 ? 'display:none;' : ''; ?>"><i class="fas fa-chevron-left"></i> Previous</button>
                        <button type="button" class="btn-next" id="nextBtn" onclick="changeStep(1)" style="<?php echo $current_step == 4 ? 'display:none;' : ''; ?>">Next <i class="fas fa-chevron-right"></i></button>
                        <button type="submit" class="btn-submit" id="submitBtn" style="<?php echo $current_step == 4 ? '' : 'display:none;'; ?>"><i class="fas fa-save"></i> Register Household</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    
    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
        });
    }
    
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
    
    let currentStep = <?php echo $current_step; ?>;
    const totalSteps = 4;
    
    function changeStep(direction) {
        const sections = document.querySelectorAll('.form-section');
        const steps = document.querySelectorAll('.step');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');
        
        sections[currentStep - 1].classList.remove('active-section');
        steps[currentStep - 1].classList.remove('active');
        
        currentStep += direction;
        
        sections[currentStep - 1].classList.add('active-section');
        steps[currentStep - 1].classList.add('active');
        
        document.getElementById('currentStep').value = currentStep;
        
        if(currentStep === 1) prevBtn.style.display = 'none';
        else prevBtn.style.display = 'inline-flex';
        
        if(currentStep === totalSteps) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-flex';
        } else {
            nextBtn.style.display = 'inline-flex';
            submitBtn.style.display = 'none';
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    let gpsCaptured = false;
    
    function captureGPS() {
        const display = document.getElementById('gps_display');
        const statusDiv = document.getElementById('gpsStatus');
        const statusText = document.getElementById('gpsStatusText');
        
        if(!navigator.geolocation) {
            display.innerHTML = '<i class="fas fa-exclamation-triangle" style="color: #D32F2F;"></i> GPS not supported by this browser';
            return;
        }
        
        statusDiv.style.display = 'flex';
        statusDiv.className = 'gps-status pending';
        statusText.textContent = 'Fetching GPS...';
        display.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Capturing GPS...';
        
        navigator.geolocation.getCurrentPosition(
            function(position) {
                const lat = position.coords.latitude.toFixed(6);
                const lng = position.coords.longitude.toFixed(6);
                
                document.getElementById('gps_latitude').value = lat;
                document.getElementById('gps_longitude').value = lng;
                
                display.innerHTML = `<i class="fas fa-check-circle" style="color: #059669;"></i> 📍 Captured: ${lat}, ${lng}`;
                
                statusDiv.className = 'gps-status success';
                statusText.textContent = '✅ GPS captured successfully!';
                
                gpsCaptured = true;
                
                sessionStorage.setItem('gps_lat', lat);
                sessionStorage.setItem('gps_lng', lng);
                
                setTimeout(() => {
                    statusDiv.style.display = 'none';
                }, 3000);
            },
            function(error) {
                let errorMsg = 'Unable to capture GPS. ';
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMsg += 'Please enable location permissions.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMsg += 'Location unavailable. Please try again.';
                        break;
                    case error.TIMEOUT:
                        errorMsg += 'GPS timed out. Please try again.';
                        break;
                    default:
                        errorMsg += 'Please enable location services.';
                }
                
                display.innerHTML = `<i class="fas fa-exclamation-triangle" style="color: #D32F2F;"></i> ${errorMsg}`;
                
                statusDiv.className = 'gps-status error';
                statusText.textContent = '❌ ' + errorMsg;
                
                setTimeout(() => {
                    statusDiv.style.display = 'none';
                }, 5000);
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
        );
    }
    
    function calculateAge() {
        const birthdate = document.getElementById('head_birthdate').value;
        if(birthdate) {
            const today = new Date();
            const birth = new Date(birthdate);
            let age = today.getFullYear() - birth.getFullYear();
            const m = today.getMonth() - birth.getMonth();
            if(m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
            document.getElementById('head_age').value = age;
            if(age >= 60) {
                document.getElementById('head_age').style.borderColor = '#F5B042';
                document.getElementById('head_age').style.background = '#FFF9EF';
            }
        }
    }
    
    function previewPhoto(input) {
        const previewContainer = document.getElementById('photoPreview');
        const fileNameDiv = document.getElementById('photoFileName');
        if(input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewContainer.innerHTML = `<img src="${e.target.result}" class="photo-preview" alt="Affidavit Photo">`;
                fileNameDiv.innerHTML = `<i class="fas fa-check-circle" style="color: #059669;"></i> ✅ Photo captured successfully!`;
                fileNameDiv.style.color = '#065F46';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    document.getElementById('householdForm').addEventListener('submit', function(e) {
        const hasPhoto = document.getElementById('affidavit_photo').files.length > 0;
        if(!hasPhoto) {
            e.preventDefault();
            alert('Please capture the photo-affidavit before submitting.');
            document.getElementById('step4').scrollIntoView({ behavior: 'smooth' });
            return false;
        }
        
        if(!gpsCaptured) {
            if(!confirm('⚠️ No GPS coordinates captured. The household will not appear on the poverty heatmap.\n\nContinue without GPS?')) {
                e.preventDefault();
                document.getElementById('step2').scrollIntoView({ behavior: 'smooth' });
                return false;
            }
        }
        return true;
    });
    
    window.addEventListener('load', function() { 
        setTimeout(captureGPS, 1000);
    });
    
    document.addEventListener('click', function(e) {
        if(e.target.closest('#nextBtn') && currentStep === 1) {
            setTimeout(captureGPS, 500);
        }
    });
</script>

   <?= renderPwaServiceWorker() ?>
</body>
</html>