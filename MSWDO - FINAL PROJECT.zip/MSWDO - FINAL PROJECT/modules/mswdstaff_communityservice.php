<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Allow only staff roles
$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];

// ============================================================
// DATABASE FOREIGN KEY CONSTRAINTS - Community Service Logs
// ============================================================

try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS community_service_assignments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            member_id INT NOT NULL,
            household_id INT NULL,
            task_name VARCHAR(255) NOT NULL,
            assigned_site VARCHAR(255) NULL,
            total_hours_required DECIMAL(10,2) NOT NULL,
            hours_completed DECIMAL(10,2) DEFAULT 0.00,
            start_date DATE NULL,
            assignment_reason VARCHAR(100) NULL,
            status ENUM('ACTIVE', 'IN_PROGRESS', 'COMPLETED', 'NON_COMPLIANT') DEFAULT 'ACTIVE',
            assigned_by INT NULL,
            assigned_by_name VARCHAR(100) NULL,
            is_clearance_approved TINYINT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_member_id (member_id),
            INDEX idx_household_id (household_id),
            INDEX idx_status (status),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS community_service_logs (
            service_id INT AUTO_INCREMENT PRIMARY KEY,
            member_id INT NOT NULL,
            assignment_id INT NOT NULL,
            task_name VARCHAR(255) NULL,
            assigned_site VARCHAR(255) NULL,
            hours_rendered DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            hours_required DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            hours_completed DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            date_rendered DATE NULL,
            supervisor_id INT NULL,
            supervisor_name VARCHAR(100) NULL,
            remarks TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_member_id (member_id),
            INDEX idx_assignment_id (assignment_id),
            INDEX idx_date_rendered (date_rendered),
            INDEX idx_created_at (created_at),
            CONSTRAINT fk_resident_member 
                FOREIGN KEY (member_id) 
                REFERENCES users(id)
                ON DELETE RESTRICT 
                ON UPDATE CASCADE,
            CONSTRAINT fk_service_assignment
                FOREIGN KEY (assignment_id) 
                REFERENCES community_service_assignments(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM information_schema.KEY_COLUMN_USAGE 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'community_service_assignments' 
        AND CONSTRAINT_NAME = 'fk_assignment_member'
    ");
    $stmt->execute();
    $fk_exists = $stmt->fetch()['count'] ?? 0;
    
    if($fk_exists == 0) {
        $pdo->exec("
            ALTER TABLE community_service_assignments 
            ADD CONSTRAINT fk_assignment_member 
            FOREIGN KEY (member_id) 
            REFERENCES users(id) 
            ON DELETE RESTRICT 
            ON UPDATE CASCADE
        ");
    }

} catch(PDOException $e) {
    $db_error = "Database setup: " . $e->getMessage();
}

// ============ HANDLE COMMUNITY SERVICE ACTIONS ============

if(isset($_POST['assign_service'])) {
    $member_id = intval($_POST['member_id'] ?? 0);
    $task_name = trim($_POST['task_name'] ?? '');
    $assigned_site = trim($_POST['assigned_site'] ?? '');
    $total_hours_required = floatval($_POST['total_hours_required'] ?? 0);
    $start_date = $_POST['start_date'] ?? date('Y-m-d');
    $assignment_reason = $_POST['assignment_reason'] ?? '';
    
    if($member_id > 0 && !empty($task_name) && $total_hours_required > 0) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("
                INSERT INTO community_service_assignments 
                (member_id, task_name, assigned_site, total_hours_required, 
                 start_date, assignment_reason, assigned_by, assigned_by_name) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $member_id, 
                $task_name, 
                $assigned_site, 
                $total_hours_required, 
                $start_date, 
                $assignment_reason, 
                $user_id, 
                $full_name
            ]);
            
            $assignment_id = $pdo->lastInsertId();
            
            $stmt = $pdo->prepare("
                INSERT INTO community_service_logs 
                (member_id, assignment_id, task_name, assigned_site, hours_required, 
                 hours_completed, date_rendered, supervisor_id, supervisor_name, remarks) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $member_id,
                $assignment_id,
                $task_name,
                $assigned_site,
                $total_hours_required,
                0,
                $start_date,
                $user_id,
                $full_name,
                'Service assignment created.'
            ]);
            
            $pdo->commit();
            $assign_success = "Resident successfully assigned to community service!";
        } catch(PDOException $e) {
            $pdo->rollBack();
            if(strpos($e->getMessage(), 'foreign key constraint') !== false) {
                $assign_error = "Database error: The selected resident may not exist or has been removed. Please verify the Member ID.";
            } else {
                $assign_error = "Database error: " . $e->getMessage();
            }
        }
    } else {
        $assign_error = "Please fill in all required fields.";
    }
}

if(isset($_POST['log_hours'])) {
    $assignment_id = intval($_POST['assignment_id'] ?? 0);
    $hours_rendered = floatval($_POST['hours_rendered'] ?? 0);
    $date_rendered = $_POST['date_rendered'] ?? date('Y-m-d');
    $remarks = trim($_POST['remarks'] ?? '');
    $work_site = trim($_POST['work_site'] ?? '');
    
    if($assignment_id > 0 && $hours_rendered > 0) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("
                SELECT member_id, hours_completed, total_hours_required, task_name, assigned_site 
                FROM community_service_assignments 
                WHERE id = ?
            ");
            $stmt->execute([$assignment_id]);
            $assignment = $stmt->fetch();
            
            if($assignment) {
                $new_hours_completed = $assignment['hours_completed'] + $hours_rendered;
                $hours_remaining = $assignment['total_hours_required'] - $new_hours_completed;
                $site = !empty($work_site) ? $work_site : $assignment['assigned_site'];
                
                $stmt = $pdo->prepare("
                    INSERT INTO community_service_logs 
                    (assignment_id, member_id, hours_rendered, hours_required, hours_completed,
                     date_rendered, supervisor_id, supervisor_name, remarks, task_name, assigned_site) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $assignment_id,
                    $assignment['member_id'],
                    $hours_rendered,
                    $assignment['total_hours_required'],
                    $new_hours_completed,
                    $date_rendered,
                    $user_id,
                    $full_name,
                    $remarks,
                    $assignment['task_name'],
                    $site
                ]);
                
                $status = 'IN_PROGRESS';
                $is_clearance_approved = 0;
                if($hours_remaining <= 0) {
                    $status = 'COMPLETED';
                    $is_clearance_approved = 1;
                }
                
                $stmt = $pdo->prepare("
                    UPDATE community_service_assignments SET 
                        hours_completed = ?, 
                        status = ?, 
                        is_clearance_approved = ?,
                        updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$new_hours_completed, $status, $is_clearance_approved, $assignment_id]);
                
                $pdo->commit();
                $log_success = "Hours logged successfully! Hours remaining: " . max(0, $hours_remaining) . " hrs";
            } else {
                $log_error = "Assignment not found.";
            }
        } catch(PDOException $e) {
            $pdo->rollBack();
            if(strpos($e->getMessage(), 'foreign key constraint') !== false) {
                $log_error = "Database integrity error: The resident record may have been deleted. Please verify the assignment.";
            } else {
                $log_error = "Database error: " . $e->getMessage();
            }
        }
    } else {
        $log_error = "Please fill in all required fields.";
    }
}

if(isset($_GET['clear_id'])) {
    $clear_id = intval($_GET['clear_id']);
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("SELECT member_id FROM community_service_assignments WHERE id = ?");
        $stmt->execute([$clear_id]);
        $assignment = $stmt->fetch();
        
        if($assignment) {
            $stmt = $pdo->prepare("
                UPDATE community_service_assignments SET 
                    status = 'COMPLETED', 
                    is_clearance_approved = 1,
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$clear_id]);
            
            $stmt = $pdo->prepare("
                INSERT INTO community_service_logs 
                (assignment_id, member_id, hours_rendered, hours_required, hours_completed,
                 date_rendered, supervisor_id, supervisor_name, remarks, task_name) 
                SELECT 
                    id, 
                    member_id, 
                    total_hours_required, 
                    total_hours_required, 
                    total_hours_required,
                    NOW(),
                    ?,
                    ?,
                    'Service completed and cleared.',
                    task_name
                FROM community_service_assignments 
                WHERE id = ?
            ");
            $stmt->execute([$user_id, $full_name, $clear_id]);
            
            $pdo->commit();
            $clear_success = "Record cleared successfully! Resident is now in good standing.";
        } else {
            $clear_error = "Assignment not found.";
        }
    } catch(PDOException $e) {
        $pdo->rollBack();
        $clear_error = "Database error: " . $e->getMessage();
    }
}

$active_assignments = [];
try {
    $stmt = $pdo->query("
        SELECT csa.*, u.full_name as member_name, h.head_first_name, h.head_last_name 
        FROM community_service_assignments csa
        LEFT JOIN users u ON csa.member_id = u.id
        LEFT JOIN households h ON csa.household_id = h.id
        WHERE csa.status IN ('ACTIVE', 'IN_PROGRESS')
        ORDER BY csa.created_at DESC
    ");
    $active_assignments = $stmt->fetchAll();
} catch(PDOException $e) {
    $active_assignments = [];
}

$completed_assignments = [];
try {
    $stmt = $pdo->query("
        SELECT csa.*, u.full_name as member_name, h.head_first_name, h.head_last_name 
        FROM community_service_assignments csa
        LEFT JOIN users u ON csa.member_id = u.id
        LEFT JOIN households h ON csa.household_id = h.id
        WHERE csa.status = 'COMPLETED'
        ORDER BY csa.updated_at DESC
        LIMIT 20
    ");
    $completed_assignments = $stmt->fetchAll();
} catch(PDOException $e) {
    $completed_assignments = [];
}

$work_sites = [];
try {
    $stmt = $pdo->query("SELECT DISTINCT assigned_site FROM community_service_assignments WHERE assigned_site IS NOT NULL AND assigned_site != '' ORDER BY assigned_site");
    $work_sites = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch(PDOException $e) {
    $work_sites = [];
}

$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'assign';

$log_assignment_id = isset($_GET['log_id']) ? intval($_GET['log_id']) : 0;
$log_assignment = null;
if($log_assignment_id > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT csa.*, u.full_name as member_name 
            FROM community_service_assignments csa
            LEFT JOIN users u ON csa.member_id = u.id
            WHERE csa.id = ?
        ");
        $stmt->execute([$log_assignment_id]);
        $log_assignment = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        $log_assignment = null;
    }
}

// Stats for hero section
$total_active = count($active_assignments);
$total_in_progress = count(array_filter($active_assignments, fn($a) => $a['status'] == 'IN_PROGRESS'));
$total_completed = count($completed_assignments);
$total_hours_tracked = 0;
foreach($active_assignments as $a) { $total_hours_tracked += $a['hours_completed']; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Community Service - MSWDO Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   
    <?= renderPwaMetaTags() ?>

   <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
            background-image: 
                radial-gradient(at 0% 0%, rgba(30, 74, 140, 0.06) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(245, 176, 66, 0.06) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(211, 47, 47, 0.04) 0px, transparent 50%);
            background-attachment: fixed;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #3B6BB5;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --accent-dark: #D99524;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        }
        
        /* ============ SIDEBAR ============ */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        /* ============================================================
           UPDATED: Logo container now displays MSWDO logo image
           ============================================================ */
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem; font-weight: 500;
            transition: all 0.2s;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; font-size: 0.7rem; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px; overflow: hidden;
            max-height: 0; transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex; align-items: center; gap: 12px;
            padding: 8px 12px; border-radius: var(--radius-md);
            color: var(--gray-500); text-decoration: none;
            font-size: 0.8rem; font-weight: 500;
            transition: all 0.2s;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .submenu-item.active i { color: white; }
        
        .main-content { width: 100%; min-height: 100vh; padding: 16px; }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        /* ============ TOP BAR ============ */
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none; border: none;
            font-size: 1.3rem; cursor: pointer;
            padding: 8px; color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 { 
            font-size: 1.35rem; font-weight: 800; 
            color: var(--gray-800); letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex; align-items: center; gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px; text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-menu span { font-size: 0.8rem; font-weight: 600; color: var(--gray-700); }
        
        /* ============ HERO BANNER ============ */
        .hero-banner {
            position: relative;
            background: linear-gradient(135deg, #1E4A8C 0%, #0A2F6C 50%, #1E4A8C 100%);
            border-radius: var(--radius-xl);
            padding: 28px 32px;
            margin-bottom: 24px;
            overflow: hidden;
            box-shadow: 0 12px 24px -8px rgba(30, 74, 140, 0.4);
        }
        .hero-banner::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 400px; height: 400px;
            background: radial-gradient(circle, rgba(245, 176, 66, 0.15) 0%, transparent 70%);
            border-radius: 50%;
        }
        .hero-banner::after {
            content: '';
            position: absolute;
            bottom: -60%; left: -5%;
            width: 350px; height: 350px;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.08) 0%, transparent 70%);
            border-radius: 50%;
        }
        .hero-content { position: relative; z-index: 1; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; }
        .hero-text h2 {
            color: white; font-size: 1.5rem; font-weight: 800;
            letter-spacing: -0.02em; margin-bottom: 6px;
            display: flex; align-items: center; gap: 12px;
        }
        .hero-text h2 i { color: var(--accent); }
        .hero-text p { color: rgba(255, 255, 255, 0.85); font-size: 0.85rem; max-width: 500px; line-height: 1.6; }
        .hero-badges { display: flex; gap: 10px; flex-wrap: wrap; }
        .hero-badge {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 10px 16px;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: var(--radius-md);
            color: white; font-size: 0.72rem; font-weight: 600;
            backdrop-filter: blur(8px);
        }
        .hero-badge i { color: var(--accent); font-size: 0.85rem; }
        .hero-badge strong { color: var(--accent); font-size: 1rem; font-weight: 800; }
        
        /* ============ STAT CARDS ============ */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            position: relative;
            background: var(--white);
            padding: 20px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: var(--shadow-sm);
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
        }
        .stat-card.success::before { background: linear-gradient(90deg, #059669, #34D399); }
        .stat-card.warning::before { background: linear-gradient(90deg, #F5B042, #FCD34D); }
        .stat-card.danger::before { background: linear-gradient(90deg, #D32F2F, #F87171); }
        .stat-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); }
        .stat-card .stat-icon {
            width: 42px; height: 42px;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem;
            margin-bottom: 14px;
        }
        .stat-card .stat-icon.blue { background: #EFF6FF; color: var(--primary); }
        .stat-card .stat-icon.green { background: #D1FAE5; color: #059669; }
        .stat-card .stat-icon.amber { background: #FEF3C7; color: #D97706; }
        .stat-card .stat-icon.red { background: #FEE2E2; color: #D32F2F; }
        .stat-card .stat-number {
            font-size: 1.75rem; font-weight: 800;
            color: var(--gray-800); letter-spacing: -0.03em;
            line-height: 1;
        }
        .stat-card .stat-label {
            font-size: 0.68rem; font-weight: 600;
            color: var(--gray-500); margin-top: 6px;
            text-transform: uppercase; letter-spacing: 0.04em;
        }
        
        /* ============ TAB NAVIGATION ============ */
        .tab-navigation {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            margin-bottom: 24px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .tab-buttons {
            display: flex;
            padding: 6px;
            gap: 4px;
            background: var(--gray-50);
        }
        .tab-btn {
            flex: 1;
            padding: 14px 20px;
            background: transparent;
            border: none;
            font-size: 0.85rem; font-weight: 600;
            color: var(--gray-600);
            cursor: pointer;
            border-radius: var(--radius-md);
            transition: all 0.25s;
            display: flex; align-items: center; justify-content: center;
            gap: 8px;
            position: relative;
        }
        .tab-btn:hover { background: var(--white); color: var(--primary); }
        .tab-btn.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.3);
        }
        .tab-btn .badge {
            background: var(--secondary); color: white;
            border-radius: 20px; padding: 2px 8px;
            font-size: 0.62rem; font-weight: 700;
            margin-left: 4px;
        }
        .tab-btn.active .badge { background: var(--accent); color: var(--primary-dark); }
        .tab-content { display: none; padding: 0; }
        .tab-content.active { display: block; animation: fadeIn 0.3s ease; }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* ============ FORM CARD ============ */
        .form-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 24px;
            box-shadow: var(--shadow-md);
        }
        .form-card-header {
            padding: 20px 24px;
            background: linear-gradient(135deg, #F8FAFC, #F1F5F9);
            border-bottom: 1px solid var(--gray-200);
            display: flex; justify-content: space-between; align-items: center;
            flex-wrap: wrap; gap: 12px;
        }
        .form-card-header h2 {
            font-size: 1.05rem; font-weight: 700;
            color: var(--gray-800);
            display: flex; align-items: center; gap: 10px;
        }
        .form-card-header h2 i { color: var(--primary); }
        .form-card-header .header-chip {
            font-size: 0.68rem; font-weight: 600;
            padding: 5px 12px;
            background: #EFF6FF; color: var(--primary);
            border-radius: 20px;
            display: inline-flex; align-items: center; gap: 6px;
        }
        .form-body { padding: 24px; }
        
        /* ============ FORM ELEMENTS ============ */
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: flex; align-items: center; gap: 8px;
            font-size: 0.78rem; font-weight: 600;
            color: var(--gray-700); margin-bottom: 8px;
        }
        .form-group label i { color: var(--primary); font-size: 0.8rem; width: 16px; }
        .form-group label .required { color: var(--secondary); }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group input[type="date"],
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.88rem;
            font-family: 'Inter', sans-serif;
            color: var(--gray-800);
            background: var(--white);
            transition: all 0.2s;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 4px rgba(30, 74, 140, 0.1);
        }
        .form-group input::placeholder,
        .form-group textarea::placeholder { color: var(--gray-400); }
        .form-group textarea { resize: vertical; min-height: 90px; line-height: 1.6; }
        .form-group .field-hint {
            font-size: 0.68rem; color: var(--gray-500);
            margin-top: 6px; display: flex; align-items: center; gap: 5px;
        }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        
        /* ============ BUTTONS ============ */
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white; border: none;
            padding: 14px 28px;
            border-radius: var(--radius-md);
            font-weight: 700; font-size: 0.88rem;
            cursor: pointer;
            display: inline-flex; align-items: center; gap: 10px;
            transition: all 0.25s;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.3);
            font-family: 'Inter', sans-serif;
        }
        .btn-primary:hover { 
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(30, 74, 140, 0.4);
        }
        .btn-primary:active { transform: translateY(0); }
        .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-block { width: 100%; justify-content: center; }
        
        .btn-accent {
            background: linear-gradient(135deg, #2563EB, #1D4ED8);
            color: white; border: none;
            padding: 16px 24px;
            border-radius: var(--radius-md);
            font-weight: 700; font-size: 0.92rem;
            cursor: pointer; width: 100%;
            display: flex; align-items: center; justify-content: center;
            gap: 10px; transition: all 0.25s;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
            font-family: 'Inter', sans-serif;
        }
        .btn-accent:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.4);
        }
        .btn-accent:active { transform: translateY(0); }
        .btn-accent:disabled { opacity: 0.6; cursor: not-allowed; }
        
        /* ============ ALERTS ============ */
        .alert {
            padding: 14px 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex; align-items: flex-start;
            gap: 12px; font-size: 0.82rem;
            font-weight: 500;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .alert-success { background: #D1FAE5; color: #065F46; border-left: 4px solid #059669; }
        .alert-danger { background: #FEE2E2; color: #991B1B; border-left: 4px solid #D32F2F; }
        .alert-info { background: #EFF6FF; color: #1E40AF; border-left: 4px solid #1E4A8C; }
        .alert i { font-size: 1rem; flex-shrink: 0; margin-top: 1px; }
        
        /* ============ LOG HOURS FORM ============ */
        .log-hours-container { max-width: 640px; margin: 0 auto; }
        .log-hours-form {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }
        .log-hours-form .form-header {
            padding: 22px 26px;
            background: linear-gradient(135deg, #EFF6FF, #DBEAFE);
            border-bottom: 1px solid #BFDBFE;
            display: flex; justify-content: space-between; align-items: center;
        }
        .log-hours-form .form-header h2 {
            font-size: 1.05rem; font-weight: 700;
            color: #1E40AF;
            display: flex; align-items: center; gap: 10px;
        }
        .log-hours-form .form-header .close-btn {
            background: rgba(255, 255, 255, 0.6);
            border: none;
            font-size: 1rem;
            color: #1E40AF;
            cursor: pointer;
            padding: 6px 10px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .log-hours-form .form-header .close-btn:hover { background: white; }
        .log-hours-form .form-body { padding: 26px; }
        
        .info-box {
            background: linear-gradient(135deg, #F8FAFC, #F1F5F9);
            padding: 18px;
            border-radius: var(--radius-md);
            border: 1px solid var(--gray-200);
            margin-bottom: 22px;
            position: relative;
            overflow: hidden;
        }
        .info-box::before {
            content: '';
            position: absolute; top: 0; left: 0;
            width: 3px; height: 100%;
            background: linear-gradient(180deg, var(--primary), var(--accent));
        }
        .info-box .info-label {
            font-size: 0.62rem; font-weight: 700;
            color: var(--gray-500);
            text-transform: uppercase; letter-spacing: 0.08em;
        }
        .info-box .info-value {
            font-size: 1.15rem; font-weight: 800;
            color: var(--gray-800); margin-top: 4px;
            letter-spacing: -0.02em;
        }
        .info-box .info-subtext {
            font-size: 0.72rem;
            font-family: 'SF Mono', monospace;
            color: var(--gray-500); margin-top: 2px;
        }
        .info-box .info-task {
            font-size: 0.8rem; color: var(--gray-600);
            margin-top: 8px; padding-top: 8px;
            border-top: 1px dashed var(--gray-300);
            display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
        }
        .info-box .info-task i { color: var(--primary); }
        
        .field-label {
            font-size: 0.78rem; font-weight: 600;
            color: var(--gray-700); margin-bottom: 8px;
            display: flex; align-items: center; gap: 8px;
        }
        .field-label i { color: var(--primary); font-size: 0.8rem; }
        .field-label .required { color: var(--secondary); }
        
        .numeric-input-wrapper { position: relative; margin-bottom: 18px; }
        .numeric-input {
            border: 2px solid var(--gray-200);
            border-radius: var(--radius-md);
            padding: 16px 50px 16px 18px;
            font-size: 1.4rem; font-weight: 800;
            color: var(--gray-800);
            width: 100%;
            background: var(--white);
            transition: all 0.2s;
            font-family: 'Inter', sans-serif;
            letter-spacing: -0.02em;
        }
        .numeric-input:focus {
            border-color: #2563EB;
            outline: none;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
        }
        .numeric-input::placeholder { color: var(--gray-300); font-weight: 400; }
        .numeric-input-wrapper .input-icon {
            position: absolute; right: 18px; top: 50%;
            transform: translateY(-50%);
            font-size: 1.3rem; opacity: 0.5;
        }
        
        .log-hours-form select,
        .log-hours-form input[type="date"],
        .log-hours-form textarea {
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            padding: 12px 16px;
            font-size: 0.88rem;
            color: var(--gray-800);
            width: 100%;
            margin-bottom: 18px;
            background: var(--white);
            transition: all 0.2s;
            font-family: 'Inter', sans-serif;
        }
        .log-hours-form select:focus,
        .log-hours-form input:focus,
        .log-hours-form textarea:focus {
            border-color: #2563EB;
            outline: none;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
        }
        .log-hours-form textarea {
            resize: vertical; min-height: 90px;
            line-height: 1.6; font-size: 0.85rem;
        }
        
        /* ============ TABLES ============ */
        .recent-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
        }
        .recent-header {
            padding: 18px 22px;
            background: linear-gradient(135deg, #F8FAFC, #F1F5F9);
            border-bottom: 1px solid var(--gray-200);
            display: flex; align-items: center; gap: 12px;
        }
        .recent-header h3 {
            font-size: 0.92rem; font-weight: 700;
            color: var(--gray-800);
            display: flex; align-items: center; gap: 10px;
        }
        .recent-header h3 i { color: var(--primary); }
        .recent-header .count-chip {
            margin-left: auto;
            font-size: 0.68rem; font-weight: 700;
            padding: 4px 12px;
            background: var(--primary); color: white;
            border-radius: 20px;
        }
        .table-container { overflow-x: auto; }
        .table { width: 100%; border-collapse: collapse; font-size: 0.78rem; }
        .table th {
            text-align: left;
            padding: 14px 18px;
            background: var(--gray-50);
            border-bottom: 1px solid var(--gray-200);
            font-weight: 700;
            color: var(--gray-600);
            font-size: 0.68rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            white-space: nowrap;
        }
        .table td { 
            padding: 14px 18px; 
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .table tbody tr { transition: background 0.15s; }
        .table tbody tr:hover { background: var(--gray-50); }
        .table tbody tr:last-child td { border-bottom: none; }
        
        /* ============ STATUS BADGES ============ */
        .status-badge {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.66rem; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.03em;
        }
        .status-badge::before {
            content: ''; width: 6px; height: 6px;
            border-radius: 50%; background: currentColor;
        }
        .status-active { background: #FEF3C7; color: #B45309; }
        .status-in_progress { background: #DBEAFE; color: #1E40AF; }
        .status-completed { background: #D1FAE5; color: #065F46; }
        
        /* ============ PROGRESS BAR ============ */
        .progress-wrapper { margin-top: 6px; }
        .progress-bar {
            width: 100%; height: 6px;
            background: var(--gray-200);
            border-radius: 6px;
            overflow: hidden;
            position: relative;
        }
        .progress-fill {
            height: 100%;
            border-radius: 6px;
            transition: width 0.5s ease;
            position: relative;
            overflow: hidden;
        }
        .progress-fill::after {
            content: '';
            position: absolute; top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        .progress-fill.low { background: linear-gradient(90deg, #D32F2F, #F87171); }
        .progress-fill.medium { background: linear-gradient(90deg, #F5B042, #FCD34D); }
        .progress-fill.high { background: linear-gradient(90deg, #059669, #34D399); }
        .progress-text {
            font-size: 0.62rem; color: var(--gray-500);
            margin-top: 3px; font-weight: 600;
        }
        
        /* ============ CONSTRAINT CARD ============ */
        .constraint-card {
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            border-left: 4px solid #059669;
            padding: 16px 22px;
            margin-bottom: 24px;
            display: flex; justify-content: space-between; align-items: center;
            flex-wrap: wrap; gap: 12px;
            box-shadow: var(--shadow-sm);
        }
        .constraint-info {
            display: flex; align-items: center; gap: 14px;
        }
        .constraint-icon-wrap {
            width: 40px; height: 40px;
            border-radius: var(--radius-md);
            background: linear-gradient(135deg, #D1FAE5, #A7F3D0);
            display: flex; align-items: center; justify-content: center;
            color: #059669; font-size: 1rem;
        }
        .constraint-text {
            font-size: 0.8rem; color: var(--gray-600); line-height: 1.5;
        }
        .constraint-text strong { color: var(--gray-800); display: block; }
        .constraint-badges { display: flex; gap: 8px; flex-wrap: wrap; }
        .constraint-badge {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.62rem; font-weight: 700;
            background: #D1FAE5; color: #065F46;
            text-transform: uppercase; letter-spacing: 0.03em;
        }
        
        /* ============ TIP BOX ============ */
        .tip-box {
            margin-top: 18px;
            padding: 14px 18px;
            background: linear-gradient(135deg, #FFF9EF, #FEF3C7);
            border-radius: var(--radius-lg);
            border-left: 4px solid var(--accent);
            font-size: 0.78rem;
            color: #78350F;
            display: flex; align-items: flex-start; gap: 10px;
            line-height: 1.6;
        }
        .tip-box i { color: var(--accent-dark); font-size: 1rem; margin-top: 1px; }
        
        /* ============ EMPTY STATE ============ */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        .empty-state .empty-icon {
            width: 80px; height: 80px;
            margin: 0 auto 18px;
            border-radius: 50%;
            background: linear-gradient(135deg, #EFF6FF, #DBEAFE);
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; color: var(--primary);
        }
        .empty-state h4 { font-size: 1rem; font-weight: 700; color: var(--gray-700); margin-bottom: 6px; }
        .empty-state p { font-size: 0.8rem; color: var(--gray-500); max-width: 320px; margin: 0 auto; line-height: 1.6; }
        
        /* ============ BOTTOM NAV ============ */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex; justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex; flex-direction: column; align-items: center;
            font-size: 0.65rem; color: var(--gray-500);
            text-decoration: none; font-weight: 600;
            padding: 6px 8px; border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 3px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        
        /* ============ RESPONSIVE ============ */
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .hero-banner { padding: 22px 20px; }
            .hero-text h2 { font-size: 1.2rem; }
            .hero-text p { font-size: 0.78rem; }
            .tab-btn { padding: 12px 14px; font-size: 0.75rem; flex-direction: column; gap: 4px; }
            .tab-btn i { font-size: 0.9rem; }
            .form-row { grid-template-columns: 1fr; }
            .constraint-card { flex-direction: column; align-items: flex-start; }
            .form-body { padding: 18px; }
            .log-hours-form .form-body { padding: 18px; }
            .top-bar { padding: 10px 14px; }
            .page-title h1 { font-size: 1.1rem; }
            .page-title p { display: none; }
        }
        @media (max-width: 480px) {
            .main-content { padding: 12px; }
            .stats-grid { gap: 10px; }
            .stat-card { padding: 14px; }
            .stat-card .stat-number { font-size: 1.4rem; }
            .user-menu span { display: none; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <!-- ============================================================
                     UPDATED: MSWDO Logo Image replaces Font Awesome icon
                     ============================================================ -->
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="mswdstaff_communityservice.php" class="nav-item active">
                    <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
                </a>
                <a href="household.php" class="nav-item">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
            </div>
            
            <div class="nav-section">
                <div class="nav-label">Applications</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="mswdstaff_idapplication.php" class="nav-item">
                    <i class="fas fa-id-card"></i> <span>ID Applications</span>
                </a>
                <a href="staff_eligibility_engine.php" class="nav-item">
                    <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
            </div>
            
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="mswdstaff_profile.php" class="nav-item">
                    <i class="fas fa-user-circle"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Community Service</h1>
                <p>Manage resident community service assignments and track compliance</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.65rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Hero Banner -->
        <div class="hero-banner">
            <div class="hero-content">
                <div class="hero-text">
                    <h2><i class="fas fa-hands-helping"></i> Community Service Management</h2>
                    <p>Assign, track, and manage community service hours for residents. Ensure compliance and maintain accurate records with full audit trail.</p>
                </div>
                <div class="hero-badges">
                    <div class="hero-badge">
                        <i class="fas fa-clock"></i>
                        <span><strong><?php echo number_format($total_hours_tracked, 1); ?></strong> hrs tracked</span>
                    </div>
                    <div class="hero-badge">
                        <i class="fas fa-users"></i>
                        <span><strong><?php echo $total_active; ?></strong> active</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-clipboard-list"></i></div>
                <div class="stat-number"><?php echo $total_active; ?></div>
                <div class="stat-label">Active Assignments</div>
            </div>
            <div class="stat-card warning">
                <div class="stat-icon amber"><i class="fas fa-spinner"></i></div>
                <div class="stat-number"><?php echo $total_in_progress; ?></div>
                <div class="stat-label">In Progress</div>
            </div>
            <div class="stat-card success">
                <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
                <div class="stat-number"><?php echo $total_completed; ?></div>
                <div class="stat-label">Completed</div>
            </div>
            <div class="stat-card danger">
                <div class="stat-icon red"><i class="fas fa-hourglass-half"></i></div>
                <div class="stat-number"><?php echo number_format($total_hours_tracked, 1); ?></div>
                <div class="stat-label">Hours Logged</div>
            </div>
        </div>

        <!-- Constraint Status -->
        <div class="constraint-card">
            <div class="constraint-info">
                <div class="constraint-icon-wrap"><i class="fas fa-shield-alt"></i></div>
                <div class="constraint-text">
                    <strong>Database Integrity Active</strong>
                    Foreign key constraints enforce data consistency across assignments and logs.
                </div>
            </div>
            <div class="constraint-badges">
                <span class="constraint-badge"><i class="fas fa-link"></i> ON DELETE RESTRICT</span>
                <span class="constraint-badge"><i class="fas fa-sync-alt"></i> ON UPDATE CASCADE</span>
            </div>
        </div>

        <!-- Tab Navigation -->
        <div class="tab-navigation">
            <div class="tab-buttons">
                <button class="tab-btn <?php echo $active_tab == 'assign' ? 'active' : ''; ?>" onclick="switchTab('assign')">
                    <i class="fas fa-user-plus"></i> Assign Service
                </button>
                <button class="tab-btn <?php echo $active_tab == 'log' ? 'active' : ''; ?>" onclick="switchTab('log')">
                    <i class="fas fa-clock"></i> Log Hours
                </button>
                <button class="tab-btn <?php echo $active_tab == 'track' ? 'active' : ''; ?>" onclick="switchTab('track')">
                    <i class="fas fa-chart-line"></i> Track Progress
                    <span class="badge"><?php echo $active_assignments ? count($active_assignments) : 0; ?></span>
                </button>
            </div>
        </div>

        <!-- TAB 1: ASSIGN SERVICE -->
        <div id="tab-assign" class="tab-content <?php echo $active_tab == 'assign' ? 'active' : ''; ?>">
            <div class="form-card">
                <div class="form-card-header">
                    <h2><i class="fas fa-user-plus"></i> New Service Assignment</h2>
                    <span class="header-chip"><i class="fas fa-pen"></i> Manual Entry</span>
                </div>
                <div class="form-body">
                    <?php if(isset($assign_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $assign_success; ?></div>
                    <?php endif; ?>
                    <?php if(isset($assign_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $assign_error; ?></div>
                    <?php endif; ?>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> 
                        <div>
                            <strong>Manual Entry:</strong> Enter the resident's Member ID and service details to create an assignment. Ensure the Member ID is valid.
                        </div>
                    </div>

                    <form method="POST" id="assignForm">
                        <input type="hidden" name="assign_service" value="1">
                        
                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> Member ID <span class="required">*</span></label>
                            <input type="number" name="member_id" placeholder="Enter the resident's Member ID (e.g., 123)" required min="1">
                            <div class="field-hint">
                                <i class="fas fa-lightbulb"></i> Ask the resident for their Member ID or look it up in Household Records.
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-tasks"></i> Task Name <span class="required">*</span></label>
                                <input type="text" name="task_name" placeholder="e.g., Public Market Cleanup" required>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-map-marker-alt"></i> Assigned Site</label>
                                <input type="text" name="assigned_site" placeholder="e.g., Zone 4 Public Market">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-clock"></i> Total Hours Required <span class="required">*</span></label>
                                <input type="number" name="total_hours_required" step="0.5" min="0.5" placeholder="e.g., 16" required>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-calendar"></i> Start Date</label>
                                <input type="date" name="start_date" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Assignment Reason</label>
                            <select name="assignment_reason">
                                <option value="">Select Reason</option>
                                <option value="ORDINANCE_VIOLATION_CURFEW">Ordinance Violation - Curfew</option>
                                <option value="ORDINANCE_VIOLATION_LITTERING">Ordinance Violation - Littering</option>
                                <option value="COMMUNITY_AID_REQUIREMENT">Community Aid Requirement</option>
                                <option value="COURT_MANDATED">Court Mandated</option>
                                <option value="OTHER">Other</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn-primary btn-block" id="assignBtn">
                            <i class="fas fa-plus-circle"></i> Create Service Assignment
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- TAB 2: LOG HOURS -->
        <div id="tab-log" class="tab-content <?php echo $active_tab == 'log' ? 'active' : ''; ?>">
            <div class="log-hours-container">
                <?php if(isset($log_success)): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $log_success; ?></div>
                <?php endif; ?>
                <?php if(isset($log_error)): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $log_error; ?></div>
                <?php endif; ?>

                <div class="log-hours-form">
                    <div class="form-header">
                        <h2><i class="fas fa-clock"></i> Log Service Hours</h2>
                        <button class="close-btn" onclick="switchTab('track')" title="Close form">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="form-body">
                        <?php if($log_assignment): ?>
                        <div class="info-box">
                            <div class="info-label">Assigned Server</div>
                            <div class="info-value"><?php echo htmlspecialchars($log_assignment['member_name'] ?? 'Unknown'); ?></div>
                            <div class="info-subtext">Member ID: <?php echo $log_assignment['member_id']; ?></div>
                            <div class="info-task">
                                <i class="fas fa-tasks"></i> 
                                <span><?php echo htmlspecialchars($log_assignment['task_name']); ?></span>
                                <span style="color: var(--gray-300);">•</span>
                                <span><?php echo number_format($log_assignment['total_hours_required'] - $log_assignment['hours_completed'], 1); ?> hrs remaining</span>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="info-box">
                            <div class="info-label">Select Assignment</div>
                            <div class="info-value" style="font-size: 0.88rem; font-weight: 500; color: var(--gray-500);">
                                <i class="fas fa-info-circle"></i> Choose an active assignment below
                            </div>
                        </div>
                        <?php endif; ?>

                        <form method="POST">
                            <input type="hidden" name="log_hours" value="1">
                            
                            <div class="form-group">
                                <label class="field-label"><i class="fas fa-user"></i> Select Assignment <span class="required">*</span></label>
                                <select name="assignment_id" required>
                                    <option value="">Select an active assignment</option>
                                    <?php foreach($active_assignments as $a): 
                                        $member_name = $a['member_name'] ?? ($a['head_first_name'] . ' ' . $a['head_last_name'] ?? 'Unknown');
                                        $remaining = $a['total_hours_required'] - $a['hours_completed'];
                                        $selected = ($log_assignment && $log_assignment['id'] == $a['id']) ? 'selected' : '';
                                    ?>
                                        <option value="<?php echo $a['id']; ?>" <?php echo $selected; ?>>
                                            <?php echo htmlspecialchars($member_name); ?> - <?php echo htmlspecialchars($a['task_name']); ?> (<?php echo number_format($remaining, 1); ?> hrs left)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="field-label">
                                    <i class="fas fa-clock"></i> Hours Rendered Today <span class="required">*</span>
                                </label>
                                <div class="numeric-input-wrapper">
                                    <input type="number" 
                                           name="hours_rendered" 
                                           class="numeric-input" 
                                           placeholder="0.00" 
                                           step="0.5" 
                                           min="0.5" 
                                           required
                                           value="<?php echo isset($_POST['hours_rendered']) ? htmlspecialchars($_POST['hours_rendered']) : ''; ?>">
                                    <span class="input-icon">⏰</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="field-label"><i class="fas fa-map-marker-alt"></i> Work Site Location</label>
                                <select name="work_site">
                                    <option value="">Select work site...</option>
                                    <?php foreach($work_sites as $site): ?>
                                        <option value="<?php echo htmlspecialchars($site); ?>"><?php echo htmlspecialchars($site); ?></option>
                                    <?php endforeach; ?>
                                    <option value="OTHER">Other (specify in remarks)</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="field-label"><i class="fas fa-calendar-day"></i> Date Rendered</label>
                                <input type="date" name="date_rendered" value="<?php echo isset($_POST['date_rendered']) ? htmlspecialchars($_POST['date_rendered']) : date('Y-m-d'); ?>">
                            </div>

                            <div class="form-group">
                                <label class="field-label"><i class="fas fa-comment"></i> Supervisor Remarks / Field Notes</label>
                                <textarea name="remarks" 
                                          placeholder="Describe tasks completed (e.g., swept market stalls, assisted with trash disposal)..."><?php echo isset($_POST['remarks']) ? htmlspecialchars($_POST['remarks']) : ''; ?></textarea>
                            </div>

                            <button type="submit" class="btn-accent" id="logHoursBtn">
                                <i class="fas fa-save"></i> Save and Log Hours
                            </button>
                        </form>

                        <div class="tip-box">
                            <i class="fas fa-lightbulb"></i>
                            <div>
                                <strong>Tip:</strong> Select the assignment, enter hours worked, and add notes. The system automatically calculates remaining hours and updates the status.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB 3: TRACK PROGRESS -->
        <div id="tab-track" class="tab-content <?php echo $active_tab == 'track' ? 'active' : ''; ?>">
            <?php if(isset($clear_success)): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $clear_success; ?></div>
            <?php endif; ?>
            <?php if(isset($clear_error)): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $clear_error; ?></div>
            <?php endif; ?>
            
            <div class="recent-card">
                <div class="recent-header">
                    <h3><i class="fas fa-chart-line"></i> Active Service Assignments</h3>
                    <span class="count-chip"><?php echo count($active_assignments); ?> total</span>
                </div>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Resident</th>
                                <th>Task</th>
                                <th>Hours Required</th>
                                <th>Hours Completed</th>
                                <th>Remaining</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($active_assignments) > 0): ?>
                                <?php foreach($active_assignments as $a): 
                                    $member_name = $a['member_name'] ?? ($a['head_first_name'] . ' ' . $a['head_last_name'] ?? 'Unknown');
                                    $remaining = $a['total_hours_required'] - $a['hours_completed'];
                                    $status_class = $a['status'] == 'ACTIVE' ? 'status-active' : 'status-in_progress';
                                    $status_label = $a['status'] == 'ACTIVE' ? 'Pending' : 'In Progress';
                                    $progress_percent = ($a['total_hours_required'] > 0) ? ($a['hours_completed'] / $a['total_hours_required']) * 100 : 0;
                                    $progress_class = $progress_percent > 75 ? 'high' : ($progress_percent > 40 ? 'medium' : 'low');
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($member_name); ?></strong></td>
                                    <td><?php echo htmlspecialchars($a['task_name']); ?></td>
                                    <td><?php echo number_format($a['total_hours_required'], 1); ?></td>
                                    <td><?php echo number_format($a['hours_completed'], 1); ?></td>
                                    <td><strong><?php echo number_format(max(0, $remaining), 1); ?></strong></td>
                                    <td>
                                        <span class="status-badge <?php echo $status_class; ?>"><?php echo $status_label; ?></span>
                                        <div class="progress-wrapper">
                                            <div class="progress-bar">
                                                <div class="progress-fill <?php echo $progress_class; ?>" style="width: <?php echo min(100, $progress_percent); ?>%;"></div>
                                            </div>
                                            <div class="progress-text"><?php echo round($progress_percent); ?>% complete</div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6">
                                    <div class="empty-state">
                                        <div class="empty-icon"><i class="fas fa-clipboard-list"></i></div>
                                        <h4>No Active Assignments</h4>
                                        <p>There are no active community service assignments at the moment. Assign a resident to get started.</p>
                                    </div>
                                </td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="recent-card">
                <div class="recent-header">
                    <h3><i class="fas fa-history"></i> Completed Assignments</h3>
                    <span class="count-chip" style="background: #059669;"><?php echo count($completed_assignments); ?> total</span>
                </div>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Resident</th>
                                <th>Task</th>
                                <th>Hours Required</th>
                                <th>Completed</th>
                                <th>Status</th>
                                <th>Cleared</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($completed_assignments) > 0): ?>
                                <?php foreach($completed_assignments as $a): 
                                    $member_name = $a['member_name'] ?? ($a['head_first_name'] . ' ' . $a['head_last_name'] ?? 'Unknown');
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($member_name); ?></strong></td>
                                    <td><?php echo htmlspecialchars($a['task_name']); ?></td>
                                    <td><?php echo number_format($a['total_hours_required'], 1); ?></td>
                                    <td><?php echo number_format($a['hours_completed'], 1); ?></td>
                                    <td><span class="status-badge status-completed">Completed</span></td>
                                    <td><?php echo date('M d, Y', strtotime($a['updated_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6">
                                    <div class="empty-state" style="padding: 40px 20px;">
                                        <div class="empty-icon"><i class="fas fa-check-double"></i></div>
                                        <h4>No Completed Assignments</h4>
                                        <p>Completed service records will appear here once residents finish their required hours.</p>
                                    </div>
                                </td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="alert alert-info" style="font-size: 0.78rem;">
                <i class="fas fa-shield-alt"></i>
                <div>
                    <strong>Data Protection:</strong> 
                    Residents with active service assignments cannot be deleted from the system. This ensures data integrity and prevents orphaned records.
                    <span style="display: block; margin-top: 4px; font-size: 0.7rem; color: var(--gray-500);">
                        <i class="fas fa-link"></i> Foreign key constraints are enforced at the database level.
                    </span>
                </div>
            </div>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item active"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="staff_eligibility_engine.php" class="nav-item"><i class="fas fa-balance-scale"></i><span>Eligibility</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <script>
        function switchTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            
            document.getElementById('tab-' + tabName).classList.add('active');
            document.querySelectorAll('.tab-btn').forEach(btn => {
                if(btn.textContent.trim().includes(tabName) || 
                   (tabName === 'assign' && btn.textContent.includes('Assign')) ||
                   (tabName === 'log' && btn.textContent.includes('Log')) ||
                   (tabName === 'track' && btn.textContent.includes('Track'))) {
                    btn.classList.add('active');
                }
            });
            
            const url = new URL(window.location);
            url.searchParams.set('tab', tabName);
            window.history.pushState({}, '', url);
        }

        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) {
            menuToggle.addEventListener('click', () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); });
        }
        if(overlay) {
            overlay.addEventListener('click', () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); });
        }
        
        const progToggle = document.getElementById('programToggle');
        const progSub = document.getElementById('programSubmenu');
        const progIcon = document.getElementById('programIcon');
        if(progToggle) {
            progToggle.addEventListener('click', () => { progSub.classList.toggle('show'); progIcon.classList.toggle('rotated'); });
        }
        
        window.addEventListener('load', function() { 
            const urlParams = new URLSearchParams(window.location.search);
            const tabParam = urlParams.get('tab');
            if(tabParam && ['assign', 'log', 'track'].includes(tabParam)) {
                switchTab(tabParam);
            }
            const logId = urlParams.get('log_id');
            if(logId) {
                switchTab('log');
            }
        });

        document.querySelector('.btn-accent')?.addEventListener('click', function(e) {
            const btn = this;
            if(!btn.disabled) {
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            }
        });
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>