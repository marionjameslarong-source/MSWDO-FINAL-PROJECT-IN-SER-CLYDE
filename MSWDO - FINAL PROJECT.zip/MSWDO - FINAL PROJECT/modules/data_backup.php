<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$error = '';
$success = '';
$backup_files = [];

// Create backup directory if not exists
$backup_dir = '../backups/';
if(!file_exists($backup_dir)) {
    mkdir($backup_dir, 0777, true);
}

// Handle backup creation
if(isset($_POST['create_backup'])) {
    $backup_type = $_POST['backup_type'] ?? 'full';
    $backup_name = 'mswdo_backup_' . date('Y-m-d_H-i-s') . '.sql';
    $backup_path = $backup_dir . $backup_name;
    
    try {
        // Get all tables
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $backup_content = "-- MSWDO Database Backup\n";
        $backup_content .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $backup_content .= "-- Backup Type: " . strtoupper($backup_type) . "\n\n";
        $backup_content .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
        
        foreach($tables as $table) {
            // Skip certain tables for partial backup
            if($backup_type == 'structure' && in_array($table, ['audit_logs', 'login_attempts'])) {
                continue;
            }
            
            // Get create table syntax
            $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
            $create = $stmt->fetch(PDO::FETCH_ASSOC);
            $backup_content .= "DROP TABLE IF EXISTS `$table`;\n";
            $backup_content .= $create['Create Table'] . ";\n\n";
            
            // Get data for full backup
            if($backup_type == 'full') {
                $stmt = $pdo->query("SELECT * FROM `$table`");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach($rows as $row) {
                    $columns = array_keys($row);
                    $values = array_map(function($value) use ($pdo) {
                        if($value === null) return 'NULL';
                        return $pdo->quote($value);
                    }, array_values($row));
                    
                    $backup_content .= "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES (" . implode(', ', $values) . ");\n";
                }
                $backup_content .= "\n";
            }
        }
        
        $backup_content .= "SET FOREIGN_KEY_CHECKS=1;\n";
        
        // Write backup file
        file_put_contents($backup_path, $backup_content);
        
        // Compress if requested
        if(isset($_POST['compress'])) {
            $gz_path = $backup_path . '.gz';
            $gz_data = gzencode($backup_content, 9);
            file_put_contents($gz_path, $gz_data);
            unlink($backup_path);
            $backup_path = $gz_path;
            $backup_name .= '.gz';
        }
        
        $success = "Backup created successfully: " . $backup_name;
        
        // Log backup action
        $log_stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, created_at) VALUES (?, 'backup', ?, ?, NOW())");
        $log_stmt->execute([$_SESSION['user_id'], "Created backup: $backup_name", $_SERVER['REMOTE_ADDR']]);
        
    } catch(Exception $e) {
        $error = "Backup failed: " . $e->getMessage();
    }
}

// Handle backup restoration
if(isset($_POST['restore_backup']) && isset($_POST['backup_file'])) {
    $backup_file = $_POST['backup_file'];
    $backup_path = $backup_dir . $backup_file;
    
    if(file_exists($backup_path)) {
        try {
            // Check if it's gzipped
            $content = file_get_contents($backup_path);
            if(pathinfo($backup_path, PATHINFO_EXTENSION) == 'gz') {
                $content = gzdecode($content);
            }
            
            // Execute SQL
            $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
            
            // Split queries
            $queries = explode(";\n", $content);
            foreach($queries as $query) {
                $query = trim($query);
                if(!empty($query) && $query != 'SET FOREIGN_KEY_CHECKS=0') {
                    $pdo->exec($query);
                }
            }
            
            $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
            
            $success = "Database restored successfully from: " . $backup_file;
            
            // Log restore action
            $log_stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, created_at) VALUES (?, 'restore', ?, ?, NOW())");
            $log_stmt->execute([$_SESSION['user_id'], "Restored from backup: $backup_file", $_SERVER['REMOTE_ADDR']]);
            
        } catch(Exception $e) {
            $error = "Restore failed: " . $e->getMessage();
        }
    } else {
        $error = "Backup file not found!";
    }
}

// Handle backup deletion
if(isset($_GET['delete']) && !empty($_GET['delete'])) {
    $file = $_GET['delete'];
    $file_path = $backup_dir . $file;
    
    if(file_exists($file_path) && unlink($file_path)) {
        $success = "Backup file deleted: " . $file;
    } else {
        $error = "Failed to delete backup file!";
    }
}

// Handle download
if(isset($_GET['download']) && !empty($_GET['download'])) {
    $file = $_GET['download'];
    $file_path = $backup_dir . $file;
    
    if(file_exists($file_path)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit();
    }
}

// Get list of backup files
$files = scandir($backup_dir);
foreach($files as $file) {
    if($file != '.' && $file != '..') {
        $file_path = $backup_dir . $file;
        $backup_files[] = [
            'name' => $file,
            'size' => round(filesize($file_path) / 1024, 2),
            'date' => date('Y-m-d H:i:s', filemtime($file_path)),
            'type' => pathinfo($file, PATHINFO_EXTENSION) == 'gz' ? 'Compressed' : 'SQL'
        ];
    }
}
rsort($backup_files);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Data Backup - MSWDO Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .backup-options {
            background: var(--gray-100);
            padding: 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 25px;
        }
        .backup-type {
            display: flex;
            gap: 20px;
            margin: 15px 0;
            flex-wrap: wrap;
        }
        .backup-type label {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }
        .file-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .backup-file {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid var(--gray-200);
            flex-wrap: wrap;
            gap: 10px;
        }
        .backup-file:hover {
            background: var(--gray-100);
        }
        .file-info {
            flex: 2;
        }
        .file-actions {
            display: flex;
            gap: 8px;
        }
        .file-name {
            font-weight: 600;
            font-family: monospace;
        }
        .file-size {
            font-size: 0.75rem;
            color: var(--gray-600);
            margin-left: 10px;
        }
        .file-date {
            font-size: 0.75rem;
            color: var(--gray-600);
        }
        .warning-box {
            background: var(--warning-light);
            border-left: 4px solid var(--warning);
            padding: 15px;
            margin-bottom: 20px;
            border-radius: var(--radius-md);
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <div class="top-bar">
            <a href="../dashboards/admin_dashboard.php" class="nav-item" style="flex-direction: row; gap: var(--spacing-xs);">
                ← Dashboard
            </a>
            <div class="logo" style="font-size: 1.25rem;">💾 MSWDO Backup</div>
            <div style="width: 80px;"></div>
        </div>
        
        <div class="container">
            <?php if($error): ?>
                <div class="alert alert-danger">⚠️ <?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="alert alert-success">✅ <?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="warning-box">
                <strong>⚠️ Important Notice:</strong><br>
                • Regular backups are recommended (weekly or monthly)<br>
                • Store backups in a secure location<br>
                • Restoring a backup will overwrite current database data<br>
                • Always verify backup files after creation
            </div>
            
            <!-- Create Backup Section -->
            <div class="card">
                <div class="card-header">
                    <h3>📦 Create New Backup</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="" class="backup-options">
                        <div class="backup-type">
                            <label>
                                <input type="radio" name="backup_type" value="full" checked>
                                <strong>Full Backup</strong> (Structure + Data)
                            </label>
                            <label>
                                <input type="radio" name="backup_type" value="structure">
                                <strong>Structure Only</strong> (Tables only, no data)
                            </label>
                        </div>
                        <div class="backup-type">
                            <label>
                                <input type="checkbox" name="compress" value="1">
                                <strong>Compress Backup</strong> (GZIP - saves space)
                            </label>
                        </div>
                        <button type="submit" name="create_backup" class="btn btn-primary">
                            🔒 Create Backup Now
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Existing Backups -->
            <div class="card" style="margin-top: 20px;">
                <div class="card-header">
                    <h3>📋 Existing Backups</h3>
                </div>
                <div class="card-body">
                    <?php if(count($backup_files) == 0): ?>
                        <div class="alert alert-info text-center">No backup files found. Create your first backup above.</div>
                    <?php else: ?>
                        <div class="file-list">
                            <?php foreach($backup_files as $file): ?>
                                <div class="backup-file">
                                    <div class="file-info">
                                        <div>
                                            <span class="file-name">📄 <?php echo htmlspecialchars($file['name']); ?></span>
                                            <span class="file-size">(<?php echo $file['size']; ?> KB)</span>
                                        </div>
                                        <div class="file-date">📅 <?php echo $file['date']; ?> | Type: <?php echo $file['type']; ?></div>
                                    </div>
                                    <div class="file-actions">
                                        <a href="?download=<?php echo urlencode($file['name']); ?>" class="btn btn-success btn-sm">⬇️ Download</a>
                                        <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Restoring will overwrite current data. Continue?')">
                                            <input type="hidden" name="backup_file" value="<?php echo htmlspecialchars($file['name']); ?>">
                                            <button type="submit" name="restore_backup" class="btn btn-warning btn-sm">🔄 Restore</button>
                                        </form>
                                        <a href="?delete=<?php echo urlencode($file['name']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this backup file?')">🗑️ Delete</a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Database Statistics -->
            <div class="card" style="margin-top: 20px;">
                <div class="card-header">
                    <h3>📊 Database Statistics</h3>
                </div>
                <div class="card-body">
                    <div class="stats-grid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <?php
                        $stmt = $pdo->query("SHOW TABLE STATUS");
                        $tables = $stmt->fetchAll();
                        $total_size = 0;
                        $total_rows = 0;
                        foreach($tables as $table) {
                            $total_size += $table['Data_length'] + $table['Index_length'];
                            $total_rows += $table['Rows'];
                        }
                        ?>
                        <div class="stat-box">
                            <div class="stat-number"><?php echo count($tables); ?></div>
                            <div>Total Tables</div>
                        </div>
                        <div class="stat-box">
                            <div class="stat-number"><?php echo number_format($total_rows); ?></div>
                            <div>Total Records</div>
                        </div>
                        <div class="stat-box">
                            <div class="stat-number"><?php echo round($total_size / 1024, 2); ?> KB</div>
                            <div>Database Size</div>
                        </div>
                        <div class="stat-box">
                            <div class="stat-number"><?php echo count($backup_files); ?></div>
                            <div>Backup Files</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>