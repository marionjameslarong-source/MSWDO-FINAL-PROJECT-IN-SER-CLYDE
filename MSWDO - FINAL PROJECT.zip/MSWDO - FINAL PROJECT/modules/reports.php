<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];
$report_type = isset($_GET['type']) ? $_GET['type'] : 'summary';

// ============================================================
// MONTHLY DATE NAVIGATION
// ============================================================
$month = isset($_GET['month']) ? intval($_GET['month']) : intval(date('m'));
$year = isset($_GET['year']) ? intval($_GET['year']) : intval(date('Y'));

// Get first and last day of the selected month
$date_from = date('Y-m-01', strtotime("$year-$month-01"));
$date_to = date('Y-m-t', strtotime("$year-$month-01"));

// Previous and Next month navigation
$prev_month = $month - 1;
$prev_year = $year;
if($prev_month < 1) {
    $prev_month = 12;
    $prev_year = $year - 1;
}

$next_month = $month + 1;
$next_year = $year;
if($next_month > 12) {
    $next_month = 1;
    $next_year = $year + 1;
}

// Get barangay filter
$barangay = isset($_GET['barangay']) ? $_GET['barangay'] : '';

// Month name for display
$month_names = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];
$current_month_name = $month_names[$month] . ' ' . $year;

// ============================================================
// CHECK IF TABLES EXIST
// ============================================================
$tables_exist = [
    'households' => false,
    'users' => false,
    'id_applications' => false,
    'welfare_applications' => false,
    'community_service_assignments' => false
];

try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'households'");
    $tables_exist['households'] = $stmt->rowCount() > 0;
    
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    $tables_exist['users'] = $stmt->rowCount() > 0;
    
    $stmt = $pdo->query("SHOW TABLES LIKE 'id_applications'");
    $tables_exist['id_applications'] = $stmt->rowCount() > 0;
    
    $stmt = $pdo->query("SHOW TABLES LIKE 'welfare_applications'");
    $tables_exist['welfare_applications'] = $stmt->rowCount() > 0;
    
    $stmt = $pdo->query("SHOW TABLES LIKE 'community_service_assignments'");
    $tables_exist['community_service_assignments'] = $stmt->rowCount() > 0;
} catch(PDOException $e) {
    // Some tables might not exist
}

// ============================================================
// CHECK IF POVERTY_STATUS COLUMN EXISTS
// ============================================================
$has_poverty_status = false;
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM households LIKE 'poverty_status'");
    $has_poverty_status = $stmt->rowCount() > 0;
} catch(PDOException $e) {
    $has_poverty_status = false;
}

// ============================================================
// GET BARANGAYS FOR FILTER
// ============================================================
$barangays = [];
if($tables_exist['households']) {
    try {
        $stmt = $pdo->query("SELECT DISTINCT barangay FROM households WHERE barangay IS NOT NULL AND barangay != '' ORDER BY barangay");
        $barangays = $stmt->fetchAll();
    } catch(PDOException $e) {
        $barangays = [];
    }
}

// ============================================================
// AGGREGATION RESULTS FOR SELECTED MONTH
// ============================================================
$aggregation_results = [
    'total_registered_households' => 0,
    'total_verified_approved_households' => 0,
    'total_subsistence_poor_households' => 0,
    'total_poor_households' => 0,
    'total_non_poor_households' => 0,
    'total_disbursed_funds_php' => 0,
    'active_community_service_cases' => 0,
    'flag_non_compliant_offenders' => 0,
    'evaluation_timestamp' => date('Y-m-d H:i:s')
];

// Get monthly counts from households
if($tables_exist['households']) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM households WHERE DATE(created_at) BETWEEN ? AND ?");
        $stmt->execute([$date_from, $date_to]);
        $aggregation_results['total_registered_households'] = $stmt->fetch()['total'] ?? 0;
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM households WHERE verification_status = 'verified_approved' AND DATE(verified_at) BETWEEN ? AND ?");
        $stmt->execute([$date_from, $date_to]);
        $aggregation_results['total_verified_approved_households'] = $stmt->fetch()['total'] ?? 0;
        
        if($has_poverty_status) {
            $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM households WHERE poverty_status = 'POOR' AND DATE(created_at) BETWEEN ? AND ?");
            $stmt->execute([$date_from, $date_to]);
            $aggregation_results['total_poor_households'] = $stmt->fetch()['total'] ?? 0;
            
            $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM households WHERE poverty_status = 'SUBSISTENCE_POOR' AND DATE(created_at) BETWEEN ? AND ?");
            $stmt->execute([$date_from, $date_to]);
            $aggregation_results['total_subsistence_poor_households'] = $stmt->fetch()['total'] ?? 0;
            
            $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM households WHERE poverty_status = 'NON_POOR' AND DATE(created_at) BETWEEN ? AND ?");
            $stmt->execute([$date_from, $date_to]);
            $aggregation_results['total_non_poor_households'] = $stmt->fetch()['total'] ?? 0;
        }
    } catch(PDOException $e) {}
}

// ============================================================
// COMMUNITY SERVICE STATS FOR SELECTED MONTH
// ============================================================
$community_service_stats = [
    'active_cases' => 0,
    'completed_cases' => 0,
    'non_compliant' => 0,
    'total_assigned' => 0,
    'hours_completed' => 0,
    'hours_remaining' => 0
];

if($tables_exist['community_service_assignments']) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM community_service_assignments WHERE status IN ('ACTIVE', 'IN_PROGRESS') AND DATE(created_at) BETWEEN ? AND ?");
        $stmt->execute([$date_from, $date_to]);
        $community_service_stats['active_cases'] = $stmt->fetch()['count'] ?? 0;
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM community_service_assignments WHERE status = 'COMPLETED' AND DATE(created_at) BETWEEN ? AND ?");
        $stmt->execute([$date_from, $date_to]);
        $community_service_stats['completed_cases'] = $stmt->fetch()['count'] ?? 0;
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM community_service_assignments WHERE status = 'NON_COMPLIANT' AND DATE(created_at) BETWEEN ? AND ?");
        $stmt->execute([$date_from, $date_to]);
        $community_service_stats['non_compliant'] = $stmt->fetch()['count'] ?? 0;
    } catch(PDOException $e) {}
}

// ============================================================
// GET OFFENDERS FOR SELECTED MONTH
// ============================================================
$offenders = [];
if($tables_exist['community_service_assignments']) {
    try {
        $stmt = $pdo->prepare("
            SELECT csa.*, u.full_name as member_name 
            FROM community_service_assignments csa
            LEFT JOIN users u ON csa.member_id = u.id
            WHERE csa.status = 'NON_COMPLIANT' AND DATE(csa.created_at) BETWEEN ? AND ?
            ORDER BY csa.created_at DESC
        ");
        $stmt->execute([$date_from, $date_to]);
        $offenders = $stmt->fetchAll();
    } catch(PDOException $e) {
        $offenders = [];
    }
}

// ============================================================
// GENERATE REPORTS
// ============================================================
$report_title = '';
$report_data = [];
$report_headers = [];
$summary_stats = [];

$summary_stats = [
    ['label' => 'Total Households', 'value' => $aggregation_results['total_registered_households'] ?? 0, 'icon' => 'fa-home', 'color' => '#1E4A8C'],
    ['label' => 'Poor', 'value' => $aggregation_results['total_poor_households'] ?? 0, 'icon' => 'fa-exclamation-triangle', 'color' => '#D32F2F'],
    ['label' => 'Subsistence Poor', 'value' => $aggregation_results['total_subsistence_poor_households'] ?? 0, 'icon' => 'fa-exclamation-circle', 'color' => '#D32F2F'],
    ['label' => 'Verified Approved', 'value' => $aggregation_results['total_verified_approved_households'] ?? 0, 'icon' => 'fa-check-circle', 'color' => '#059669'],
    ['label' => 'Active Service Cases', 'value' => $community_service_stats['active_cases'], 'icon' => 'fa-clipboard-list', 'color' => '#1E4A8C'],
    ['label' => 'Non-Compliant', 'value' => $community_service_stats['non_compliant'], 'icon' => 'fa-exclamation-circle', 'color' => '#D32F2F'],
];

switch($report_type) {
    case 'summary':
        $report_title = 'System Summary Report - ' . $current_month_name;
        
        $total_households = $aggregation_results['total_registered_households'] ?? 0;
        $total_poor = ($aggregation_results['total_subsistence_poor_households'] ?? 0) + ($aggregation_results['total_poor_households'] ?? 0);
        $total_verified_approved = $aggregation_results['total_verified_approved_households'] ?? 0;
        $total_pending_review = max(0, $total_households - $total_verified_approved);
        
        $summary_stats = [
            ['label' => 'Total Households', 'value' => $total_households, 'icon' => 'fa-home', 'color' => '#1E4A8C'],
            ['label' => 'Poor/Subsistence', 'value' => $total_poor, 'icon' => 'fa-exclamation-triangle', 'color' => '#D32F2F'],
            ['label' => 'Verified Approved', 'value' => $total_verified_approved, 'icon' => 'fa-check-circle', 'color' => '#059669'],
            ['label' => 'Pending Review', 'value' => $total_pending_review, 'icon' => 'fa-clock', 'color' => '#F5B042'],
            ['label' => 'Active Service Cases', 'value' => $community_service_stats['active_cases'], 'icon' => 'fa-clipboard-list', 'color' => '#1E4A8C'],
        ];
        
        if($tables_exist['households']) {
            try {
                $query = "SELECT 
                            barangay,
                            COUNT(*) as total_households,
                            COALESCE(SUM(total_members), 0) as total_members,
                            ROUND(AVG(monthly_income), 2) as avg_income
                          FROM households 
                          WHERE barangay IS NOT NULL AND barangay != ''
                          AND DATE(created_at) BETWEEN ? AND ?
                          GROUP BY barangay 
                          ORDER BY total_households DESC
                          LIMIT 15";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$date_from, $date_to]);
                $barangay_summary = $stmt->fetchAll();
            } catch(PDOException $e) {
                $barangay_summary = [];
            }
        } else {
            $barangay_summary = [];
        }
        
        $report_headers = ['Barangay', 'Households', 'Residents', 'Avg Income'];
        $report_data = $barangay_summary;
        break;
        
    case 'users':
        $report_title = 'User Accounts Report - ' . $current_month_name;
        $report_headers = ['Role', 'Active', 'Inactive', 'Total'];
        
        if($tables_exist['users']) {
            try {
                $query = "SELECT 
                            role,
                            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                            SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive,
                            COUNT(*) as total
                          FROM users 
                          WHERE DATE(created_at) BETWEEN ? AND ?
                          GROUP BY role
                          ORDER BY total DESC";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$date_from, $date_to]);
                $report_data = $stmt->fetchAll();
            } catch(PDOException $e) {
                $report_data = [];
            }
        }
        break;
        
    case 'community_service':
        $report_title = 'Community Service Report - ' . $current_month_name;
        $report_headers = ['Resident', 'Task', 'Assigned Site', 'Hours Required', 'Hours Completed', 'Status', 'Assigned Date'];
        
        if($tables_exist['community_service_assignments']) {
            try {
                $query = "SELECT 
                            csa.*, 
                            u.full_name as member_name
                          FROM community_service_assignments csa
                          LEFT JOIN users u ON csa.member_id = u.id
                          WHERE DATE(csa.created_at) BETWEEN ? AND ?
                          ORDER BY csa.created_at DESC";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$date_from, $date_to]);
                $report_data = $stmt->fetchAll();
            } catch(PDOException $e) {
                $report_data = [];
            }
        }
        break;
        
    case 'applications':
        $report_title = 'Applications Report - ' . $current_month_name;
        $report_headers = ['Application Type', 'Pending', 'Approved', 'Rejected', 'Total'];
        
        $report_data = [];
        
        if($tables_exist['id_applications']) {
            try {
                $query = "SELECT 
                            'ID Application' as program_type,
                            SUM(CASE WHEN status = 'pending_verification' THEN 1 ELSE 0 END) as pending,
                            SUM(CASE WHEN status = 'approved_printed' THEN 1 ELSE 0 END) as approved,
                            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                            COUNT(*) as total
                          FROM id_applications 
                          WHERE DATE(created_at) BETWEEN ? AND ?";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$date_from, $date_to]);
                $id_data = $stmt->fetch(PDO::FETCH_ASSOC);
                if($id_data && $id_data['total'] > 0) {
                    $report_data[] = $id_data;
                }
            } catch(PDOException $e) {}
        }
        
        if($tables_exist['welfare_applications']) {
            try {
                $query = "SELECT 
                            program_type,
                            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                            COUNT(*) as total
                          FROM welfare_applications 
                          WHERE DATE(created_at) BETWEEN ? AND ?
                          GROUP BY program_type";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$date_from, $date_to]);
                $welfare_data = $stmt->fetchAll();
                foreach($welfare_data as $row) {
                    $report_data[] = $row;
                }
            } catch(PDOException $e) {}
        }
        break;
        
    default:
        $report_title = 'Summary Report - ' . $current_month_name;
        $report_headers = ['Metric', 'Value'];
        $report_data = [];
        break;
}

// ============================================================
// EXPORT FUNCTIONS
// ============================================================

// PDF EXPORT
if(isset($_GET['export_pdf']) && $_GET['export_pdf'] == 1) {
    $month_label = date('M_Y', strtotime($date_from));
    $filename = $report_type . '_report_' . $month_label . '.pdf';
    
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . $report_title . '</title>
        <style>
            body { font-family: Arial, Helvetica, sans-serif; padding: 40px; }
            .header { text-align: center; border-bottom: 3px solid #1E4A8C; padding-bottom: 20px; margin-bottom: 30px; }
            .header h1 { color: #1E4A8C; font-size: 22px; margin: 0; }
            .header p { color: #64748B; font-size: 12px; margin: 5px 0 0; }
            .meta-info { text-align: right; font-size: 10px; color: #94A3B8; margin-bottom: 20px; }
            .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 30px; }
            .stat-box { background: #F8FAFC; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #E2E8F0; }
            .stat-box .number { font-size: 24px; font-weight: bold; color: #1E4A8C; }
            .stat-box .label { font-size: 11px; color: #64748B; margin-top: 4px; }
            .stat-box.danger .number { color: #D32F2F; }
            .stat-box.success .number { color: #059669; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 11px; }
            table th { background: #1E4A8C; color: white; padding: 10px 12px; text-align: left; }
            table td { padding: 8px 12px; border-bottom: 1px solid #E2E8F0; }
            table tr:nth-child(even) { background: #F8FAFC; }
            .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #E2E8F0; font-size: 10px; color: #94A3B8; }
            .report-date-badge { 
                display: inline-block; 
                background: #1E4A8C; 
                color: white; 
                padding: 4px 14px; 
                border-radius: 20px; 
                font-size: 11px; 
                font-weight: 600;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>MUNICIPAL SOCIAL WELFARE AND DEVELOPMENT OFFICE</h1>
            <p>' . $report_title . '</p>
            <p style="margin-top: 8px;"><span class="report-date-badge">📅 ' . date('M d, Y', strtotime($date_from)) . ' - ' . date('M d, Y', strtotime($date_to)) . '</span></p>
        </div>
        <div class="meta-info">
            <strong>Generated:</strong> ' . date('F d, Y h:i A') . '<br>
            <strong>Period:</strong> ' . date('M d, Y', strtotime($date_from)) . ' - ' . date('M d, Y', strtotime($date_to)) . '<br>
            <strong>Report Type:</strong> ' . ucfirst(str_replace('_', ' ', $report_type)) . '<br>
            <strong>Report ID:</strong> ' . $report_type . '_' . date('Ymd_His') . '
        </div>';
    
    if(!empty($summary_stats)) {
        $html .= '<div class="stats-grid">';
        foreach($summary_stats as $stat) {
            $extra_class = '';
            if($stat['label'] == 'Subsistence Poor' || $stat['label'] == 'Poor/Subsistence' || $stat['label'] == 'Poor') {
                $extra_class = 'danger';
            }
            if($stat['label'] == 'Total Disbursed' || strpos($stat['label'], 'Disbursed') !== false) {
                $extra_class = 'success';
            }
            $value = is_numeric($stat['value']) ? number_format($stat['value']) : $stat['value'];
            $html .= '<div class="stat-box ' . $extra_class . '">
                        <div class="number">' . $value . '</div>
                        <div class="label">' . $stat['label'] . '</div>
                    </div>';
        }
        $html .= '</div>';
    }
    
    if(count($report_data) > 0) {
        $html .= '<table>';
        $html .= '<thead><tr>';
        foreach($report_headers as $header) {
            $html .= '<th>' . $header . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        
        foreach($report_data as $row) {
            $html .= '<tr>';
            foreach((array)$row as $key => $value) {
                if(is_numeric($value) && strpos((string)$value, '.') !== false && $key != 'avg_size') {
                    $html .= '<td>₱ ' . number_format($value, 2) . '</td>';
                } elseif(is_numeric($value)) {
                    $html .= '<td>' . number_format($value) . '</td>';
                } elseif(!is_numeric($key)) {
                    $html .= '<td>' . htmlspecialchars($value ?? 'N/A') . '</td>';
                }
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
    } else {
        $html .= '<p style="text-align:center; color:#94A3B8; padding:40px 0;">No data found for the selected period.</p>';
    }
    
    $html .= '<div class="footer">
                <p>This is a system-generated report from the MSWDO Portal. For official use only.</p>
                <p>Report Period: ' . $current_month_name . ' ( ' . date('M d, Y', strtotime($date_from)) . ' - ' . date('M d, Y', strtotime($date_to)) . ' )</p>
                <p>Generated on: ' . date('F d, Y h:i A') . '</p>
            </div>
        </body>
    </html>';
    
    echo $html;
    exit();
}

// CSV EXPORT
if(isset($_GET['export']) && $_GET['export'] == 'csv') {
    $month_label = date('M_Y', strtotime($date_from));
    $filename = $report_type . '_report_' . $month_label . '.csv';
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    fputcsv($output, ['MSWDO Portal - Report Export']);
    fputcsv($output, ['Report Type:', ucfirst(str_replace('_', ' ', $report_type))]);
    fputcsv($output, ['Period:', date('M d, Y', strtotime($date_from)) . ' - ' . date('M d, Y', strtotime($date_to))]);
    fputcsv($output, ['Generated:', date('F d, Y h:i A')]);
    fputcsv($output, []);
    
    fputcsv($output, $report_headers);
    
    foreach($report_data as $row) {
        $export_row = [];
        foreach((array)$row as $value) {
            if(is_numeric($value) && strpos((string)$value, '.') !== false) {
                $export_row[] = number_format($value, 2);
            } else {
                $export_row[] = $value;
            }
        }
        fputcsv($output, $export_row);
    }
    
    fputcsv($output, []);
    fputcsv($output, ['--- End of Report ---']);
    fputcsv($output, ['Generated on:', date('F d, Y h:i A')]);
    
    fclose($output);
    exit();
}

// EXCEL EXPORT (XLS)
if(isset($_GET['export']) && $_GET['export'] == 'xls') {
    $month_label = date('M_Y', strtotime($date_from));
    $filename = $report_type . '_report_' . $month_label . '.xls';
    
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" 
          xmlns:x="urn:schemas-microsoft-com:office:excel" 
          xmlns="http://www.w3.org/TR/REC-html40">
    <head>
        <meta charset="UTF-8">
        <!--[if gte mso 9]>
        <xml>
            <x:ExcelWorkbook>
                <x:ExcelWorksheets>
                    <x:ExcelWorksheet>
                        <x:Name>Report</x:Name>
                        <x:WorksheetOptions>
                            <x:DisplayGridlines/>
                        </x:WorksheetOptions>
                    </x:ExcelWorksheet>
                </x:ExcelWorksheets>
            </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
            th { background-color: #1E4A8C; color: #FFFFFF; font-weight: bold; padding: 8px; border: 1px solid #000; }
            td { padding: 6px 8px; border: 1px solid #ccc; }
            .header-row { background-color: #F1F5F9; font-weight: bold; }
            .title-row { font-size: 16px; font-weight: bold; color: #1E4A8C; }
            .footer-row { font-style: italic; color: #64748B; }
        </style>
    </head>
    <body>
        <table>';
    
    echo '<tr><td colspan="' . count($report_headers) . '" class="title-row">MSWDO Portal - Report Export</td></tr>';
    echo '<tr><td colspan="' . count($report_headers) . '" class="header-row">Report Type: ' . ucfirst(str_replace('_', ' ', $report_type)) . '</td></tr>';
    echo '<tr><td colspan="' . count($report_headers) . '" class="header-row">Period: ' . date('M d, Y', strtotime($date_from)) . ' - ' . date('M d, Y', strtotime($date_to)) . '</td></tr>';
    echo '<tr><td colspan="' . count($report_headers) . '" class="header-row">Generated: ' . date('F d, Y h:i A') . '</td></tr>';
    echo '<tr><td colspan="' . count($report_headers) . '">&nbsp;</td></tr>';
    
    echo '<tr>';
    foreach($report_headers as $header) {
        echo '<th>' . $header . '</th>';
    }
    echo '</tr>';
    
    foreach($report_data as $row) {
        echo '<tr>';
        foreach((array)$row as $key => $value) {
            if(is_numeric($value) && strpos((string)$value, '.') !== false && $key != 'avg_size') {
                echo '<td align="right">₱ ' . number_format($value, 2) . '</td>';
            } elseif(is_numeric($value)) {
                echo '<td align="right">' . number_format($value) . '</td>';
            } else {
                echo '<td>' . htmlspecialchars($value ?? 'N/A') . '</td>';
            }
        }
        echo '</tr>';
    }
    
    echo '<tr><td colspan="' . count($report_headers) . '">&nbsp;</td></tr>';
    echo '<tr><td colspan="' . count($report_headers) . '" class="footer-row">--- End of Report ---</td></tr>';
    echo '<tr><td colspan="' . count($report_headers) . '" class="footer-row">Generated on: ' . date('F d, Y h:i A') . '</td></tr>';
    
    echo '</table></body></html>';
    exit();
}

function getStatusLabel($status) {
    switch($status) {
        case 'ACTIVE': return 'Active';
        case 'IN_PROGRESS': return 'In Progress';
        case 'COMPLETED': return 'Completed';
        case 'NON_COMPLIANT': return 'Non-Compliant';
        default: return ucfirst(strtolower($status));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Reports - MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #EFF6FF;
            --secondary: #D32F2F;
            --secondary-light: #FEF2F2;
            --accent: #F5B042;
            --accent-light: #FFFBEB;
            --success: #059669;
            --success-light: #ECFDF5;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --radius-2xl: 2rem;
        }
        
        /* ============================================================
           SIDEBAR
           ============================================================ */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 2px;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .submenu-item.active i { color: var(--accent); }
        
        /* ============================================================
           MAIN CONTENT
           ============================================================ */
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 {
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px;
            height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        
        /* ============================================================
           HERO HEADER - REPLACES THE BLACK BANNER
           ============================================================ */
        .hero-header {
            background: linear-gradient(135deg, #1E4A8C 0%, #0A2F6C 50%, #1E4A8C 100%);
            border-radius: var(--radius-2xl);
            padding: 32px 28px;
            margin-bottom: 24px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 40px -12px rgba(30, 74, 140, 0.35);
        }
        .hero-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -10%;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(245, 176, 66, 0.15) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .hero-header::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -5%;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.08) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .hero-header .hero-content {
            position: relative;
            z-index: 1;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        .hero-header .hero-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .hero-header .hero-icon {
            width: 64px;
            height: 64px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(8px);
            border-radius: var(--radius-xl);
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            flex-shrink: 0;
        }
        .hero-header .hero-icon i {
            font-size: 1.8rem;
            color: var(--accent);
        }
        .hero-header .hero-text h2 {
            font-size: 1.6rem;
            font-weight: 800;
            color: white;
            letter-spacing: -0.02em;
            margin-bottom: 4px;
        }
        .hero-header .hero-text p {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.75);
            font-weight: 500;
        }
        .hero-header .hero-right {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .hero-header .hero-badge {
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: var(--radius-lg);
            padding: 12px 20px;
            text-align: center;
            min-width: 100px;
            transition: all 0.3s;
        }
        .hero-header .hero-badge:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }
        .hero-header .hero-badge .badge-value {
            font-size: 1.4rem;
            font-weight: 800;
            color: white;
            line-height: 1;
        }
        .hero-header .hero-badge .badge-label {
            font-size: 0.6rem;
            color: rgba(255, 255, 255, 0.7);
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-top: 4px;
            font-weight: 600;
        }
        .hero-header .hero-badge.accent .badge-value { color: var(--accent); }
        .hero-header .hero-badge.success .badge-value { color: #34D399; }
        .hero-header .hero-badge.danger .badge-value { color: #F87171; }
        
        /* ============================================================
           MONTHLY NAVIGATION
           ============================================================ */
        .monthly-nav {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 16px 20px;
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            box-shadow: var(--shadow-sm);
            transition: box-shadow 0.3s;
        }
        .monthly-nav:hover { box-shadow: var(--shadow-md); }
        .monthly-nav .nav-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .monthly-nav .nav-title .month-badge {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .monthly-nav .nav-controls {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .monthly-nav .nav-btn {
            background: var(--gray-50);
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            padding: 8px 16px;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--gray-700);
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .monthly-nav .nav-btn:hover {
            background: var(--primary-light);
            border-color: var(--primary);
            color: var(--primary);
            transform: translateY(-1px);
        }
        .monthly-nav .nav-btn.current {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border-color: var(--primary);
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .monthly-nav .nav-btn.current:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 16px rgba(30, 74, 140, 0.35);
        }
        .monthly-nav .nav-date-display {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--primary);
            padding: 8px 16px;
            background: var(--primary-light);
            border-radius: var(--radius-md);
            min-width: 140px;
            text-align: center;
            border: 1px solid rgba(30, 74, 140, 0.1);
        }
        
        /* ============================================================
           REPORT TYPE SELECTOR - PILL TABS
           ============================================================ */
        .report-type-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 24px;
            background: var(--white);
            padding: 8px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .report-btn {
            padding: 10px 20px;
            background: transparent;
            border: none;
            border-radius: var(--radius-md);
            text-decoration: none;
            color: var(--gray-600);
            font-size: 0.82rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.25s ease;
            position: relative;
        }
        .report-btn:hover {
            background: var(--gray-100);
            color: var(--primary);
        }
        .report-btn.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .report-btn.active i { color: var(--accent); }
        .report-btn i { font-size: 0.9rem; }
        
        /* ============================================================
           FILTER CARD
           ============================================================ */
        .filter-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: box-shadow 0.3s;
        }
        .filter-card:hover { box-shadow: var(--shadow-md); }
        .filter-row {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        .filter-group label {
            font-size: 0.7rem;
            font-weight: 700;
            color: var(--gray-500);
            margin-bottom: 6px;
            display: block;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .filter-group label i { color: var(--accent); margin-right: 4px; }
        .filter-group select {
            width: 100%;
            padding: 10px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.82rem;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s;
            background: var(--gray-50);
            cursor: pointer;
        }
        .filter-group select:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
            background: white;
        }
        .filter-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .btn-filter {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border: none;
            padding: 10px 22px;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.82rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.2);
        }
        .btn-filter:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(30, 74, 140, 0.3);
        }
        .btn-reset {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
            padding: 10px 22px;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.82rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            transition: all 0.2s;
        }
        .btn-reset:hover {
            background: var(--gray-200);
            transform: translateY(-1px);
        }
        
        /* ============================================================
           STAT CARDS - REDESIGNED
           ============================================================ */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: var(--white);
            padding: 20px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), #3B82F6);
        }
        .stat-card:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-xl);
            border-color: transparent;
        }
        .stat-card .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 14px;
            font-size: 1.3rem;
            transition: all 0.3s;
        }
        .stat-card:hover .stat-icon {
            transform: scale(1.1) rotate(-5deg);
        }
        .stat-card .stat-content .stat-number {
            font-size: 2rem;
            font-weight: 800;
            color: var(--gray-800);
            letter-spacing: -0.03em;
            line-height: 1;
            margin-bottom: 6px;
        }
        .stat-card .stat-content .stat-label {
            font-size: 0.7rem;
            color: var(--gray-500);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .stat-card .stat-trend {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 20px;
        }
        
        /* Stat card variants */
        .stat-card.primary::before { background: linear-gradient(90deg, #1E4A8C, #3B82F6); }
        .stat-card.primary .stat-icon { background: var(--primary-light); color: var(--primary); }
        
        .stat-card.danger::before { background: linear-gradient(90deg, #D32F2F, #F87171); }
        .stat-card.danger .stat-icon { background: var(--secondary-light); color: var(--secondary); }
        .stat-card.danger .stat-content .stat-number { color: var(--secondary); }
        
        .stat-card.success::before { background: linear-gradient(90deg, #059669, #34D399); }
        .stat-card.success .stat-icon { background: var(--success-light); color: var(--success); }
        .stat-card.success .stat-content .stat-number { color: var(--success); }
        
        .stat-card.accent::before { background: linear-gradient(90deg, #F5B042, #FCD34D); }
        .stat-card.accent .stat-icon { background: var(--accent-light); color: #B45309; }
        .stat-card.accent .stat-content .stat-number { color: #B45309; }
        
        /* ============================================================
           REPORT CARD
           ============================================================ */
        .report-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
            transition: box-shadow 0.3s;
        }
        .report-card:hover { box-shadow: var(--shadow-lg); }
        .report-header {
            padding: 20px 24px;
            background: linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%);
            border-bottom: 2px solid var(--accent);
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
        }
        .report-header h3 {
            font-size: 1.05rem;
            font-weight: 700;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .report-header h3 i {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--accent);
            font-size: 0.85rem;
        }
        .export-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            align-items: center;
        }
        .period-info {
            font-size: 0.7rem;
            color: var(--primary);
            background: var(--primary-light);
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: 1px solid rgba(30, 74, 140, 0.1);
        }
        .btn-export {
            padding: 8px 16px;
            border-radius: 20px;
            text-decoration: none;
            font-size: 0.72rem;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.25s;
            border: none;
            cursor: pointer;
            letter-spacing: 0.02em;
        }
        .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.15);
        }
        .btn-export:active { transform: translateY(0); }
        .btn-export-csv { background: linear-gradient(135deg, #059669, #047857); color: white; }
        .btn-export-excel { background: linear-gradient(135deg, #1E4A8C, #0A2F6C); color: white; }
        .btn-export-pdf { background: linear-gradient(135deg, #D32F2F, #B71C1C); color: white; }
        
        /* ============================================================
           TABLE
           ============================================================ */
        .table-container {
            overflow-x: auto;
            padding: 0;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
            min-width: 600px;
        }
        .table th {
            text-align: left;
            padding: 14px 20px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            color: var(--gray-600);
            border-bottom: 2px solid var(--accent);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 0.68rem;
            white-space: nowrap;
        }
        .table td {
            padding: 14px 20px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
            transition: background 0.2s;
        }
        .table tr:hover td { background: var(--primary-light); }
        .table tr:last-child td { border-bottom: none; }
        
        /* ============================================================
           EMPTY STATE
           ============================================================ */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        .empty-state .empty-icon {
            width: 80px;
            height: 80px;
            background: var(--gray-100);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
        }
        .empty-state .empty-icon i {
            font-size: 2rem;
            color: var(--gray-400);
        }
        .empty-state p {
            font-size: 0.9rem;
            font-weight: 500;
        }
        .empty-state .empty-hint {
            font-size: 0.75rem;
            color: var(--gray-400);
            margin-top: 4px;
        }
        
        /* ============================================================
           OFFENDERS CARD - REDESIGNED
           ============================================================ */
        .offenders-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid #FCA5A5;
            overflow: hidden;
            margin-bottom: 24px;
            box-shadow: 0 4px 12px rgba(211, 47, 47, 0.1);
        }
        .offenders-card .offenders-header {
            padding: 16px 24px;
            background: linear-gradient(135deg, #FEF2F2, #FEE2E2);
            border-bottom: 2px solid var(--secondary);
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }
        .offenders-card .offenders-header h3 {
            font-size: 1rem;
            font-weight: 700;
            color: var(--secondary);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .offenders-card .offenders-header h3 i {
            width: 32px;
            height: 32px;
            background: var(--secondary);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.85rem;
        }
        .offenders-card .offenders-badge {
            background: var(--secondary);
            color: white;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        /* ============================================================
           BOTTOM NAV
           ============================================================ */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-decoration: none;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        
        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 992px) {
            .hero-header .hero-content { flex-direction: column; align-items: stretch; }
            .hero-header .hero-right { justify-content: center; }
        }
        @media (max-width: 768px) {
            .hero-header { padding: 24px 20px; }
            .hero-header .hero-text h2 { font-size: 1.3rem; }
            .hero-header .hero-icon { width: 52px; height: 52px; }
            .hero-header .hero-icon i { font-size: 1.4rem; }
            .filter-row { flex-direction: column; }
            .report-header { flex-direction: column; align-items: flex-start; }
            .export-buttons { width: 100%; }
            .monthly-nav { flex-direction: column; text-align: center; }
            .monthly-nav .nav-controls { flex-wrap: wrap; justify-content: center; }
            .top-bar { flex-wrap: wrap; gap: 12px; }
            .page-title h1 { font-size: 1.1rem; }
            .page-title p { display: none; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr; }
            .hero-header .hero-badge { flex: 1; min-width: 80px; }
        }
        
        /* ============================================================
           ANIMATIONS
           ============================================================ */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        .animate-in {
            animation: fadeInUp 0.5s ease forwards;
        }
        .stat-card:nth-child(1) { animation-delay: 0.05s; }
        .stat-card:nth-child(2) { animation-delay: 0.1s; }
        .stat-card:nth-child(3) { animation-delay: 0.15s; }
        .stat-card:nth-child(4) { animation-delay: 0.2s; }
        .stat-card:nth-child(5) { animation-delay: 0.25s; }
        .stat-card:nth-child(6) { animation-delay: 0.3s; }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="mswdstaff_communityservice.php" class="nav-item">
                    <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
                </a>
                <a href="household.php" class="nav-item">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Applications</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="mswdstaff_idapplication.php" class="nav-item">
                    <i class="fas fa-id-card"></i> <span>ID Applications</span>
                </a>
                <a href="staff_eligibility_engine.php" class="nav-item">
                    <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
                </a>
                <a href="reports.php" class="nav-item active">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="mswdstaff_profile.php" class="nav-item">
                    <i class="fas fa-user-circle"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Reports & Analytics</h1>
                <p>Monthly reports and data insights</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- ============================================================
             HERO HEADER - Replaces the dark black banner
             ============================================================ -->
        <div class="hero-header animate-in">
            <div class="hero-content">
                <div class="hero-left">
                    <div class="hero-icon">
                        <i class="fas fa-chart-pie"></i>
                    </div>
                    <div class="hero-text">
                        <h2><?php echo $current_month_name; ?></h2>
                        <p><i class="fas fa-calendar-alt"></i> <?php echo date('M d, Y', strtotime($date_from)); ?> — <?php echo date('M d, Y', strtotime($date_to)); ?></p>
                    </div>
                </div>
                <div class="hero-right">
                    <div class="hero-badge">
                        <div class="badge-value"><?php echo number_format($aggregation_results['total_registered_households'] ?? 0); ?></div>
                        <div class="badge-label">Households</div>
                    </div>
                    <div class="hero-badge danger">
                        <div class="badge-value"><?php echo number_format(($aggregation_results['total_poor_households'] ?? 0) + ($aggregation_results['total_subsistence_poor_households'] ?? 0)); ?></div>
                        <div class="badge-label">Poor</div>
                    </div>
                    <div class="hero-badge success">
                        <div class="badge-value"><?php echo number_format($aggregation_results['total_verified_approved_households'] ?? 0); ?></div>
                        <div class="badge-label">Verified</div>
                    </div>
                    <div class="hero-badge accent">
                        <div class="badge-value"><?php echo number_format($community_service_stats['active_cases']); ?></div>
                        <div class="badge-label">Active Cases</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Monthly Navigation -->
        <div class="monthly-nav animate-in">
            <div class="nav-title">
                <i class="fas fa-calendar-alt" style="color: var(--primary);"></i>
                <span><?php echo $current_month_name; ?></span>
                <span class="month-badge">Monthly</span>
            </div>
            <div class="nav-controls">
                <a href="?type=<?php echo $report_type; ?>&month=<?php echo $prev_month; ?>&year=<?php echo $prev_year; ?>" class="nav-btn">
                    <i class="fas fa-chevron-left"></i> Prev
                </a>
                <a href="?type=<?php echo $report_type; ?>&month=<?php echo date('m'); ?>&year=<?php echo date('Y'); ?>" class="nav-btn current">
                    <i class="fas fa-calendar-day"></i> Today
                </a>
                <span class="nav-date-display">
                    <?php echo date('M d', strtotime($date_from)); ?> - <?php echo date('M d, Y', strtotime($date_to)); ?>
                </span>
                <a href="?type=<?php echo $report_type; ?>&month=<?php echo $next_month; ?>&year=<?php echo $next_year; ?>" class="nav-btn">
                    Next <i class="fas fa-chevron-right"></i>
                </a>
            </div>
        </div>

        <!-- Report Type Selector -->
        <div class="report-type-buttons animate-in">
            <a href="?type=summary&month=<?php echo $month; ?>&year=<?php echo $year; ?>" class="report-btn <?php echo $report_type == 'summary' ? 'active' : ''; ?>">
                <i class="fas fa-chart-simple"></i> Summary
            </a>
            <a href="?type=community_service&month=<?php echo $month; ?>&year=<?php echo $year; ?>" class="report-btn <?php echo $report_type == 'community_service' ? 'active' : ''; ?>">
                <i class="fas fa-clipboard-list"></i> Community Service
            </a>
            <a href="?type=applications&month=<?php echo $month; ?>&year=<?php echo $year; ?>" class="report-btn <?php echo $report_type == 'applications' ? 'active' : ''; ?>">
                <i class="fas fa-file-alt"></i> Applications
            </a>
            <a href="?type=users&month=<?php echo $month; ?>&year=<?php echo $year; ?>" class="report-btn <?php echo $report_type == 'users' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i> Users
            </a>
        </div>

        <!-- Filter Card -->
        <div class="filter-card animate-in">
            <form method="GET" class="filter-row">
                <input type="hidden" name="type" value="<?php echo $report_type; ?>">
                <input type="hidden" name="month" value="<?php echo $month; ?>">
                <input type="hidden" name="year" value="<?php echo $year; ?>">
                <div class="filter-group">
                    <label><i class="fas fa-map-marker-alt"></i> Filter by Barangay</label>
                    <select name="barangay">
                        <option value="">All Barangays</option>
                        <?php foreach($barangays as $b): ?>
                            <option value="<?php echo htmlspecialchars($b['barangay']); ?>" <?php echo $barangay == $b['barangay'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($b['barangay']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-actions">
                    <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Apply Filter</button>
                    <a href="?type=<?php echo $report_type; ?>&month=<?php echo $month; ?>&year=<?php echo $year; ?>" class="btn-reset">
                        <i class="fas fa-sync-alt"></i> Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Stats Cards -->
        <?php if(!empty($summary_stats)): ?>
        <div class="stats-grid">
            <?php 
            $stat_variants = ['primary', 'danger', 'danger', 'success', 'primary', 'danger'];
            $stat_icons = ['fa-home', 'fa-exclamation-triangle', 'fa-exclamation-circle', 'fa-check-circle', 'fa-clipboard-list', 'fa-exclamation-circle'];
            $stat_index = 0;
            foreach($summary_stats as $stat): 
                $variant = $stat_variants[$stat_index] ?? 'primary';
                $icon = $stat_icons[$stat_index] ?? $stat['icon'];
                $stat_index++;
            ?>
                <div class="stat-card <?php echo $variant; ?> animate-in">
                    <div class="stat-icon">
                        <i class="fas <?php echo $icon; ?>"></i>
                    </div>
                    <div class="stat-content">
                        <div class="stat-number"><?php echo is_numeric($stat['value']) ? number_format($stat['value']) : $stat['value']; ?></div>
                        <div class="stat-label"><?php echo $stat['label']; ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Community Service Offenders -->
        <?php if($report_type == 'community_service' && count($offenders) > 0): ?>
        <div class="offenders-card animate-in">
            <div class="offenders-header">
                <h3><i class="fas fa-exclamation-triangle"></i> Non-Compliant Offenders</h3>
                <span class="offenders-badge">
                    <i class="fas fa-user-slash"></i> <?php echo count($offenders); ?> offenders
                </span>
            </div>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Resident</th>
                            <th>Task</th>
                            <th>Hours Required</th>
                            <th>Hours Completed</th>
                            <th>Status</th>
                            <th>Last Activity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($offenders as $o): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($o['member_name'] ?? 'Unknown'); ?></strong></td>
                            <td><?php echo htmlspecialchars($o['task_name']); ?></td>
                            <td><?php echo number_format($o['total_hours_required'], 1); ?></td>
                            <td><?php echo number_format($o['hours_completed'], 1); ?></td>
                            <td><span style="background: #FEE2E2; color: #991B1B; padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; font-weight: 700;">Non-Compliant</span></td>
                            <td><?php echo date('M d, Y', strtotime($o['updated_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Main Report Card -->
        <div class="report-card animate-in">
            <div class="report-header">
                <h3><i class="fas fa-chart-bar"></i> <?php echo $report_title; ?></h3>
                <div class="export-buttons">
                    <span class="period-info">
                        <i class="fas fa-calendar"></i> <?php echo date('M d', strtotime($date_from)); ?> - <?php echo date('M d, Y', strtotime($date_to)); ?>
                    </span>
                    <a href="?type=<?php echo $report_type; ?>&month=<?php echo $month; ?>&year=<?php echo $year; ?>&barangay=<?php echo $barangay; ?>&export=csv" class="btn-export btn-export-csv">
                        <i class="fas fa-file-csv"></i> CSV
                    </a>
                    <a href="?type=<?php echo $report_type; ?>&month=<?php echo $month; ?>&year=<?php echo $year; ?>&barangay=<?php echo $barangay; ?>&export=xls" class="btn-export btn-export-excel">
                        <i class="fas fa-file-excel"></i> Excel
                    </a>
                    <a href="?type=<?php echo $report_type; ?>&month=<?php echo $month; ?>&year=<?php echo $year; ?>&barangay=<?php echo $barangay; ?>&export_pdf=1" class="btn-export btn-export-pdf" target="_blank">
                        <i class="fas fa-file-pdf"></i> PDF
                    </a>
                </div>
            </div>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <?php foreach($report_headers as $header): ?>
                                <th><?php echo $header; ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($report_data) == 0): ?>
                            <tr>
                                <td colspan="<?php echo count($report_headers); ?>">
                                    <div class="empty-state">
                                        <div class="empty-icon">
                                            <i class="fas fa-folder-open"></i>
                                        </div>
                                        <p>No data found for <?php echo $current_month_name; ?></p>
                                        <div class="empty-hint">Try selecting a different month or adjusting filters</div>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($report_data as $row): ?>
                                <tr>
                                    <?php foreach((array)$row as $key => $value): ?>
                                        <?php if(is_numeric($value) && strpos((string)$value, '.') !== false && $key != 'avg_size'): ?>
                                            <td>₱ <?php echo number_format($value, 2); ?></td>
                                        <?php elseif(is_numeric($value)): ?>
                                            <td><?php echo number_format($value); ?></td>
                                        <?php elseif(!is_numeric($key)): ?>
                                            <td><?php echo htmlspecialchars($value ?? 'N/A'); ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item active"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_idapplication.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Apps</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <script>
        // Sidebar toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) {
            menuToggle.addEventListener('click', () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); });
        }
        if(overlay) {
            overlay.addEventListener('click', () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); });
        }

        // Collapsible Program Menu
        const programToggle = document.getElementById('programToggle');
        const programSubmenu = document.getElementById('programSubmenu');
        const programIcon = document.getElementById('programIcon');
        if(programToggle) {
            programToggle.addEventListener('click', () => { 
                programSubmenu.classList.toggle('show'); 
                programIcon.classList.toggle('rotated'); 
            });
        }

        // Animate cards on scroll
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if(entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.animate-in').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(el);
        });

        console.log('✅ Reports Module loaded with new creative design');
        console.log('📅 Current Month: <?php echo $current_month_name; ?>');
        console.log('📊 Report Type: <?php echo $report_type; ?>');
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>