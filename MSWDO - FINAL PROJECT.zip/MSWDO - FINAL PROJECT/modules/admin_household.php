<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];
$error = '';
$success = '';

// Get deleted count for recycle bin badge
$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
$deleted_count = $stmt->fetch()['total'];

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$barangay_filter = isset($_GET['barangay']) ? trim($_GET['barangay']) : '';
$poverty_filter = isset($_GET['poverty']) ? trim($_GET['poverty']) : '';

// Build query
$where_conditions = [];
$params = [];

if($search) {
    $where_conditions[] = "(head_first_name LIKE ? OR head_last_name LIKE ? OR address LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if($barangay_filter) {
    $where_conditions[] = "barangay = ?";
    $params[] = $barangay_filter;
}

if($poverty_filter) {
    $where_conditions[] = "poverty_status = ?";
    $params[] = $poverty_filter;
}

$where_clause = "";
if(!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

// Get total count
$count_query = "SELECT COUNT(*) as total FROM households $where_clause";
$stmt = $pdo->prepare($count_query);
$stmt->execute($params);
$total_households = $stmt->fetch()['total'];
$total_pages = ceil($total_households / $limit);

// Get households - UPDATED: New salary ranges
$query = "
    SELECT h.*, 
           CASE 
               WHEN h.monthly_income >= 5000 AND h.monthly_income <= 10000 THEN 'POOR'
               WHEN h.monthly_income > 10000 AND h.monthly_income <= 25000 THEN 'MIDDLE-CLASS'
               WHEN h.monthly_income > 25000 THEN 'RICH'
               ELSE 'NOT CLASSIFIED'
           END as calculated_poverty
    FROM households h
    $where_clause
    ORDER BY h.created_at DESC
    LIMIT $limit OFFSET $offset
";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$households = $stmt->fetchAll();

// Get unique barangays for filter
$stmt = $pdo->query("SELECT DISTINCT barangay FROM households WHERE barangay IS NOT NULL AND barangay != '' ORDER BY barangay");
$barangays = $stmt->fetchAll();

// Get poverty statistics - UPDATED: New salary ranges
$stmt = $pdo->query("
    SELECT 
        SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) as poor,
        SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) as middle_class,
        SUM(CASE WHEN monthly_income > 25000 THEN 1 ELSE 0 END) as rich,
        COUNT(*) as total
    FROM households WHERE monthly_income IS NOT NULL
");
$poverty_stats = $stmt->fetch();

// Get household member statistics
$stmt = $pdo->query("SELECT SUM(total_members) as total_members FROM households");
$total_members = $stmt->fetch()['total_members'] ?? 0;

// Get 4Ps beneficiaries count
$stmt = $pdo->query("SELECT COUNT(*) as count FROM households WHERE is_4ps_beneficiary = 1");
$total_4ps = $stmt->fetch()['count'];

// Export to CSV - UPDATED: New salary ranges
if(isset($_GET['export']) && $_GET['export'] == 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="household_data_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Household Head', 'Barangay', 'Address', 'Total Members', 'Monthly Income', 'Poverty Status', '4Ps Beneficiary', 'Date Registered']);
    
    $export_query = "SELECT * FROM households ORDER BY created_at DESC";
    $export_stmt = $pdo->query($export_query);
    while($row = $export_stmt->fetch(PDO::FETCH_ASSOC)) {
        $income = $row['monthly_income'] ?? 0;
        if($income >= 5000 && $income <= 10000) $poverty = 'POOR';
        elseif($income > 10000 && $income <= 25000) $poverty = 'MIDDLE-CLASS';
        elseif($income > 25000) $poverty = 'RICH';
        else $poverty = 'NOT CLASSIFIED';
        
        fputcsv($output, [
            $row['id'],
            $row['head_first_name'] . ' ' . $row['head_last_name'],
            $row['barangay'],
            $row['address'],
            $row['total_members'],
            $row['monthly_income'],
            $poverty,
            $row['is_4ps_beneficiary'] ? 'Yes' : 'No',
            date('Y-m-d', strtotime($row['created_at']))
        ]);
    }
    fclose($output);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Household Records - MSWDO Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 10px; }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.6rem; color: var(--gray-500); }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--gray-500);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
        }
        .nav-item i { width: 20px; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); width: 260px; }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        /* Top Bar */
        .top-bar {
            background: var(--white);
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border: 1px solid var(--gray-200);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
        }
        .page-title h1 { font-size: 1.3rem; font-weight: 600; color: var(--gray-800); }
        .page-title p { font-size: 0.7rem; color: var(--gray-500); margin-top: 2px; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            background: var(--gray-50);
            padding: 6px 12px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); }
        .user-details span { font-size: 0.8rem; font-weight: 500; }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; }
        
        /* Buttons */
        .btn-export {
            background: #2E7D32;
            color: white;
            padding: 10px 20px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-export:hover { background: #1B5E20; transform: translateY(-2px); }
        
        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: white;
            padding: 16px;
            border-radius: var(--radius-lg);
            text-align: center;
            border: 1px solid var(--gray-200);
        }
        .stat-card i { font-size: 1.8rem; margin-bottom: 8px; }
        .stat-card .stat-number { font-size: 1.6rem; font-weight: 700; color: var(--gray-800); }
        .stat-card .stat-label { font-size: 0.7rem; color: var(--gray-500); }
        
        /* Poverty Mini Stats - 3 CLASSES */
        .poverty-mini {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 24px;
        }
        .poverty-mini-item {
            padding: 10px;
            border-radius: var(--radius-lg);
            text-align: center;
        }
        .poverty-mini-item .pov-number { font-size: 1.3rem; font-weight: 700; }
        
        /* Filter Section */
        .filter-section {
            background: white;
            border-radius: var(--radius-xl);
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
        }
        .filter-row {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        .filter-group {
            flex: 1;
            min-width: 150px;
        }
        .filter-group label {
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--gray-500);
            margin-bottom: 4px;
            display: block;
        }
        .filter-group input, .filter-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.8rem;
        }
        .btn-filter {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
        }
        .btn-clear {
            background: var(--gray-100);
            color: var(--gray-600);
            border: 1px solid var(--gray-200);
            padding: 8px 20px;
            border-radius: var(--radius-md);
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
        }
        
        /* Table */
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 900px;
        }
        .table th {
            padding: 12px 16px;
            background: var(--gray-50);
            font-weight: 600;
            border-bottom: 2px solid var(--accent);
            text-align: left;
        }
        .table td {
            padding: 10px 16px;
            border-bottom: 1px solid var(--gray-200);
        }
        
        /* Badges - 3 CLASSES */
        .poverty-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .poverty-poor { background: #D32F2F; color: white; }
        .poverty-middle { background: #1E4A8C; color: white; }
        .poverty-rich { background: #F5B042; color: #1E2F4E; }
        
        .btn-view {
            background: var(--primary);
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            text-decoration: none;
            font-size: 0.7rem;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .btn-view:hover { background: var(--primary-dark); }
        
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 24px;
            flex-wrap: wrap;
        }
        .pagination a, .pagination span {
            padding: 6px 12px;
            border-radius: var(--radius-md);
            text-decoration: none;
            font-size: 0.8rem;
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--primary);
        }
        .pagination a:hover { background: var(--primary); color: white; }
        .pagination .active { background: var(--secondary); color: white; border-color: var(--secondary); }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        .empty-state i { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; }
        
        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.7rem;
            color: var(--gray-600);
            text-decoration: none;
            position: relative;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        .nav-badge {
            position: absolute;
            top: -8px;
            right: -12px;
            background: var(--secondary);
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.6rem;
        }
        
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .poverty-mini { grid-template-columns: repeat(3, 1fr); }
            .filter-row { flex-direction: column; }
        }
        @media (max-width: 480px) {
            .poverty-mini { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Administrator</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <!-- MAIN SECTION -->
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="manage_users.php" class="nav-item"><i class="fas fa-users-cog"></i> User Management</a>
                <a href="admin_household.php" class="nav-item active"><i class="fas fa-home"></i> All Households</a>
            </div>
            <!-- SYSTEM SECTION -->
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i> Poverty Analysis</a>
                <a href="admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="../admin/recycle_bin.php" class="nav-item"><i class="fas fa-trash-restore"></i> Recycle Bin</a>
            </div>
            <!-- ACCOUNT SECTION -->
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Household Records</h1>
                <p>Manage and view all registered households</p>
            </div>
            <a href="admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card"><i class="fas fa-home" style="color: var(--primary);"></i><div class="stat-number"><?php echo $total_households; ?></div><div class="stat-label">Total Households</div></div>
            <div class="stat-card"><i class="fas fa-users" style="color: #2E7D32;"></i><div class="stat-number"><?php echo $total_members; ?></div><div class="stat-label">Total Residents</div></div>
            <div class="stat-card"><i class="fas fa-hand-holding-usd" style="color: var(--accent);"></i><div class="stat-number"><?php echo $total_4ps; ?></div><div class="stat-label">4Ps Beneficiaries</div></div>
            <div class="stat-card"><i class="fas fa-chart-line" style="color: #9C27B0;"></i><div class="stat-number"><?php echo $total_households > 0 ? round(($total_4ps / $total_households) * 100, 1) : 0; ?>%</div><div class="stat-label">4Ps Coverage</div></div>
            <div class="stat-card"><i class="fas fa-chart-bar" style="color: var(--secondary);"></i><div class="stat-number"><?php echo $total_households > 0 ? round($total_members / $total_households, 1) : 0; ?></div><div class="stat-label">Avg Household Size</div></div>
        </div>

        <!-- Poverty Mini Stats - UPDATED: New salary ranges -->
        <div class="poverty-mini">
            <div class="poverty-mini-item" style="background: #D32F2F; color: white;">
                <div class="pov-number"><?php echo $poverty_stats['poor'] ?? 0; ?></div>
                <div>POOR</div>
                <div style="font-size:0.6rem;">₱5,000 - ₱10,000</div>
            </div>
            <div class="poverty-mini-item" style="background: #1E4A8C; color: white;">
                <div class="pov-number"><?php echo $poverty_stats['middle_class'] ?? 0; ?></div>
                <div>MIDDLE-CLASS</div>
                <div style="font-size:0.6rem;">₱10,000 - ₱25,000</div>
            </div>
            <div class="poverty-mini-item" style="background: #F5B042; color: #1E2F4E;">
                <div class="pov-number"><?php echo $poverty_stats['rich'] ?? 0; ?></div>
                <div>RICH</div>
                <div style="font-size:0.6rem;">₱25,000 and above</div>
            </div>
        </div>

        <!-- Export Button -->
        <div style="display: flex; justify-content: flex-end; margin-bottom: 16px;">
            <a href="?export=csv" class="btn-export"><i class="fas fa-file-csv"></i> Export to CSV</a>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" action="" class="filter-row">
                <div class="filter-group">
                    <label><i class="fas fa-search"></i> Search</label>
                    <input type="text" name="search" placeholder="Household head or address..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-group">
                    <label><i class="fas fa-map-marker-alt"></i> Barangay</label>
                    <select name="barangay">
                        <option value="">All Barangays</option>
                        <?php foreach($barangays as $b): ?>
                            <option value="<?php echo htmlspecialchars($b['barangay']); ?>" <?php echo $barangay_filter == $b['barangay'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($b['barangay']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-group">
                    <label><i class="fas fa-chart-line"></i> Poverty Status</label>
                    <select name="poverty">
                        <option value="">All Status</option>
                        <option value="POOR" <?php echo $poverty_filter == 'POOR' ? 'selected' : ''; ?>>POOR</option>
                        <option value="MIDDLE-CLASS" <?php echo $poverty_filter == 'MIDDLE-CLASS' ? 'selected' : ''; ?>>MIDDLE-CLASS</option>
                        <option value="RICH" <?php echo $poverty_filter == 'RICH' ? 'selected' : ''; ?>>RICH</option>
                    </select>
                </div>
                <div class="filter-group">
                    <button type="submit" class="btn-filter"><i class="fas fa-search"></i> Apply Filter</button>
                    <?php if($search || $barangay_filter || $poverty_filter): ?>
                        <a href="admin_household.php" class="btn-clear"><i class="fas fa-sync-alt"></i> Clear</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Households Table -->
        <div class="table-container">
            <?php if(count($households) == 0): ?>
                <div class="empty-state"><i class="fas fa-folder-open"></i><p>No household records found.</p><p style="font-size:0.75rem;">Try adjusting your search or filter criteria.</p></div>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Household Head</th>
                            <th>Barangay</th>
                            <th>Address</th>
                            <th>Members</th>
                            <th>Monthly Income</th>
                            <th>Poverty Status</th>
                            <th>4Ps</th>
                            <th>Date Registered</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($households as $hh): 
                            $income = $hh['monthly_income'] ?? 0;
                            if($income >= 5000 && $income <= 10000) { $poverty = 'POOR'; $poverty_class = 'poverty-poor'; }
                            elseif($income > 10000 && $income <= 25000) { $poverty = 'MIDDLE-CLASS'; $poverty_class = 'poverty-middle'; }
                            elseif($income > 25000) { $poverty = 'RICH'; $poverty_class = 'poverty-rich'; }
                            else { $poverty = 'NOT CLASSIFIED'; $poverty_class = 'poverty-poor'; }
                        ?>
                            <tr>
                                <td><?php echo $hh['id']; ?></td>
                                <td><strong><?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($hh['barangay'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars(substr($hh['address'] ?? '', 0, 40)) . (strlen($hh['address'] ?? '') > 40 ? '...' : ''); ?></td>
                                <td><?php echo $hh['total_members'] ?? 1; ?></td>
                                <td>₱ <?php echo number_format($income, 2); ?></td>
                                <td><span class="poverty-badge <?php echo $poverty_class; ?>"><?php echo $poverty; ?></span></td>
                                <td><?php echo $hh['is_4ps_beneficiary'] ? '<i class="fas fa-check-circle" style="color:#2E7D32;"></i> Yes' : '<i class="fas fa-times-circle" style="color:#D32F2F;"></i> No'; ?></td>
                                <td><?php echo date('M d, Y', strtotime($hh['created_at'])); ?></td>
                                <td><a href="admin_household_view.php?id=<?php echo $hh['id']; ?>" class="btn-view"><i class="fas fa-eye"></i> View</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if($total_pages > 1): ?>
            <div class="pagination">
                <?php if($page > 1): ?>
                    <a href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>&barangay=<?php echo urlencode($barangay_filter); ?>&poverty=<?php echo urlencode($poverty_filter); ?>"><i class="fas fa-chevron-left"></i> Prev</a>
                <?php endif; ?>
                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if($i == $page): ?>
                        <span class="active"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&barangay=<?php echo urlencode($barangay_filter); ?>&poverty=<?php echo urlencode($poverty_filter); ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                <?php if($page < $total_pages): ?>
                    <a href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>&barangay=<?php echo urlencode($barangay_filter); ?>&poverty=<?php echo urlencode($poverty_filter); ?>">Next <i class="fas fa-chevron-right"></i></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="admin_household.php" class="nav-item active"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Poverty</span></a>
        <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>