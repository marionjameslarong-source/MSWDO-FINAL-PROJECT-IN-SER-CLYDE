<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$error = '';
$success = '';

// Handle settings update
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['save_general'])) {
        $site_name = $_POST['site_name'] ?? 'MSWDO Mobile System';
        $site_description = $_POST['site_description'] ?? '';
        $contact_email = $_POST['contact_email'] ?? '';
        $contact_phone = $_POST['contact_phone'] ?? '';
        $office_address = $_POST['office_address'] ?? '';
        
        $_SESSION['settings'] = [
            'site_name' => $site_name,
            'site_description' => $site_description,
            'contact_email' => $contact_email,
            'contact_phone' => $contact_phone,
            'office_address' => $office_address
        ];
        
        $success = "General settings saved successfully!";
    }
    
    if(isset($_POST['save_security'])) {
        $session_timeout = $_POST['session_timeout'] ?? 30;
        $max_login_attempts = $_POST['max_login_attempts'] ?? 5;
        $password_expiry = $_POST['password_expiry'] ?? 90;
        $enable_2fa = isset($_POST['enable_2fa']) ? 1 : 0;
        
        $_SESSION['security_settings'] = [
            'session_timeout' => $session_timeout,
            'max_login_attempts' => $max_login_attempts,
            'password_expiry' => $password_expiry,
            'enable_2fa' => $enable_2fa
        ];
        
        $success = "Security settings saved successfully!";
    }
    
    if(isset($_POST['save_notification'])) {
        $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
        $sms_notifications = isset($_POST['sms_notifications']) ? 1 : 0;
        $new_user_alert = isset($_POST['new_user_alert']) ? 1 : 0;
        $household_submit_alert = isset($_POST['household_submit_alert']) ? 1 : 0;
        
        $_SESSION['notification_settings'] = [
            'email_notifications' => $email_notifications,
            'sms_notifications' => $sms_notifications,
            'new_user_alert' => $new_user_alert,
            'household_submit_alert' => $household_submit_alert
        ];
        
        $success = "Notification settings saved successfully!";
    }
}

// Load settings from session or defaults
$general_settings = $_SESSION['settings'] ?? [
    'site_name' => 'MSWDO Mobile System',
    'site_description' => 'Municipal Social Welfare and Development Office Mobile Data Collection System',
    'contact_email' => 'info@mswdo.gov.ph',
    'contact_phone' => '(02) 1234 5678',
    'office_address' => 'Municipal Hall, Poblacion, Municipality'
];

$security_settings = $_SESSION['security_settings'] ?? [
    'session_timeout' => 30,
    'max_login_attempts' => 5,
    'password_expiry' => 90,
    'enable_2fa' => 0
];

$notification_settings = $_SESSION['notification_settings'] ?? [
    'email_notifications' => 1,
    'sms_notifications' => 0,
    'new_user_alert' => 1,
    'household_submit_alert' => 1
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>System Settings - MSWDO Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .settings-tabs {
            display: flex;
            gap: 5px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            border-bottom: 2px solid var(--gray-200);
            padding-bottom: 10px;
        }
        .tab-btn {
            padding: 10px 20px;
            background: var(--gray-200);
            border: none;
            border-radius: var(--radius-lg) var(--radius-lg) 0 0;
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition-fast);
        }
        .tab-btn.active {
            background: var(--primary);
            color: white;
        }
        .tab-pane {
            display: none;
            animation: fadeIn 0.3s ease;
        }
        .tab-pane.active {
            display: block;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .settings-card {
            background: white;
            border-radius: var(--radius-lg);
            overflow: hidden;
        }
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: var(--gray-400);
            transition: 0.3s;
            border-radius: 24px;
        }
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: 0.3s;
            border-radius: 50%;
        }
        input:checked + .toggle-slider {
            background-color: var(--success);
        }
        input:checked + .toggle-slider:before {
            transform: translateX(26px);
        }
        .setting-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid var(--gray-200);
            flex-wrap: wrap;
            gap: 10px;
        }
        .setting-label {
            font-weight: 600;
        }
        .setting-description {
            font-size: 0.75rem;
            color: var(--gray-600);
            margin-top: 3px;
        }
        .setting-control {
            min-width: 200px;
        }
        .setting-control input, .setting-control select {
            width: 100%;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            border: 1px solid var(--gray-300);
        }
        @media (max-width: 768px) {
            .setting-row {
                flex-direction: column;
                align-items: flex-start;
            }
            .setting-control {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <div class="top-bar">
            <a href="../dashboards/admin_dashboard.php" class="nav-item" style="flex-direction: row; gap: var(--spacing-xs);">
                ← Dashboard
            </a>
            <div class="logo" style="font-size: 1.25rem;">⚙️ MSWDO Settings</div>
            <div style="width: 80px;"></div>
        </div>
        
        <div class="container">
            <?php if($error): ?>
                <div class="alert alert-danger">⚠️ <?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="alert alert-success">✅ <?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="settings-card">
                <div class="settings-tabs">
                    <button class="tab-btn active" onclick="showTab('general')">🏢 General</button>
                    <button class="tab-btn" onclick="showTab('security')">🔒 Security</button>
                    <button class="tab-btn" onclick="showTab('notifications')">🔔 Notifications</button>
                    <button class="tab-btn" onclick="showTab('database')">💾 Database</button>
                </div>
                
                <!-- General Settings Tab -->
                <div id="general" class="tab-pane active">
                    <form method="POST" action="">
                        <div style="padding: 20px;">
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Site Name</div>
                                    <div class="setting-description">The name of the system displayed throughout the application</div>
                                </div>
                                <div class="setting-control">
                                    <input type="text" name="site_name" value="<?php echo htmlspecialchars($general_settings['site_name']); ?>" required>
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Site Description</div>
                                    <div class="setting-description">Brief description of the system</div>
                                </div>
                                <div class="setting-control">
                                    <textarea name="site_description" rows="2" style="width: 100%; padding: 8px; border-radius: 8px; border: 1px solid var(--gray-300);"><?php echo htmlspecialchars($general_settings['site_description']); ?></textarea>
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Contact Email</div>
                                    <div class="setting-description">Primary email address for system notifications</div>
                                </div>
                                <div class="setting-control">
                                    <input type="email" name="contact_email" value="<?php echo htmlspecialchars($general_settings['contact_email']); ?>">
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Contact Phone</div>
                                    <div class="setting-description">Primary contact number</div>
                                </div>
                                <div class="setting-control">
                                    <input type="text" name="contact_phone" value="<?php echo htmlspecialchars($general_settings['contact_phone']); ?>">
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Office Address</div>
                                    <div class="setting-description">MSWDO office location</div>
                                </div>
                                <div class="setting-control">
                                    <textarea name="office_address" rows="2" style="width: 100%; padding: 8px; border-radius: 8px; border: 1px solid var(--gray-300);"><?php echo htmlspecialchars($general_settings['office_address']); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div style="padding: 20px; background: var(--gray-100); text-align: right;">
                            <button type="submit" name="save_general" class="btn btn-primary">Save General Settings</button>
                        </div>
                    </form>
                </div>
                
                <!-- Security Settings Tab -->
                <div id="security" class="tab-pane">
                    <form method="POST" action="">
                        <div style="padding: 20px;">
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Session Timeout (minutes)</div>
                                    <div class="setting-description">Auto logout after inactivity</div>
                                </div>
                                <div class="setting-control">
                                    <input type="number" name="session_timeout" value="<?php echo $security_settings['session_timeout']; ?>" min="5" max="480">
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Max Login Attempts</div>
                                    <div class="setting-description">Number of failed attempts before account lockout</div>
                                </div>
                                <div class="setting-control">
                                    <input type="number" name="max_login_attempts" value="<?php echo $security_settings['max_login_attempts']; ?>" min="3" max="10">
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Password Expiry (days)</div>
                                    <div class="setting-description">Number of days before password must be changed (0 = never)</div>
                                </div>
                                <div class="setting-control">
                                    <input type="number" name="password_expiry" value="<?php echo $security_settings['password_expiry']; ?>" min="0" max="365">
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Two-Factor Authentication</div>
                                    <div class="setting-description">Require 2FA for admin accounts</div>
                                </div>
                                <div class="setting-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" name="enable_2fa" <?php echo $security_settings['enable_2fa'] ? 'checked' : ''; ?>>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div style="padding: 20px; background: var(--gray-100); text-align: right;">
                            <button type="submit" name="save_security" class="btn btn-primary">Save Security Settings</button>
                        </div>
                    </form>
                </div>
                
                <!-- Notifications Tab -->
                <div id="notifications" class="tab-pane">
                    <form method="POST" action="">
                        <div style="padding: 20px;">
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Email Notifications</div>
                                    <div class="setting-description">Send email notifications for system events</div>
                                </div>
                                <div class="setting-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" name="email_notifications" <?php echo $notification_settings['email_notifications'] ? 'checked' : ''; ?>>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">SMS Notifications</div>
                                    <div class="setting-description">Send SMS notifications for critical alerts</div>
                                </div>
                                <div class="setting-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" name="sms_notifications" <?php echo $notification_settings['sms_notifications'] ? 'checked' : ''; ?>>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">New User Alert</div>
                                    <div class="setting-description">Notify admin when new user registers</div>
                                </div>
                                <div class="setting-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" name="new_user_alert" <?php echo $notification_settings['new_user_alert'] ? 'checked' : ''; ?>>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="setting-row">
                                <div>
                                    <div class="setting-label">Household Submission Alert</div>
                                    <div class="setting-description">Notify staff when new household data is submitted</div>
                                </div>
                                <div class="setting-control">
                                    <label class="toggle-switch">
                                        <input type="checkbox" name="household_submit_alert" <?php echo $notification_settings['household_submit_alert'] ? 'checked' : ''; ?>>
                                        <span class="toggle-slider"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div style="padding: 20px; background: var(--gray-100); text-align: right;">
                            <button type="submit" name="save_notification" class="btn btn-primary">Save Notification Settings</button>
                        </div>
                    </form>
                </div>
                
                <!-- Database Tab -->
                <div id="database" class="tab-pane">
                    <div style="padding: 20px;">
                        <div class="setting-row">
                            <div>
                                <div class="setting-label">Database Status</div>
                                <div class="setting-description">Current database connection status</div>
                            </div>
                            <div class="setting-control">
                                <span class="badge" style="background: #27ae60; color: white; padding: 5px 15px;">✅ Connected</span>
                            </div>
                        </div>
                        
                        <div class="setting-row">
                            <div>
                                <div class="setting-label">Database Name</div>
                                <div class="setting-description">Current database in use</div>
                            </div>
                            <div class="setting-control">
                                <code><?php echo $dbname ?? 'mswdo_db'; ?></code>
                            </div>
                        </div>
                        
                        <div class="setting-row">
                            <div>
                                <div class="setting-label">Last Backup</div>
                                <div class="setting-description">Date of last database backup</div>
                            </div>
                            <div class="setting-control">
                                <span>Not yet backed up</span>
                                <a href="data_backup.php" class="btn btn-primary btn-sm" style="margin-left: 10px;">Backup Now</a>
                            </div>
                        </div>
                        
                        <div class="setting-row">
                            <div>
                                <div class="setting-label">System Logs</div>
                                <div class="setting-description">View system activity and error logs</div>
                            </div>
                            <div class="setting-control">
                                <a href="audit_logs.php" class="btn btn-outline btn-sm">View Logs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-pane').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active class from all buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
        }
    </script>
</body>
</html>