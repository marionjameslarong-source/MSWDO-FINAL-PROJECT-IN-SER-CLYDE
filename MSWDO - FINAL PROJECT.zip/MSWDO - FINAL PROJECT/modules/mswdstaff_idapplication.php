<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder', 'admin'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];

// ============================================================
// 1. APPROVE ID APPLICATION (Moves to PENDING_PRINT queue)
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve_id'])) {
    $application_id = $_POST['application_id'];
    $quality_check_passed = isset($_POST['quality_check_passed']) ? 1 : 0;
    $system_remarks = $_POST['system_remarks'] ?? 'Photo and signature verified clear. Moving to production queue.';
    
    // Generate tracking number
    $tracking_number = 'ID-' . date('Y') . '-' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
    
    $stmt = $pdo->prepare("
        UPDATE welfare_applications 
        SET status = 'pending_print', 
            review_notes = ?, 
            reviewed_by = ?, 
            reviewed_at = NOW(), 
            updated_at = NOW(),
            tracking_number = ?,
            quality_check_passed = ?
        WHERE id = ?
    ");
    $stmt->execute([$system_remarks, $user_id, $tracking_number, $quality_check_passed, $application_id]);
    $success_message = "ID Application approved and moved to printing queue. Tracking #: " . $tracking_number;
}

// ============================================================
// 2. ISSUE ID CARD (Activate and assign serial number)
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['issue_id'])) {
    $application_id = $_POST['application_id'];
    $physical_card_serial = $_POST['physical_card_serial'] ?? '';
    $issuance_method = $_POST['issuance_method'] ?? 'WALK_IN_PICKUP';
    $date_issued = date('Y-m-d H:i:s');
    
    // Validate serial number
    if(empty($physical_card_serial)) {
        $error_message = "Physical card serial number is required.";
    } else {
        // Check if serial already used
        $check = $pdo->prepare("SELECT id FROM welfare_applications WHERE physical_card_serial = ? AND id != ?");
        $check->execute([$physical_card_serial, $application_id]);
        if($check->rowCount() > 0) {
            $error_message = "Serial number already assigned to another ID card.";
        } else {
            $stmt = $pdo->prepare("
                UPDATE welfare_applications 
                SET status = 'issued', 
                    physical_card_serial = ?,
                    issuance_method = ?,
                    date_issued = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$physical_card_serial, $issuance_method, $date_issued, $application_id]);
            $success_message = "ID Card issued successfully! Serial: " . $physical_card_serial;
        }
    }
}

// ============================================================
// 3. REJECT ID APPLICATION
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_id'])) {
    $application_id = $_POST['application_id'];
    $rejection_reason = $_POST['rejection_reason'] ?? 'BLURRY_ID_PHOTO';
    $instruction_to_resident = $_POST['instruction_to_resident'] ?? 'Please re-upload a clear, formal passport-sized photo with a plain white background.';
    
    $stmt = $pdo->prepare("
        UPDATE welfare_applications 
        SET status = 'rejected', 
            review_notes = CONCAT('Rejection Code: ', ?, ' - Instruction: ', ?),
            reviewed_by = ?,
            reviewed_at = NOW(),
            updated_at = NOW(),
            rejection_reason = ?,
            instruction_to_resident = ?
        WHERE id = ?
    ");
    $stmt->execute([$rejection_reason, $instruction_to_resident, $user_id, $rejection_reason, $instruction_to_resident, $application_id]);
    $success_message = "ID Application rejected. Resident has been notified.";
}

// ============================================================
// 4. HANDLE VIEW ID DETAILS (Side-by-Side Photo & Signature)
// ============================================================
$view_application = null;
$view_app_data = [];
if(isset($_GET['view_id']) && !empty($_GET['view_id'])) {
    $view_id = intval($_GET['view_id']);
    $stmt = $pdo->prepare("
        SELECT wa.*, u.full_name as applicant_name, u.username, u.email, u.contact_number 
        FROM welfare_applications wa 
        LEFT JOIN users u ON wa.user_id = u.id 
        WHERE wa.id = ? AND wa.program_type = 'id_application'
    ");
    $stmt->execute([$view_id]);
    $view_application = $stmt->fetch(PDO::FETCH_ASSOC);
    if($view_application) {
        $view_app_data = json_decode($view_application['application_data'], true);
    }
}

// ============================================================
// 5. GET ALL ID APPLICATIONS
// ============================================================
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$query = "
    SELECT wa.*, u.full_name as applicant_name, u.username, u.email, u.contact_number 
    FROM welfare_applications wa 
    LEFT JOIN users u ON wa.user_id = u.id 
    WHERE wa.program_type = 'id_application'
";
if($status_filter != 'all') {
    $query .= " AND wa.status = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$status_filter]);
} else {
    $stmt = $pdo->prepare($query);
    $stmt->execute();
}
$applications = $stmt->fetchAll();

// Get statistics
$pending_count = count(array_filter($applications, fn($a) => $a['status'] == 'pending'));
$pending_print_count = count(array_filter($applications, fn($a) => $a['status'] == 'pending_print'));
$approved_count = count(array_filter($applications, fn($a) => $a['status'] == 'approved'));
$issued_count = count(array_filter($applications, fn($a) => $a['status'] == 'issued'));
$rejected_count = count(array_filter($applications, fn($a) => $a['status'] == 'rejected'));

// ID Type mapping
$id_types = [
    'mswdo_id' => 'MSWDO ID Card',
    'senior_citizen_id' => 'Senior Citizen ID',
    'pwd_id' => 'PWD ID',
    'solo_parent_id' => 'Solo Parent ID',
    'replacement' => 'Replacement of Lost ID',
    'other' => 'Other'
];

// Rejection reason codes
$rejection_reasons = [
    'BLURRY_ID_PHOTO' => 'Blurry/Unclear ID Photo',
    'MISSING_SIGNATURE' => 'Missing Signature File',
    'WRONG_DOCUMENT' => 'Wrong/Invalid Document',
    'INCOMPLETE_FORM' => 'Incomplete Application Form',
    'NO_PROOF_OF_RESIDENCY' => 'No Proof of Residency',
    'OTHER' => 'Other Reason'
];

// Issuance methods
$issuance_methods = [
    'WALK_IN_PICKUP' => 'Walk-in Pickup',
    'MAIL_DELIVERY' => 'Mail Delivery',
    'MOBILE_APP' => 'Mobile App Deployment',
    'BARANGAY_CENTER' => 'Barangay Center Pickup'
];

// Helper function to get status badge class
function getStatusClass($status) {
    switch($status) {
        case 'pending': return 'status-pending';
        case 'pending_print': return 'status-printing';
        case 'approved': return 'status-approved';
        case 'issued': return 'status-issued';
        case 'rejected': return 'status-rejected';
        default: return 'status-pending';
    }
}

function getStatusLabel($status) {
    switch($status) {
        case 'pending': return 'Pending Review';
        case 'pending_print': return 'Pending Print';
        case 'approved': return 'Approved';
        case 'issued': return 'Issued';
        case 'rejected': return 'Rejected';
        default: return ucfirst($status);
    }
}

// Get deleted count for recycle bin badge (only for admin)
$deleted_count = 0;
if($role === 'admin') {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
    $deleted_count = $stmt->fetch()['total'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>ID Applications - MSWD Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        /* ============================================================
           UPDATED: MSWDO Logo Image replaces Font Awesome icon
           ============================================================ */
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 2px;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .submenu-item.active i { color: var(--accent); }
        
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 {
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px;
            height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        
        .program-header {
            background: linear-gradient(135deg, #E0F7FA, #B2EBF2);
            padding: 28px;
            border-radius: var(--radius-xl);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 18px;
            box-shadow: 0 12px 24px -8px rgba(0, 105, 92, 0.2);
            border: 1px solid rgba(0, 137, 123, 0.3);
        }
        .program-icon {
            width: 64px;
            height: 64px;
            background: #00695C;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 20px rgba(0, 105, 92, 0.3);
            flex-shrink: 0;
        }
        .program-icon i { font-size: 1.8rem; color: white; }
        .program-title h2 { font-size: 1.5rem; color: #004D40; font-weight: 800; letter-spacing: -0.02em; }
        .program-title p { color: #00695C; font-size: 0.82rem; margin-top: 4px; }
        
        .stats-row {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-box {
            background: white;
            padding: 20px;
            border-radius: var(--radius-xl);
            text-align: center;
            border: 1px solid var(--gray-200);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .stat-box::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), #3B82F6);
        }
        .stat-box:nth-child(1)::before { background: linear-gradient(90deg, #F5B042, #FCD34D); }
        .stat-box:nth-child(2)::before { background: linear-gradient(90deg, #F97316, #FB923C); }
        .stat-box:nth-child(3)::before { background: linear-gradient(90deg, #059669, #34D399); }
        .stat-box:nth-child(4)::before { background: linear-gradient(90deg, #10B981, #6EE7B7); }
        .stat-box:nth-child(5)::before { background: linear-gradient(90deg, #DC2626, #F87171); }
        .stat-box:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); border-color: transparent; }
        .stat-number { font-size: 2rem; font-weight: 800; color: var(--gray-800); letter-spacing: -0.03em; }
        .stat-box:nth-child(1) .stat-number { color: #B45309; }
        .stat-box:nth-child(2) .stat-number { color: #E65100; }
        .stat-box:nth-child(3) .stat-number { color: #059669; }
        .stat-box:nth-child(4) .stat-number { color: #059669; }
        .stat-box:nth-child(5) .stat-number { color: #DC2626; }
        .stat-label { font-size: 0.68rem; color: var(--gray-500); font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 6px; }
        
        .filter-bar {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            background: white;
            padding: 6px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .filter-btn {
            padding: 9px 20px;
            border-radius: var(--radius-md);
            background: transparent;
            border: none;
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--gray-600);
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .filter-btn:hover { background: var(--gray-100); color: var(--primary); }
        .filter-btn.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        
        .alert-success {
            background: #D1FAE5;
            color: #065F46;
            padding: 14px 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.85rem;
            font-weight: 500;
            border-left: 4px solid #059669;
            animation: slideDown 0.3s ease;
        }
        .alert-error {
            background: #FEE2E2;
            color: #991B1B;
            padding: 14px 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.85rem;
            font-weight: 500;
            border-left: 4px solid #D32F2F;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
            box-shadow: var(--shadow-sm);
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 1100px;
        }
        .table th {
            text-align: left;
            padding: 14px 16px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            color: var(--gray-600);
            border-bottom: 2px solid var(--accent);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 0.68rem;
        }
        .table td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .table tr:hover td { background: var(--gray-50); }
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .status-pending { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .status-printing { background: #FFE0B2; color: #E65100; border: 1px solid #FB923C; }
        .status-approved { background: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7; }
        .status-issued { background: #D1FAE5; color: #059669; border: 1px solid #6EE7B7; }
        .status-rejected { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        
        .btn-approve {
            background: #059669;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-approve:hover { background: #047857; transform: translateY(-1px); }
        .btn-reject {
            background: #D32F2F;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            margin-left: 5px;
            transition: all 0.2s;
        }
        .btn-reject:hover { background: #B71C1C; transform: translateY(-1px); }
        .btn-issue {
            background: var(--primary);
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-issue:hover { background: var(--primary-dark); transform: translateY(-1px); }
        .btn-view {
            background: var(--primary);
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.2s;
        }
        .btn-view:hover { background: var(--primary-dark); transform: translateY(-1px); }
        
        /* ID Details Modal */
        .id-details-modal .modal-content { max-width: 650px; }
        .id-details-modal .meta-block {
            background: var(--gray-50);
            padding: 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
        }
        .id-details-modal .meta-block .meta-label {
            font-size: 0.65rem;
            font-weight: 700;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .id-details-modal .meta-block .meta-value {
            font-size: 1rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-top: 2px;
        }
        .id-details-modal .meta-block .id-type-badge {
            display: inline-block;
            background: #E0F2FE;
            color: #0284C7;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 700;
            margin-top: 4px;
        }
        .id-details-modal .section-header {
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--gray-700);
            margin-bottom: 12px;
        }
        .id-details-modal .image-flex-row {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100%;
            margin-bottom: 20px;
            gap: 16px;
        }
        .id-details-modal .image-column { width: 50%; }
        .id-details-modal .image-label {
            font-size: 0.7rem;
            font-weight: 700;
            color: var(--gray-600);
            text-align: center;
            margin-bottom: 6px;
        }
        .id-details-modal .image-frame {
            width: 100%;
            height: 180px;
            background: var(--gray-100);
            border-radius: var(--radius-md);
            overflow: hidden;
            border: 2px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        .id-details-modal .image-frame img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .id-details-modal .image-frame .signature-img { object-fit: contain; }
        .id-details-modal .image-frame .image-status {
            position: absolute;
            bottom: 8px;
            right: 8px;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.55rem;
            font-weight: 700;
            background: rgba(0,0,0,0.6);
            color: white;
        }
        .id-details-modal .image-frame .image-status.verified { background: rgba(5, 150, 105, 0.8); }
        .id-details-modal .image-frame .image-status.missing { background: rgba(211, 47, 47, 0.8); }
        
        .id-details-modal .actions-block {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 8px;
        }
        .id-details-modal .btn-approve-id {
            background: #10B981;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .id-details-modal .btn-approve-id:hover {
            background: #059669;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }
        .id-details-modal .btn-reject-id {
            background: #EF4444;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .id-details-modal .btn-reject-id:hover {
            background: #DC2626;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }
        .id-details-modal .btn-close-details {
            background: var(--gray-200);
            color: var(--gray-700);
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        .id-details-modal .btn-close-details:hover { background: var(--gray-300); }
        .id-details-modal .modal-footer-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--gray-200);
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            z-index: 1100;
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 550px;
            width: 90%;
            padding: 24px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.2);
        }
        .form-group { margin-bottom: 16px; }
        .form-group label { 
            display: block; 
            font-size: 0.75rem; 
            font-weight: 700; 
            margin-bottom: 6px;
            color: var(--gray-700);
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .form-group select, 
        .form-group textarea,
        .form-group input[type="text"] {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: inherit;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        .form-group select:focus,
        .form-group textarea:focus,
        .form-group input[type="text"]:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
        }
        .form-group textarea { resize: vertical; min-height: 60px; }
        .form-group .checkbox-group {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .form-group .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
        }
        .form-group .checkbox-group label {
            margin-bottom: 0;
            font-weight: 500;
            text-transform: none;
        }
        .btn-submit {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 700;
            font-size: 0.85rem;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-cancel {
            background: var(--gray-200);
            color: var(--gray-700);
            border: none;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            cursor: pointer;
            margin-left: 10px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        .btn-cancel:hover { background: var(--gray-300); }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--gray-200);
        }
        
        .tracking-number {
            font-family: monospace;
            background: var(--gray-100);
            padding: 3px 10px;
            border-radius: 6px;
            font-size: 0.7rem;
            font-weight: 700;
            color: var(--gray-700);
        }
        .serial-number {
            font-family: monospace;
            font-weight: 700;
            color: var(--primary);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        .empty-state i { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; display: block; }
        
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-decoration: none;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        
        @media (max-width: 992px) {
            .stats-row { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .top-bar { flex-wrap: wrap; gap: 12px; }
            .page-title h1 { font-size: 1.1rem; }
            .page-title p { display: none; }
            .id-details-modal .image-flex-row {
                flex-direction: column;
                gap: 12px;
            }
            .id-details-modal .image-column { width: 100%; }
            .id-details-modal .image-frame { height: 150px; }
            .id-details-modal .modal-footer-actions { flex-direction: column; }
            .id-details-modal .modal-footer-actions .btn-close-details { order: 1; }
        }
        @media (max-width: 480px) { 
            .stats-row { grid-template-columns: 1fr; }
            .id-details-modal .image-frame { height: 130px; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <!-- ============================================================
                     UPDATED: MSWDO Logo Image replaces Font Awesome icon
                     ============================================================ -->
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="mswdstaff_communityservice.php" class="nav-item">
                    <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
                </a>
                <a href="household.php" class="nav-item">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Applications</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="mswdstaff_idapplication.php" class="nav-item active">
                    <i class="fas fa-id-card"></i> <span>ID Applications</span>
                </a>
                <a href="staff_eligibility_engine.php" class="nav-item">
                    <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="mswdstaff_profile.php" class="nav-item">
                    <i class="fas fa-user-circle"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>ID Applications</h1>
                <p>View and manage ID card applications submitted by residents</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <?php if(isset($success_message)): ?>
            <div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if(isset($error_message)): ?>
            <div class="alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="program-header">
            <div class="program-icon"><i class="fas fa-id-card"></i></div>
            <div class="program-title">
                <h2>ID Card Processing</h2>
                <p>Municipal ID applications for Senior Citizens, PWDs, Solo Parents, and General Residents</p>
            </div>
        </div>

        <!-- Statistics -->
        <div class="stats-row">
            <div class="stat-box">
                <div class="stat-number"><?php echo $pending_count; ?></div>
                <div class="stat-label">Pending Review</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?php echo $pending_print_count; ?></div>
                <div class="stat-label">Pending Print</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?php echo $approved_count; ?></div>
                <div class="stat-label">Approved</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?php echo $issued_count; ?></div>
                <div class="stat-label">Issued</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?php echo $rejected_count; ?></div>
                <div class="stat-label">Rejected</div>
            </div>
        </div>

        <!-- Filter Bar -->
        <div class="filter-bar">
            <a href="?status=all" class="filter-btn <?php echo $status_filter == 'all' ? 'active' : ''; ?>">
                <i class="fas fa-list"></i> All
            </a>
            <a href="?status=pending" class="filter-btn <?php echo $status_filter == 'pending' ? 'active' : ''; ?>">
                <i class="fas fa-clock"></i> Pending
            </a>
            <a href="?status=pending_print" class="filter-btn <?php echo $status_filter == 'pending_print' ? 'active' : ''; ?>">
                <i class="fas fa-print"></i> Pending Print
            </a>
            <a href="?status=approved" class="filter-btn <?php echo $status_filter == 'approved' ? 'active' : ''; ?>">
                <i class="fas fa-check-circle"></i> Approved
            </a>
            <a href="?status=issued" class="filter-btn <?php echo $status_filter == 'issued' ? 'active' : ''; ?>">
                <i class="fas fa-id-card"></i> Issued
            </a>
            <a href="?status=rejected" class="filter-btn <?php echo $status_filter == 'rejected' ? 'active' : ''; ?>">
                <i class="fas fa-times-circle"></i> Rejected
            </a>
        </div>

        <!-- Applications Table -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant</th>
                        <th>ID Type</th>
                        <th>Tracking #</th>
                        <th>Serial #</th>
                        <th>Date Applied</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($applications) == 0): ?>
                    <tr>
                        <td colspan="8" class="empty-state">
                            <i class="fas fa-folder-open"></i>
                            <p>No ID applications found</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach($applications as $app): 
                        $app_data = json_decode($app['application_data'], true);
                        $id_type = $app_data['id_type'] ?? 'N/A';
                        $id_type_display = $id_types[$id_type] ?? ucfirst(str_replace('_', ' ', $id_type));
                        if($id_type == 'other' && !empty($app_data['id_type_other'])) {
                            $id_type_display .= " ({$app_data['id_type_other']})";
                        }
                    ?>
                    <tr>
                        <td><strong>#<?php echo $app['id']; ?></strong></td>
                        <td>
                            <strong><?php echo htmlspecialchars($app['applicant_name'] ?? 'N/A'); ?></strong>
                            <br><small style="color: var(--gray-400);"><?php echo htmlspecialchars($app['username'] ?? ''); ?></small>
                        </td>
                        <td><?php echo $id_type_display; ?></td>
                        <td>
                            <?php if(!empty($app['tracking_number'])): ?>
                                <span class="tracking-number"><?php echo htmlspecialchars($app['tracking_number']); ?></span>
                            <?php else: ?>
                                <span style="color: var(--gray-500); font-size: 0.7rem;">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!empty($app['physical_card_serial'])): ?>
                                <span class="serial-number"><?php echo htmlspecialchars($app['physical_card_serial']); ?></span>
                            <?php else: ?>
                                <span style="color: var(--gray-500); font-size: 0.7rem;">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                        <td><span class="status-badge status-<?php echo $app['status']; ?>"><?php echo getStatusLabel($app['status']); ?></span></td>
                        <td>
                            <button class="btn-view" onclick="openViewDetailsModal(<?php echo $app['id']; ?>)">
                                <i class="fas fa-eye"></i> View Details
                            </button>
                            <?php if($app['status'] == 'pending'): ?>
                                <button class="btn-approve" onclick="openApproveModal(<?php echo $app['id']; ?>)">
                                    <i class="fas fa-check"></i> Approve
                                </button>
                                <button class="btn-reject" onclick="openRejectModal(<?php echo $app['id']; ?>)">
                                    <i class="fas fa-times"></i> Reject
                                </button>
                            <?php endif; ?>
                            <?php if($app['status'] == 'pending_print'): ?>
                                <button class="btn-issue" onclick="openIssueModal(<?php echo $app['id']; ?>)">
                                    <i class="fas fa-id-card"></i> Issue
                                </button>
                                <button class="btn-reject" onclick="openRejectModal(<?php echo $app['id']; ?>)">
                                    <i class="fas fa-times"></i> Reject
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_idapplication.php" class="nav-item active"><i class="fas fa-id-card"></i><span>ID Apps</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <!-- VIEW ID DETAILS MODAL -->
    <div id="viewDetailsModal" class="modal id-details-modal">
        <div class="modal-content">
            <h3 style="font-weight: 800; color: var(--primary);"><i class="fas fa-id-card"></i> ID Application Details</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Review applicant information and verify attachment quality
            </p>
            
            <?php if($view_application): 
                $photo_url = $view_app_data['photo_url'] ?? '';
                $signature_url = $view_app_data['signature_url'] ?? '';
                $id_type_display = $id_types[$view_app_data['id_type'] ?? ''] ?? ucfirst(str_replace('_', ' ', $view_app_data['id_type'] ?? 'N/A'));
                $has_photo = !empty($photo_url);
                $has_signature = !empty($signature_url);
            ?>
            <div class="meta-block">
                <div class="meta-label">Applicant Name</div>
                <div class="meta-value"><?php echo htmlspecialchars($view_application['applicant_name'] ?? 'N/A'); ?></div>
                <div class="meta-label" style="margin-top: 12px;">Target Document Type</div>
                <div class="id-type-badge"><?php echo $id_type_display; ?></div>
                <div class="meta-label" style="margin-top: 12px;">Application ID</div>
                <div class="meta-value" style="font-size: 0.85rem; font-weight: 500; color: var(--gray-600);">#<?php echo $view_application['id']; ?></div>
                <?php if(!empty($view_application['tracking_number'])): ?>
                    <div class="meta-label" style="margin-top: 12px;">Tracking Number</div>
                    <div class="meta-value" style="font-size: 0.85rem; font-weight: 500; color: var(--primary); font-family: monospace;">
                        <?php echo htmlspecialchars($view_application['tracking_number']); ?>
                    </div>
                <?php endif; ?>
                <?php if(!empty($view_application['contact_number'])): ?>
                    <div class="meta-label" style="margin-top: 12px;">Contact</div>
                    <div class="meta-value" style="font-size: 0.85rem; font-weight: 500; color: var(--gray-600);">
                        <?php echo htmlspecialchars($view_application['contact_number']); ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="section-header">Attachment Verification Quality Check</div>

            <div class="image-flex-row">
                <div class="image-column">
                    <div class="image-label">Capture Photo</div>
                    <div class="image-frame">
                        <?php if($has_photo): ?>
                            <img src="<?php echo htmlspecialchars($photo_url); ?>" alt="ID Photo" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div style="display: none; align-items: center; justify-content: center; width: 100%; height: 100%; flex-direction: column; color: var(--gray-500);">
                                <i class="fas fa-user-circle" style="font-size: 2.5rem;"></i>
                                <span style="font-size: 0.65rem; margin-top: 4px;">No photo uploaded</span>
                            </div>
                        <?php else: ?>
                            <div style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100%; flex-direction: column; color: var(--gray-500);">
                                <i class="fas fa-user-circle" style="font-size: 2.5rem;"></i>
                                <span style="font-size: 0.65rem; margin-top: 4px;">No photo uploaded</span>
                            </div>
                        <?php endif; ?>
                        <span class="image-status <?php echo $has_photo ? 'verified' : 'missing'; ?>">
                            <?php echo $has_photo ? '✓ Verified' : '✗ Missing'; ?>
                        </span>
                    </div>
                </div>

                <div class="image-column">
                    <div class="image-label">Digital Signature</div>
                    <div class="image-frame">
                        <?php if($has_signature): ?>
                            <img src="<?php echo htmlspecialchars($signature_url); ?>" alt="Digital Signature" class="signature-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div style="display: none; align-items: center; justify-content: center; width: 100%; height: 100%; flex-direction: column; color: var(--gray-500);">
                                <i class="fas fa-signature" style="font-size: 2.5rem;"></i>
                                <span style="font-size: 0.65rem; margin-top: 4px;">No signature uploaded</span>
                            </div>
                        <?php else: ?>
                            <div style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100%; flex-direction: column; color: var(--gray-500);">
                                <i class="fas fa-signature" style="font-size: 2.5rem;"></i>
                                <span style="font-size: 0.65rem; margin-top: 4px;">No signature uploaded</span>
                            </div>
                        <?php endif; ?>
                        <span class="image-status <?php echo $has_signature ? 'verified' : 'missing'; ?>">
                            <?php echo $has_signature ? '✓ Verified' : '✗ Missing'; ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="actions-block">
                <?php if($view_application['status'] == 'pending'): ?>
                <form method="POST" action="">
                    <input type="hidden" name="application_id" value="<?php echo $view_application['id']; ?>">
                    <input type="hidden" name="approve_id" value="1">
                    <input type="hidden" name="quality_check_passed" value="1">
                    <input type="hidden" name="system_remarks" value="Photo and signature verified clear. Moving to production queue.">
                    <button type="submit" class="btn-approve-id">
                        <i class="fas fa-check-circle"></i> 🟢 Print & Issue Physical ID Card
                    </button>
                </form>
                <form method="POST" action="">
                    <input type="hidden" name="application_id" value="<?php echo $view_application['id']; ?>">
                    <input type="hidden" name="reject_id" value="1">
                    <input type="hidden" name="rejection_reason" value="BLURRY_ID_PHOTO">
                    <input type="hidden" name="instruction_to_resident" value="Please re-upload a clear, formal passport-sized photo with a plain white background.">
                    <button type="submit" class="btn-reject-id">
                        <i class="fas fa-times-circle"></i> ❌ Reject Application (Blurry/Missing)
                    </button>
                </form>
                <?php elseif($view_application['status'] == 'pending_print'): ?>
                <form method="POST" action="">
                    <input type="hidden" name="application_id" value="<?php echo $view_application['id']; ?>">
                    <input type="hidden" name="issue_id" value="1">
                    <input type="hidden" name="physical_card_serial" value="SN-<?php echo date('Y'); ?>-ID-<?php echo str_pad($view_application['id'], 5, '0', STR_PAD_LEFT); ?>">
                    <input type="hidden" name="issuance_method" value="WALK_IN_PICKUP">
                    <button type="submit" class="btn-approve-id">
                        <i class="fas fa-id-card"></i> Issue ID Card Now
                    </button>
                </form>
                <form method="POST" action="">
                    <input type="hidden" name="application_id" value="<?php echo $view_application['id']; ?>">
                    <input type="hidden" name="reject_id" value="1">
                    <input type="hidden" name="rejection_reason" value="OTHER">
                    <input type="hidden" name="instruction_to_resident" value="Please contact the MSWDO office for assistance.">
                    <button type="submit" class="btn-reject-id">
                        <i class="fas fa-times-circle"></i> Reject Application
                    </button>
                </form>
                <?php else: ?>
                <div style="text-align: center; padding: 12px; background: var(--gray-50); border-radius: var(--radius-md); color: var(--gray-600);">
                    <i class="fas fa-info-circle"></i> This application is already <?php echo strtolower(getStatusLabel($view_application['status'])); ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="modal-footer-actions">
                <button type="button" class="btn-close-details" onclick="closeModal('viewDetailsModal')">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>

            <?php else: ?>
            <div style="text-align: center; padding: 20px; color: var(--gray-500);">
                <i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 12px; display: block;"></i>
                <p>Application not found.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- APPROVE MODAL -->
    <div id="approveModal" class="modal">
        <div class="modal-content">
            <h3 style="font-weight: 800;"><i class="fas fa-check-circle" style="color: #059669;"></i> Approve ID Application</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Approving this application will move it to the printing queue and generate a tracking number.
            </p>
            <form method="POST" action="">
                <input type="hidden" name="application_id" id="approveAppId">
                <input type="hidden" name="approve_id" value="1">
                
                <div class="form-group">
                    <label>Quality Check</label>
                    <div class="checkbox-group">
                        <input type="checkbox" name="quality_check_passed" id="qualityCheck" value="1" checked>
                        <label for="qualityCheck">Photo and signature verified clear</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>System Remarks</label>
                    <textarea name="system_remarks" rows="2" placeholder="Add any additional remarks...">Photo and signature verified clear. Moving to production queue.</textarea>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('approveModal')">Cancel</button>
                    <button type="submit" class="btn-submit" style="background: #059669;">Approve & Queue for Print</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ISSUE MODAL -->
    <div id="issueModal" class="modal">
        <div class="modal-content">
            <h3 style="font-weight: 800;"><i class="fas fa-id-card" style="color: #1E4A8C;"></i> Issue ID Card</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Enter the physical card serial number to activate and issue the ID.
            </p>
            <form method="POST" action="">
                <input type="hidden" name="application_id" id="issueAppId">
                <input type="hidden" name="issue_id" value="1">
                
                <div class="form-group">
                    <label>Physical Card Serial Number <span style="color: #D32F2F;">*</span></label>
                    <input type="text" name="physical_card_serial" id="cardSerial" placeholder="e.g., SN-2026-PWD-09214" required>
                    <small style="color: var(--gray-500); font-size: 0.7rem;">Format: SN-YYYY-TYPE-XXXXX</small>
                </div>
                
                <div class="form-group">
                    <label>Issuance Method</label>
                    <select name="issuance_method">
                        <?php foreach($issuance_methods as $key => $label): ?>
                            <option value="<?php echo $key; ?>" <?php echo $key == 'WALK_IN_PICKUP' ? 'selected' : ''; ?>>
                                <?php echo $label; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('issueModal')">Cancel</button>
                    <button type="submit" class="btn-submit">Issue Card</button>
                </div>
            </form>
        </div>
    </div>

    <!-- REJECT MODAL -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <h3 style="font-weight: 800;"><i class="fas fa-times-circle" style="color: #D32F2F;"></i> Reject ID Application</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Select the rejection reason and provide instructions for the resident to correct the issue.
            </p>
            <form method="POST" action="">
                <input type="hidden" name="application_id" id="rejectAppId">
                <input type="hidden" name="reject_id" value="1">
                
                <div class="form-group">
                    <label>Rejection Reason <span style="color: #D32F2F;">*</span></label>
                    <select name="rejection_reason" id="rejectionReason" onchange="updateInstruction()">
                        <?php foreach($rejection_reasons as $key => $label): ?>
                            <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Instruction to Resident <span style="color: #D32F2F;">*</span></label>
                    <textarea name="instruction_to_resident" id="instructionText" rows="3">Please re-upload a clear, formal passport-sized photo with a plain white background.</textarea>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('rejectModal')">Cancel</button>
                    <button type="submit" class="btn-submit" style="background: #D32F2F;">Reject Application</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) {
            menuToggle.addEventListener('click', () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); });
        }
        if(overlay) {
            overlay.addEventListener('click', () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); });
        }

        // Collapsible Program Menu
        const programToggle = document.getElementById('programToggle');
        const programSubmenu = document.getElementById('programSubmenu');
        const programIcon = document.getElementById('programIcon');
        if(programToggle) {
            programToggle.addEventListener('click', () => { 
                programSubmenu.classList.toggle('show'); 
                programIcon.classList.toggle('rotated'); 
            });
        }

        // View Details Modal
        function openViewDetailsModal(id) {
            window.location.href = window.location.pathname + '?view_id=' + id;
        }

        <?php if(isset($_GET['view_id']) && !empty($_GET['view_id']) && $view_application): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('viewDetailsModal').style.display = 'flex';
        });
        <?php endif; ?>

        // Modal functions
        function openApproveModal(id) {
            document.getElementById('approveAppId').value = id;
            document.getElementById('approveModal').style.display = 'flex';
        }

        function openIssueModal(id) {
            document.getElementById('issueAppId').value = id;
            document.getElementById('cardSerial').value = '';
            document.getElementById('issueModal').style.display = 'flex';
        }

        function openRejectModal(id) {
            document.getElementById('rejectAppId').value = id;
            document.getElementById('rejectModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            if(modalId === 'viewDetailsModal') {
                const url = new URL(window.location);
                url.searchParams.delete('view_id');
                window.history.replaceState({}, document.title, url);
            }
        }

        // Update instruction text based on rejection reason
        function updateInstruction() {
            const reason = document.getElementById('rejectionReason').value;
            const instructions = {
                'BLURRY_ID_PHOTO': 'Please re-upload a clear, formal passport-sized photo with a plain white background. Ensure the photo is well-lit and your face is fully visible.',
                'MISSING_SIGNATURE': 'Please upload a clear copy of your signature. You can sign on a white paper, take a photo, and upload it.',
                'WRONG_DOCUMENT': 'Please upload the correct document as specified in the application requirements. Check the required documents list.',
                'INCOMPLETE_FORM': 'Please complete all required fields in the application form. Review and fill in all missing information.',
                'NO_PROOF_OF_RESIDENCY': 'Please provide a valid proof of residency such as a barangay clearance or utility bill showing your current address.',
                'OTHER': 'Please review your application and provide the required corrections. Contact the MSWDO office for further assistance.'
            };
            document.getElementById('instructionText').value = instructions[reason] || instructions['OTHER'];
        }

        // Close modals when clicking outside
        window.onclick = (e) => { 
            if(e.target.classList.contains('modal')) {
                const modalId = e.target.id;
                closeModal(modalId);
            }
        }

        // Close view details modal with ESC key
        document.addEventListener('keydown', function(e) {
            if(e.key === 'Escape') {
                const viewModal = document.getElementById('viewDetailsModal');
                if(viewModal && viewModal.style.display === 'flex') {
                    closeModal('viewDetailsModal');
                }
            }
        });
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>