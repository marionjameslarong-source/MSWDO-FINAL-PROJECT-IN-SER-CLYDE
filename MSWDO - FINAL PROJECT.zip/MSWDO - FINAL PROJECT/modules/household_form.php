<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$error = '';
$success = '';
$household = null;
$members = [];

// Get sidebar household ID for dynamic navigation
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get unread notification count for sidebar badge
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

// Check if user already has household data
$stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
$stmt->execute([$user_id]);
$existing_household = $stmt->fetch();

// Check if continuing from dashboard
$continue_id = isset($_GET['continue']) ? intval($_GET['continue']) : 0;
if($continue_id) {
    $stmt = $pdo->prepare("SELECT * FROM households WHERE id = ? AND user_id = ?");
    $stmt->execute([$continue_id, $user_id]);
    $household = $stmt->fetch();
    if($household) {
        $stmt = $pdo->prepare("SELECT * FROM household_members WHERE household_id = ? ORDER BY id");
        $stmt->execute([$household['id']]);
        $members = $stmt->fetchAll();
    }
}

// If editing existing household
if(isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM households WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['edit'], $user_id]);
    $household = $stmt->fetch();
    if(!$household) {
        header("Location: household_form.php");
        exit();
    }
    $stmt = $pdo->prepare("SELECT * FROM household_members WHERE household_id = ? ORDER BY id");
    $stmt->execute([$household['id']]);
    $members = $stmt->fetchAll();
}

// Function to classify poverty based on income
function classifyPovertyIncome($income) {
    if($income < 5000) {
        return 'Extremely Poor';
    } elseif($income >= 5000 && $income <= 10000) {
        return 'Poor';
    } elseif($income >= 10001 && $income <= 15000) {
        return 'Low Income';
    } elseif($income >= 15001 && $income <= 25000) {
        return 'Lower Middle';
    } else {
        return 'Middle Income and Above';
    }
}

// ==============================================
// FIXED LOCATION: CANTILAN, SURIGAO DEL SUR
// ==============================================
$fixed_province = 'Surigao del Sur';
$fixed_city = 'Cantilan';

// ==============================================
// OFFICIAL BARANGAYS OF CANTILAN, SURIGAO DEL SUR
// ==============================================
$cantilan_barangays = [
    'Bugsukan',
    'Buntalid',
    'Cabangahan',
    'Cabas-an',
    'Calagdaan',
    'Consuelo',
    'General Island',
    'Lininti-an (Poblacion)',
    'Lobo',
    'Magasang',
    'Magosilom (Poblacion)',
    'Pag-Antayan',
    'Palasao',
    'Parang',
    'San Pedro',
    'Tapi',
    'Tigabong'
];

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $head_first_name = trim($_POST['head_first_name'] ?? '');
    $head_last_name = trim($_POST['head_last_name'] ?? '');
    $head_middle_name = trim($_POST['head_middle_name'] ?? '');
    $relation_to_head = $_POST['relation_to_head'] ?? 'Self';
    $contact_number = trim($_POST['contact_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $barangay = trim($_POST['barangay'] ?? '');
    $city_municipality = $fixed_city;
    $province = $fixed_province;
    $zip_code = trim($_POST['zip_code'] ?? '8317');
    $total_members = intval($_POST['total_members'] ?? 1);
    $monthly_income = floatval($_POST['monthly_income'] ?? 0);
    $is_4ps_beneficiary = isset($_POST['is_4ps_beneficiary']) ? 1 : 0;
    $poverty_status = classifyPovertyIncome($monthly_income);
    
    $errors = [];
    
    if(empty($head_first_name)) $errors[] = "First name is required.";
    if(empty($head_last_name)) $errors[] = "Last name is required.";
    if(empty($address)) $errors[] = "Address is required.";
    if(empty($barangay)) $errors[] = "Barangay is required.";
    if(!in_array($barangay, $cantilan_barangays)) $errors[] = "Please select a valid barangay in Cantilan.";
    if($total_members < 1) $errors[] = "Household size must be at least 1.";
    
    if(empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            if($household && (isset($_GET['edit']) || $continue_id)) {
                $stmt = $pdo->prepare("
                    UPDATE households SET 
                        head_first_name = ?, head_last_name = ?, head_middle_name = ?,
                        relation_to_head = ?, contact_number = ?, email = ?,
                        address = ?, barangay = ?, city_municipality = ?, province = ?,
                        zip_code = ?, total_members = ?, monthly_income = ?,
                        is_4ps_beneficiary = ?, poverty_status = ?, updated_at = NOW()
                    WHERE id = ? AND user_id = ?
                ");
                $stmt->execute([
                    $head_first_name, $head_last_name, $head_middle_name,
                    $relation_to_head, $contact_number, $email,
                    $address, $barangay, $city_municipality, $province,
                    $zip_code, $total_members, $monthly_income,
                    $is_4ps_beneficiary, $poverty_status, $household['id'], $user_id
                ]);
                $household_id = $household['id'];
                $success = "Household data updated successfully!";
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO households (
                        user_id, head_first_name, head_last_name, head_middle_name,
                        relation_to_head, contact_number, email,
                        address, barangay, city_municipality, province, zip_code,
                        total_members, monthly_income, is_4ps_beneficiary, 
                        poverty_status, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $user_id, $head_first_name, $head_last_name, $head_middle_name,
                    $relation_to_head, $contact_number, $email,
                    $address, $barangay, $city_municipality, $province, $zip_code,
                    $total_members, $monthly_income, $is_4ps_beneficiary,
                    $poverty_status
                ]);
                $household_id = $pdo->lastInsertId();
                $success = "Household data saved successfully!";
            }
            
            $stmt = $pdo->prepare("DELETE FROM household_members WHERE household_id = ?");
            $stmt->execute([$household_id]);
            
            $member_names = $_POST['member_name'] ?? [];
            $member_relationships = $_POST['member_relationship'] ?? [];
            $member_ages = $_POST['member_age'] ?? [];
            $member_genders = $_POST['member_gender'] ?? [];
            $member_occupations = $_POST['member_occupation'] ?? [];
            
            $member_count = 0;
            foreach($member_names as $index => $full_name_member) {
                $full_name_member = trim($full_name_member);
                if(empty($full_name_member)) continue;
                
                $name_parts = explode(' ', $full_name_member, 2);
                $first_name = $name_parts[0] ?? '';
                $last_name = $name_parts[1] ?? '';
                
                $relationship = trim($member_relationships[$index] ?? '');
                $age = intval($member_ages[$index] ?? 0);
                $gender = trim($member_genders[$index] ?? '');
                $occupation = trim($member_occupations[$index] ?? '');
                
                $stmt = $pdo->prepare("
                    INSERT INTO household_members (
                        household_id, first_name, last_name, relationship, 
                        age, gender, occupation, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $household_id, $first_name, $last_name, $relationship,
                    $age, $gender, $occupation
                ]);
                $member_count++;
            }
            
            $stmt = $pdo->prepare("UPDATE households SET total_members = ? WHERE id = ?");
            $stmt->execute([$member_count, $household_id]);
            
            $pdo->commit();
            
            echo '<script>setTimeout(function(){ window.location.href = "household_data.php?view=' . $household_id . '"; }, 1500);</script>';
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    $error = implode("<br>", $errors);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Household Registration - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- ADD THIS: PWA meta tags -->
    <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F; --accent: #F5B042;
            --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9; --gray-200: #E2E8F0;
            --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B; --gray-600: #475569;
            --gray-700: #334155; --gray-800: #1E293B; --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1); --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem; --radius-md: 0.75rem; --radius-lg: 1rem; --radius-xl: 1.5rem; --radius-2xl: 2rem;
        }
        .app { display: flex; min-height: 100vh; }
        .sidebar { width: 280px; background: var(--white); border-right: 1px solid var(--gray-200); position: fixed; top: 0; left: 0; bottom: 0; overflow-y: auto; z-index: 40; }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--gray-400); margin-bottom: 12px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; margin-bottom: 4px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; transition: all 0.2s ease; cursor: pointer; position: relative; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge { margin-left: auto; background: var(--secondary); color: white; font-size: 0.65rem; font-weight: 700; padding: 2px 8px; border-radius: 20px; line-height: 1.4; }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 16px; margin-bottom: 2px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; transition: all 0.2s ease; font-size: 0.8rem; }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .submenu-item.active i { color: white; }
        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid var(--gray-200); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--gray-50); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }
        .form-card { background: var(--white); border-radius: var(--radius-2xl); border: 1px solid var(--gray-200); overflow: hidden; box-shadow: var(--shadow-sm); }
        .form-header { padding: 28px 32px; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); }
        .form-header h2 { font-size: 1.1rem; font-weight: 600; color: var(--gray-800); display: flex; align-items: center; gap: 10px; }
        .form-header h2 i { color: var(--secondary); }
        .form-body { padding: 32px; }
        .form-section { margin-bottom: 40px; padding-bottom: 32px; border-bottom: 1px solid var(--gray-200); }
        .form-section:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
        .section-title { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
        .section-icon { width: 36px; height: 36px; background: var(--gray-100); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; }
        .section-icon i { font-size: 1rem; color: var(--secondary); }
        .section-title h3 { font-size: 1rem; font-weight: 600; color: var(--gray-800); }
        .section-title p { font-size: 0.7rem; color: var(--gray-500); margin-top: 2px; }
        .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; margin-bottom: 20px; }
        .form-row-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 600; color: var(--gray-600); margin-bottom: 8px; }
        .form-group label i { margin-right: 6px; color: var(--secondary); font-size: 0.7rem; }
        .required { color: var(--secondary); }
        input, select { width: 100%; padding: 10px 14px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-family: 'Inter', sans-serif; font-size: 0.85rem; transition: all 0.2s ease; background: var(--white); }
        input:focus, select:focus { border-color: var(--accent); outline: none; box-shadow: 0 0 0 3px rgba(245,176,66,0.15); }
        input[readonly], select[readonly], input:disabled, select:disabled { background: var(--gray-100); color: var(--gray-600); cursor: not-allowed; border-color: var(--gray-200); }
        .locked-field { position: relative; }
        .locked-field .lock-badge { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: var(--gray-400); font-size: 0.75rem; pointer-events: none; }
        .btn-submit { width: 100%; background: var(--primary); color: white; padding: 14px 24px; border: none; border-radius: var(--radius-md); font-weight: 600; font-size: 0.9rem; cursor: pointer; transition: all 0.2s ease; display: flex; align-items: center; justify-content: center; gap: 10px; margin-top: 32px; }
        .btn-submit:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: var(--shadow-md); }
        .btn-back { display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; background: var(--white); color: var(--gray-700); padding: 12px 20px; border: 1px solid var(--gray-200); border-radius: var(--radius-md); font-weight: 500; font-size: 0.85rem; text-decoration: none; margin-top: 16px; transition: all 0.2s ease; }
        .btn-back:hover { background: var(--gray-50); border-color: var(--gray-300); }
        .alert { padding: 16px 20px; border-radius: var(--radius-lg); margin-bottom: 24px; font-size: 0.85rem; display: flex; align-items: center; gap: 12px; }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }
        .alert-info { background: #FFF9EF; border-left: 3px solid var(--accent); color: #7B5E2A; }
        .poverty-preview { background: var(--gray-50); padding: 16px 20px; border-radius: var(--radius-lg); margin-top: 16px; border-left: 3px solid var(--accent); }
        .checkbox-group { display: flex; align-items: center; gap: 12px; margin-top: 20px; }
        .checkbox-group input { width: 18px; height: 18px; cursor: pointer; }
        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .menu-toggle:hover { background: var(--gray-100); }
        .location-banner { background: linear-gradient(135deg, #1E4A8C, #0A2F6C); color: white; padding: 14px 20px; border-radius: var(--radius-lg); margin-bottom: 20px; display: flex; align-items: center; gap: 12px; font-size: 0.8rem; }
        .location-banner i { font-size: 1.1rem; color: var(--accent); }
        .location-banner strong { color: var(--accent); }
        .members-table-wrapper { overflow-x: auto; margin-top: 16px; }
        .members-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; }
        .members-table th { background: var(--primary); color: white; padding: 10px 8px; text-align: left; font-weight: 600; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.3px; white-space: nowrap; }
        .members-table td { padding: 6px 4px; border-bottom: 1px solid var(--gray-200); vertical-align: middle; }
        .members-table input, .members-table select { padding: 8px 10px; font-size: 0.8rem; border: 1.5px solid var(--gray-200); border-radius: var(--radius-sm); width: 100%; }
        .members-table input:focus, .members-table select:focus { border-color: var(--accent); }
        .members-table .member-name-input { min-width: 160px; }
        .members-table .member-rel-select { min-width: 120px; }
        .members-table .member-age-input { min-width: 60px; width: 70px; }
        .members-table .member-gender-select { min-width: 100px; }
        .members-table .member-occupation-input { min-width: 130px; }
        .btn-add-member { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: var(--primary); color: white; border: none; border-radius: var(--radius-md); font-weight: 600; font-size: 0.8rem; cursor: pointer; transition: all 0.2s ease; margin-top: 12px; }
        .btn-add-member:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: var(--shadow-md); }
        .btn-remove-member { display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; background: #FEF2F2; color: var(--secondary); border: 1px solid #FECACA; border-radius: 50%; cursor: pointer; transition: all 0.2s ease; font-size: 0.8rem; }
        .btn-remove-member:hover { background: #FEE2E2; border-color: #FCA5A5; }
        .btn-remove-member:disabled { opacity: 0.4; cursor: not-allowed; }
        .member-count-badge { display: inline-flex; align-items: center; gap: 6px; background: var(--gray-100); padding: 4px 12px; border-radius: 40px; font-size: 0.7rem; color: var(--gray-600); font-weight: 500; }
        .member-count-badge i { color: var(--primary); font-size: 0.7rem; }
        
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .form-row-3 { grid-template-columns: 1fr; gap: 0; }
            .form-body { padding: 20px; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .form-header { padding: 20px; }
            .members-table { font-size: 0.7rem; }
            .members-table th, .members-table td { padding: 4px 3px; }
            .members-table input, .members-table select { padding: 6px 6px; font-size: 0.7rem; }
            .members-table .member-name-input { min-width: 100px; }
            .members-table .member-rel-select { min-width: 80px; }
            .members-table .member-age-input { min-width: 45px; width: 50px; }
            .members-table .member-gender-select { min-width: 70px; }
            .members-table .member-occupation-input { min-width: 80px; }
        }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Municipal Social Welfare</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/resident_dashboard.php" class="nav-item">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo ($sidebar_household_id) ? 'household_data.php?view=' . $sidebar_household_id : 'household_form.php'; ?>" class="nav-item active">
                    <i class="fas fa-users"></i>
                    <span>Household Profile</span>
                </a>
                <a href="my_applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i>
                    <span>My Applications</span>
                </a>
                <a href="../notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i>
                    <span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="../soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="../seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="../pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="../aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="../vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="survey_form.php" class="nav-item">
                    <i class="fas fa-chart-line"></i>
                    <span>Community Survey</span>
                </a>
                <a href="../id_application.php" class="nav-item">
                    <i class="fas fa-id-card"></i>
                    <span>ID Application</span>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../profile_settings.php" class="nav-item">
                    <i class="fas fa-user-circle"></i>
                    <span>Profile Settings</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="page-title">
                    <h1>Household Registration</h1>
                    <p>Complete your household profile for MSWDO records</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small><?php echo ucfirst($role); ?></small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <h2><i class="fas fa-clipboard-list"></i> Household Data Collection Form</h2>
            </div>

            <div class="form-body">
                <?php if($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
                <?php endif; ?>

                <?php if($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        <div style="margin-top: 8px;"><i class="fas fa-spinner fa-pulse"></i> Redirecting to your household profile...</div>
                    </div>
                <?php endif; ?>

                <?php if($existing_household && !isset($_GET['edit']) && !$continue_id && !isset($household) && !$success): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> You have already submitted household data. 
                        <a href="?edit=<?php echo $existing_household['id']; ?>" style="color: var(--secondary); font-weight: 600;">Click here to update your information.</a>
                    </div>
                <?php endif; ?>

                <?php if(!$success): ?>
                <form method="POST" action="" id="householdForm">
                    <!-- Section 1: Household Head Information -->
                    <div class="form-section">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-user-circle"></i></div>
                            <div>
                                <h3>Household Head Information</h3>
                                <p>Primary contact and identification details</p>
                            </div>
                        </div>
                        <div class="form-row-3">
                            <div class="form-group">
                                <label><i class="fas fa-user"></i> First Name <span class="required">*</span></label>
                                <input type="text" name="head_first_name" value="<?php echo htmlspecialchars($household['head_first_name'] ?? $existing_household['head_first_name'] ?? ''); ?>" required>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-user"></i> Middle Name</label>
                                <input type="text" name="head_middle_name" value="<?php echo htmlspecialchars($household['head_middle_name'] ?? $existing_household['head_middle_name'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-user"></i> Last Name <span class="required">*</span></label>
                                <input type="text" name="head_last_name" value="<?php echo htmlspecialchars($household['head_last_name'] ?? $existing_household['head_last_name'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-handshake"></i> Relation to Household Head</label>
                                <select name="relation_to_head">
                                    <option value="Self" <?php echo (($household['relation_to_head'] ?? $existing_household['relation_to_head'] ?? '') == 'Self') ? 'selected' : ''; ?>>Self</option>
                                    <option value="Spouse" <?php echo (($household['relation_to_head'] ?? $existing_household['relation_to_head'] ?? '') == 'Spouse') ? 'selected' : ''; ?>>Spouse</option>
                                    <option value="Child" <?php echo (($household['relation_to_head'] ?? $existing_household['relation_to_head'] ?? '') == 'Child') ? 'selected' : ''; ?>>Child</option>
                                    <option value="Parent" <?php echo (($household['relation_to_head'] ?? $existing_household['relation_to_head'] ?? '') == 'Parent') ? 'selected' : ''; ?>>Parent</option>
                                    <option value="Sibling" <?php echo (($household['relation_to_head'] ?? $existing_household['relation_to_head'] ?? '') == 'Sibling') ? 'selected' : ''; ?>>Sibling</option>
                                    <option value="Other Relative" <?php echo (($household['relation_to_head'] ?? $existing_household['relation_to_head'] ?? '') == 'Other Relative') ? 'selected' : ''; ?>>Other Relative</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-phone"></i> Contact Number</label>
                                <input type="text" name="contact_number" value="<?php echo htmlspecialchars($household['contact_number'] ?? $existing_household['contact_number'] ?? ''); ?>" placeholder="e.g., 09123456789">
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-envelope"></i> Email Address</label>
                                <input type="email" name="email" value="<?php echo htmlspecialchars($household['email'] ?? $existing_household['email'] ?? ''); ?>" placeholder="e.g., juan@email.com">
                            </div>
                        </div>
                    </div>

                    <!-- Section 2: Address Information (LOCKED TO CANTILAN) -->
                    <div class="form-section">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-map-marker-alt"></i></div>
                            <div>
                                <h3>Address Information</h3>
                                <p>Current residential address</p>
                            </div>
                        </div>

                        <div class="location-banner">
                            <i class="fas fa-map-pin"></i>
                            <span>This form is exclusively for residents of <strong>Municipality of Cantilan, Province of Surigao del Sur</strong>. Location fields are pre-set.</span>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-road"></i> House/Unit Number & Street / Purok <span class="required">*</span></label>
                            <input type="text" name="address" value="<?php echo htmlspecialchars($household['address'] ?? $existing_household['address'] ?? ''); ?>" placeholder="e.g., Purok 3, Rizal Street" required>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-globe"></i> Province</label>
                                <div class="locked-field">
                                    <input type="text" value="<?php echo $fixed_province; ?>" readonly>
                                    <i class="fas fa-lock lock-badge"></i>
                                </div>
                                <input type="hidden" name="province" value="<?php echo $fixed_province; ?>">
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-city"></i> City/Municipality</label>
                                <div class="locked-field">
                                    <input type="text" value="<?php echo $fixed_city; ?>" readonly>
                                    <i class="fas fa-lock lock-badge"></i>
                                </div>
                                <input type="hidden" name="city_municipality" value="<?php echo $fixed_city; ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-map-pin"></i> Barangay <span class="required">*</span></label>
                                <select name="barangay" id="barangay" required>
                                    <option value="">Select Barangay</option>
                                    <?php foreach($cantilan_barangays as $brgy): ?>
                                        <option value="<?php echo $brgy; ?>" <?php echo (($household['barangay'] ?? $existing_household['barangay'] ?? '') == $brgy) ? 'selected' : ''; ?>>
                                            <?php echo $brgy; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-mail-bulk"></i> ZIP Code</label>
                                <input type="text" name="zip_code" id="zip_code" value="<?php echo htmlspecialchars($household['zip_code'] ?? $existing_household['zip_code'] ?? '8317'); ?>" placeholder="e.g., 8317" readonly>
                            </div>
                        </div>
                    </div>

                    <!-- Section 3: Economic Information -->
                    <div class="form-section">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-chart-line"></i></div>
                            <div>
                                <h3>Economic Information</h3>
                                <p>Household financial details for assistance programs</p>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-money-bill-wave"></i> Monthly Household Income (₱)</label>
                                <input type="number" name="monthly_income" id="monthly_income" value="<?php echo htmlspecialchars($household['monthly_income'] ?? $existing_household['monthly_income'] ?? 0); ?>" step="500" min="0" onchange="updatePovertyPreview()" onkeyup="updatePovertyPreview()">
                            </div>
                            <div class="form-group" style="display: flex; align-items: flex-end; padding-bottom: 20px;">
                                <div class="checkbox-group" style="margin-top: 0;">
                                    <input type="checkbox" name="is_4ps_beneficiary" id="is_4ps" value="1" <?php echo (($household['is_4ps_beneficiary'] ?? $existing_household['is_4ps_beneficiary'] ?? 0) == 1) ? 'checked' : ''; ?>>
                                    <label for="is_4ps" style="margin-bottom: 0; cursor: pointer;">This household is a 4Ps beneficiary</label>
                                </div>
                            </div>
                        </div>
                        <div class="poverty-preview" id="povertyPreview">
                            <i class="fas fa-chart-simple"></i> 
                            <strong>Poverty Classification:</strong> <span id="povertyStatus"><?php echo classifyPovertyIncome($household['monthly_income'] ?? $existing_household['monthly_income'] ?? 0); ?></span>
                            <small style="display: block; margin-top: 6px;" id="povertyDesc"></small>
                        </div>
                    </div>

                    <!-- Section 4: Household Members Enumeration -->
                    <div class="form-section">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-users"></i></div>
                            <div style="display: flex; align-items: center; justify-content: space-between; width: 100%; flex-wrap: wrap; gap: 12px;">
                                <div>
                                    <h3>Household Members</h3>
                                    <p>Enumerate all members of your household</p>
                                </div>
                                <span class="member-count-badge" id="memberCountBadge">
                                    <i class="fas fa-users"></i> <span id="memberCount"><?php echo count($members); ?></span> member(s)
                                </span>
                            </div>
                        </div>
                        
                        <div class="members-table-wrapper">
                            <table class="members-table" id="membersTable">
                                <thead>
                                    <tr>
                                        <th style="width: 4%;">#</th>
                                        <th style="width: 24%;">Full Name <span class="required">*</span></th>
                                        <th style="width: 15%;">Relationship</th>
                                        <th style="width: 8%;">Age</th>
                                        <th style="width: 12%;">Gender</th>
                                        <th style="width: 15%;">Occupation</th>
                                        <th style="width: 5%;"></th>
                                    </tr>
                                </thead>
                                <tbody id="membersBody">
                                    <?php if(count($members) > 0): ?>
                                        <?php foreach($members as $index => $member): ?>
                                            <tr class="member-row">
                                                <td style="text-align: center; font-weight: 600; color: var(--gray-500);" class="row-number"><?php echo $index + 1; ?></td>
                                                <td>
                                                    <input type="text" name="member_name[]" class="member-name-input" value="<?php echo htmlspecialchars($member['first_name'] . ' ' . ($member['last_name'] ?? '')); ?>" placeholder="Enter full name" required>
                                                </td>
                                                <td>
                                                    <select name="member_relationship[]" class="member-rel-select">
                                                        <option value="">Select</option>
                                                        <option value="Head" <?php echo ($member['relationship'] == 'Head') ? 'selected' : ''; ?>>Head</option>
                                                        <option value="Spouse" <?php echo ($member['relationship'] == 'Spouse') ? 'selected' : ''; ?>>Spouse</option>
                                                        <option value="Child" <?php echo ($member['relationship'] == 'Child') ? 'selected' : ''; ?>>Child</option>
                                                        <option value="Parent" <?php echo ($member['relationship'] == 'Parent') ? 'selected' : ''; ?>>Parent</option>
                                                        <option value="Sibling" <?php echo ($member['relationship'] == 'Sibling') ? 'selected' : ''; ?>>Sibling</option>
                                                        <option value="Grandchild" <?php echo ($member['relationship'] == 'Grandchild') ? 'selected' : ''; ?>>Grandchild</option>
                                                        <option value="Relative" <?php echo ($member['relationship'] == 'Relative') ? 'selected' : ''; ?>>Relative</option>
                                                        <option value="Other" <?php echo ($member['relationship'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="number" name="member_age[]" class="member-age-input" value="<?php echo htmlspecialchars($member['age'] ?? ''); ?>" min="0" max="150" placeholder="0">
                                                </td>
                                                <td>
                                                    <select name="member_gender[]" class="member-gender-select">
                                                        <option value="">Select</option>
                                                        <option value="Male" <?php echo ($member['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                                        <option value="Female" <?php echo ($member['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" name="member_occupation[]" class="member-occupation-input" value="<?php echo htmlspecialchars($member['occupation'] ?? ''); ?>" placeholder="Occupation">
                                                </td>
                                                <td style="text-align: center;">
                                                    <button type="button" class="btn-remove-member" onclick="removeMember(this)" title="Remove member">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr class="member-row">
                                            <td style="text-align: center; font-weight: 600; color: var(--gray-500);" class="row-number">1</td>
                                            <td>
                                                <input type="text" name="member_name[]" class="member-name-input" placeholder="Enter full name" required>
                                            </td>
                                            <td>
                                                <select name="member_relationship[]" class="member-rel-select">
                                                    <option value="">Select</option>
                                                    <option value="Head" selected>Head</option>
                                                    <option value="Spouse">Spouse</option>
                                                    <option value="Child">Child</option>
                                                    <option value="Parent">Parent</option>
                                                    <option value="Sibling">Sibling</option>
                                                    <option value="Grandchild">Grandchild</option>
                                                    <option value="Relative">Relative</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                            </td>
                                            <td>
                                                <input type="number" name="member_age[]" class="member-age-input" min="0" max="150" placeholder="0">
                                            </td>
                                            <td>
                                                <select name="member_gender[]" class="member-gender-select">
                                                    <option value="">Select</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                            </td>
                                            <td>
                                                <input type="text" name="member_occupation[]" class="member-occupation-input" placeholder="Occupation">
                                            </td>
                                            <td style="text-align: center;">
                                                <button type="button" class="btn-remove-member" onclick="removeMember(this)" title="Remove member" disabled>
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <button type="button" class="btn-add-member" onclick="addMember()">
                            <i class="fas fa-plus-circle"></i> Add Member
                        </button>
                    </div>

                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save"></i> Save Household Data
                    </button>
                    
                    <a href="../dashboards/resident_dashboard.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </form>
                <?php endif; ?>
                
                <?php if($success): ?>
                    <a href="../dashboards/resident_dashboard.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
    // ============================================================
    // 🆕 OFFLINE SYNC — Intercepts form submit
    // If online: POSTs to /api/save_household.php
    // If offline: saves to IndexedDB queue for later sync
    // ============================================================
    (function() {
        const form = document.getElementById('householdForm');
        if (!form) return;

        // Wait until sync engine is ready
        function attach() {
            if (!window.MSWDOSync) { setTimeout(attach, 100); return; }

            form.addEventListener('submit', async function (e) {
                e.preventDefault();

                const fd = new FormData(form);

                // Collect members from the table
                const memberRows = document.querySelectorAll('#membersBody .member-row');
                const members = [];
                memberRows.forEach((row) => {
                    const name = row.querySelector('.member-name-input')?.value.trim() || '';
                    if (!name) return;
                    members.push({
                        full_name:    name,
                        relationship: row.querySelector('.member-rel-select')?.value || '',
                        age:          row.querySelector('.member-age-input')?.value || '',
                        gender:       row.querySelector('.member-gender-select')?.value || '',
                        occupation:   row.querySelector('.member-occupation-input')?.value || '',
                    });
                });

                const payload = {
                    head_first_name:    fd.get('head_first_name') || '',
                    head_middle_name:   fd.get('head_middle_name') || '',
                    head_last_name:     fd.get('head_last_name')   || '',
                    relation_to_head:   fd.get('relation_to_head') || 'Self',
                    contact_number:     fd.get('contact_number')   || '',
                    email:              fd.get('email')            || '',
                    address:            fd.get('address')          || '',
                    barangay:           fd.get('barangay')         || '',
                    zip_code:           fd.get('zip_code')         || '8317',
                    monthly_income:     parseFloat(fd.get('monthly_income')) || 0,
                    is_4ps_beneficiary: fd.get('is_4ps_beneficiary') ? 1 : 0,
                    members:            members,
                };

                // Basic required-field check
                if (!payload.head_first_name || !payload.head_last_name || !payload.address || !payload.barangay) {
                    alert('Please fill in all required fields.');
                    return;
                }

                const submitBtn = form.querySelector('.btn-submit');
                if (submitBtn) submitBtn.disabled = true;

                try {
                    const result = await window.MSWDOSync.submitOrQueue(payload);

                    if (result.queued) {
                        // Saved offline
                        alert('💾 Saved offline. It will sync automatically when you are back online.');
                        form.reset();
                        // Reset member table to single empty row
                        const tbody = document.getElementById('membersBody');
                        if (tbody) {
                            tbody.innerHTML = '';
                            addMember();
                        }
                    } else {
                        // Submitted online — go to profile
                        const id = result.result.household_id;
                        window.location.href = 'household_data.php?view=' + id;
                    }
                } catch (err) {
                    alert('Something went wrong: ' + err.message);
                } finally {
                    if (submitBtn) submitBtn.disabled = false;
                }
            });
        }
        attach();
    })();

    // ============================================================
    // EXISTING UI LOGIC (unchanged)
    // ============================================================
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    
    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
        });
    }
    
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
    
    function updatePovertyPreview() {
        let income = document.getElementById('monthly_income').value;
        let status = '', desc = '';
        if(income < 5000) { status = 'Extremely Poor'; desc = 'Urgent assistance needed - qualifies for all programs'; }
        else if(income >= 5000 && income <= 10000) { status = 'Poor'; desc = 'Qualified for most social welfare programs'; }
        else if(income >= 10001 && income <= 15000) { status = 'Low Income'; desc = 'May qualify for select programs'; }
        else if(income >= 15001 && income <= 25000) { status = 'Lower Middle'; desc = 'Limited program eligibility'; }
        else if(income > 25000) { status = 'Middle Income and Above'; desc = 'Not eligible for financial assistance'; }
        else { status = 'Not Classified'; desc = 'Enter income to see classification'; }
        
        document.getElementById('povertyStatus').innerText = status;
        document.getElementById('povertyDesc').innerHTML = desc;
        
        let preview = document.getElementById('povertyPreview');
        if(status === 'Extremely Poor') preview.style.borderColor = '#D32F2F';
        else if(status === 'Poor') preview.style.borderColor = '#F5B042';
        else if(status === 'Low Income') preview.style.borderColor = '#1E4A8C';
        else if(status === 'Lower Middle') preview.style.borderColor = '#9C27B0';
        else if(status === 'Middle Income and Above') preview.style.borderColor = '#2E7D32';
        else preview.style.borderColor = '#E2E8F0';
    }
    
    function updateMemberCount() {
        let rows = document.querySelectorAll('#membersBody .member-row');
        document.getElementById('memberCount').innerText = rows.length;
        updateRowNumbers();
        updateRemoveButtons();
    }
    
    function updateRowNumbers() {
        let rows = document.querySelectorAll('#membersBody .member-row');
        rows.forEach((row, index) => {
            let numCell = row.querySelector('.row-number');
            if(numCell) numCell.innerText = index + 1;
        });
    }
    
    function updateRemoveButtons() {
        let rows = document.querySelectorAll('#membersBody .member-row');
        let buttons = document.querySelectorAll('#membersBody .btn-remove-member');
        buttons.forEach((btn) => {
            btn.disabled = (rows.length <= 1);
        });
    }
    
    function addMember() {
        let tbody = document.getElementById('membersBody');
        let rowCount = tbody.querySelectorAll('.member-row').length;
        
        let newRow = document.createElement('tr');
        newRow.className = 'member-row';
        newRow.innerHTML = `
            <td style="text-align: center; font-weight: 600; color: var(--gray-500);" class="row-number">${rowCount + 1}</td>
            <td>
                <input type="text" name="member_name[]" class="member-name-input" placeholder="Enter full name" required>
            </td>
            <td>
                <select name="member_relationship[]" class="member-rel-select">
                    <option value="">Select</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Child">Child</option>
                    <option value="Parent">Parent</option>
                    <option value="Sibling">Sibling</option>
                    <option value="Grandchild">Grandchild</option>
                    <option value="Relative">Relative</option>
                    <option value="Other">Other</option>
                </select>
            </td>
            <td>
                <input type="number" name="member_age[]" class="member-age-input" min="0" max="150" placeholder="0">
            </td>
            <td>
                <select name="member_gender[]" class="member-gender-select">
                    <option value="">Select</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </td>
            <td>
                <input type="text" name="member_occupation[]" class="member-occupation-input" placeholder="Occupation">
            </td>
            <td style="text-align: center;">
                <button type="button" class="btn-remove-member" onclick="removeMember(this)" title="Remove member">
                    <i class="fas fa-times"></i>
                </button>
            </td>
        `;
        
        tbody.appendChild(newRow);
        updateMemberCount();
        
        let newInput = newRow.querySelector('.member-name-input');
        if(newInput) newInput.focus();
    }
    
    function removeMember(button) {
        let row = button.closest('.member-row');
        let tbody = document.getElementById('membersBody');
        let rowCount = tbody.querySelectorAll('.member-row').length;
        
        if(rowCount <= 1) {
            alert('At least one household member is required.');
            return;
        }
        
        if(confirm('Are you sure you want to remove this member?')) {
            row.remove();
            updateMemberCount();
        }
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        updateMemberCount();
        updatePovertyPreview();
    });
</script>

<!-- ADD THIS: PWA service worker -->
<?= renderPwaServiceWorker() ?>

<!-- 🆕 ADD THIS: Offline sync files -->
<script src="../pwa/offline-db.js"></script>
<script src="../pwa/sync.js"></script>
<script src="../pwa/sync-ui.js"></script>

</body>
</html>