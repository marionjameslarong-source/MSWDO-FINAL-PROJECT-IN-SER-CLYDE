<?php
session_start();
require_once '../config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];

$household_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $pdo->prepare("SELECT * FROM households WHERE id = ?");
$stmt->execute([$household_id]);
$household = $stmt->fetch();

if(!$household) {
    header("Location: household.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM household_members WHERE household_id = ? ORDER BY id");
$stmt->execute([$household_id]);
$members = $stmt->fetchAll();

function classifyPovertyIncome($income) {
    if($income < 5000) return 'Extremely Poor';
    elseif($income >= 5000 && $income <= 10000) return 'Poor';
    elseif($income >= 10001 && $income <= 15000) return 'Low Income';
    elseif($income >= 15001 && $income <= 25000) return 'Lower Middle';
    else return 'Middle Income and Above';
}

$poverty_status = $household['poverty_status'] ?? classifyPovertyIncome($household['monthly_income'] ?? 0);
$doc_number = 'OSCA-HH-' . date('Y') . '-' . str_pad($household_id, 5, '0', STR_PAD_LEFT);
$date_generated = date('F d, Y');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit & Finalize Household - MSWDO Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }
        .header {
            background: white;
            padding: 20px 30px;
            border-radius: 12px;
            margin-bottom: 20px;
            border: 1px solid #E2E8F0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.3rem; font-weight: 600; color: #1E293B; }
        .header p { font-size: 0.75rem; color: #64748B; margin-top: 4px; }

        .alert-info {
            background: #EFF6FF;
            border-left: 4px solid #1E4A8C;
            padding: 14px 18px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.85rem;
            color: #1E4A8C;
        }

        .card {
            background: white;
            border-radius: 12px;
            padding: 24px 30px;
            margin-bottom: 20px;
            border: 1px solid #E2E8F0;
        }

        .card h2 {
            font-size: 1rem;
            font-weight: 700;
            color: #1E4A8C;
            padding: 8px 12px;
            background: #F1F5F9;
            border-left: 4px solid #1E4A8C;
            margin-bottom: 16px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        @media (max-width: 768px) {
            .form-grid { grid-template-columns: 1fr; }
        }

        .form-group { margin-bottom: 14px; }
        .form-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            color: #475569;
            margin-bottom: 6px;
        }
        .form-group label .req { color: #D32F2F; }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1.5px solid #E2E8F0;
            border-radius: 8px;
            font-family: inherit;
            font-size: 0.85rem;
            background: white;
        }
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #1E4A8C;
            box-shadow: 0 0 0 3px rgba(30,74,140,0.1);
        }
        .form-group textarea { resize: vertical; min-height: 60px; }
        .form-group .hint {
            font-size: 0.65rem;
            color: #94A3B8;
            margin-top: 4px;
        }

        /* Members table */
        .members-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 8px;
        }
        .members-table th {
            background: #1E4A8C;
            color: white;
            padding: 8px 6px;
            font-size: 0.7rem;
            text-align: left;
            text-transform: uppercase;
            border: 1px solid #0A2F6C;
        }
        .members-table td {
            padding: 6px;
            border: 1px solid #E2E8F0;
        }
        .members-table input {
            width: 100%;
            padding: 6px 8px;
            border: 1px solid #E2E8F0;
            border-radius: 6px;
            font-size: 0.8rem;
            font-family: inherit;
        }
        .btn-remove {
            background: #FEE2E2;
            color: #991B1B;
            border: none;
            padding: 6px 10px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.75rem;
        }
        .btn-add-row {
            background: #DBEAFE;
            color: #1E40AF;
            border: none;
            padding: 8px 14px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: 600;
            margin-top: 10px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        /* Action buttons */
        .action-bar {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            justify-content: flex-end;
            margin-top: 20px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 22px;
            border-radius: 10px;
            border: none;
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s;
        }
        .btn-pdf {
            background: linear-gradient(135deg, #DC2626, #991B1B);
            color: white;
        }
        .btn-pdf:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(220,38,38,0.3); }
        .btn-word {
            background: linear-gradient(135deg, #2B579A, #1E3F73);
            color: white;
        }
        .btn-word:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(43,87,154,0.3); }
        .btn-back {
            background: white;
            color: #475569;
            border: 1px solid #E2E8F0;
        }
        .btn-back:hover { background: #F8FAFC; }
    </style>
</head>
<body>
<div class="container">

    <div class="header">
        <div>
            <h1><i class="fas fa-edit" style="color: #1E4A8C;"></i> Edit & Finalize Household</h1>
            <p>Modify the data below, then generate the final PDF or Word document</p>
        </div>
        <a href="household_view.php?id=<?php echo $household_id; ?>" class="btn btn-back">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>

    <div class="alert-info">
        <i class="fas fa-info-circle"></i>
        <strong>Editable Preview:</strong> All fields below are loaded from the database. You can modify them before generating the final document. Your changes will not be saved to the database — they only affect the generated PDF/Word file.
    </div>

    <form id="finalizeForm" method="POST" action="household_generate.php">
        <input type="hidden" name="household_id" value="<?php echo $household_id; ?>">
        <input type="hidden" name="doc_number" value="<?php echo htmlspecialchars($doc_number); ?>">
        <input type="hidden" name="date_generated" value="<?php echo htmlspecialchars($date_generated); ?>">

        <!-- SECTION I -->
        <div class="card">
            <h2>I. Household Head Information</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>First Name <span class="req">*</span></label>
                    <input type="text" name="head_first_name" required
                           value="<?php echo htmlspecialchars($household['head_first_name']); ?>">
                </div>
                <div class="form-group">
                    <label>Middle Name</label>
                    <input type="text" name="head_middle_name"
                           value="<?php echo htmlspecialchars($household['head_middle_name'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Last Name <span class="req">*</span></label>
                    <input type="text" name="head_last_name" required
                           value="<?php echo htmlspecialchars($household['head_last_name']); ?>">
                </div>
                <div class="form-group">
                    <label>Relation to Head</label>
                    <input type="text" name="relation_to_head"
                           value="<?php echo htmlspecialchars($household['relation_to_head'] ?? 'Self'); ?>">
                </div>
                <div class="form-group">
                    <label>Total Members</label>
                    <input type="number" name="total_members" min="1"
                           value="<?php echo htmlspecialchars($household['total_members'] ?? count($members)); ?>">
                </div>
            </div>
        </div>

        <!-- SECTION II -->
        <div class="card">
            <h2>II. Address Information</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>Street / House No.</label>
                    <input type="text" name="address"
                           value="<?php echo htmlspecialchars($household['address'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Barangay</label>
                    <input type="text" name="barangay"
                           value="<?php echo htmlspecialchars($household['barangay'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>City / Municipality</label>
                    <input type="text" name="city_municipality"
                           value="<?php echo htmlspecialchars($household['city_municipality'] ?? 'Cantilan'); ?>">
                </div>
                <div class="form-group">
                    <label>Province</label>
                    <input type="text" name="province"
                           value="<?php echo htmlspecialchars($household['province'] ?? 'Surigao del Sur'); ?>">
                </div>
            </div>
        </div>

        <!-- SECTION III -->
        <div class="card">
            <h2>III. Economic Information</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>Monthly Household Income (PHP)</label>
                    <input type="number" step="0.01" name="monthly_income"
                           value="<?php echo htmlspecialchars($household['monthly_income'] ?? 0); ?>">
                </div>
                <div class="form-group">
                    <label>Poverty Classification</label>
                    <select name="poverty_status">
                        <?php 
                        $options = ['Extremely Poor', 'Poor', 'Low Income', 'Lower Middle', 'Middle Income and Above'];
                        foreach ($options as $opt):
                        ?>
                            <option value="<?php echo $opt; ?>" <?php echo ($poverty_status == $opt) ? 'selected' : ''; ?>>
                                <?php echo $opt; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>4Ps Beneficiary</label>
                    <select name="is_4ps_beneficiary">
                        <option value="0" <?php echo (($household['is_4ps_beneficiary'] ?? 0) == 0) ? 'selected' : ''; ?>>No</option>
                        <option value="1" <?php echo (($household['is_4ps_beneficiary'] ?? 0) == 1) ? 'selected' : ''; ?>>Yes</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- SECTION IV: Members (editable list) -->
        <div class="card">
            <h2>IV. Household Members</h2>
            <table class="members-table" id="membersTable">
                <thead>
                    <tr>
                        <th style="width:5%; text-align:center;">#</th>
                        <th style="width:25%;">Full Name</th>
                        <th style="width:18%;">Relationship</th>
                        <th style="width:10%;">Age</th>
                        <th style="width:15%;">Gender</th>
                        <th style="width:20%;">Occupation</th>
                        <th style="width:7%; text-align:center;">X</th>
                    </tr>
                </thead>
                <tbody id="membersBody">
                    <?php if (count($members) > 0): ?>
                        <?php foreach ($members as $i => $m): ?>
                        <tr class="member-row">
                            <td style="text-align:center;" class="row-num"><?php echo $i + 1; ?></td>
                            <td><input type="text" name="member_name[]" value="<?php echo htmlspecialchars(($m['first_name'] ?? '') . ' ' . ($m['last_name'] ?? '')); ?>"></td>
                            <td><input type="text" name="member_relationship[]" value="<?php echo htmlspecialchars($m['relationship'] ?? ''); ?>"></td>
                            <td><input type="text" name="member_age[]" value="<?php echo htmlspecialchars($m['age'] ?? ''); ?>"></td>
                            <td><input type="text" name="member_gender[]" value="<?php echo htmlspecialchars($m['gender'] ?? ''); ?>"></td>
                            <td><input type="text" name="member_occupation[]" value="<?php echo htmlspecialchars($m['occupation'] ?? ''); ?>"></td>
                            <td style="text-align:center;"><button type="button" class="btn-remove" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr class="member-row">
                            <td style="text-align:center;" class="row-num">1</td>
                            <td><input type="text" name="member_name[]"></td>
                            <td><input type="text" name="member_relationship[]"></td>
                            <td><input type="text" name="member_age[]"></td>
                            <td><input type="text" name="member_gender[]"></td>
                            <td><input type="text" name="member_occupation[]"></td>
                            <td style="text-align:center;"><button type="button" class="btn-remove" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="button" class="btn-add-row" onclick="addRow()">
                <i class="fas fa-plus"></i> Add Member Row
            </button>
        </div>

        <!-- SECTION V: GPS -->
        <div class="card">
            <h2>V. GPS Location (Optional)</h2>
            <div class="form-grid">
                <div class="form-group">
                    <label>Latitude</label>
                    <input type="text" name="gps_latitude"
                           value="<?php echo htmlspecialchars($household['gps_latitude'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Longitude</label>
                    <input type="text" name="gps_longitude"
                           value="<?php echo htmlspecialchars($household['gps_longitude'] ?? ''); ?>">
                </div>
            </div>
        </div>

        <!-- ACTION BUTTONS -->
        <div class="card">
            <h2>Generate Document</h2>
            <p style="font-size: 0.85rem; color: #64748B; margin-bottom: 12px;">
                Choose your output format. Both will use the edited data above.
            </p>
            <div class="action-bar" style="justify-content: flex-start;">
                <button type="submit" name="format" value="pdf" class="btn btn-pdf">
                    <i class="fas fa-file-pdf"></i> Generate Final PDF
                </button>
                <button type="submit" name="format" value="word" class="btn btn-word">
                    <i class="fas fa-file-word"></i> Download as Word (.docx)
                </button>
                <a href="household_view.php?id=<?php echo $household_id; ?>" class="btn btn-back">
                    <i class="fas fa-times"></i> Cancel
                </a>
            </div>
        </div>

    </form>

</div>

<script>
    function addRow() {
        const tbody = document.getElementById('membersBody');
        const tr = document.createElement('tr');
        tr.className = 'member-row';
        tr.innerHTML = `
            <td style="text-align:center;" class="row-num"></td>
            <td><input type="text" name="member_name[]"></td>
            <td><input type="text" name="member_relationship[]"></td>
            <td><input type="text" name="member_age[]"></td>
            <td><input type="text" name="member_gender[]"></td>
            <td><input type="text" name="member_occupation[]"></td>
            <td style="text-align:center;"><button type="button" class="btn-remove" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
        `;
        tbody.appendChild(tr);
        renumber();
    }

    function removeRow(btn) {
        const row = btn.closest('tr');
        row.remove();
        renumber();
    }

    function renumber() {
        const rows = document.querySelectorAll('#membersBody .member-row');
        rows.forEach((r, i) => {
            r.querySelector('.row-num').innerText = i + 1;
        });
    }

    // Initialize on load
    renumber();
</script>

</body>
</html>