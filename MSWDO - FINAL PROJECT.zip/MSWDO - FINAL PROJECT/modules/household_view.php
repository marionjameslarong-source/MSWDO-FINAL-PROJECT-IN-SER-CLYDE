<?php
session_start();
require_once '../config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];

$household_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $pdo->prepare("SELECT * FROM households WHERE id = ?");
$stmt->execute([$household_id]);
$household = $stmt->fetch();

if(!$household) {
    header("Location: household.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM household_members WHERE household_id = ? ORDER BY id");
$stmt->execute([$household_id]);
$members = $stmt->fetchAll();

function classifyPovertyIncome($income) {
    if($income < 5000) return 'Extremely Poor';
    elseif($income >= 5000 && $income <= 10000) return 'Poor';
    elseif($income >= 10001 && $income <= 15000) return 'Low Income';
    elseif($income >= 15001 && $income <= 25000) return 'Lower Middle';
    else return 'Middle Income and Above';
}

$poverty_status = $household['poverty_status'] ?? classifyPovertyIncome($household['monthly_income'] ?? 0);

$deleted_count = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
    $deleted_count = $stmt->fetch()['total'] ?? 0;
} catch(PDOException $e) {
    $deleted_count = 0;
}

$doc_number = 'MSWDO-HH-' . date('Y') . '-' . str_pad($household_id, 5, '0', STR_PAD_LEFT);
$date_generated = date('F d, Y');

$member_count = count($members);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Household Details - MSWDO Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lucida+Calligraphy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: #E5E7EB;
            color: #334155;
            padding-bottom: 75px;
        }

        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 25px -3px rgb(0 0 0 / 0.15);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        .app { display: flex; min-height: 100vh; }

        /* SIDEBAR */
        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0; left: 0; bottom: 0;
            overflow-y: auto;
            z-index: 40;
            transition: transform 0.3s ease;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon { width: 40px; height: 40px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; }
        .logo-icon i { font-size: 1.3rem; color: var(--accent); }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 28px; }
        .nav-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--gray-400); margin-bottom: 12px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; margin-bottom: 4px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; transition: all 0.2s ease; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 16px; margin-bottom: 2px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; font-size: 0.8rem; }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }

        /* MAIN */
        .main-content { flex: 1; margin-left: 280px; padding: 24px 40px 80px 40px; }

        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--gray-300); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--white); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        /* ACTION BAR */
        .action-bar { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
        .btn-action {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 10px 20px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.8rem;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .btn-edit-finalize {
            background: linear-gradient(135deg, #059669, #047857);
            color: white;
            box-shadow: 0 4px 12px rgba(5,150,105,0.3);
        }
        .btn-edit-finalize:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(5,150,105,0.4); }
        .btn-pdf {
            background: linear-gradient(135deg, #2B579A, #1E3F73);
            color: white;
            box-shadow: 0 4px 12px rgba(43,87,154,0.3);
        }
        .btn-pdf:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(43,87,154,0.4); }
        .btn-back { background: var(--white); color: var(--primary); border: 1px solid var(--gray-200); }
        .btn-back:hover { background: var(--gray-50); }

        /* DOCUMENT (SCREEN VIEW) */
        .document-wrapper {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            box-shadow: var(--shadow-lg);
            border-radius: 4px;
            overflow: hidden;
        }

        .document {
            padding: 40px 45px 30px 45px;
            background: white;
            font-family: Arial, sans-serif;
            font-size: 12pt;
            color: #000;
            line-height: 1.5;
            position: relative;
        }

        /* LETTERHEAD */
        .doc-header {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0;
            gap: 15px;
            width: 100%;
            padding-bottom: 12px;
            border-bottom: 2px solid #000;
        }
        .doc-header-logo-left,
        .doc-header-logo-right {
            width: 85px;
            height: 85px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .doc-header-logo-left img,
        .doc-header-logo-right img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        .doc-header-center {
            flex: 1 1 auto;
            text-align: center;
            line-height: 1.4;
            font-family: Arial, sans-serif;
            font-size: 12pt;
            min-width: 0;
        }
        .doc-header-center .line1 { font-size: 12pt; font-weight: normal; color: #000; }
        .doc-header-center .line2 { font-size: 12pt; font-weight: bold; color: #000; }
        .doc-header-center .line3 { font-size: 12pt; font-weight: bold; color: #000; }

        /* TITLE */
        .doc-title-block { text-align: center; margin: 22px 0 22px 0; }
        .doc-title-block .doc-title {
            font-size: 15pt;
            font-weight: 700;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            text-decoration: underline;
            text-underline-offset: 4px;
            margin-bottom: 8px;
            color: #000;
        }
        .doc-title-block .doc-meta {
            font-size: 10pt;
            color: #000;
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }

        /* SECTIONS - PLAIN */
        .doc-section { margin-bottom: 18px; }
        .doc-section-title {
            font-size: 12pt;
            font-weight: 700;
            color: #000;
            background: transparent;
            border: none;
            padding: 0 0 4px 0;
            margin-bottom: 8px;
            text-transform: uppercase;
        }
        .doc-section-body { padding: 0; }

        /* Info lines — plain text */
        .doc-info-line {
            font-size: 12pt;
            color: #000;
            line-height: 1.5;
            padding: 2px 0;
        }
        .doc-info-line .label { font-weight: normal; color: #000; }
        .doc-info-line .value { color: #000; }

        /* Members table */
        .doc-members-table { width: 100%; border-collapse: collapse; font-size: 12pt; margin-top: 4px; color: #000; }
        .doc-members-table th {
            background: transparent;
            color: #000;
            padding: 8px 10px;
            text-align: left;
            font-weight: bold;
            font-size: 12pt;
            text-transform: uppercase;
            border: 1px solid #000;
        }
        .doc-members-table td { padding: 6px 10px; border: 1px solid #000; color: #000; font-size: 12pt; background: transparent; }
        .doc-members-table tr.no-members td { text-align: center; padding: 16px; font-style: italic; color: #000; }

        /* SIGNATURES */
        .doc-signature-block {
            display: flex;
            justify-content: space-between;
            gap: 40px;
            margin-top: 60px;
        }
        .doc-signature-item { flex: 1; text-align: center; }
        .doc-signature-item .sig-line {
            font-size: 12pt;
            font-weight: 700;
            text-transform: uppercase;
            color: #000;
            margin-bottom: 4px;
            padding-top: 60px;
            border-top: 1px solid #000;
        }
        .doc-signature-item .sig-role { font-size: 12pt; color: #000; font-style: italic; }

        /* FOOTER */
        .doc-footer {
            margin-top: 50px;
            padding-top: 14px;
            border-top: 2px solid #000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            font-size: 12pt;
            color: #000;
        }
        .doc-footer .footer-left,
        .doc-footer .footer-right {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12pt;
            color: #000;
        }
        .doc-footer .footer-left i,
        .doc-footer .footer-right i {
            font-size: 14pt;
            color: #000;
        }

        /* BOTTOM NAV */
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: var(--white); display: flex; justify-content: space-around; padding: 8px 16px 12px; border-top: 1px solid var(--gray-200); z-index: 100; }
        .bottom-nav .nav-item { display: flex; flex-direction: column; align-items: center; font-size: 0.7rem; color: var(--gray-600); text-decoration: none; }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .menu-toggle:hover { background: var(--gray-100); }

        .sidebar-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 39; display: none; }
        .sidebar-overlay.active { display: block; }

        @media (max-width: 992px) {
            .document { padding: 28px 24px 24px 24px; }
            .doc-header-logo-left, .doc-header-logo-right { width: 65px; height: 65px; }
        }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .menu-toggle { display: block; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .document { padding: 20px 16px; }
            .doc-header { flex-wrap: wrap; justify-content: center; gap: 10px; }
            .doc-header-logo-left, .doc-header-logo-right { width: 55px; height: 55px; }
            .doc-header-center { width: 100%; order: -1; }
            .doc-signature-block { flex-direction: column; gap: 20px; }
            .doc-members-table { font-size: 9pt; }
            .doc-members-table th, .doc-members-table td { padding: 4px 6px; }
            .doc-footer { flex-direction: column; align-items: flex-start; gap: 6px; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-hand-holding-heart"></i></div>
                <div class="logo-text">
                    <h1>MSWDO Portal</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="mswdstaff_communityservice.php" class="nav-item">
                    <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
                </a>
                <a href="household.php" class="nav-item active">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Applications</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="mswdstaff_idapplication.php" class="nav-item"><i class="fas fa-id-card"></i> <span>ID Applications</span></a>
                <a href="staff_eligibility_engine.php" class="nav-item"><i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span></a>
                <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> <span>Reports</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i> <span>Profile</span></a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Household Details</h1>
                    <p>View complete household information</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small><?php echo ucfirst(str_replace('_', ' ', $role)); ?></small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <!-- ACTION BAR -->
        <div class="action-bar">
            <a href="household_form.php?edit=<?php echo $household_id; ?>" class="btn-action btn-edit-finalize">
                <i class="fas fa-edit"></i> Edit & Finalize
            </a>
            <a href="household_docx.php?id=<?php echo $household_id; ?>" class="btn-action btn-pdf">
                <i class="fas fa-file-word"></i> Download Word
            </a>
            <a href="household.php" class="btn-action btn-back">
                <i class="fas fa-arrow-left"></i> Back to Households
            </a>
        </div>

        <div class="document-wrapper">
            <div class="document">

                <!-- ============================================================
                     LETTERHEAD
                     - MSWDO logo on right (replaced OSCA logo)
                     - "OFFICE OF THE SENIOR CITIZENS AFFAIRS" line REMOVED
                     ============================================================ -->
                <div class="doc-header">
                    <div class="doc-header-logo-left">
                        <img src="../assets/img/cantilan_logo.png" alt="Cantilan Logo">
                    </div>
                    <div class="doc-header-center">
                        <div class="line1">Republic of the Philippines</div>
                        <div class="line2">PROVINCE OF SURIGAO DEL SUR</div>
                        <div class="line3">MUNICIPALITY OF CANTILAN</div>
                    </div>
                    <div class="doc-header-logo-right">
                        <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                    </div>
                </div>

                <!-- TITLE -->
                <div class="doc-title-block">
                    <div class="doc-title">Household Data Record</div>
                    <div class="doc-meta">
                        <span><strong>Document No:</strong> <?php echo $doc_number; ?></span>
                        <span><strong>Date Generated:</strong> <?php echo $date_generated; ?></span>
                    </div>
                </div>

                <!-- I. HOUSEHOLD HEAD -->
                <div class="doc-section">
                    <div class="doc-section-title">I. Household Head Information</div>
                    <div class="doc-section-body">
                        <div class="doc-info-line">
                            <span class="label">Full Name:</span>
                            <span class="value">
                                <?php 
                                $middle = !empty($household['head_middle_name']) ? ' ' . $household['head_middle_name'] : '';
                                echo htmlspecialchars($household['head_first_name'] . $middle . ' ' . $household['head_last_name']); 
                                ?>
                            </span>
                        </div>
                        <div class="doc-info-line">
                            <span class="label">Relation to Head:</span>
                            <span class="value"><?php echo htmlspecialchars($household['relation_to_head'] ?? 'Self'); ?></span>
                        </div>
                        <?php if(!empty($household['contact_number'])): ?>
                        <div class="doc-info-line">
                            <span class="label">Contact Number:</span>
                            <span class="value"><?php echo htmlspecialchars($household['contact_number']); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="doc-info-line">
                            <span class="label">Total Members:</span>
                            <span class="value"><?php echo $member_count; ?></span>
                        </div>
                    </div>
                </div>

                <!-- II. ADDRESS -->
                <div class="doc-section">
                    <div class="doc-section-title">II. Address Information</div>
                    <div class="doc-section-body">
                        <div class="doc-info-line">
                            <span class="label">Street / House No.:</span>
                            <span class="value"><?php echo htmlspecialchars($household['address'] ?? 'Not specified'); ?></span>
                        </div>
                        <div class="doc-info-line">
                            <span class="label">Barangay:</span>
                            <span class="value"><?php echo htmlspecialchars($household['barangay'] ?? 'Not specified'); ?></span>
                        </div>
                        <div class="doc-info-line">
                            <span class="label">City / Municipality:</span>
                            <span class="value"><?php echo htmlspecialchars($household['city_municipality'] ?? 'Cantilan'); ?></span>
                        </div>
                        <div class="doc-info-line">
                            <span class="label">Province:</span>
                            <span class="value"><?php echo htmlspecialchars($household['province'] ?? 'Surigao del Sur'); ?></span>
                        </div>
                        <?php if(!empty($household['zip_code'])): ?>
                        <div class="doc-info-line">
                            <span class="label">ZIP Code:</span>
                            <span class="value"><?php echo htmlspecialchars($household['zip_code']); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- III. ECONOMIC -->
                <div class="doc-section">
                    <div class="doc-section-title">III. Economic Information</div>
                    <div class="doc-section-body">
                        <div class="doc-info-line">
                            <span class="label">Monthly Household Income:</span>
                            <span class="value">₱ <?php echo number_format($household['monthly_income'] ?? 0, 2); ?></span>
                        </div>
                        <div class="doc-info-line">
                            <span class="label">Poverty Classification:</span>
                            <span class="value"><?php echo htmlspecialchars($poverty_status); ?></span>
                        </div>
                        <div class="doc-info-line">
                            <span class="label">4Ps Beneficiary:</span>
                            <span class="value"><?php echo ($household['is_4ps_beneficiary'] ?? 0) == 1 ? 'Yes' : 'No'; ?></span>
                        </div>
                    </div>
                </div>

                <!-- IV. MEMBERS -->
                <div class="doc-section">
                    <div class="doc-section-title">IV. Household Members</div>
                    <div class="doc-section-body">
                        <table class="doc-members-table">
                            <thead>
                                <tr>
                                    <th style="width: 6%;">#</th>
                                    <th style="width: 30%;">Full Name</th>
                                    <th style="width: 18%;">Relationship</th>
                                    <th style="width: 8%;">Age</th>
                                    <th style="width: 15%;">Gender</th>
                                    <th style="width: 23%;">Occupation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($member_count > 0): ?>
                                    <?php foreach($members as $index => $member): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars(trim(($member['first_name'] ?? '') . ' ' . ($member['last_name'] ?? ''))); ?></td>
                                            <td><?php echo htmlspecialchars($member['relationship'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($member['age'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($member['gender'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($member['occupation'] ?? 'N/A'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr class="no-members"><td colspan="6">No household members recorded.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- ============================================================
                     SIGNATURES
                     - "MSWDO Officer / OSCA Head" changed to "MSWDO Officer"
                     ============================================================ -->
                <div class="doc-signature-block">
                    <div class="doc-signature-item">
                        <div class="sig-line">Prepared by:</div>
                        <div class="sig-role">MSWDO Staff / Encoder</div>
                    </div>
                    <div class="doc-signature-item">
                        <div class="sig-line">Certified Correct:</div>
                        <div class="sig-role">MSWDO Officer</div>
                    </div>
                </div>

                <!-- ============================================================
                     FOOTER
                     - Text changed to "Cantilan Municipal Social Welfare & Development Office"
                     - Facebook logo kept
                     - OSCA email replaced with MSWDO email
                     ============================================================ -->
                <div class="doc-footer">
                    <div class="footer-left">
                        <i class="fab fa-facebook"></i>
                        <span>Cantilan Municipal Social Welfare &amp; Development Office</span>
                    </div>
                    <div class="footer-right">
                        <i class="fas fa-envelope"></i>
                        <span>mswdo.cantilan@gmail.com</span>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <!-- BOTTOM NAV -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item active"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_idapplication.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Apps</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
        });
    }
    if(overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
    }

    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');

    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
</script>
</body>
</html>