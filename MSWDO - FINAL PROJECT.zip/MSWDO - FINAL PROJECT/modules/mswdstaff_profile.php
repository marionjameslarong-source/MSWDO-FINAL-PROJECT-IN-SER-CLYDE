<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder', 'admin'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];

// ============================================================
// 1. GET STAFF PROFILE
// ============================================================
$user_data = [];
$permissions = [];
$device_registered = false;
$staff_status = 'ACTIVE';
$sync_stats = [];
$mobile_session_active = false;
$last_mobile_login = null;

try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
               s.designation_title, 
               s.assigned_office, 
               s.operational_status,
               s.current_assigned_zone,
               s.device_uuid,
               s.device_model,
               s.app_version,
               s.last_sync_at,
               s.total_synced_records,
               s.total_pending_records,
               s.last_mobile_login,
               s.mobile_session_token,
               s.session_expires_at
        FROM users u
        LEFT JOIN staff_profiles s ON u.id = s.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($user_data) {
        $staff_status = $user_data['operational_status'] ?? 'ACTIVE';
        $device_registered = !empty($user_data['device_uuid']);
        $last_mobile_login = $user_data['last_mobile_login'] ?? null;
        
        if($user_data['mobile_session_token'] && $user_data['session_expires_at']) {
            $expires_at = strtotime($user_data['session_expires_at']);
            $mobile_session_active = ($expires_at > time());
        }
    }
    
    // Get permissions based on role
    $permissions = [
        'can_approve_financial_aid' => in_array($role, ['admin', 'social_worker', 'staff']),
        'can_view_vawc_files' => in_array($role, ['admin', 'vawc_officer']),
        'can_issue_id_cards' => in_array($role, ['admin', 'staff', 'encoder']),
        'can_assess_applications' => in_array($role, ['admin', 'social_worker']),
        'can_disburse_funds' => in_array($role, ['admin', 'staff']),
        'can_approve_beneficiaries' => in_array($role, ['admin', 'social_worker']),
        'can_access_mobile_app' => in_array($role, ['admin', 'staff', 'social_worker', 'encoder']),
        'can_offline_sync' => in_array($role, ['admin', 'staff', 'social_worker'])
    ];
    
    // Get sync statistics
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM offline_sync_queue WHERE user_id = ? AND synced_at IS NULL");
        $stmt->execute([$user_id]);
        $sync_stats['pending'] = $stmt->fetch()['total'] ?? 0;
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM offline_sync_queue WHERE user_id = ? AND synced_at IS NOT NULL");
        $stmt->execute([$user_id]);
        $sync_stats['synced'] = $stmt->fetch()['total'] ?? 0;
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM offline_sync_queue WHERE user_id = ? AND sync_attempts > 3");
        $stmt->execute([$user_id]);
        $sync_stats['failed'] = $stmt->fetch()['total'] ?? 0;
    } catch(PDOException $e) {
        $sync_stats = ['pending' => 0, 'synced' => 0, 'failed' => 0];
    }
    
} catch(PDOException $e) {
    $user_data = [
        'username' => $_SESSION['username'] ?? '',
        'full_name' => $full_name,
        'email' => '',
        'contact_number' => '',
        'role' => $role,
        'created_at' => date('Y-m-d H:i:s'),
        'designation_title' => ucfirst(str_replace('_', ' ', $role)) . ' Officer',
        'assigned_office' => 'MSWDO_MAIN_OFFICE',
        'operational_status' => 'AVAILABLE',
        'current_assigned_zone' => 'Not Assigned',
        'device_uuid' => null,
        'device_model' => null,
        'app_version' => null,
        'last_sync_at' => null,
        'total_synced_records' => 0,
        'total_pending_records' => 0,
        'last_mobile_login' => null,
        'mobile_session_token' => null,
        'session_expires_at' => null
    ];
    $sync_stats = ['pending' => 0, 'synced' => 0, 'failed' => 0];
}

// Get staff statistics
$pending_applications = 0;
$total_processed = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM welfare_applications WHERE status = 'pending'");
    $stmt->execute();
    $pending_applications = $stmt->fetch()['count'];
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM welfare_applications WHERE reviewed_by = ?");
    $stmt->execute([$user_id]);
    $total_processed = $stmt->fetch()['count'];
} catch(PDOException $e) {}

// ============================================================
// 2. UPDATE PROFILE
// ============================================================
$error = '';
$success = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $new_full_name = trim($_POST['full_name'] ?? '');
    $new_email = trim($_POST['email'] ?? '');
    $new_contact = trim($_POST['contact_number'] ?? '');
    $new_designation = trim($_POST['designation_title'] ?? '');
    $new_office = trim($_POST['assigned_office'] ?? '');
    
    $errors = [];
    if(empty($new_full_name)) $errors[] = "Full name is required.";
    if(!empty($new_email) && !filter_var($new_email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    
    if(empty($errors)) {
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'staff_profiles'");
            if($stmt->rowCount() == 0) {
                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS staff_profiles (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL UNIQUE,
                        designation_title VARCHAR(100),
                        assigned_office VARCHAR(100),
                        operational_status VARCHAR(50) DEFAULT 'AVAILABLE',
                        current_assigned_zone VARCHAR(100),
                        device_uuid VARCHAR(255),
                        device_model VARCHAR(100),
                        app_version VARCHAR(50),
                        last_sync_at DATETIME,
                        total_synced_records INT DEFAULT 0,
                        total_pending_records INT DEFAULT 0,
                        last_mobile_login DATETIME,
                        mobile_session_token VARCHAR(255),
                        session_expires_at DATETIME,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    )
                ");
            }
            
            $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, contact_number = ? WHERE id = ?");
            $stmt->execute([$new_full_name, $new_email, $new_contact, $user_id]);
            
            $stmt = $pdo->prepare("
                INSERT INTO staff_profiles (user_id, designation_title, assigned_office) 
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    designation_title = VALUES(designation_title),
                    assigned_office = VALUES(assigned_office)
            ");
            $stmt->execute([$user_id, $new_designation, $new_office]);
            
            $success = "Profile updated successfully!";
            $_SESSION['full_name'] = $new_full_name;
            $user_data['full_name'] = $new_full_name;
            $user_data['email'] = $new_email;
            $user_data['contact_number'] = $new_contact;
            $user_data['designation_title'] = $new_designation;
            $user_data['assigned_office'] = $new_office;
            
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = implode("<br>", $errors);
    }
}

// ============================================================
// 3. CHANGE PASSWORD
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $errors = [];
    if(empty($current_password)) $errors[] = "Current password is required.";
    if(empty($new_password)) $errors[] = "New password is required.";
    if(strlen($new_password) < 6) $errors[] = "New password must be at least 6 characters.";
    if($new_password !== $confirm_password) $errors[] = "New passwords do not match.";
    
    if(empty($errors)) {
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        if($user && password_verify($current_password, $user['password'])) {
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed, $user_id]);
            $password_success = "Password changed successfully!";
        } else {
            $password_error = "Current password is incorrect.";
        }
    } else {
        $password_error = implode("<br>", $errors);
    }
}

// ============================================================
// 4. UPDATE OPERATIONAL STATUS
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $operational_status = $_POST['operational_status'] ?? 'AVAILABLE';
    $current_zone = $_POST['current_assigned_zone'] ?? '';
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO staff_profiles (user_id, operational_status, current_assigned_zone) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                operational_status = VALUES(operational_status),
                current_assigned_zone = VALUES(current_assigned_zone)
        ");
        $stmt->execute([$user_id, $operational_status, $current_zone]);
        
        $status_success = "Status updated to: " . str_replace('_', ' ', $operational_status);
        $user_data['operational_status'] = $operational_status;
        $user_data['current_assigned_zone'] = $current_zone;
        
    } catch(PDOException $e) {
        $status_error = "Failed to update status.";
    }
}

// ============================================================
// 5. DEVICE REGISTRATION
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_device'])) {
    $device_uuid = $_POST['device_uuid'] ?? '';
    $device_model = $_POST['device_model'] ?? '';
    $app_version = $_POST['app_version'] ?? 'v2.4.1';
    
    if(empty($device_uuid)) {
        $device_error = "Device UUID is required for registration.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT user_id FROM staff_profiles WHERE device_uuid = ? AND user_id != ?");
            $stmt->execute([$device_uuid, $user_id]);
            if($stmt->rowCount() > 0) {
                $device_error = "This device is already registered to another staff member.";
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO staff_profiles (user_id, device_uuid, device_model, app_version) 
                    VALUES (?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                        device_uuid = VALUES(device_uuid),
                        device_model = VALUES(device_model),
                        app_version = VALUES(app_version)
                ");
                $stmt->execute([$user_id, $device_uuid, $device_model, $app_version]);
                
                $device_success = "Device registered successfully!";
                $device_registered = true;
                $user_data['device_uuid'] = $device_uuid;
                $user_data['device_model'] = $device_model;
                $user_data['app_version'] = $app_version;
            }
            
        } catch(PDOException $e) {
            $device_error = "Failed to register device.";
        }
    }
}

// ============================================================
// 6. SESSION REFRESH
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['refresh_session'])) {
    $secure_pin = $_POST['secure_pin'] ?? '';
    $biometric_passed = isset($_POST['biometric_verification_passed']) ? true : false;
    
    if($biometric_passed || !empty($secure_pin)) {
        $session_token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+8 hours'));
        
        try {
            $stmt = $pdo->prepare("
                UPDATE staff_profiles 
                SET mobile_session_token = ?, 
                    session_expires_at = ?,
                    last_mobile_login = NOW()
                WHERE user_id = ?
            ");
            $stmt->execute([$session_token, $expires_at, $user_id]);
            
            $_SESSION['last_activity'] = time();
            $_SESSION['session_refreshed'] = true;
            $_SESSION['mobile_session_token'] = $session_token;
            
            $mobile_session_active = true;
            $last_mobile_login = date('Y-m-d H:i:s');
            $session_success = "Session refreshed successfully! Mobile session active until " . date('h:i A', strtotime($expires_at));
            
        } catch(PDOException $e) {
            $session_error = "Failed to refresh session.";
        }
    } else {
        $session_error = "Biometric verification or PIN required.";
    }
}

// ============================================================
// 7. MOBILE LOGIN
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mobile_login'])) {
    try {
        $session_token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+8 hours'));
        
        $stmt = $pdo->prepare("
            UPDATE staff_profiles 
            SET mobile_session_token = ?, 
                session_expires_at = ?,
                last_mobile_login = NOW()
            WHERE user_id = ?
        ");
        $stmt->execute([$session_token, $expires_at, $user_id]);
        
        $mobile_login_success = "Mobile app login successful! Session active until " . date('h:i A', strtotime($expires_at));
        $mobile_session_active = true;
        $last_mobile_login = date('Y-m-d H:i:s');
        
    } catch(PDOException $e) {
        $mobile_login_error = "Failed to authenticate mobile session.";
    }
}

// ============================================================
// 8. LOGOUT MOBILE SESSION
// ============================================================
if(isset($_GET['logout_mobile']) && $_GET['logout_mobile'] == 1) {
    try {
        $stmt = $pdo->prepare("
            UPDATE staff_profiles 
            SET mobile_session_token = NULL, 
                session_expires_at = NULL
            WHERE user_id = ?
        ");
        $stmt->execute([$user_id]);
        $mobile_logout_success = "Mobile session logged out successfully.";
        $mobile_session_active = false;
        
    } catch(PDOException $e) {
        $mobile_logout_error = "Failed to logout mobile session.";
    }
}

// Helper function to get status badge class
function getStatusClass($status) {
    switch($status) {
        case 'ACTIVE':
        case 'AVAILABLE':
            return 'status-active';
        case 'FIELD_DEPLOYMENT':
            return 'status-field';
        case 'ON_BREAK':
        case 'AWAY':
            return 'status-away';
        case 'INACTIVE':
            return 'status-inactive';
        default:
            return 'status-active';
    }
}

function getStatusLabel($status) {
    switch($status) {
        case 'ACTIVE': return 'Active';
        case 'AVAILABLE': return 'Available';
        case 'FIELD_DEPLOYMENT': return 'Field Deployment';
        case 'ON_BREAK': return 'On Break';
        case 'AWAY': return 'Away';
        case 'INACTIVE': return 'Inactive';
        default: return ucfirst(str_replace('_', ' ', $status));
    }
}

$has_mobile_access = in_array($role, ['admin', 'staff', 'social_worker', 'encoder']);
$can_approve_id = in_array($role, ['admin', 'staff', 'encoder']);

// Get pending sync records
$pending_sync_records = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM offline_sync_queue 
        WHERE user_id = ? AND synced_at IS NULL 
        ORDER BY timestamp_created DESC 
        LIMIT 20
    ");
    $stmt->execute([$user_id]);
    $pending_sync_records = $stmt->fetchAll();
} catch(PDOException $e) {
    $pending_sync_records = [];
}

// Get role display name
function getRoleDisplay($role) {
    $roles = [
        'admin' => 'Administrator',
        'staff' => 'Staff Member',
        'social_worker' => 'Social Worker',
        'encoder' => 'Data Encoder',
        'vawc_officer' => 'VAWC Officer'
    ];
    return $roles[$role] ?? ucfirst(str_replace('_', ' ', $role));
}

// Get role icon
function getRoleIcon($role) {
    $icons = [
        'admin' => 'fa-crown',
        'staff' => 'fa-user-tie',
        'social_worker' => 'fa-hands-helping',
        'encoder' => 'fa-keyboard',
        'vawc_officer' => 'fa-shield-alt'
    ];
    return $icons[$role] ?? 'fa-user';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Staff Profile - MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #EFF6FF;
            --secondary: #D32F2F;
            --secondary-light: #FEF2F2;
            --accent: #F5B042;
            --accent-light: #FFFBEB;
            --success: #059669;
            --success-light: #ECFDF5;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --radius-2xl: 2rem;
        }

        /* ============================================================
           SIDEBAR
           ============================================================ */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 2px;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .submenu-item.active i { color: var(--accent); }
        
        /* ============================================================
           MAIN CONTENT
           ============================================================ */
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }

        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 {
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px;
            height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }

        /* ============================================================
           HERO PROFILE CARD
           ============================================================ */
        .profile-hero {
            background: linear-gradient(135deg, #1E4A8C 0%, #0A2F6C 50%, #1E4A8C 100%);
            border-radius: var(--radius-2xl);
            padding: 40px 32px;
            margin-bottom: 24px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 40px -12px rgba(30, 74, 140, 0.35);
        }
        .profile-hero::before {
            content: '';
            position: absolute;
            top: -60%;
            right: -10%;
            width: 500px;
            height: 500px;
            background: radial-gradient(circle, rgba(245, 176, 66, 0.15) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .profile-hero::after {
            content: '';
            position: absolute;
            bottom: -40%;
            left: -10%;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.08) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .profile-hero .hero-content {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 28px;
            flex-wrap: wrap;
        }
        .profile-hero .hero-avatar {
            width: 110px;
            height: 110px;
            background: linear-gradient(135deg, #F5B042, #FCD34D);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 4px solid rgba(255, 255, 255, 0.25);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.25);
            flex-shrink: 0;
            position: relative;
        }
        .profile-hero .hero-avatar i {
            font-size: 3.2rem;
            color: #1E4A8C;
        }
        .profile-hero .hero-avatar .status-dot-large {
            position: absolute;
            bottom: 8px;
            right: 8px;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 3px solid #1E4A8C;
            background: #34D399;
            box-shadow: 0 0 12px rgba(52, 211, 153, 0.6);
        }
        .profile-hero .hero-avatar .status-dot-large.inactive {
            background: #F87171;
            box-shadow: 0 0 12px rgba(248, 113, 113, 0.6);
        }
        .profile-hero .hero-info {
            flex: 1;
            min-width: 250px;
        }
        .profile-hero .hero-info h2 {
            font-size: 1.8rem;
            font-weight: 800;
            color: white;
            letter-spacing: -0.02em;
            margin-bottom: 6px;
        }
        .profile-hero .hero-info .hero-designation {
            font-size: 0.95rem;
            color: rgba(255, 255, 255, 0.75);
            font-weight: 500;
            margin-bottom: 14px;
        }
        .profile-hero .hero-badges {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        .profile-hero .hero-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            font-size: 0.72rem;
            font-weight: 600;
            color: white;
            transition: all 0.3s;
        }
        .profile-hero .hero-chip:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }
        .profile-hero .hero-chip i { color: var(--accent); font-size: 0.75rem; }
        .profile-hero .hero-chip.success i { color: #34D399; }
        .profile-hero .hero-chip.danger i { color: #F87171; }
        .profile-hero .hero-chip.info i { color: #60A5FA; }
        
        .profile-hero .hero-actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-left: auto;
        }
        .profile-hero .hero-action-btn {
            padding: 12px 24px;
            border-radius: var(--radius-md);
            border: 1px solid rgba(255, 255, 255, 0.25);
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(8px);
            color: white;
            font-size: 0.8rem;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
            white-space: nowrap;
        }
        .profile-hero .hero-action-btn:hover {
            background: rgba(255, 255, 255, 0.22);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
        .profile-hero .hero-action-btn i { color: var(--accent); font-size: 0.9rem; }

        /* ============================================================
           STATUS BANNER - Quick info row
           ============================================================ */
        .status-strip {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .status-strip-item {
            background: var(--white);
            padding: 16px 20px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            gap: 14px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: var(--shadow-sm);
            position: relative;
            overflow: hidden;
        }
        .status-strip-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: var(--primary);
            transition: width 0.3s;
        }
        .status-strip-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
        }
        .status-strip-item:hover::before { width: 6px; }
        .status-strip-item.success::before { background: var(--success); }
        .status-strip-item.danger::before { background: var(--secondary); }
        .status-strip-item.accent::before { background: var(--accent); }
        .status-strip-item .strip-icon {
            width: 42px;
            height: 42px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .status-strip-item .strip-icon.primary { background: var(--primary-light); color: var(--primary); }
        .status-strip-item .strip-icon.success { background: var(--success-light); color: var(--success); }
        .status-strip-item .strip-icon.danger { background: var(--secondary-light); color: var(--secondary); }
        .status-strip-item .strip-icon.accent { background: var(--accent-light); color: #B45309; }
        .status-strip-item .strip-content .strip-label {
            font-size: 0.65rem;
            color: var(--gray-500);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 2px;
        }
        .status-strip-item .strip-content .strip-value {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--gray-800);
        }
        .status-strip-item .strip-content .strip-value.online { color: var(--success); }
        .status-strip-item .strip-content .strip-value.offline { color: var(--secondary); }

        /* ============================================================
           STAT CARDS ROW
           ============================================================ */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card-modern {
            background: var(--white);
            padding: 20px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            text-align: center;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .stat-card-modern::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), #3B82F6);
        }
        .stat-card-modern:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-xl);
            border-color: transparent;
        }
        .stat-card-modern .stat-ico {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 12px;
            font-size: 1.2rem;
            transition: transform 0.3s;
        }
        .stat-card-modern:hover .stat-ico { transform: scale(1.15) rotate(-5deg); }
        .stat-card-modern .stat-num {
            font-size: 1.7rem;
            font-weight: 800;
            color: var(--gray-800);
            letter-spacing: -0.03em;
            line-height: 1;
            margin-bottom: 6px;
        }
        .stat-card-modern .stat-lbl {
            font-size: 0.65rem;
            color: var(--gray-500);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .stat-card-modern.pending::before { background: linear-gradient(90deg, #F5B042, #FCD34D); }
        .stat-card-modern.pending .stat-ico { background: var(--accent-light); color: #B45309; }
        .stat-card-modern.pending .stat-num { color: #B45309; }
        .stat-card-modern.processed::before { background: linear-gradient(90deg, #1E4A8C, #3B82F6); }
        .stat-card-modern.processed .stat-ico { background: var(--primary-light); color: var(--primary); }
        .stat-card-modern.processed .stat-num { color: var(--primary); }
        .stat-card-modern.synced::before { background: linear-gradient(90deg, #059669, #34D399); }
        .stat-card-modern.synced .stat-ico { background: var(--success-light); color: var(--success); }
        .stat-card-modern.synced .stat-num { color: var(--success); }
        .stat-card-modern.failed::before { background: linear-gradient(90deg, #D32F2F, #F87171); }
        .stat-card-modern.failed .stat-ico { background: var(--secondary-light); color: var(--secondary); }
        .stat-card-modern.failed .stat-num { color: var(--secondary); }
        .stat-card-modern.mobile::before { background: linear-gradient(90deg, #0891B2, #22D3EE); }
        .stat-card-modern.mobile .stat-ico { background: #ECFEFF; color: #0891B2; }
        .stat-card-modern.mobile .stat-num { color: #0891B2; font-size: 1.1rem; }

        /* ============================================================
           SECTION CARDS
           ============================================================ */
        .section-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            margin-bottom: 24px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: box-shadow 0.3s;
        }
        .section-card:hover { box-shadow: var(--shadow-lg); }
        .section-header {
            padding: 18px 24px;
            background: linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%);
            border-bottom: 2px solid var(--accent);
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .section-header .section-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--accent);
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .section-header h3 {
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
            letter-spacing: -0.01em;
        }
        .section-header .section-badge {
            margin-left: auto;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .section-badge.info { background: var(--primary-light); color: var(--primary); }
        .section-badge.success { background: var(--success-light); color: var(--success); }
        .section-badge.danger { background: var(--secondary-light); color: var(--secondary); }
        .section-badge.accent { background: var(--accent-light); color: #B45309; }
        .section-body { padding: 24px; }

        /* ============================================================
           INFO GRID
           ============================================================ */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 14px;
        }
        .info-tile {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 16px;
            background: var(--gray-50);
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-100);
            transition: all 0.25s;
            position: relative;
            overflow: hidden;
        }
        .info-tile::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 3px;
            height: 100%;
            background: var(--primary);
            transform: scaleY(0);
            transition: transform 0.25s;
        }
        .info-tile:hover {
            background: var(--primary-light);
            border-color: rgba(30, 74, 140, 0.15);
            transform: translateX(4px);
        }
        .info-tile:hover::after { transform: scaleY(1); }
        .info-tile .tile-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--white);
            color: var(--primary);
            box-shadow: var(--shadow-sm);
            flex-shrink: 0;
            font-size: 0.95rem;
        }
        .info-tile .tile-content { min-width: 0; flex: 1; }
        .info-tile .tile-label {
            font-size: 0.63rem;
            color: var(--gray-500);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 3px;
        }
        .info-tile .tile-value {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--gray-800);
            word-break: break-word;
        }

        /* ============================================================
           PERMISSIONS GRID
           ============================================================ */
        .permissions-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
        .permission-chip {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: var(--gray-50);
            border-radius: var(--radius-md);
            border: 1px solid var(--gray-100);
            font-size: 0.78rem;
            font-weight: 500;
            color: var(--gray-700);
            transition: all 0.2s;
        }
        .permission-chip:hover { background: var(--gray-100); }
        .permission-chip.granted {
            background: var(--success-light);
            border-color: rgba(5, 150, 105, 0.15);
            color: #065F46;
        }
        .permission-chip.denied {
            background: var(--secondary-light);
            border-color: rgba(211, 47, 47, 0.15);
            color: #991B1B;
        }
        .permission-chip .chip-check {
            width: 22px;
            height: 22px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.65rem;
            flex-shrink: 0;
        }
        .permission-chip.granted .chip-check { background: var(--success); color: white; }
        .permission-chip.denied .chip-check { background: var(--secondary); color: white; }

        /* ============================================================
           FORM STYLING
           ============================================================ */
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.72rem;
            font-weight: 700;
            color: var(--gray-600);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }
        .form-group label i { color: var(--accent); font-size: 0.75rem; }
        .form-group label .required { color: var(--secondary); }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s;
            background: var(--gray-50);
            color: var(--gray-800);
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
            background: white;
        }
        .form-group .helper-text {
            font-size: 0.68rem;
            color: var(--gray-500);
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .form-group .helper-text i { color: var(--primary); font-size: 0.6rem; }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            font-size: 0.82rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.25s;
            border: none;
            font-family: inherit;
            text-decoration: none;
            letter-spacing: 0.02em;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12); }
        .btn:active { transform: translateY(0); }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .btn-primary:hover { box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-success {
            background: linear-gradient(135deg, #059669, #047857);
            color: white;
            box-shadow: 0 4px 12px rgba(5, 150, 105, 0.25);
        }
        .btn-success:hover { box-shadow: 0 8px 20px rgba(5, 150, 105, 0.35); }
        .btn-danger {
            background: linear-gradient(135deg, #D32F2F, #B71C1C);
            color: white;
            box-shadow: 0 4px 12px rgba(211, 47, 47, 0.25);
        }
        .btn-danger:hover { box-shadow: 0 8px 20px rgba(211, 47, 47, 0.35); }
        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }
        .btn-secondary:hover { background: var(--gray-200); }
        .btn-block { width: 100%; }
        .btn-sm { padding: 8px 16px; font-size: 0.72rem; }

        /* ============================================================
           ALERTS
           ============================================================ */
        .alert {
            padding: 14px 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            font-size: 0.82rem;
            font-weight: 500;
            border-left: 4px solid;
        }
        .alert i { font-size: 1rem; margin-top: 1px; flex-shrink: 0; }
        .alert-success { background: var(--success-light); border-color: var(--success); color: #065F46; }
        .alert-success i { color: var(--success); }
        .alert-danger { background: var(--secondary-light); border-color: var(--secondary); color: #991B1B; }
        .alert-danger i { color: var(--secondary); }
        .alert-info { background: var(--primary-light); border-color: var(--primary); color: var(--primary); }
        .alert-info i { color: var(--primary); }
        .alert-warning { background: var(--accent-light); border-color: var(--accent); color: #7B5E2A; }
        .alert-warning i { color: #B45309; }

        /* ============================================================
           SYNC QUEUE TABLE
           ============================================================ */
        .sync-table-container {
            overflow-x: auto;
            border-radius: var(--radius-md);
            border: 1px solid var(--gray-200);
        }
        .sync-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.78rem;
            min-width: 500px;
        }
        .sync-table th {
            text-align: left;
            padding: 12px 16px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            color: var(--gray-600);
            border-bottom: 2px solid var(--accent);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 0.65rem;
        }
        .sync-table td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .sync-table tr:hover td { background: var(--primary-light); }
        .sync-table tr:last-child td { border-bottom: none; }
        .sync-method {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.62rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .sync-method.POST { background: #DBEAFE; color: #1E40AF; }
        .sync-method.PUT { background: #FEF3C7; color: #B45309; }
        .sync-method.PATCH { background: #D1FAE5; color: #065F46; }
        .sync-method.DELETE { background: #FEE2E2; color: #991B1B; }
        .sync-status-pill {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 700;
        }
        .sync-status-pill.pending { background: var(--accent-light); color: #B45309; }
        .sync-status-pill.failed { background: var(--secondary-light); color: #991B1B; }

        /* ============================================================
           ARCHITECTURE GRID
           ============================================================ */
        .arch-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
            margin-bottom: 16px;
        }
        .arch-card {
            padding: 20px 16px;
            border-radius: var(--radius-lg);
            text-align: center;
            transition: all 0.3s;
            border: 1px solid var(--gray-100);
            background: var(--gray-50);
            position: relative;
            overflow: hidden;
        }
        .arch-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            transition: opacity 0.3s;
        }
        .arch-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            background: white;
        }
        .arch-card:hover::before { opacity: 1; }
        .arch-card .arch-icon {
            width: 52px;
            height: 52px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 12px;
            font-size: 1.3rem;
            transition: transform 0.3s;
        }
        .arch-card:hover .arch-icon { transform: scale(1.15) rotate(-8deg); }
        .arch-card .arch-title {
            font-size: 0.65rem;
            color: var(--gray-500);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 4px;
        }
        .arch-card .arch-desc {
            font-size: 0.78rem;
            font-weight: 700;
            color: var(--gray-800);
        }
        .arch-card.storage::before { background: linear-gradient(90deg, #1E4A8C, #3B82F6); }
        .arch-card.storage .arch-icon { background: var(--primary-light); color: var(--primary); }
        .arch-card.sync::before { background: linear-gradient(90deg, #059669, #34D399); }
        .arch-card.sync .arch-icon { background: var(--success-light); color: var(--success); }
        .arch-card.conflict::before { background: linear-gradient(90deg, #D32F2F, #F87171); }
        .arch-card.conflict .arch-icon { background: var(--secondary-light); color: var(--secondary); }
        .arch-card.biometric::before { background: linear-gradient(90deg, #0891B2, #22D3EE); }
        .arch-card.biometric .arch-icon { background: #ECFEFF; color: #0891B2; }

        /* ============================================================
           SECURITY RULES GRID
           ============================================================ */
        .rules-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 16px;
        }
        .rule-card {
            padding: 16px 18px;
            border-radius: var(--radius-lg);
            border-left: 4px solid;
            background: var(--gray-50);
            transition: all 0.25s;
        }
        .rule-card:hover { transform: translateX(4px); }
        .rule-card .rule-title {
            font-weight: 700;
            font-size: 0.82rem;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 4px;
        }
        .rule-card .rule-desc {
            font-size: 0.72rem;
            color: var(--gray-600);
            line-height: 1.4;
        }
        .rule-card.blue { border-color: var(--primary); background: var(--primary-light); }
        .rule-card.blue .rule-title { color: var(--primary); }
        .rule-card.amber { border-color: var(--accent); background: var(--accent-light); }
        .rule-card.amber .rule-title { color: #B45309; }
        .rule-card.green { border-color: var(--success); background: var(--success-light); }
        .rule-card.green .rule-title { color: var(--success); }
        .rule-card.red { border-color: var(--secondary); background: var(--secondary-light); }
        .rule-card.red .rule-title { color: var(--secondary); }

        /* ============================================================
           MOBILE SESSION CARD
           ============================================================ */
        .session-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            margin-bottom: 24px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: box-shadow 0.3s;
        }
        .session-card:hover { box-shadow: var(--shadow-lg); }
        .session-card .session-header-row {
            padding: 18px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 14px;
            background: linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%);
            border-bottom: 1px solid var(--gray-200);
        }
        .session-card .session-status-block {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .session-card .session-status-dot {
            width: 14px;
            height: 14px;
            border-radius: 50%;
            position: relative;
        }
        .session-card .session-status-dot.active {
            background: var(--success);
            box-shadow: 0 0 0 4px rgba(5, 150, 105, 0.15);
        }
        .session-card .session-status-dot.inactive {
            background: var(--secondary);
            box-shadow: 0 0 0 4px rgba(211, 47, 47, 0.15);
        }
        .session-card .session-status-dot.active::after {
            content: '';
            position: absolute;
            inset: -4px;
            border-radius: 50%;
            border: 2px solid var(--success);
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            100% { transform: scale(1.8); opacity: 0; }
        }
        .session-card .session-status-text .session-title {
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--gray-800);
        }
        .session-card .session-status-text .session-subtitle {
            font-size: 0.72rem;
            color: var(--gray-500);
            margin-top: 2px;
        }
        .session-card .session-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* ============================================================
           BOTTOM NAV
           ============================================================ */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-decoration: none;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: var(--primary-light); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        /* ============================================================
           MODAL
           ============================================================ */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            z-index: 1100;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 520px;
            width: 100%;
            padding: 0;
            max-height: 88vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.4);
            animation: modalIn 0.3s ease;
        }
        @keyframes modalIn {
            from { opacity: 0; transform: scale(0.95) translateY(20px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .modal-header {
            padding: 20px 24px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-xl) var(--radius-xl) 0 0;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .modal-header .modal-icon {
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--accent);
            flex-shrink: 0;
        }
        .modal-header h3 {
            color: white;
            font-size: 1rem;
            font-weight: 700;
            letter-spacing: -0.01em;
        }
        .modal-header p {
            color: rgba(255, 255, 255, 0.75);
            font-size: 0.72rem;
            margin-top: 2px;
        }
        .modal-body { padding: 24px; }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid var(--gray-200);
        }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 992px) {
            .status-strip { grid-template-columns: repeat(2, 1fr); }
            .stats-row { grid-template-columns: repeat(3, 1fr); }
            .arch-grid { grid-template-columns: repeat(2, 1fr); }
            .profile-hero .hero-actions { margin-left: 0; flex-direction: row; flex-wrap: wrap; }
        }
        @media (max-width: 768px) {
            .profile-hero { padding: 28px 20px; }
            .profile-hero .hero-info h2 { font-size: 1.4rem; }
            .profile-hero .hero-avatar { width: 88px; height: 88px; }
            .profile-hero .hero-avatar i { font-size: 2.4rem; }
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .info-grid { grid-template-columns: 1fr; }
            .permissions-grid { grid-template-columns: 1fr; }
            .rules-grid { grid-template-columns: 1fr; }
            .status-strip { grid-template-columns: 1fr; }
            .top-bar { flex-wrap: wrap; gap: 12px; }
            .page-title h1 { font-size: 1.1rem; }
            .page-title p { display: none; }
        }
        @media (max-width: 480px) {
            .stats-row { grid-template-columns: 1fr; }
            .arch-grid { grid-template-columns: 1fr; }
        }

        /* ============================================================
           ANIMATIONS
           ============================================================ */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-in {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
        }
        .animate-in.delay-1 { animation-delay: 0.05s; }
        .animate-in.delay-2 { animation-delay: 0.1s; }
        .animate-in.delay-3 { animation-delay: 0.15s; }
        .animate-in.delay-4 { animation-delay: 0.2s; }
        .animate-in.delay-5 { animation-delay: 0.25s; }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="mswdstaff_communityservice.php" class="nav-item">
                    <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
                </a>
                <a href="household.php" class="nav-item">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Applications</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="mswdstaff_idapplication.php" class="nav-item">
                    <i class="fas fa-id-card"></i> <span>ID Applications</span>
                </a>
                <a href="staff_eligibility_engine.php" class="nav-item">
                    <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="mswdstaff_profile.php" class="nav-item active">
                    <i class="fas fa-user-circle"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Staff Profile</h1>
                <p>Manage your account, security, and mobile access</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- ============================================================
             HERO PROFILE CARD
             ============================================================ -->
        <div class="profile-hero animate-in">
            <div class="hero-content">
                <div class="hero-avatar">
                    <i class="fas <?php echo getRoleIcon($role); ?>"></i>
                    <span class="status-dot-large <?php echo $mobile_session_active ? '' : 'inactive'; ?>"></span>
                </div>
                <div class="hero-info">
                    <h2><?php echo htmlspecialchars($user_data['full_name'] ?? $full_name); ?></h2>
                    <div class="hero-designation">
                        <i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($user_data['designation_title'] ?? getRoleDisplay($role)); ?>
                    </div>
                    <div class="hero-badges">
                        <span class="hero-chip"><i class="fas fa-id-badge"></i> <?php echo strtoupper(str_replace('_', ' ', $role)); ?></span>
                        <span class="hero-chip"><i class="fas fa-building"></i> <?php echo str_replace('_', ' ', htmlspecialchars($user_data['assigned_office'] ?? 'MSWDO Main')); ?></span>
                        <?php if($device_registered): ?>
                        <span class="hero-chip success"><i class="fas fa-check-circle"></i> Device Registered</span>
                        <?php else: ?>
                        <span class="hero-chip danger"><i class="fas fa-exclamation-triangle"></i> No Device</span>
                        <?php endif; ?>
                        <?php if($mobile_session_active): ?>
                        <span class="hero-chip info"><i class="fas fa-lock-open"></i> Session Active</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="hero-actions">
                    <button class="hero-action-btn" onclick="openStatusModal()">
                        <i class="fas fa-sync-alt"></i> Update Status
                    </button>
                    <button class="hero-action-btn" onclick="openSessionRefreshModal()">
                        <i class="fas fa-fingerprint"></i> Refresh Session
                    </button>
                </div>
            </div>
        </div>

        <!-- ============================================================
             STATUS STRIP
             ============================================================ -->
        <div class="status-strip">
            <div class="status-strip-item animate-in delay-1">
                <div class="strip-icon primary"><i class="fas fa-circle"></i></div>
                <div class="strip-content">
                    <div class="strip-label">Operational Status</div>
                    <div class="strip-value">
                        <span class="status-badge <?php echo getStatusClass($user_data['operational_status'] ?? 'AVAILABLE'); ?>" style="padding: 3px 12px; font-size: 0.7rem;">
                            <?php echo getStatusLabel($user_data['operational_status'] ?? 'AVAILABLE'); ?>
                        </span>
                    </div>
                </div>
            </div>
            <div class="status-strip-item success animate-in delay-2">
                <div class="strip-icon success"><i class="fas fa-map-marker-alt"></i></div>
                <div class="strip-content">
                    <div class="strip-label">Assigned Zone</div>
                    <div class="strip-value"><?php echo htmlspecialchars($user_data['current_assigned_zone'] ?? 'Not Assigned'); ?></div>
                </div>
            </div>
            <div class="status-strip-item <?php echo $device_registered ? 'success' : 'accent'; ?> animate-in delay-3">
                <div class="strip-icon <?php echo $device_registered ? 'success' : 'accent'; ?>"><i class="fas fa-mobile-alt"></i></div>
                <div class="strip-content">
                    <div class="strip-label">Device</div>
                    <div class="strip-value <?php echo $device_registered ? 'online' : ''; ?>">
                        <?php echo $device_registered ? 'Registered' : 'Not Registered'; ?>
                    </div>
                </div>
            </div>
            <div class="status-strip-item <?php echo $mobile_session_active ? 'success' : 'danger'; ?> animate-in delay-4">
                <div class="strip-icon <?php echo $mobile_session_active ? 'success' : 'danger'; ?>"><i class="fas fa-lock"></i></div>
                <div class="strip-content">
                    <div class="strip-label">Mobile Session</div>
                    <div class="strip-value <?php echo $mobile_session_active ? 'online' : 'offline'; ?>">
                        <?php echo $mobile_session_active ? 'Active' : 'Inactive'; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================================
             STAT CARDS
             ============================================================ -->
        <div class="stats-row">
            <div class="stat-card-modern pending animate-in delay-1">
                <div class="stat-ico"><i class="fas fa-clock"></i></div>
                <div class="stat-num"><?php echo $pending_applications; ?></div>
                <div class="stat-lbl">Pending Apps</div>
            </div>
            <div class="stat-card-modern processed animate-in delay-2">
                <div class="stat-ico"><i class="fas fa-check-double"></i></div>
                <div class="stat-num"><?php echo $total_processed; ?></div>
                <div class="stat-lbl">Processed</div>
            </div>
            <div class="stat-card-modern synced animate-in delay-3">
                <div class="stat-ico"><i class="fas fa-cloud-upload-alt"></i></div>
                <div class="stat-num"><?php echo $sync_stats['synced']; ?></div>
                <div class="stat-lbl">Synced</div>
            </div>
            <div class="stat-card-modern failed animate-in delay-4">
                <div class="stat-ico"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-num"><?php echo $sync_stats['pending']; ?></div>
                <div class="stat-lbl">Pending Sync</div>
            </div>
            <div class="stat-card-modern mobile animate-in delay-5">
                <div class="stat-ico"><i class="fas fa-mobile-alt"></i></div>
                <div class="stat-num"><?php echo $mobile_session_active ? 'Active' : 'Offline'; ?></div>
                <div class="stat-lbl">Mobile Status</div>
            </div>
        </div>

        <!-- ============================================================
             MOBILE SESSION CARD
             ============================================================ -->
        <?php if($has_mobile_access): ?>
        <div class="session-card animate-in">
            <div class="session-header-row">
                <div class="session-status-block">
                    <div class="session-status-dot <?php echo $mobile_session_active ? 'active' : 'inactive'; ?>"></div>
                    <div class="session-status-text">
                        <div class="session-title">
                            <?php echo $mobile_session_active ? 'Mobile Session Active' : 'Mobile Session Inactive'; ?>
                        </div>
                        <div class="session-subtitle">
                            <?php if($last_mobile_login): ?>
                                <i class="fas fa-history"></i> Last login: <?php echo date('M d, Y h:i A', strtotime($last_mobile_login)); ?>
                            <?php else: ?>
                                <i class="fas fa-info-circle"></i> No mobile session recorded yet
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="session-actions">
                    <?php if($mobile_session_active): ?>
                        <a href="?logout_mobile=1" class="btn btn-danger btn-sm" onclick="return confirm('Logout mobile session?')">
                            <i class="fas fa-sign-out-alt"></i> Logout Mobile
                        </a>
                    <?php else: ?>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="mobile_login" value="1">
                            <button type="submit" class="btn btn-success btn-sm">
                                <i class="fas fa-mobile-alt"></i> Login Mobile
                            </button>
                        </form>
                    <?php endif; ?>
                    <button class="btn btn-primary btn-sm" onclick="openSessionRefreshModal()">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                </div>
            </div>
            <?php if(isset($mobile_login_success)): ?>
                <div class="alert alert-success" style="margin: 16px 24px 0;">
                    <i class="fas fa-check-circle"></i> <?php echo $mobile_login_success; ?>
                </div>
            <?php endif; ?>
            <?php if(isset($mobile_logout_success)): ?>
                <div class="alert alert-info" style="margin: 16px 24px 0;">
                    <i class="fas fa-info-circle"></i> <?php echo $mobile_logout_success; ?>
                </div>
            <?php endif; ?>
            <?php if(isset($session_success)): ?>
                <div class="alert alert-success" style="margin: 16px 24px 0;">
                    <i class="fas fa-check-circle"></i> <?php echo $session_success; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- ============================================================
             SYNC STATUS CARD
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                <h3>Offline Sync Status</h3>
                <span class="section-badge <?php echo $sync_stats['pending'] > 0 ? 'accent' : 'success'; ?>">
                    <?php if($sync_stats['pending'] > 0): ?>
                        <i class="fas fa-clock"></i> <?php echo $sync_stats['pending']; ?> Pending
                    <?php else: ?>
                        <i class="fas fa-check-circle"></i> All Synced
                    <?php endif; ?>
                </span>
            </div>
            <div class="section-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        Records saved offline are stored locally and automatically synced when internet is available.
                        <?php if($sync_stats['pending'] > 0): ?>
                            <strong><?php echo $sync_stats['pending']; ?> pending records</strong> waiting to sync.
                        <?php endif; ?>
                        <?php if($sync_stats['failed'] > 0): ?>
                            <br><strong style="color: #D32F2F;"><i class="fas fa-exclamation-triangle"></i> <?php echo $sync_stats['failed']; ?> records failed after multiple attempts.</strong>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if(count($pending_sync_records) > 0): ?>
                <div class="sync-table-container">
                    <table class="sync-table">
                        <thead>
                            <tr>
                                <th>Endpoint</th>
                                <th>Method</th>
                                <th>Created</th>
                                <th>Attempts</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($pending_sync_records as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars(substr($record['endpoint_route'], 0, 30) . (strlen($record['endpoint_route']) > 30 ? '...' : '')); ?></td>
                                <td><span class="sync-method <?php echo $record['http_method']; ?>"><?php echo $record['http_method']; ?></span></td>
                                <td><?php echo date('M d, H:i', strtotime($record['timestamp_created'])); ?></td>
                                <td><?php echo $record['sync_attempts']; ?></td>
                                <td>
                                    <?php if($record['sync_attempts'] > 3): ?>
                                        <span class="sync-status-pill failed"><i class="fas fa-times-circle"></i> Failed</span>
                                    <?php else: ?>
                                        <span class="sync-status-pill pending"><i class="fas fa-clock"></i> Pending</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div style="text-align: center; padding: 32px 20px; background: var(--gray-50); border-radius: var(--radius-lg);">
                    <div style="width: 60px; height: 60px; background: var(--success-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px;">
                        <i class="fas fa-check-circle" style="color: var(--success); font-size: 1.5rem;"></i>
                    </div>
                    <p style="color: var(--gray-600); font-size: 0.85rem; font-weight: 600;">No pending sync records</p>
                    <p style="color: var(--gray-400); font-size: 0.72rem; margin-top: 4px;">All your data is up to date</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ============================================================
             ACCOUNT INFORMATION
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-info-circle"></i></div>
                <h3>Account Information</h3>
                <span class="section-badge info"><i class="fas fa-user"></i> Personal</span>
            </div>
            <div class="section-body">
                <div class="info-grid">
                    <div class="info-tile">
                        <div class="tile-icon"><i class="fas fa-user"></i></div>
                        <div class="tile-content">
                            <div class="tile-label">Username</div>
                            <div class="tile-value"><?php echo htmlspecialchars($user_data['username'] ?? ''); ?></div>
                        </div>
                    </div>
                    <div class="info-tile">
                        <div class="tile-icon"><i class="fas fa-calendar-plus"></i></div>
                        <div class="tile-content">
                            <div class="tile-label">Member Since</div>
                            <div class="tile-value"><?php echo date('F d, Y', strtotime($user_data['created_at'] ?? date('Y-m-d'))); ?></div>
                        </div>
                    </div>
                    <div class="info-tile">
                        <div class="tile-icon"><i class="fas fa-envelope"></i></div>
                        <div class="tile-content">
                            <div class="tile-label">Email</div>
                            <div class="tile-value"><?php echo htmlspecialchars($user_data['email'] ?? 'Not set'); ?></div>
                        </div>
                    </div>
                    <div class="info-tile">
                        <div class="tile-icon"><i class="fas fa-phone"></i></div>
                        <div class="tile-content">
                            <div class="tile-label">Contact Number</div>
                            <div class="tile-value"><?php echo htmlspecialchars($user_data['contact_number'] ?? 'Not set'); ?></div>
                        </div>
                    </div>
                    <div class="info-tile">
                        <div class="tile-icon"><i class="fas fa-building"></i></div>
                        <div class="tile-content">
                            <div class="tile-label">Assigned Office</div>
                            <div class="tile-value"><?php echo str_replace('_', ' ', htmlspecialchars($user_data['assigned_office'] ?? 'MSWDO Main Office')); ?></div>
                        </div>
                    </div>
                    <?php if($device_registered): ?>
                    <div class="info-tile">
                        <div class="tile-icon"><i class="fas fa-mobile-alt"></i></div>
                        <div class="tile-content">
                            <div class="tile-label">Device Model</div>
                            <div class="tile-value"><?php echo htmlspecialchars($user_data['device_model'] ?? 'Unknown'); ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($last_mobile_login): ?>
                    <div class="info-tile">
                        <div class="tile-icon"><i class="fas fa-clock"></i></div>
                        <div class="tile-content">
                            <div class="tile-label">Last Mobile Login</div>
                            <div class="tile-value"><?php echo date('M d, Y h:i A', strtotime($last_mobile_login)); ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ============================================================
             SECURITY CLEARANCES
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-shield-alt"></i></div>
                <h3>Security Clearances</h3>
                <span class="section-badge success">
                    <i class="fas fa-check-circle"></i> <?php echo count(array_filter($permissions)); ?>/<?php echo count($permissions); ?> Granted
                </span>
            </div>
            <div class="section-body">
                <div class="permissions-grid">
                    <?php foreach($permissions as $key => $value): ?>
                    <div class="permission-chip <?php echo $value ? 'granted' : 'denied'; ?>">
                        <div class="chip-check">
                            <i class="fas <?php echo $value ? 'fa-check' : 'fa-times'; ?>"></i>
                        </div>
                        <?php echo ucfirst(str_replace('_', ' ', $key)); ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ============================================================
             UPDATE PROFILE FORM
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-edit"></i></div>
                <h3>Update Profile Information</h3>
                <span class="section-badge info"><i class="fas fa-pen"></i> Editable</span>
            </div>
            <div class="section-body">
                <form method="POST">
                    <?php if($success): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if($error): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Full Name <span class="required">*</span></label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user_data['full_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>" placeholder="your.email@example.com">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Contact Number</label>
                        <input type="text" name="contact_number" value="<?php echo htmlspecialchars($user_data['contact_number'] ?? ''); ?>" placeholder="0917-123-4567">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-user-tag"></i> Designation Title</label>
                        <input type="text" name="designation_title" value="<?php echo htmlspecialchars($user_data['designation_title'] ?? ''); ?>" placeholder="e.g., Senior Social Worker">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-building"></i> Assigned Office</label>
                        <select name="assigned_office">
                            <option value="MSWDO_MAIN_OFFICE" <?php echo ($user_data['assigned_office'] ?? '') == 'MSWDO_MAIN_OFFICE' ? 'selected' : ''; ?>>MSWDO Main Office</option>
                            <option value="BARANGAY_CENTER" <?php echo ($user_data['assigned_office'] ?? '') == 'BARANGAY_CENTER' ? 'selected' : ''; ?>>Barangay Center</option>
                            <option value="FIELD_OFFICE" <?php echo ($user_data['assigned_office'] ?? '') == 'FIELD_OFFICE' ? 'selected' : ''; ?>>Field Office</option>
                            <option value="DISTRICT_OFFICE" <?php echo ($user_data['assigned_office'] ?? '') == 'DISTRICT_OFFICE' ? 'selected' : ''; ?>>District Office</option>
                        </select>
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-primary btn-block">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </form>
            </div>
        </div>

        <!-- ============================================================
             DEVICE REGISTRATION
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-mobile-alt"></i></div>
                <h3>Mobile Device Registration</h3>
                <span class="section-badge <?php echo $device_registered ? 'success' : 'accent'; ?>">
                    <?php if($device_registered): ?>
                        <i class="fas fa-check-circle"></i> Registered
                    <?php else: ?>
                        <i class="fas fa-exclamation-triangle"></i> Not Registered
                    <?php endif; ?>
                </span>
            </div>
            <div class="section-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <?php if($device_registered): ?>
                            Your device is already registered. You can re-register if you're using a new device.
                        <?php else: ?>
                            Register your mobile device for secure mobile access and offline sync.
                        <?php endif; ?>
                    </div>
                </div>
                <form method="POST">
                    <?php if(isset($device_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $device_success; ?></div>
                    <?php endif; ?>
                    <?php if(isset($device_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $device_error; ?></div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label><i class="fas fa-qrcode"></i> Device UUID <span class="required">*</span></label>
                        <input type="text" name="device_uuid" placeholder="e.g., 9a3f82c4-7d11-4b2e-a567-8c3d12f45e99" value="<?php echo htmlspecialchars($user_data['device_uuid'] ?? ''); ?>" required>
                        <div class="helper-text"><i class="fas fa-info-circle"></i> Unique device identifier from your mobile app</div>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-mobile-alt"></i> Device Model</label>
                        <input type="text" name="device_model" placeholder="e.g., Samsung Galaxy S24 Ultra" value="<?php echo htmlspecialchars($user_data['device_model'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-code"></i> App Version</label>
                        <input type="text" name="app_version" placeholder="e.g., v2.4.1" value="<?php echo htmlspecialchars($user_data['app_version'] ?? 'v2.4.1'); ?>">
                    </div>
                    <button type="submit" name="register_device" class="btn btn-success btn-block">
                        <i class="fas fa-check"></i> Register Device
                    </button>
                </form>
            </div>
        </div>

        <!-- ============================================================
             CHANGE PASSWORD
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-key"></i></div>
                <h3>Change Password</h3>
                <span class="section-badge danger"><i class="fas fa-lock"></i> Security</span>
            </div>
            <div class="section-body">
                <form method="POST">
                    <?php if(isset($password_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $password_success; ?></div>
                    <?php endif; ?>
                    <?php if(isset($password_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $password_error; ?></div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Current Password <span class="required">*</span></label>
                        <input type="password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-key"></i> New Password <span class="required">*</span></label>
                        <input type="password" name="new_password" required>
                        <div class="helper-text"><i class="fas fa-info-circle"></i> Minimum 6 characters</div>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-check-circle"></i> Confirm New Password <span class="required">*</span></label>
                        <input type="password" name="confirm_password" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-secondary btn-block">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </form>
            </div>
        </div>

        <!-- ============================================================
             SYNC ARCHITECTURE
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-layer-group"></i></div>
                <h3>Mobile Offline Sync Architecture</h3>
                <span class="section-badge info"><i class="fas fa-cogs"></i> System</span>
            </div>
            <div class="section-body">
                <div class="arch-grid">
                    <div class="arch-card storage">
                        <div class="arch-icon"><i class="fas fa-mobile-alt"></i></div>
                        <div class="arch-title">Local Storage</div>
                        <div class="arch-desc">SQLite Queue</div>
                    </div>
                    <div class="arch-card sync">
                        <div class="arch-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                        <div class="arch-title">Auto Sync</div>
                        <div class="arch-desc">Background Engine</div>
                    </div>
                    <div class="arch-card conflict">
                        <div class="arch-icon"><i class="fas fa-shield-alt"></i></div>
                        <div class="arch-title">Conflict Resolution</div>
                        <div class="arch-desc">Idempotency Keys</div>
                    </div>
                    <div class="arch-card biometric">
                        <div class="arch-icon"><i class="fas fa-fingerprint"></i></div>
                        <div class="arch-title">Biometric Auth</div>
                        <div class="arch-desc">PIN / Session Refresh</div>
                    </div>
                </div>
                <div class="alert alert-warning">
                    <i class="fas fa-lightbulb"></i>
                    <div>
                        <strong>How it works:</strong> When offline, data is saved to your device's local storage.
                        Once internet is restored, the system automatically syncs all pending records.
                        Each transaction has a unique ID to prevent duplicate submissions.
                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================================
             SECURITY RULES
             ============================================================ -->
        <div class="section-card animate-in">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-user-shield"></i></div>
                <h3>Mobile Security Rules</h3>
                <span class="section-badge accent"><i class="fas fa-shield-alt"></i> Best Practices</span>
            </div>
            <div class="section-body">
                <div class="rules-grid">
                    <div class="rule-card blue">
                        <div class="rule-title"><i class="fas fa-clock"></i> Session Timeout</div>
                        <div class="rule-desc">Sessions expire after 8 hours of inactivity for security.</div>
                    </div>
                    <div class="rule-card amber">
                        <div class="rule-title"><i class="fas fa-fingerprint"></i> Biometric Auth</div>
                        <div class="rule-desc">Fingerprint / Face ID supported on mobile devices.</div>
                    </div>
                    <div class="rule-card green">
                        <div class="rule-title"><i class="fas fa-cloud"></i> Offline Sync</div>
                        <div class="rule-desc">Auto-sync when internet connection is restored.</div>
                    </div>
                    <div class="rule-card red">
                        <div class="rule-title"><i class="fas fa-lock"></i> Device Binding</div>
                        <div class="rule-desc">Device UUID prevents unauthorized access.</div>
                    </div>
                </div>

                <div class="alert alert-warning">
                    <i class="fas fa-shield-alt"></i>
                    <div>
                        For security purposes, we recommend changing your password regularly and keeping your mobile device registered.
                        <?php if(!$device_registered && $has_mobile_access): ?>
                        <strong style="display: block; margin-top: 6px; color: #D32F2F;">
                            <i class="fas fa-exclamation-triangle"></i> Please register your mobile device to use the mobile app.
                        </strong>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_profile.php" class="nav-item active"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <!-- Modal: Update Operational Status -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-icon"><i class="fas fa-sync-alt"></i></div>
                <div>
                    <h3>Update Operational Status</h3>
                    <p>Update your current work status for field tracking</p>
                </div>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="update_status" value="1">
                    
                    <div class="form-group">
                        <label><i class="fas fa-circle"></i> Operational Status</label>
                        <select name="operational_status">
                            <option value="AVAILABLE" <?php echo ($user_data['operational_status'] ?? 'AVAILABLE') == 'AVAILABLE' ? 'selected' : ''; ?>>🟢 Available</option>
                            <option value="FIELD_DEPLOYMENT" <?php echo ($user_data['operational_status'] ?? '') == 'FIELD_DEPLOYMENT' ? 'selected' : ''; ?>>🔵 Field Deployment</option>
                            <option value="ON_BREAK" <?php echo ($user_data['operational_status'] ?? '') == 'ON_BREAK' ? 'selected' : ''; ?>>🟡 On Break</option>
                            <option value="AWAY" <?php echo ($user_data['operational_status'] ?? '') == 'AWAY' ? 'selected' : ''; ?>>🟠 Away</option>
                            <option value="INACTIVE" <?php echo ($user_data['operational_status'] ?? '') == 'INACTIVE' ? 'selected' : ''; ?>>🔴 Inactive</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Current Assigned Zone</label>
                        <input type="text" name="current_assigned_zone" placeholder="e.g., Barangay Zone 4" value="<?php echo htmlspecialchars($user_data['current_assigned_zone'] ?? ''); ?>">
                        <div class="helper-text"><i class="fas fa-info-circle"></i> Specify your current field location if deployed</div>
                    </div>
                    
                    <div class="modal-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeModal('statusModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Update Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal: Session Refresh -->
    <div id="sessionModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-icon"><i class="fas fa-fingerprint"></i></div>
                <div>
                    <h3>Refresh Mobile Session</h3>
                    <p>Verify identity using biometrics or PIN</p>
                </div>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="refresh_session" value="1">
                    
                    <div class="form-group">
                        <label><i class="fas fa-fingerprint"></i> Biometric Verification</label>
                        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                            <button type="button" class="btn btn-success" onclick="simulateBiometric()">
                                <i class="fas fa-fingerprint"></i> Verify Biometric
                            </button>
                            <span style="font-size: 0.7rem; color: var(--gray-500);">(Simulated for demo)</span>
                        </div>
                        <input type="hidden" name="biometric_verification_passed" id="biometricPassed" value="0">
                        <div class="helper-text"><i class="fas fa-info-circle"></i> Use fingerprint or Face ID on mobile devices</div>
                    </div>
                    
                    <div style="text-align: center; color: var(--gray-400); margin: 16px 0; font-size: 0.75rem; font-weight: 600;">— OR —</div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Secure PIN</label>
                        <input type="password" name="secure_pin" placeholder="Enter 6-digit PIN" maxlength="6" pattern="[0-9]{6}">
                        <div class="helper-text"><i class="fas fa-info-circle"></i> Enter your 6-digit security PIN</div>
                    </div>
                    
                    <div class="modal-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeModal('sessionModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-sync-alt"></i> Refresh Session</button>
                    </div>
                </form>
                <div class="alert alert-warning" style="margin-top: 16px; margin-bottom: 0;">
                    <i class="fas fa-clock"></i> Session will be extended for 8 hours
                </div>
            </div>
        </div>
    </div>

    <script>
        // Sidebar toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        if(menuToggle) {
            menuToggle.addEventListener('click', function() {
                sidebar.classList.toggle('open');
                overlay.classList.toggle('active');
            });
        }
        
        if(overlay) {
            overlay.addEventListener('click', function() {
                sidebar.classList.remove('open');
                overlay.classList.remove('active');
            });
        }

        // Collapsible Program Menu
        const programToggle = document.getElementById('programToggle');
        const programSubmenu = document.getElementById('programSubmenu');
        const programIcon = document.getElementById('programIcon');
        
        if(programToggle) {
            programToggle.addEventListener('click', function() {
                programSubmenu.classList.toggle('show');
                programIcon.classList.toggle('rotated');
            });
        }

        // Modal functions
        function openStatusModal() {
            document.getElementById('statusModal').style.display = 'flex';
        }

        function openSessionRefreshModal() {
            document.getElementById('sessionModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        window.onclick = (e) => { 
            if(e.target.classList.contains('modal')) {
                closeModal(e.target.id);
            }
        }

        // Simulate biometric
        function simulateBiometric() {
            const btn = event.target.closest('.btn-success');
            if(btn) {
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
                btn.disabled = true;
                
                setTimeout(() => {
                    btn.innerHTML = '<i class="fas fa-check-circle"></i> Verified!';
                    btn.style.background = 'linear-gradient(135deg, #059669, #047857)';
                    document.getElementById('biometricPassed').value = '1';
                    
                    setTimeout(() => {
                        btn.innerHTML = '<i class="fas fa-fingerprint"></i> Verify Biometric';
                        btn.disabled = false;
                    }, 2000);
                }, 2000);
            }
        }

        // Animate cards on scroll
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if(entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.animate-in').forEach(el => {
            observer.observe(el);
        });

        console.log('✅ Staff Profile loaded with creative design');
        console.log('📱 Mobile Access: <?php echo $has_mobile_access ? 'Enabled' : 'Disabled'; ?>');
        console.log('🔐 Device Registered: <?php echo $device_registered ? 'Yes' : 'No'; ?>');
        console.log('🔄 Session Active: <?php echo $mobile_session_active ? 'Yes' : 'No'; ?>');
        console.log('📊 Pending Sync: <?php echo $sync_stats['pending']; ?> records');
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>