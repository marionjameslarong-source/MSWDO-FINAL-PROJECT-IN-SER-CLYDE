<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$admin_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// ============================================================
// 1. API ENDPOINT HANDLERS - RESTful Commands
// ============================================================

// 1a. GET /api/v1/admin/users - Fetch all users with filters
if(isset($_GET['api']) && $_GET['api'] == 'users') {
    header('Content-Type: application/json');
    
    $role = isset($_GET['role']) ? $_GET['role'] : '';
    $status = isset($_GET['status']) ? $_GET['status'] : '';
    
    $sql = "SELECT id as user_id, username, full_name, email, contact_number, role as role_classification, status as account_status, created_at as last_login_timestamp FROM users WHERE 1=1";
    $params = [];
    
    if($role) {
        $sql .= " AND role = ?";
        $params[] = $role;
    }
    if($status) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
    
    $response = [];
    foreach($users as $user) {
        $response[] = [
            'user_id' => $user['user_id'],
            'username' => $user['username'],
            'full_name' => $user['full_name'],
            'email' => $user['email'],
            'contact_number' => $user['contact_number'],
            'role_classification' => strtoupper(str_replace(' ', '_', $user['role_classification'])),
            'account_status' => strtoupper($user['account_status']),
            'last_login_timestamp' => $user['last_login_timestamp'] ? date('c', strtotime($user['last_login_timestamp'])) : null
        ];
    }
    
    echo json_encode($response);
    exit();
}

// 1b. POST /api/v1/admin/users/provision - Create new staff account
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['api']) && $_POST['api'] == 'provision') {
    header('Content-Type: application/json');
    
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $full_name_user = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contact = trim($_POST['contact_number'] ?? '');
    $role_user = $_POST['role'] ?? 'staff';
    $assigned_office = trim($_POST['assigned_office'] ?? 'MSWDO_MAIN_OFFICE');
    
    $permissions = [
        'can_approve_financial_aid' => isset($_POST['perm_approve_financial']),
        'can_view_vawc_files' => isset($_POST['perm_view_vawc']),
        'can_issue_id_cards' => isset($_POST['perm_issue_id']),
        'can_assess_applications' => isset($_POST['perm_assess_apps']),
        'can_disburse_funds' => isset($_POST['perm_disburse_funds']),
        'can_approve_beneficiaries' => isset($_POST['perm_approve_beneficiaries']),
        'can_offline_sync' => isset($_POST['perm_offline_sync']),
        'can_authorize_verification' => isset($_POST['perm_authorize_verification']),
        'can_manually_trigger_sms' => isset($_POST['perm_manual_sms']),
        'can_scan_qr' => isset($_POST['perm_scan_qr'])
    ];
    
    $errors = [];
    if(empty($username)) $errors[] = "Username is required.";
    if(empty($password)) $errors[] = "Password is required.";
    if(strlen($password) < 6) $errors[] = "Password must be at least 6 characters.";
    if(empty($full_name_user)) $errors[] = "Full name is required.";
    
    if(!empty($errors)) {
        echo json_encode([
            'status' => 'ERROR',
            'code' => 'VALIDATION_FAILED',
            'message' => implode(' ', $errors)
        ]);
        exit();
    }
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if($stmt->fetch()) {
        echo json_encode([
            'status' => 'ERROR',
            'code' => 'USERNAME_EXISTS',
            'message' => 'Username already exists.'
        ]);
        exit();
    }
    
    try {
        $pdo->beginTransaction();
        
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, contact_number, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())");
        $stmt->execute([$username, $hashed, $full_name_user, $email, $contact, $role_user]);
        $new_user_id = $pdo->lastInsertId();
        
        try {
            $stmt = $pdo->prepare("INSERT INTO staff_profiles (user_id, designation_title, assigned_office) VALUES (?, ?, ?)");
            $stmt->execute([$new_user_id, ucfirst($role_user) . ' Officer', $assigned_office]);
        } catch(PDOException $e) {}
        
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'user_permissions'");
            if($stmt->rowCount() > 0) {
                foreach($permissions as $key => $value) {
                    $stmt = $pdo->prepare("INSERT INTO user_permissions (user_id, permission_key, permission_value, assigned_by_admin_id) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$new_user_id, $key, $value ? 1 : 0, $admin_id]);
                }
            }
        } catch(PDOException $e) {}
        
        $pdo->commit();
        
        echo json_encode([
            'status' => 'SUCCESS',
            'message' => 'Staff account provisioned successfully.',
            'user_id' => $new_user_id,
            'username' => $username,
            'role' => $role_user,
            'assigned_office' => $assigned_office,
            'permissions' => $permissions
        ]);
        exit();
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        echo json_encode([
            'status' => 'ERROR',
            'code' => 'DATABASE_ERROR',
            'message' => $e->getMessage()
        ]);
        exit();
    }
}

// 1c. PATCH /api/v1/admin/users/{user_id}/permissions
if(isset($_GET['api']) && $_GET['api'] == 'permissions' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json');
    
    $user_id = $_POST['user_id'] ?? 0;
    $admin_reason = trim($_POST['administrative_reason'] ?? '');
    $target_module = trim($_POST['target_assigned_module'] ?? '');
    
    $permissions = [
        'can_approve_financial_aid' => isset($_POST['perm_approve_financial']),
        'can_view_vawc_files' => isset($_POST['perm_view_vawc']),
        'can_issue_id_cards' => isset($_POST['perm_issue_id']),
        'can_assess_applications' => isset($_POST['perm_assess_apps']),
        'can_disburse_funds' => isset($_POST['perm_disburse_funds']),
        'can_approve_beneficiaries' => isset($_POST['perm_approve_beneficiaries']),
        'can_offline_sync' => isset($_POST['perm_offline_sync']),
        'can_authorize_verification' => isset($_POST['perm_authorize_verification']),
        'can_manually_trigger_sms' => isset($_POST['perm_manual_sms']),
        'can_scan_qr' => isset($_POST['perm_scan_qr'])
    ];
    
    if(!$user_id) {
        echo json_encode(['status' => 'ERROR', 'code' => 'MISSING_USER_ID', 'message' => 'User ID is required.']);
        exit();
    }
    
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'user_permissions'");
        if($stmt->rowCount() > 0) {
            foreach($permissions as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO user_permissions (user_id, permission_key, permission_value, assigned_by_admin_id) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE permission_value = VALUES(permission_value), assigned_by_admin_id = VALUES(assigned_by_admin_id), modified_at = NOW()");
                $stmt->execute([$user_id, $key, $value ? 1 : 0, $admin_id]);
            }
        }
        
        if($target_module) {
            try {
                $stmt = $pdo->prepare("UPDATE staff_profiles SET assigned_office = ? WHERE user_id = ?");
                $stmt->execute([$target_module, $user_id]);
            } catch(PDOException $e) {}
        }
        
        echo json_encode([
            'status' => 'SUCCESS',
            'message' => 'Permissions updated successfully.',
            'modified_by_admin_id' => $admin_id,
            'target_assigned_module' => $target_module,
            'updated_permissions' => $permissions,
            'administrative_reason' => $admin_reason
        ]);
        exit();
        
    } catch(PDOException $e) {
        echo json_encode([
            'status' => 'ERROR',
            'code' => 'DATABASE_ERROR',
            'message' => $e->getMessage()
        ]);
        exit();
    }
}

// 1d. PUT /api/v1/admin/users/{user_id}/suspend
if(isset($_GET['api']) && $_GET['api'] == 'suspend' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json');
    
    $user_id = $_POST['user_id'] ?? 0;
    $suspension_type = $_POST['suspension_type'] ?? 'IMMEDIATE_HARD_LOCKOUT';
    $reason_notes = trim($_POST['reason_notes'] ?? '');
    
    if(!$user_id) {
        echo json_encode(['status' => 'ERROR', 'code' => 'MISSING_USER_ID', 'message' => 'User ID is required.']);
        exit();
    }
    
    if($user_id == $admin_id) {
        echo json_encode(['status' => 'ERROR', 'code' => 'CANNOT_SUSPEND_SELF', 'message' => 'You cannot suspend your own account.']);
        exit();
    }
    
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("UPDATE users SET status = 'suspended', updated_at = NOW() WHERE id = ?");
        $stmt->execute([$user_id]);
        
        try {
            $stmt = $pdo->prepare("UPDATE staff_profiles SET mobile_session_token = NULL, session_expires_at = NULL, active_device_session_fingerprint = NULL, operational_status = 'INACTIVE' WHERE user_id = ?");
            $stmt->execute([$user_id]);
        } catch(PDOException $e) {}
        
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'user_audit_logs'");
            if($stmt->rowCount() > 0) {
                $stmt = $pdo->prepare("INSERT INTO user_audit_logs (admin_id, target_user_id, action_type, action_description, new_data) VALUES (?, ?, 'SUSPEND', ?, ?)");
                $stmt->execute([$admin_id, $user_id, "Account suspended: $suspension_type - $reason_notes", json_encode(['suspension_type' => $suspension_type, 'reason' => $reason_notes])]);
            }
        } catch(PDOException $e) {}
        
        $pdo->commit();
        
        echo json_encode([
            'status' => 'SUCCESS',
            'message' => 'Account suspended successfully.',
            'action_by_admin_id' => $admin_id,
            'suspension_type' => $suspension_type,
            'reason_notes' => $reason_notes
        ]);
        exit();
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        echo json_encode([
            'status' => 'ERROR',
            'code' => 'DATABASE_ERROR',
            'message' => $e->getMessage()
        ]);
        exit();
    }
}

// 1e. GET /api/v1/admin/users/{user_id}
if(isset($_GET['api']) && $_GET['api'] == 'user' && isset($_GET['id'])) {
    header('Content-Type: application/json');
    
    $user_id = $_GET['id'];
    
    $stmt = $pdo->prepare("SELECT id as user_id, username, full_name, email, contact_number, role as role_classification, status as account_status, created_at as last_login_timestamp FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if($user) {
        $permissions = [];
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'user_permissions'");
            if($stmt->rowCount() > 0) {
                $stmt = $pdo->prepare("SELECT permission_key, permission_value FROM user_permissions WHERE user_id = ?");
                $stmt->execute([$user_id]);
                while($row = $stmt->fetch()) {
                    $permissions[$row['permission_key']] = (bool)$row['permission_value'];
                }
            }
        } catch(PDOException $e) {}
        
        echo json_encode([
            'status' => 'SUCCESS',
            'user' => [
                'user_id' => $user['user_id'],
                'username' => $user['username'],
                'full_name' => $user['full_name'],
                'email' => $user['email'],
                'contact_number' => $user['contact_number'],
                'role_classification' => strtoupper(str_replace(' ', '_', $user['role_classification'])),
                'account_status' => strtoupper($user['account_status']),
                'last_login_timestamp' => $user['last_login_timestamp'] ? date('c', strtotime($user['last_login_timestamp'])) : null
            ],
            'permissions' => $permissions
        ]);
    } else {
        echo json_encode(['status' => 'ERROR', 'code' => 'USER_NOT_FOUND', 'message' => 'User not found.']);
    }
    exit();
}

// ============================================================
// 2. REGULAR FORM HANDLERS
// ============================================================

$add_error = '';
$add_success = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user']) && !isset($_POST['api'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $full_name_user = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $contact = trim($_POST['contact_number']);
    $role_user = $_POST['role'];
    
    if(empty($username) || empty($password) || empty($full_name_user)) {
        $add_error = "Username, password, and full name are required.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if($stmt->fetch()) {
            $add_error = "Username already exists.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, contact_number, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())");
            if($stmt->execute([$username, $hashed, $full_name_user, $email, $contact, $role_user])) {
                $add_success = "User added successfully.";
            } else {
                $add_error = "Failed to add user.";
            }
        }
    }
}

$edit_error = '';
$edit_success = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_user']) && !isset($_POST['api'])) {
    $user_id = $_POST['user_id'];
    $full_name_user = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $contact = trim($_POST['contact_number']);
    $role_user = $_POST['role'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, contact_number = ?, role = ?, status = ? WHERE id = ?");
    if($stmt->execute([$full_name_user, $email, $contact, $role_user, $status, $user_id])) {
        $edit_success = "User updated successfully.";
    } else {
        $edit_error = "Failed to update user.";
    }
}

if(isset($_GET['delete_id']) && !isset($_GET['api'])) {
    $delete_id = $_GET['delete_id'];
    if($delete_id == $admin_id) {
        $delete_error = "You cannot delete your own account.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        if($stmt->execute([$delete_id])) {
            $delete_success = "User deleted successfully.";
        } else {
            $delete_error = "Failed to delete user.";
        }
    }
}

if(isset($_POST['reset_password']) && !isset($_POST['api'])) {
    $user_id = $_POST['user_id'];
    $new_password = $_POST['new_password'];
    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    if($stmt->execute([$hashed, $user_id])) {
        $reset_success = "Password reset successfully.";
    } else {
        $reset_error = "Failed to reset password.";
    }
}

if(isset($_POST['suspend_user']) && !isset($_POST['api'])) {
    $user_id = $_POST['user_id'];
    $reason = trim($_POST['suspension_reason'] ?? 'No reason provided.');
    
    if($user_id == $admin_id) {
        $suspend_error = "You cannot suspend your own account.";
    } else {
        $stmt = $pdo->prepare("UPDATE users SET status = 'suspended', updated_at = NOW() WHERE id = ?");
        if($stmt->execute([$user_id])) {
            $suspend_success = "User suspended successfully.";
        } else {
            $suspend_error = "Failed to suspend user.";
        }
    }
}

if(isset($_POST['activate_user']) && !isset($_POST['api'])) {
    $user_id = $_POST['user_id'];
    
    $stmt = $pdo->prepare("UPDATE users SET status = 'active', updated_at = NOW() WHERE id = ?");
    if($stmt->execute([$user_id])) {
        $activate_success = "User activated successfully.";
    } else {
        $activate_error = "Failed to activate user.";
    }
}

// ============================================================
// 3. GET ALL USERS WITH SEARCH AND FILTERS
// ============================================================
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$role_filter = isset($_GET['role_filter']) ? trim($_GET['role_filter']) : '';
$status_filter = isset($_GET['status_filter']) ? trim($_GET['status_filter']) : '';

$users = [];
try {
    $sql = "SELECT u.*, s.assigned_office, s.designation_title FROM users u LEFT JOIN staff_profiles s ON u.id = s.user_id WHERE 1=1";
    $params = [];
    
    if(!empty($search)) {
        $sql .= " AND (u.username LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    if(!empty($role_filter)) {
        $sql .= " AND u.role = ?";
        $params[] = $role_filter;
    }
    
    if(!empty($status_filter)) {
        $sql .= " AND u.status = ?";
        $params[] = $status_filter;
    }
    
    $sql .= " ORDER BY u.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
} catch(PDOException $e) {
    $sql = "SELECT * FROM users WHERE 1=1";
    $params = [];
    
    if(!empty($search)) {
        $sql .= " AND (username LIKE ? OR full_name LIKE ? OR email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    if(!empty($role_filter)) {
        $sql .= " AND role = ?";
        $params[] = $role_filter;
    }
    
    if(!empty($status_filter)) {
        $sql .= " AND status = ?";
        $params[] = $status_filter;
    }
    
    $sql .= " ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
}

// ============================================================
// 4. GET USER FOR EDIT
// ============================================================
$edit_user = null;
if(isset($_GET['edit_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_GET['edit_id']]);
    $edit_user = $stmt->fetch();
}

// ============================================================
// 5. GET STATS
// ============================================================
$stats = [];
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
    $stats['total'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'admin'");
    $stats['admins'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role IN ('staff', 'social_worker', 'encoder')");
    $stats['staff'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'resident'");
    $stats['residents'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE status = 'active'");
    $stats['active'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE status = 'inactive'");
    $stats['inactive'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE status = 'suspended'");
    $stats['suspended'] = $stmt->fetch()['total'];
} catch(PDOException $e) {
    $stats = ['total' => 0, 'admins' => 0, 'staff' => 0, 'residents' => 0, 'active' => 0, 'inactive' => 0, 'suspended' => 0];
}

$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
$deleted_count = $stmt->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Manage Users - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 10px; }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.6rem; color: var(--gray-500); }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--gray-500);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
        }
        .nav-item i { width: 20px; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        /* Top Bar */
        .top-bar {
            background: var(--white);
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border: 1px solid var(--gray-200);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
        }
        .page-title h1 { font-size: 1.3rem; font-weight: 600; color: var(--gray-800); }
        .page-title p { font-size: 0.7rem; color: var(--gray-500); margin-top: 2px; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            background: var(--gray-50);
            padding: 6px 12px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); }
        .user-details span { font-size: 0.8rem; font-weight: 500; }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; }
        
        /* Stats Row */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        .stat-box {
            background: white;
            padding: 12px;
            border-radius: var(--radius-lg);
            text-align: center;
            border: 1px solid var(--gray-200);
        }
        .stat-number { font-size: 1.3rem; font-weight: 700; color: var(--primary); }
        .stat-label { font-size: 0.6rem; color: var(--gray-500); }
        
        /* Search & Filter Bar */
        .search-filter-bar {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 16px 20px;
            margin-bottom: 20px;
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        .search-filter-bar .search-group {
            flex: 2;
            min-width: 200px;
            position: relative;
        }
        .search-filter-bar .search-group input {
            width: 100%;
            padding: 10px 16px 10px 40px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            font-family: 'Inter', sans-serif;
            transition: all 0.2s;
        }
        .search-filter-bar .search-group input:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30,74,140,0.1);
        }
        .search-filter-bar .search-group .search-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-400);
        }
        .search-filter-bar .filter-group {
            flex: 1;
            min-width: 150px;
        }
        .search-filter-bar .filter-group label {
            display: block;
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--gray-500);
            margin-bottom: 4px;
        }
        .search-filter-bar .filter-group select {
            width: 100%;
            padding: 10px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            font-family: 'Inter', sans-serif;
            background: white;
            transition: all 0.2s;
        }
        .search-filter-bar .filter-group select:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30,74,140,0.1);
        }
        .search-filter-bar .btn-group {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .btn-filter {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.8rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-filter:hover { background: var(--primary-dark); }
        .btn-reset {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
            padding: 10px 20px;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.8rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            transition: all 0.2s;
        }
        .btn-reset:hover { background: var(--gray-200); }
        
        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 16px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .btn-primary {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.8rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary:hover { background: var(--primary-dark); }
        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
            padding: 8px 16px;
            border-radius: var(--radius-md);
            font-weight: 500;
            font-size: 0.8rem;
            cursor: pointer;
            text-decoration: none;
        }
        .btn-danger {
            background: var(--secondary);
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            cursor: pointer;
        }
        .btn-danger:hover { background: #B71C1C; }
        .btn-warning {
            background: var(--accent);
            color: var(--gray-800);
            border: none;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            cursor: pointer;
        }
        .btn-warning:hover { background: #E6A03A; }
        .btn-success-sm {
            background: var(--success);
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            cursor: pointer;
        }
        .btn-success-sm:hover { background: #047857; }
        .btn-suspend {
            background: #8B5CF6;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            cursor: pointer;
        }
        .btn-suspend:hover { background: #7C3AED; }
        
        /* API Status Badge */
        .api-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.55rem;
            font-weight: 700;
            margin-left: 8px;
        }
        .api-badge.get { background: #DBEAFE; color: #1E40AF; }
        .api-badge.post { background: #D1FAE5; color: #065F46; }
        .api-badge.put { background: #FEF3C7; color: #B45309; }
        .api-badge.patch { background: #E0F2FE; color: #0369A1; }
        .api-badge.delete { background: #FEE2E2; color: #991B1B; }
        
        /* Table */
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 800px;
        }
        .table th {
            padding: 12px 16px;
            background: var(--gray-50);
            font-weight: 600;
            border-bottom: 2px solid var(--accent);
            text-align: left;
        }
        .table td {
            padding: 10px 16px;
            border-bottom: 1px solid var(--gray-200);
        }
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .status-active { background: #D1FAE5; color: #065F46; }
        .status-inactive { background: #FEE2E2; color: #991B1B; }
        .status-suspended { background: #FEF3C7; color: #B45309; }
        .role-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .role-admin { background: #FEF3C7; color: #B45309; }
        .role-staff { background: #E3F2FD; color: #1565C0; }
        .role-social_worker { background: #E0F2E9; color: #1E7B48; }
        .role-encoder { background: #F3E5F5; color: #6A1B9A; }
        .role-resident { background: #E8F5E9; color: #2E7D32; }
        
        /* Modals */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1100;
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 500px;
            width: 90%;
            padding: 24px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 4px; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: inherit;
            font-size: 0.85rem;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 60px;
        }
        .form-group .checkbox-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }
        .form-group .checkbox-group label {
            font-weight: 400;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 6px;
            cursor: pointer;
        }
        .alert {
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success { background: #D1FAE5; color: #065F46; border-left: 4px solid #059669; }
        .alert-error { background: #FEE2E2; color: #991B1B; border-left: 4px solid #D32F2F; }
        .alert-info { background: #EFF6FF; color: #1E4A8C; border-left: 4px solid #1E4A8C; }
        
        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.7rem;
            color: var(--gray-600);
            text-decoration: none;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(3, 1fr); }
            .action-buttons { flex-direction: column; }
            .form-group .checkbox-group { grid-template-columns: 1fr; }
            .search-filter-bar { flex-direction: column; }
            .search-filter-bar .btn-group { width: 100%; }
            .search-filter-bar .btn-group .btn-filter,
            .search-filter-bar .btn-group .btn-reset { flex: 1; justify-content: center; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Administrator</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="manage_users.php" class="nav-item active"><i class="fas fa-users-cog"></i> User Management</a>
                <a href="admin_household.php" class="nav-item"><i class="fas fa-home"></i> All Households</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i> Poverty Analysis</a>
                <a href="admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="../admin/recycle_bin.php" class="nav-item"><i class="fas fa-trash-restore"></i> Recycle Bin</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Manage Users</h1>
                <p>Search, filter, and manage system users</p>
                <div style="font-size: 0.6rem; color: var(--gray-400); margin-top: 2px;">
                    <span class="api-badge get">GET</span> /api/v1/admin/users
                    <span class="api-badge post" style="margin-left:8px;">POST</span> /api/v1/admin/users/provision
                    <span class="api-badge put" style="margin-left:8px;">PUT</span> /api/v1/admin/users/{id}/suspend
                    <span class="api-badge patch" style="margin-left:8px;">PATCH</span> /api/v1/admin/users/{id}/permissions
                </div>
            </div>
            <a href="admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Stats -->
        <div class="stats-row">
            <div class="stat-box"><div class="stat-number"><?php echo $stats['total']; ?></div><div class="stat-label">Total Users</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $stats['admins']; ?></div><div class="stat-label">Admins</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $stats['staff']; ?></div><div class="stat-label">Staff</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $stats['residents']; ?></div><div class="stat-label">Residents</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $stats['active']; ?></div><div class="stat-label">Active</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $stats['inactive'] + $stats['suspended']; ?></div><div class="stat-label">Inactive/Suspended</div></div>
        </div>

        <!-- Alerts -->
        <?php if(isset($add_success) && $add_success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $add_success; ?></div>
        <?php endif; ?>
        <?php if(isset($add_error) && $add_error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $add_error; ?></div>
        <?php endif; ?>
        <?php if(isset($edit_success) && $edit_success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $edit_success; ?></div>
        <?php endif; ?>
        <?php if(isset($edit_error) && $edit_error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $edit_error; ?></div>
        <?php endif; ?>
        <?php if(isset($delete_success) && $delete_success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $delete_success; ?></div>
        <?php endif; ?>
        <?php if(isset($delete_error) && $delete_error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $delete_error; ?></div>
        <?php endif; ?>
        <?php if(isset($reset_success) && $reset_success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $reset_success; ?></div>
        <?php endif; ?>
        <?php if(isset($reset_error) && $reset_error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $reset_error; ?></div>
        <?php endif; ?>
        <?php if(isset($suspend_success) && $suspend_success): ?>
            <div class="alert alert-info"><i class="fas fa-lock"></i> <?php echo $suspend_success; ?></div>
        <?php endif; ?>
        <?php if(isset($suspend_error) && $suspend_error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $suspend_error; ?></div>
        <?php endif; ?>
        <?php if(isset($activate_success) && $activate_success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $activate_success; ?></div>
        <?php endif; ?>
        <?php if(isset($activate_error) && $activate_error): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $activate_error; ?></div>
        <?php endif; ?>

        <!-- Action Buttons -->
        <div class="action-buttons">
            <button class="btn-primary" onclick="document.getElementById('provisionModal').style.display='flex'">
                <i class="fas fa-user-plus"></i> Provision Staff Account
            </button>
        </div>

        <!-- SEARCH & FILTER BAR -->
        <form method="GET" class="search-filter-bar" id="searchFilterForm">
            <div class="search-group">
                <span class="search-icon"><i class="fas fa-search"></i></span>
                <input type="text" name="search" placeholder="Search by username, full name, or email..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="filter-group">
                <label><i class="fas fa-users"></i> Role</label>
                <select name="role_filter">
                    <option value="">All Roles</option>
                    <option value="admin" <?php echo $role_filter == 'admin' ? 'selected' : ''; ?>>Admin</option>
                    <option value="staff" <?php echo $role_filter == 'staff' ? 'selected' : ''; ?>>Staff</option>
                    <option value="social_worker" <?php echo $role_filter == 'social_worker' ? 'selected' : ''; ?>>Social Worker</option>
                    <option value="encoder" <?php echo $role_filter == 'encoder' ? 'selected' : ''; ?>>Encoder</option>
                    <option value="resident" <?php echo $role_filter == 'resident' ? 'selected' : ''; ?>>Resident</option>
                </select>
            </div>
            <div class="filter-group">
                <label><i class="fas fa-circle"></i> Status</label>
                <select name="status_filter">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    <option value="suspended" <?php echo $status_filter == 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                </select>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Apply Filters</button>
                <a href="manage_users.php" class="btn-reset"><i class="fas fa-times"></i> Clear</a>
            </div>
        </form>

        <!-- Users Table -->
        <div class="table-container">
            <?php if(count($users) > 0): ?>
            <table class="table" id="usersTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Office</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="usersTableBody">
                    <?php foreach($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                        <td>
                            <span class="role-badge role-<?php echo $user['role']; ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $user['role'])); ?>
                            </span>
                        </td>
                        <td>
                            <span class="status-badge <?php echo $user['status'] == 'active' ? 'status-active' : ($user['status'] == 'suspended' ? 'status-suspended' : 'status-inactive'); ?>">
                                <?php echo ucfirst($user['status']); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($user['assigned_office'] ?? 'N/A'); ?></td>
                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                        <td>
                            <button class="btn-warning" onclick="openEditModal(<?php echo $user['id']; ?>)"><i class="fas fa-edit"></i></button>
                            <button class="btn-danger" onclick="openResetModal(<?php echo $user['id']; ?>)"><i class="fas fa-key"></i></button>
                            
                            <?php if($user['status'] == 'suspended'): ?>
                                <button class="btn-success-sm" onclick="openActivateModal(<?php echo $user['id']; ?>)"><i class="fas fa-check"></i></button>
                            <?php elseif($user['status'] == 'active' && $user['id'] != $admin_id): ?>
                                <button class="btn-suspend" onclick="openSuspendModal(<?php echo $user['id']; ?>)"><i class="fas fa-ban"></i></button>
                            <?php endif; ?>
                            
                            <?php if($user['id'] != $admin_id): ?>
                                <button class="btn-danger" onclick="confirmDelete(<?php echo $user['id']; ?>)"><i class="fas fa-trash"></i></button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div style="text-align: center; padding: 40px; color: var(--gray-500);">
                <i class="fas fa-users" style="font-size: 3rem; margin-bottom: 12px; opacity: 0.5;"></i>
                <p>No users found matching your criteria.</p>
                <p style="font-size: 0.85rem; margin-top: 4px;">Try adjusting your search or filter settings.</p>
            </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Bottom Navigation (Mobile) -->
    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="manage_users.php" class="nav-item active"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Poverty</span></a>
        <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <!-- MODAL: Provision Staff Account -->
    <div id="provisionModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-user-plus" style="color: var(--primary);"></i> Provision Staff Account</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Create a new staff account with role-based permissions.
            </p>
            <form method="POST" id="provisionForm">
                <input type="hidden" name="api" value="provision">
                
                <div class="form-group">
                    <label>Username *</label>
                    <input type="text" name="username" required>
                </div>
                <div class="form-group">
                    <label>Password *</label>
                    <input type="password" name="password" required>
                    <small style="color: var(--gray-500);">Minimum 6 characters</small>
                </div>
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="full_name" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email">
                </div>
                <div class="form-group">
                    <label>Contact Number</label>
                    <input type="text" name="contact_number">
                </div>
                <div class="form-group">
                    <label>Role</label>
                    <select name="role">
                        <option value="staff">Staff</option>
                        <option value="social_worker">Social Worker</option>
                        <option value="encoder">Encoder</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Assigned Office</label>
                    <select name="assigned_office">
                        <option value="MSWDO_MAIN_OFFICE">MSWDO Main Office</option>
                        <option value="BARANGAY_CENTER">Barangay Center</option>
                        <option value="FIELD_OFFICE">Field Office</option>
                        <option value="DISTRICT_OFFICE">District Office</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Permissions Matrix</label>
                    <div class="checkbox-group">
                        <label><input type="checkbox" name="perm_approve_financial" checked> Approve Financial Aid</label>
                        <label><input type="checkbox" name="perm_view_vawc"> View VAWC Files</label>
                        <label><input type="checkbox" name="perm_issue_id" checked> Issue ID Cards</label>
                        <label><input type="checkbox" name="perm_assess_apps" checked> Assess Applications</label>
                        <label><input type="checkbox" name="perm_disburse_funds"> Disburse Funds</label>
                        <label><input type="checkbox" name="perm_approve_beneficiaries" checked> Approve Beneficiaries</label>
                        <label><input type="checkbox" name="perm_offline_sync" checked> Offline Sync</label>
                        <label><input type="checkbox" name="perm_authorize_verification"> Authorize Verification</label>
                        <label><input type="checkbox" name="perm_manual_sms"> Manual SMS</label>
                        <label><input type="checkbox" name="perm_scan_qr" checked> Scan QR</label>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn-secondary" onclick="closeModal('provisionModal')">Cancel</button>
                    <button type="submit" class="btn-primary">Provision Account</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Edit User -->
    <div id="editUserModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-edit" style="color: var(--accent);"></i> Edit User</h3>
            <form method="POST" id="editForm">
                <input type="hidden" name="user_id" id="edit_user_id">
                <input type="hidden" name="edit_user" value="1">
                
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="full_name" id="edit_full_name" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="edit_email">
                </div>
                <div class="form-group">
                    <label>Contact Number</label>
                    <input type="text" name="contact_number" id="edit_contact">
                </div>
                <div class="form-group">
                    <label>Role</label>
                    <select name="role" id="edit_role">
                        <option value="resident">Resident</option>
                        <option value="staff">Staff</option>
                        <option value="social_worker">Social Worker</option>
                        <option value="encoder">Encoder</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="edit_status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn-secondary" onclick="closeModal('editUserModal')">Cancel</button>
                    <button type="submit" class="btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Reset Password -->
    <div id="resetModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-key" style="color: var(--secondary);"></i> Reset Password</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                This will immediately change the user's password.
            </p>
            <form method="POST">
                <input type="hidden" name="user_id" id="reset_user_id">
                <input type="hidden" name="reset_password" value="1">
                <div class="form-group">
                    <label>New Password *</label>
                    <input type="password" name="new_password" required>
                    <small style="color: var(--gray-500);">Minimum 6 characters</small>
                </div>
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn-secondary" onclick="closeModal('resetModal')">Cancel</button>
                    <button type="submit" class="btn-primary">Reset Password</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Suspend User -->
    <div id="suspendModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-ban" style="color: #8B5CF6;"></i> Suspend Account</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                This will suspend the account. The user will not be able to log in.
            </p>
            <form method="POST">
                <input type="hidden" name="user_id" id="suspend_user_id">
                <input type="hidden" name="suspend_user" value="1">
                <div class="form-group">
                    <label>Reason Notes *</label>
                    <textarea name="suspension_reason" rows="3" required placeholder="Explain why this account is being suspended..."></textarea>
                </div>
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn-secondary" onclick="closeModal('suspendModal')">Cancel</button>
                    <button type="submit" class="btn-primary" style="background: #8B5CF6;">Suspend Account</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Activate User -->
    <div id="activateModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-check-circle" style="color: var(--success);"></i> Activate Account</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Reactivate a suspended account.
            </p>
            <form method="POST">
                <input type="hidden" name="user_id" id="activate_user_id">
                <input type="hidden" name="activate_user" value="1">
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn-secondary" onclick="closeModal('activateModal')">Cancel</button>
                    <button type="submit" class="btn-primary" style="background: var(--success);">Activate Account</button>
                </div>
            </form>
        </div>
    </div>

    <!-- API Response Display Modal -->
    <div id="apiResponseModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-code" style="color: #8B5CF6;"></i> API Response</h3>
            <pre id="apiResponseContent" style="background: #F1F5F9; padding: 16px; border-radius: var(--radius-md); overflow-x: auto; font-size: 0.75rem; max-height: 400px; overflow-y: auto;"></pre>
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 16px;">
                <button class="btn-secondary" onclick="closeModal('apiResponseModal')">Close</button>
            </div>
        </div>
    </div>

    <script>
        // Sidebar toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Provision via API (AJAX)
        document.getElementById('provisionForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const modal = document.getElementById('apiResponseModal');
            const content = document.getElementById('apiResponseContent');
            content.textContent = 'Processing...';
            modal.style.display = 'flex';
            
            fetch('manage_users.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                content.textContent = JSON.stringify(data, null, 2);
                if(data.status === 'SUCCESS') {
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                }
            })
            .catch(error => {
                content.textContent = 'Error: ' + error.message;
            });
        });

        function openEditModal(userId) {
            fetch('manage_users.php?api=user&id=' + userId)
                .then(response => response.json())
                .then(data => {
                    if(data.status === 'SUCCESS' && data.user) {
                        document.getElementById('edit_user_id').value = data.user.user_id;
                        document.getElementById('edit_full_name').value = data.user.full_name;
                        document.getElementById('edit_email').value = data.user.email || '';
                        document.getElementById('edit_contact').value = data.user.contact_number || '';
                        document.getElementById('edit_role').value = data.user.role_classification.toLowerCase();
                        document.getElementById('edit_status').value = data.user.account_status.toLowerCase();
                        document.getElementById('editUserModal').style.display = 'flex';
                    } else {
                        alert('Error loading user data');
                    }
                })
                .catch(() => {
                    alert('Failed to load user data');
                });
        }

        function openResetModal(userId) {
            document.getElementById('reset_user_id').value = userId;
            document.getElementById('resetModal').style.display = 'flex';
        }

        function openSuspendModal(userId) {
            document.getElementById('suspend_user_id').value = userId;
            document.getElementById('suspendModal').style.display = 'flex';
        }

        function openActivateModal(userId) {
            document.getElementById('activate_user_id').value = userId;
            document.getElementById('activateModal').style.display = 'flex';
        }

        function confirmDelete(userId) {
            if(confirm('⚠️ Are you sure you want to delete this user? This action cannot be undone.')) {
                window.location.href = '?delete_id=' + userId;
            }
        }

        window.onclick = (e) => {
            if(e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        }
        
        document.querySelectorAll('#searchFilterForm select').forEach(select => {
            select.addEventListener('change', function() {
                document.getElementById('searchFilterForm').submit();
            });
        });
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>