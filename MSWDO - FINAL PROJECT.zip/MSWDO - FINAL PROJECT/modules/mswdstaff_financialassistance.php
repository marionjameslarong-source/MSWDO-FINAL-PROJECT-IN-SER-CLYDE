<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder', 'admin'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];

// ============================================================
// DATABASE INDEXING OPTIMIZATION - Check and Create Indexes
// ============================================================

/**
 * Check if an index exists on a table
 */
function indexExists($pdo, $tableName, $indexName) {
    try {
        $stmt = $pdo->prepare("SHOW INDEX FROM $tableName WHERE Key_name = ?");
        $stmt->execute([$indexName]);
        return $stmt->rowCount() > 0;
    } catch(PDOException $e) {
        return false;
    }
}

/**
 * Create indexes if they don't exist
 */
function createOptimizationIndexes($pdo) {
    $messages = [];
    $indexes = [
        // Financial Assistance specific indexes
        [
            'table' => 'welfare_applications',
            'name' => 'idx_financial_aid_status',
            'sql' => "CREATE INDEX idx_financial_aid_status ON welfare_applications (status, program_type)"
        ],
        [
            'table' => 'welfare_applications',
            'name' => 'idx_applications_user_id',
            'sql' => "CREATE INDEX idx_applications_user_id ON welfare_applications (user_id)"
        ],
        [
            'table' => 'welfare_applications',
            'name' => 'idx_applications_created_at',
            'sql' => "CREATE INDEX idx_applications_created_at ON welfare_applications (created_at)"
        ],
        [
            'table' => 'welfare_applications',
            'name' => 'idx_applications_reviewed_by',
            'sql' => "CREATE INDEX idx_applications_reviewed_by ON welfare_applications (reviewed_by)"
        ],
        // Financial ledger indexes
        [
            'table' => 'financial_ledger',
            'name' => 'idx_ledger_application_id',
            'sql' => "CREATE INDEX idx_ledger_application_id ON financial_ledger (application_id)"
        ],
        [
            'table' => 'financial_ledger',
            'name' => 'idx_ledger_staff_id',
            'sql' => "CREATE INDEX idx_ledger_staff_id ON financial_ledger (staff_id)"
        ],
        [
            'table' => 'financial_ledger',
            'name' => 'idx_ledger_type_year',
            'sql' => "CREATE INDEX idx_ledger_type_year ON financial_ledger (type, YEAR(created_at))"
        ],
        // Users index
        [
            'table' => 'users',
            'name' => 'idx_users_role',
            'sql' => "CREATE INDEX idx_users_role ON users (role)"
        ]
    ];
    
    foreach($indexes as $index) {
        try {
            if(!indexExists($pdo, $index['table'], $index['name'])) {
                $pdo->exec($index['sql']);
                $messages[] = "✅ Created index: {$index['name']} on {$index['table']}";
            } else {
                $messages[] = "✓ Index already exists: {$index['name']}";
            }
        } catch(PDOException $e) {
            $messages[] = "⚠️ Failed to create index: {$index['name']} - " . $e->getMessage();
        }
    }
    
    return $messages;
}

// Run index optimization on page load (silent)
$index_messages = [];
try {
    $index_messages = createOptimizationIndexes($pdo);
} catch(PDOException $e) {
    // Silently fail if indexes can't be created
}

// ============================================================
// 1. GET MUNICIPAL BUDGET BALANCE
// ============================================================
$budget_balance = 1245000.00; // Default - in production, fetch from financial_ledger
$budget_status = 'OK';
$budget_status_class = 'bg-green';
$budget_status_text = '● BUDGET AVAILABLE';

try {
    // Try to get actual budget from database
    $stmt = $pdo->query("SELECT SUM(amount) as total FROM financial_ledger WHERE type = 'disbursement' AND YEAR(created_at) = YEAR(CURRENT_DATE)");
    $disbursed = $stmt->fetch()['total'] ?? 0;
    
    // Get total allocated budget for current year
    $stmt = $pdo->query("SELECT SUM(amount) as total FROM financial_ledger WHERE type = 'allocation' AND YEAR(created_at) = YEAR(CURRENT_DATE)");
    $allocated = $stmt->fetch()['total'] ?? 2000000.00;
    
    $budget_balance = $allocated - $disbursed;
    
    if($budget_balance < 50000) {
        $budget_status = 'CRITICAL';
        $budget_status_class = 'bg-red';
        $budget_status_text = '⚠️ BUDGET CRITICAL';
    } else {
        $budget_status = 'OK';
        $budget_status_class = 'bg-green';
        $budget_status_text = '● BUDGET AVAILABLE';
    }
} catch(PDOException $e) {
    // Use default values if table doesn't exist
}

// ============================================================
// 2. ASSESS FINANCIAL ASSISTANCE (Social Worker Assessment)
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assess_aid'])) {
    $application_id = $_POST['application_id'];
    $case_study_summary = $_POST['case_study_summary'] ?? '';
    $recommended_amount = $_POST['recommended_amount'] ?? 0;
    $fund_allocation_source = $_POST['fund_allocation_source'] ?? 'MUNICIPAL_EMERGENCY_CASH_BAL_2026';
    
    if(empty($case_study_summary) || $recommended_amount <= 0) {
        $error_message = "Please provide a case study summary and a valid recommended amount.";
    } else {
        $app = $pdo->prepare("SELECT application_data FROM welfare_applications WHERE id = ?");
        $app->execute([$application_id]);
        $app_data = $app->fetch();
        $data = json_decode($app_data['application_data'], true) ?? [];
        $data['case_study_summary'] = $case_study_summary;
        $data['recommended_amount'] = $recommended_amount;
        $data['fund_allocation_source'] = $fund_allocation_source;
        $data['assessed_by'] = $user_id;
        $data['assessed_at'] = date('Y-m-d H:i:s');
        
        $stmt = $pdo->prepare("
            UPDATE welfare_applications 
            SET status = 'under_review', 
                application_data = ?,
                review_notes = CONCAT('Assessment submitted: ', ?),
                reviewed_by = ?,
                reviewed_at = NOW(),
                updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([json_encode($data), $case_study_summary, $user_id, $application_id]);
        $success_message = "Financial assistance assessment submitted successfully. Recommended amount: ₱" . number_format($recommended_amount, 2);
    }
}

// ============================================================
// 3. DISBURSE FUNDS (The Payout Command)
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['disburse_funds'])) {
    $application_id = $_POST['application_id'];
    $payout_channel = $_POST['payout_channel'] ?? 'CASH_OVER_THE_COUNTER';
    $disbursement_ref = $_POST['disbursement_reference'] ?? '';
    $actual_amount = $_POST['actual_amount'] ?? 0;
    
    if(empty($disbursement_ref) || $actual_amount <= 0) {
        $error_message = "Please provide a disbursement reference number and valid amount.";
    } else {
        // Check if budget is sufficient
        if($actual_amount > $budget_balance) {
            $error_message = "Insufficient municipal budget. Available: ₱" . number_format($budget_balance, 2);
        } else {
            $app = $pdo->prepare("SELECT application_data FROM welfare_applications WHERE id = ?");
            $app->execute([$application_id]);
            $app_data = $app->fetch();
            $data = json_decode($app_data['application_data'], true) ?? [];
            $data['payout_channel'] = $payout_channel;
            $data['disbursement_reference'] = $disbursement_ref;
            $data['actual_amount_paid'] = $actual_amount;
            $data['disbursed_by'] = $user_id;
            $data['disbursed_at'] = date('Y-m-d H:i:s');
            
            $tracking_number = 'REF-CASH-' . date('Y') . '-' . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
            
            $stmt = $pdo->prepare("
                UPDATE welfare_applications 
                SET status = 'disbursed', 
                    application_data = ?,
                    tracking_number = ?,
                    reviewed_by = ?,
                    reviewed_at = NOW(),
                    updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([json_encode($data), $tracking_number, $user_id, $application_id]);
            
            // Log disbursement to financial ledger
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO financial_ledger (application_id, amount, reference, channel, staff_id, type, created_at) 
                    VALUES (?, ?, ?, ?, ?, 'disbursement', NOW())
                ");
                $stmt->execute([$application_id, $actual_amount, $disbursement_ref, $payout_channel, $user_id]);
                
                // Update budget balance
                $budget_balance -= $actual_amount;
                if($budget_balance < 50000) {
                    $budget_status = 'CRITICAL';
                    $budget_status_class = 'bg-red';
                    $budget_status_text = '⚠️ BUDGET CRITICAL';
                }
            } catch(PDOException $e) {
                // Ignore if table doesn't exist
            }
            
            $success_message = "Funds disbursed successfully! Reference: " . $tracking_number . " - ₱" . number_format($actual_amount, 2);
        }
    }
}

// ============================================================
// 4. REJECT FINANCIAL ASSISTANCE
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reject_aid'])) {
    $application_id = $_POST['application_id'];
    $rejection_reason = $_POST['rejection_reason'] ?? 'MISSING_INDIGENCY_CERTIFICATE';
    $instruction_to_resident = $_POST['instruction_to_resident'] ?? 'Please secure a valid Barangay Certificate of Indigency and upload it to your profile to resume processing.';
    
    $stmt = $pdo->prepare("
        UPDATE welfare_applications 
        SET status = 'rejected', 
            review_notes = CONCAT('Rejection Code: ', ?, ' - Instruction: ', ?),
            reviewed_by = ?,
            reviewed_at = NOW(),
            updated_at = NOW(),
            rejection_reason = ?,
            instruction_to_resident = ?
        WHERE id = ?
    ");
    $stmt->execute([$rejection_reason, $instruction_to_resident, $user_id, $rejection_reason, $instruction_to_resident, $application_id]);
    $success_message = "Financial assistance application rejected. Resident has been notified.";
}

// ============================================================
// 5. GET ALL FINANCIAL ASSISTANCE APPLICATIONS (Using Indexes)
// ============================================================
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

// Optimized query using indexes: idx_financial_aid_status, idx_applications_user_id
$query = "
    SELECT wa.*, u.full_name as applicant_name, u.username, u.email, u.contact_number 
    FROM welfare_applications wa 
    LEFT JOIN users u ON wa.user_id = u.id 
    WHERE wa.program_type = 'financial_assistance'
";
if($status_filter != 'all') {
    $query .= " AND wa.status = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$status_filter]);
} else {
    $stmt = $pdo->prepare($query);
    $stmt->execute();
}
$applications = $stmt->fetchAll();

// Get statistics (using indexes for faster counts)
$pending_count = count(array_filter($applications, fn($a) => $a['status'] == 'pending'));
$under_review_count = count(array_filter($applications, fn($a) => $a['status'] == 'under_review'));
$approved_count = count(array_filter($applications, fn($a) => $a['status'] == 'approved'));
$disbursed_count = count(array_filter($applications, fn($a) => $a['status'] == 'disbursed'));
$rejected_count = count(array_filter($applications, fn($a) => $a['status'] == 'rejected'));

// Calculate total funds
$total_requested = 0;
$total_approved = 0;
$total_disbursed = 0;
foreach($applications as $app) {
    $data = json_decode($app['application_data'], true);
    if(isset($data['amount_requested'])) {
        $total_requested += floatval($data['amount_requested']);
    }
    if(isset($data['recommended_amount']) && $app['status'] == 'under_review') {
        $total_approved += floatval($data['recommended_amount']);
    }
    if(isset($data['actual_amount_paid']) && $app['status'] == 'disbursed') {
        $total_disbursed += floatval($data['actual_amount_paid']);
    }
}

// Assistance type mapping
$assistance_types = [
    'medical' => 'Medical Assistance',
    'burial' => 'Burial/Death Assistance',
    'food' => 'Food Assistance',
    'transport' => 'Transportation Assistance',
    'educational' => 'Educational Assistance',
    'shelter' => 'Shelter/Housing Repair',
    'livelihood' => 'Livelihood Support',
    'other' => 'Other'
];

// Urgency level mapping
$urgency_levels = [
    'low' => 'Low',
    'medium' => 'Medium',
    'high' => 'High'
];

// Rejection reason codes
$rejection_reasons = [
    'MISSING_INDIGENCY_CERTIFICATE' => 'Missing Certificate of Indigency',
    'INCOMPLETE_MEDICAL_RECEIPTS' => 'Incomplete/Unreadable Medical Receipts',
    'NO_PROOF_OF_RESIDENCY' => 'No Proof of Residency',
    'INCOMPLETE_FORM' => 'Incomplete Application Form',
    'INSUFFICIENT_DOCUMENTS' => 'Insufficient Supporting Documents',
    'EXCEEDS_BUDGET' => 'Requested Amount Exceeds Available Budget',
    'DUPLICATE_APPLICATION' => 'Duplicate Application Found',
    'OTHER' => 'Other Reason'
];

// Payout channels
$payout_channels = [
    'CASH_OVER_THE_COUNTER' => 'Cash Over-the-Counter',
    'BANK_TRANSFER' => 'Bank Transfer',
    'GCASH' => 'GCash',
    'PAYMAYA' => 'PayMaya',
    'BARANGAY_PAYOUT' => 'Barangay Payout Center'
];

// Helper function to get status badge class
function getStatusClass($status) {
    switch($status) {
        case 'pending': return 'status-pending';
        case 'under_review': return 'status-review';
        case 'approved': return 'status-approved';
        case 'disbursed': return 'status-disbursed';
        case 'rejected': return 'status-rejected';
        default: return 'status-pending';
    }
}

function getStatusLabel($status) {
    switch($status) {
        case 'pending': return 'Pending Assessment';
        case 'under_review': return 'Under Review';
        case 'approved': return 'Approved';
        case 'disbursed': return 'Disbursed';
        case 'rejected': return 'Rejected';
        default: return ucfirst($status);
    }
}

// Helper function to get urgency badge class
function getUrgencyClass($level) {
    switch($level) {
        case 'high': return 'urgency-high';
        case 'medium': return 'urgency-medium';
        case 'low': return 'urgency-low';
        default: return 'urgency-medium';
    }
}

// Get deleted count for recycle bin badge (only for admin)
$deleted_count = 0;
if($role === 'admin') {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
    $deleted_count = $stmt->fetch()['total'];
}

// Get index status for display
function getIndexStatus($pdo) {
    $status = [];
    $indexes = [
        'idx_financial_aid_status' => 'Financial Aid Status',
        'idx_applications_user_id' => 'Application User ID',
        'idx_applications_created_at' => 'Created Date',
        'idx_applications_reviewed_by' => 'Reviewed By',
        'idx_ledger_application_id' => 'Ledger App ID',
        'idx_ledger_staff_id' => 'Ledger Staff ID',
        'idx_ledger_type_year' => 'Ledger Type/Year',
        'idx_users_role' => 'User Role'
    ];
    
    foreach($indexes as $name => $label) {
        try {
            $stmt = $pdo->prepare("SHOW INDEX FROM welfare_applications WHERE Key_name = ?");
            $stmt->execute([$name]);
            $exists = $stmt->rowCount() > 0;
            
            if(!$exists && strpos($name, 'ledger') !== false) {
                // Check in financial_ledger table
                $stmt = $pdo->prepare("SHOW INDEX FROM financial_ledger WHERE Key_name = ?");
                $stmt->execute([$name]);
                $exists = $stmt->rowCount() > 0;
            }
            
            $status[$name] = $exists;
        } catch(PDOException $e) {
            $status[$name] = false;
        }
    }
    return $status;
}

$index_status = getIndexStatus($pdo);
$index_count = count(array_filter($index_status));
$total_indexes = count($index_status);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Financial Assistance - MSWD Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F4F6F9;
            color: #1A1A1A;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar - Matching staff files */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-icon i { font-size: 1.2rem; color: var(--accent); }
        .logo-text h1 { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.6rem; color: var(--gray-500); }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--gray-500);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
        }
        .nav-item i { width: 20px; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .submenu-item.active i { color: white; }
        
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        .top-bar {
            background: var(--white);
            padding: 12px 20px;
            border-radius: var(--radius-lg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
        }
        .page-title h1 { font-size: 1.3rem; font-weight: 600; color: var(--gray-800); }
        .page-title p { font-size: 0.7rem; color: var(--gray-500); margin-top: 2px; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            background: var(--gray-50);
            padding: 6px 12px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        
        /* ========================================================== */
        /* INDEX STATUS BADGE                                         */
        /* ========================================================== */
        .index-status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 600;
        }
        .index-status-badge.optimized {
            background: #D1FAE5;
            color: #065F46;
        }
        .index-status-badge.partial {
            background: #FEF3C7;
            color: #B45309;
        }
        .index-status-badge.not-optimized {
            background: #FEE2E2;
            color: #991B1B;
        }
        
        /* ========================================================== */
        /* BUDGET CARD - Sticky Top Card                              */
        /* ========================================================== */
        .budget-card {
            background: #1E293B;
            padding: 24px;
            border-radius: var(--radius-xl);
            margin-bottom: 24px;
            border: none;
            box-shadow: var(--shadow-lg);
        }
        .budget-card .budget-title {
            color: #94A3B8;
            font-size: 0.7rem;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        .budget-card .budget-amount {
            color: #FFFFFF;
            font-size: 2rem;
            font-weight: 700;
            margin: 8px 0 12px;
        }
        .budget-card .budget-status {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 16px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
            color: #FFFFFF;
        }
        .budget-card .budget-status.bg-green {
            background: #10B981;
        }
        .budget-card .budget-status.bg-red {
            background: #EF4444;
        }
        .budget-card .budget-status.bg-yellow {
            background: #F59E0B;
        }
        
        /* ========================================================== */
        /* QUEUE SECTION - Applicant Cards                           */
        /* ========================================================== */
        .section-title {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--gray-700);
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .section-title .count-badge {
            background: var(--gray-200);
            padding: 2px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--gray-600);
        }
        
        .applicant-card {
            background: var(--white);
            padding: 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 12px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s ease;
        }
        .applicant-card:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-1px);
        }
        .applicant-card .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
        }
        .applicant-card .applicant-name {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--gray-800);
        }
        .applicant-card .date-badge {
            font-size: 0.6rem;
            color: var(--gray-500);
            background: var(--gray-100);
            padding: 2px 10px;
            border-radius: 12px;
        }
        .applicant-card .aid-type-text {
            font-size: 0.8rem;
            color: var(--gray-600);
            margin-top: 2px;
        }
        .applicant-card .amount-text {
            font-size: 0.8rem;
            color: var(--gray-600);
            margin-top: 2px;
            margin-bottom: 10px;
        }
        .applicant-card .amount-text .bold-price {
            font-weight: 700;
            color: var(--gray-800);
        }
        .applicant-card .process-btn {
            background: #2563EB;
            padding: 10px 16px;
            border-radius: var(--radius-md);
            border: none;
            color: white;
            font-weight: 600;
            font-size: 0.75rem;
            cursor: pointer;
            width: 100%;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .applicant-card .process-btn:hover {
            background: #1D4ED8;
            transform: translateY(-1px);
        }
        .applicant-card .process-btn:disabled {
            background: var(--gray-300);
            cursor: not-allowed;
            transform: none;
        }
        .applicant-card .process-btn.insufficient {
            background: #EF4444;
        }
        .applicant-card .process-btn.insufficient:hover {
            background: #DC2626;
        }
        
        /* ========================================================== */
        /* STATS ROW - Compact Stats                                 */
        /* ========================================================== */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 12px;
            margin-bottom: 24px;
        }
        .stat-box {
            background: white;
            padding: 12px 8px;
            border-radius: var(--radius-lg);
            text-align: center;
            border: 1px solid var(--gray-200);
        }
        .stat-number { font-size: 1.3rem; font-weight: 700; color: var(--primary); }
        .stat-label { font-size: 0.6rem; color: var(--gray-500); }
        .stat-box.disbursed .stat-number { color: #059669; }
        .stat-box.pending .stat-number { color: #B45309; }
        .stat-box.review .stat-number { color: #1E4A8C; }
        
        /* ========================================================== */
        /* FUNDS SUMMARY - Mini Cards                                */
        /* ========================================================== */
        .funds-summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        .fund-box {
            background: white;
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-200);
        }
        .fund-box .fund-label { font-size: 0.6rem; color: var(--gray-500); }
        .fund-box .fund-amount { font-size: 1rem; font-weight: 700; }
        .fund-box.requested .fund-amount { color: #D32F2F; }
        .fund-box.approved .fund-amount { color: #1E4A8C; }
        .fund-box.disbursed .fund-amount { color: #059669; }
        
        /* ========================================================== */
        /* FILTER BAR                                                 */
        /* ========================================================== */
        .filter-bar {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        .filter-btn {
            padding: 6px 14px;
            border-radius: 30px;
            background: white;
            border: 1px solid var(--gray-200);
            text-decoration: none;
            font-size: 0.7rem;
            color: var(--gray-600);
            transition: all 0.2s;
        }
        .filter-btn:hover { background: var(--gray-100); }
        .filter-btn.active { background: var(--primary); color: white; border-color: var(--primary); }
        
        /* ========================================================== */
        /* TABLE - Desktop View                                      */
        /* ========================================================== */
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
            display: none;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.75rem;
            min-width: 1100px;
        }
        .table th {
            text-align: left;
            padding: 10px 12px;
            background: var(--gray-50);
            font-weight: 600;
            border-bottom: 2px solid var(--accent);
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            color: var(--gray-600);
        }
        .table td {
            padding: 8px 12px;
            border-bottom: 1px solid var(--gray-100);
        }
        
        /* ========================================================== */
        /* STATUS BADGES                                              */
        /* ========================================================== */
        .status-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 600;
        }
        .status-pending { background: #FEF3C7; color: #B45309; }
        .status-review { background: #DBEAFE; color: #1E40AF; }
        .status-approved { background: #D1FAE5; color: #065F46; }
        .status-disbursed { background: #D1FAE5; color: #059669; }
        .status-rejected { background: #FEE2E2; color: #991B1B; }
        
        .urgency-high { background: #FEE2E2; color: #991B1B; }
        .urgency-medium { background: #FEF3C7; color: #B45309; }
        .urgency-low { background: #D1FAE5; color: #065F46; }
        
        .tracking-number {
            font-family: monospace;
            background: var(--gray-100);
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 0.65rem;
        }
        
        /* ========================================================== */
        /* BUTTONS                                                    */
        /* ========================================================== */
        .btn-assess {
            background: #1E4A8C;
            color: white;
            padding: 4px 10px;
            border-radius: 16px;
            border: none;
            font-size: 0.6rem;
            cursor: pointer;
        }
        .btn-assess:hover { background: #0A2F6C; }
        .btn-disburse {
            background: #059669;
            color: white;
            padding: 4px 10px;
            border-radius: 16px;
            border: none;
            font-size: 0.6rem;
            cursor: pointer;
        }
        .btn-disburse:hover { background: #047857; }
        .btn-reject {
            background: #D32F2F;
            color: white;
            padding: 4px 10px;
            border-radius: 16px;
            border: none;
            font-size: 0.6rem;
            cursor: pointer;
            margin-left: 4px;
        }
        .btn-reject:hover { background: #B71C1C; }
        .btn-view {
            background: var(--primary);
            color: white;
            padding: 4px 10px;
            border-radius: 16px;
            border: none;
            font-size: 0.6rem;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .btn-view:hover { background: var(--primary-dark); }
        
        /* ========================================================== */
        /* ALERTS                                                     */
        /* ========================================================== */
        .alert-success {
            background: #D1FAE5;
            color: #065F46;
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-error {
            background: #FEE2E2;
            color: #991B1B;
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* ========================================================== */
        /* INDEX INFO CARD                                            */
        /* ========================================================== */
        .index-info-card {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 16px 20px;
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        .index-info-card .index-status {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .index-info-card .index-status .index-icon {
            font-size: 1.2rem;
            color: var(--primary);
        }
        .index-info-card .index-status .index-text {
            font-size: 0.8rem;
            color: var(--gray-600);
        }
        .index-info-card .index-status .index-text strong {
            color: var(--gray-800);
        }
        
        /* ========================================================== */
        /* MODAL                                                      */
        /* ========================================================== */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1100;
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 550px;
            width: 90%;
            padding: 24px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-group { margin-bottom: 16px; }
        .form-group label { 
            display: block; 
            font-size: 0.7rem; 
            font-weight: 600; 
            margin-bottom: 4px;
            color: var(--gray-700);
        }
        .form-group select, 
        .form-group textarea,
        .form-group input[type="text"],
        .form-group input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: inherit;
            font-size: 0.8rem;
        }
        .form-group textarea { resize: vertical; min-height: 60px; }
        .form-group .helper-text {
            font-size: 0.65rem;
            color: var(--gray-500);
            margin-top: 4px;
        }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--gray-200);
        }
        .btn-submit {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 600;
            font-size: 0.8rem;
        }
        .btn-submit:hover { background: var(--primary-dark); }
        .btn-cancel {
            background: var(--gray-200);
            color: var(--gray-700);
            border: none;
            padding: 10px 24px;
            border-radius: var(--radius-md);
            cursor: pointer;
            margin-left: 10px;
            font-weight: 600;
            font-size: 0.8rem;
        }
        .btn-cancel:hover { background: var(--gray-300); }
        
        /* ========================================================== */
        /* EMPTY STATE                                                */
        /* ========================================================== */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray-500);
        }
        .empty-state i { font-size: 2.5rem; margin-bottom: 12px; opacity: 0.5; }
        
        /* ========================================================== */
        /* BOTTOM NAV                                                 */
        /* ========================================================== */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.6rem;
            color: var(--gray-600);
            text-decoration: none;
        }
        .bottom-nav .nav-item i { font-size: 1.1rem; margin-bottom: 2px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        
        /* ========================================================== */
        /* RESPONSIVE - Mobile View                                  */
        /* ========================================================== */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
                box-shadow: var(--shadow-lg);
            }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 12px; }
            .menu-toggle { display: block; }
            
            .top-bar { flex-wrap: wrap; gap: 12px; padding: 12px 16px; }
            .page-title h1 { font-size: 1.1rem; }
            
            .stats-row { grid-template-columns: repeat(3, 1fr); gap: 8px; }
            .stat-number { font-size: 1rem; }
            .stat-label { font-size: 0.55rem; }
            
            .funds-summary { grid-template-columns: 1fr 1fr; gap: 8px; }
            .fund-box .fund-amount { font-size: 0.9rem; }
            
            .budget-card { padding: 16px; }
            .budget-card .budget-amount { font-size: 1.5rem; }
            
            .table-container { display: none; }
            
            /* Mobile Queue - Show cards on mobile */
            .mobile-queue { display: block; }
            .index-info-card { flex-direction: column; align-items: flex-start; }
        }
        @media (max-width: 480px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .funds-summary { grid-template-columns: 1fr; }
        }
        
        /* Desktop: Hide mobile queue, show table */
        .mobile-queue { display: none; }
        @media (min-width: 769px) {
            .table-container { display: block; }
            .mobile-queue { display: none; }
        }
        
        @media (max-width: 992px) {
            .stats-row { grid-template-columns: repeat(3, 1fr); }
            .funds-summary { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- SIDEBAR - UPDATED WITH ALL LINKS MATCHING REFERENCE -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-hand-holding-heart"></i></div>
                <div class="logo-text">
                    <h1>MSWDO Portal</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="mswdstaff_communityservice.php" class="nav-item">
                    <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
                </a>
                <a href="household.php" class="nav-item">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Programs</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="mswdstaff_idapplication.php" class="nav-item">
                    <i class="fas fa-id-card"></i> <span>ID Applications</span>
                </a>
                <a href="mswdstaff_financialassistance.php" class="nav-item active">
                    <i class="fas fa-hand-holding-usd"></i> <span>Financial Assistance</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="mswdstaff_profile.php" class="nav-item">
                    <i class="fas fa-user-circle"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Financial Assistance</h1>
                <p>Manage aid requests and monitor municipal budget</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <?php if(isset($success_message)): ?>
            <div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if(isset($error_message)): ?>
            <div class="alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?></div>
        <?php endif; ?>

        <!-- ========================================================== -->
        <!-- INDEX OPTIMIZATION STATUS CARD                             -->
        <!-- ========================================================== -->
        <div class="index-info-card">
            <div class="index-status">
                <span class="index-icon"><i class="fas fa-database"></i></span>
                <span class="index-text">
                    <strong>Database Index Status:</strong> 
                    <?php 
                    if($index_count == $total_indexes) {
                        echo '<span style="color: #059669;">✅ Fully Optimized</span>';
                    } elseif($index_count > 0) {
                        echo '<span style="color: #B45309;">⚠️ Partially Optimized</span>';
                    } else {
                        echo '<span style="color: #991B1B;">❌ Not Optimized</span>';
                    }
                    ?>
                    <span style="color: var(--gray-400); margin-left: 8px; font-weight: 400;">
                        (<?php echo $index_count; ?>/<?php echo $total_indexes; ?> indexes active)
                    </span>
                </span>
            </div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; font-size: 0.65rem;">
                <?php foreach($index_status as $name => $exists): ?>
                    <span style="display: inline-flex; align-items: center; gap: 4px; padding: 2px 10px; border-radius: 12px; background: <?php echo $exists ? '#D1FAE5' : '#FEE2E2'; ?>; color: <?php echo $exists ? '#065F46' : '#991B1B'; ?>;">
                        <i class="fas <?php echo $exists ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                        <?php 
                        $labels = [
                            'idx_financial_aid_status' => 'Aid Status',
                            'idx_applications_user_id' => 'App User',
                            'idx_applications_created_at' => 'Created',
                            'idx_applications_reviewed_by' => 'Reviewed',
                            'idx_ledger_application_id' => 'Ledger App',
                            'idx_ledger_staff_id' => 'Ledger Staff',
                            'idx_ledger_type_year' => 'Ledger Type',
                            'idx_users_role' => 'User Role'
                        ];
                        echo $labels[$name] ?? $name;
                        ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ========================================================== -->
        <!-- 1. BUDGET CARD - Sticky Top                               -->
        <!-- ========================================================== -->
        <div class="budget-card">
            <div class="budget-title">MUNICIPAL CASH BALANCE (AICS <?php echo date('Y'); ?>)</div>
            <div class="budget-amount">₱ <?php echo number_format($budget_balance, 2); ?></div>
            <div class="budget-status <?php echo $budget_status_class; ?>">
                <?php echo $budget_status_text; ?>
            </div>
        </div>

        <!-- ========================================================== -->
        <!-- 2. STATS ROW                                               -->
        <!-- ========================================================== -->
        <div class="stats-row">
            <div class="stat-box pending">
                <div class="stat-number"><?php echo $pending_count; ?></div>
                <div class="stat-label">Pending</div>
            </div>
            <div class="stat-box review">
                <div class="stat-number"><?php echo $under_review_count; ?></div>
                <div class="stat-label">Under Review</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?php echo $approved_count; ?></div>
                <div class="stat-label">Approved</div>
            </div>
            <div class="stat-box disbursed">
                <div class="stat-number"><?php echo $disbursed_count; ?></div>
                <div class="stat-label">Disbursed</div>
            </div>
            <div class="stat-box">
                <div class="stat-number"><?php echo $rejected_count; ?></div>
                <div class="stat-label">Rejected</div>
            </div>
        </div>

        <!-- ========================================================== -->
        <!-- 3. FUNDS SUMMARY                                           -->
        <!-- ========================================================== -->
        <div class="funds-summary">
            <div class="fund-box requested">
                <div class="fund-label">Total Requested</div>
                <div class="fund-amount">₱ <?php echo number_format($total_requested, 2); ?></div>
            </div>
            <div class="fund-box approved">
                <div class="fund-label">Total Approved</div>
                <div class="fund-amount">₱ <?php echo number_format($total_approved, 2); ?></div>
            </div>
            <div class="fund-box disbursed">
                <div class="fund-label">Total Disbursed</div>
                <div class="fund-amount">₱ <?php echo number_format($total_disbursed, 2); ?></div>
            </div>
        </div>

        <!-- ========================================================== -->
        <!-- 4. FILTER BAR                                              -->
        <!-- ========================================================== -->
        <div class="filter-bar">
            <a href="?status=all" class="filter-btn <?php echo $status_filter == 'all' ? 'active' : ''; ?>">All</a>
            <a href="?status=pending" class="filter-btn <?php echo $status_filter == 'pending' ? 'active' : ''; ?>">Pending</a>
            <a href="?status=under_review" class="filter-btn <?php echo $status_filter == 'under_review' ? 'active' : ''; ?>">Under Review</a>
            <a href="?status=approved" class="filter-btn <?php echo $status_filter == 'approved' ? 'active' : ''; ?>">Approved</a>
            <a href="?status=disbursed" class="filter-btn <?php echo $status_filter == 'disbursed' ? 'active' : ''; ?>">Disbursed</a>
            <a href="?status=rejected" class="filter-btn <?php echo $status_filter == 'rejected' ? 'active' : ''; ?>">Rejected</a>
        </div>

        <!-- ========================================================== -->
        <!-- 5. MOBILE QUEUE VIEW - Card List                          -->
        <!-- ========================================================== -->
        <div class="mobile-queue">
            <div class="section-title">
                <span>Pending Assessments Queue</span>
                <span class="count-badge"><?php echo $pending_count; ?></span>
            </div>
            
            <?php
            $pending_apps = array_filter($applications, fn($a) => $a['status'] == 'pending');
            if(count($pending_apps) > 0):
                foreach($pending_apps as $app):
                    $app_data = json_decode($app['application_data'], true);
                    $assistance_type = $app_data['assistance_type'] ?? 'N/A';
                    $assistance_display = $assistance_types[$assistance_type] ?? ucfirst(str_replace('_', ' ', $assistance_type));
                    $amount = isset($app_data['amount_requested']) ? $app_data['amount_requested'] : 0;
                    $urgency = $app_data['urgency_level'] ?? 'medium';
                    $urgency_display = $urgency_levels[$urgency] ?? ucfirst($urgency);
                    $urgency_class = getUrgencyClass($urgency);
                    
                    // Check if budget is sufficient for this request
                    $is_budget_sufficient = ($budget_balance >= $amount);
            ?>
            <div class="applicant-card">
                <div class="card-header">
                    <span class="applicant-name"><i class="fas fa-user-circle" style="color: var(--primary);"></i> <?php echo htmlspecialchars($app['applicant_name'] ?? 'Unknown'); ?></span>
                    <span class="date-badge"><?php echo date('M d', strtotime($app['created_at'])); ?></span>
                </div>
                <div class="aid-type-text">Type: <?php echo $assistance_display; ?></div>
                <div class="amount-text">
                    Requested: <span class="bold-price">₱ <?php echo number_format($amount, 2); ?></span>
                    <span class="status-badge <?php echo $urgency_class; ?>" style="margin-left: 8px;"><?php echo $urgency_display; ?></span>
                </div>
                <button class="process-btn <?php echo !$is_budget_sufficient ? 'insufficient' : ''; ?>" 
                        onclick="openProcessModal(<?php echo $app['id']; ?>, <?php echo $amount; ?>, '<?php echo $budget_balance; ?>')"
                        <?php echo !$is_budget_sufficient ? 'disabled' : ''; ?>>
                    <?php if($is_budget_sufficient): ?>
                        <i class="fas fa-hand-holding-usd"></i> Process Application
                    <?php else: ?>
                        <i class="fas fa-exclamation-triangle"></i> Insufficient Municipal Funds
                    <?php endif; ?>
                </button>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <div class="empty-state" style="background: white; border-radius: var(--radius-lg); padding: 30px; border: 1px solid var(--gray-200);">
                <i class="fas fa-check-circle" style="color: #059669;"></i>
                <p>No pending financial evaluations remaining.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- ========================================================== -->
        <!-- 6. TABLE VIEW - Desktop                                   -->
        <!-- ========================================================== -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Urgency</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($applications) == 0): ?>
                    <tr>
                        <td colspan="8" class="empty-state">
                            <i class="fas fa-folder-open"></i>
                            <p>No financial assistance applications found</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach($applications as $app): 
                        $app_data = json_decode($app['application_data'], true);
                        $assistance_type = $app_data['assistance_type'] ?? 'N/A';
                        $assistance_display = $assistance_types[$assistance_type] ?? ucfirst(str_replace('_', ' ', $assistance_type));
                        $amount = isset($app_data['amount_requested']) ? '₱ ' . number_format($app_data['amount_requested'], 2) : '-';
                        $urgency = $app_data['urgency_level'] ?? 'medium';
                        $urgency_display = $urgency_levels[$urgency] ?? ucfirst($urgency);
                        $urgency_class = getUrgencyClass($urgency);
                    ?>
                    <tr>
                        <td><?php echo $app['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($app['applicant_name'] ?? 'N/A'); ?></strong>
                            <br><small><?php echo htmlspecialchars($app['username'] ?? ''); ?></small>
                        </td>
                        <td><?php echo $assistance_display; ?></td>
                        <td><?php echo $amount; ?></td>
                        <td><span class="status-badge <?php echo $urgency_class; ?>"><?php echo $urgency_display; ?></span></td>
                        <td><span class="status-badge status-<?php echo $app['status']; ?>"><?php echo getStatusLabel($app['status']); ?></span></td>
                        <td><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                        <td>
                            <a href="mswdstaff_view.php?id=<?php echo $app['id']; ?>" class="btn-view">
                                <i class="fas fa-eye"></i> View
                            </a>
                            <?php if($app['status'] == 'pending'): ?>
                                <button class="btn-assess" onclick="openAssessModal(<?php echo $app['id']; ?>)">Assess</button>
                                <button class="btn-reject" onclick="openRejectModal(<?php echo $app['id']; ?>)">Reject</button>
                            <?php endif; ?>
                            <?php if($app['status'] == 'under_review'): ?>
                                <button class="btn-disburse" onclick="openDisburseModal(<?php echo $app['id']; ?>)">Disburse</button>
                                <button class="btn-reject" onclick="openRejectModal(<?php echo $app['id']; ?>)">Reject</button>
                            <?php endif; ?>
                            <?php if($app['status'] == 'approved'): ?>
                                <button class="btn-disburse" onclick="openDisburseModal(<?php echo $app['id']; ?>)">Disburse</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Bottom Navigation - UPDATED -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_financialassistance.php" class="nav-item active"><i class="fas fa-hand-holding-usd"></i><span>Financial</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <!-- ============================================================ -->
    <!-- MODAL 1: Process Application (Mobile Action)                 -->
    <!-- ============================================================ -->
    <div id="processModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-hand-holding-usd" style="color: #2563EB;"></i> Process Application</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Review applicant details and select an action.
            </p>
            <form method="POST" action="">
                <input type="hidden" name="application_id" id="processAppId">
                
                <div class="form-group">
                    <label>Applicant Details</label>
                    <div style="background: var(--gray-50); padding: 12px; border-radius: var(--radius-md); font-size: 0.8rem;">
                        <div><strong>Name:</strong> <span id="processApplicantName">Loading...</span></div>
                        <div><strong>Requested Amount:</strong> <span id="processRequestedAmount">₱ 0.00</span></div>
                        <div><strong>Available Budget:</strong> <span id="processAvailableBudget">₱ <?php echo number_format($budget_balance, 2); ?></span></div>
                        <div><strong>Budget Status:</strong> <span id="processBudgetStatus" style="color: <?php echo $budget_balance >= 50000 ? '#059669' : '#D32F2F'; ?>;"><?php echo $budget_status_text; ?></span></div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Select Action</label>
                    <select name="review_action" id="processAction" onchange="updateProcessButton()">
                        <option value="assess">📋 Assess Case</option>
                        <option value="disburse" <?php echo $budget_balance < 50000 ? 'disabled' : ''; ?>>💰 Disburse Funds</option>
                        <option value="reject">❌ Reject Application</option>
                    </select>
                    <?php if($budget_balance < 50000): ?>
                        <div class="helper-text" style="color: #D32F2F;"><i class="fas fa-exclamation-triangle"></i> Disbursement disabled due to low budget</div>
                    <?php endif; ?>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('processModal')">Cancel</button>
                    <button type="submit" class="btn-submit" id="processSubmitBtn" style="background: #2563EB;">
                        <i class="fas fa-arrow-right"></i> <span id="processBtnText">Proceed</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- MODAL 2: Assess Financial Assistance                         -->
    <!-- ============================================================ -->
    <div id="assessModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-clipboard-check" style="color: #1E4A8C;"></i> Social Worker Assessment</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Submit your case study assessment and recommend the approved amount.
            </p>
            <form method="POST" action="">
                <input type="hidden" name="application_id" id="assessAppId">
                <input type="hidden" name="assess_aid" value="1">
                
                <div class="form-group">
                    <label>Case Study Summary <span style="color: #D32F2F;">*</span></label>
                    <textarea name="case_study_summary" id="caseStudySummary" rows="3" required placeholder="Describe the family's situation, verified documents, and social worker's evaluation..."></textarea>
                    <div class="helper-text">Provide a detailed assessment of the applicant's case</div>
                </div>
                
                <div class="form-group">
                    <label>Recommended Amount <span style="color: #D32F2F;">*</span></label>
                    <input type="number" name="recommended_amount" id="recommendedAmount" step="0.01" min="1" required placeholder="Enter recommended amount in PHP">
                    <div class="helper-text">Based on municipal guidelines and applicant's need</div>
                </div>
                
                <div class="form-group">
                    <label>Fund Allocation Source</label>
                    <select name="fund_allocation_source">
                        <option value="MUNICIPAL_EMERGENCY_CASH_BAL_2026">Municipal Emergency Cash Fund 2026</option>
                        <option value="NATIONAL_CRISIS_FUND">National Crisis Fund</option>
                        <option value="PROVINCIAL_AID_BUDGET">Provincial Aid Budget</option>
                        <option value="DONATION_FUND">Donation Fund</option>
                        <option value="OTHER">Other</option>
                    </select>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('assessModal')">Cancel</button>
                    <button type="submit" class="btn-submit">Submit Assessment</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- MODAL 3: Disburse Funds (Payout Command)                     -->
    <!-- ============================================================ -->
    <div id="disburseModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-hand-holding-usd" style="color: #059669;"></i> Disburse Funds</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Enter the payout details to officially release the funds.
            </p>
            <form method="POST" action="">
                <input type="hidden" name="application_id" id="disburseAppId">
                <input type="hidden" name="disburse_funds" value="1">
                
                <div class="form-group">
                    <label>Disbursement Reference Number <span style="color: #D32F2F;">*</span></label>
                    <input type="text" name="disbursement_reference" id="disbursementRef" required placeholder="e.g., REF-CASH-2026-99042" value="REF-CASH-<?php echo date('Y'); ?>-<?php echo str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT); ?>">
                    <div class="helper-text">Unique reference number for audit tracking</div>
                </div>
                
                <div class="form-group">
                    <label>Payout Channel</label>
                    <select name="payout_channel">
                        <?php foreach($payout_channels as $key => $label): ?>
                            <option value="<?php echo $key; ?>" <?php echo $key == 'CASH_OVER_THE_COUNTER' ? 'selected' : ''; ?>>
                                <?php echo $label; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Actual Amount Paid <span style="color: #D32F2F;">*</span></label>
                    <input type="number" name="actual_amount" id="actualAmount" step="0.01" min="1" required placeholder="Enter actual amount disbursed">
                    <div class="helper-text">Amount paid to the beneficiary</div>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('disburseModal')">Cancel</button>
                    <button type="submit" class="btn-submit" style="background: #059669;">Confirm Disbursement</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- MODAL 4: Reject Financial Assistance                         -->
    <!-- ============================================================ -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-times-circle" style="color: #D32F2F;"></i> Reject Financial Assistance</h3>
            <p style="color: var(--gray-500); font-size: 0.85rem; margin-bottom: 16px;">
                Select the rejection reason and provide instructions for the resident.
            </p>
            <form method="POST" action="">
                <input type="hidden" name="application_id" id="rejectAppId">
                <input type="hidden" name="reject_aid" value="1">
                
                <div class="form-group">
                    <label>Rejection Reason <span style="color: #D32F2F;">*</span></label>
                    <select name="rejection_reason" id="rejectionReason" onchange="updateRejectInstruction()">
                        <?php foreach($rejection_reasons as $key => $label): ?>
                            <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Instruction to Resident <span style="color: #D32F2F;">*</span></label>
                    <textarea name="instruction_to_resident" id="rejectInstruction" rows="3">Please secure a valid Barangay Certificate of Indigency and upload it to your profile to resume processing.</textarea>
                    <div class="helper-text">Clear instructions for the resident to correct the issue</div>
                </div>
                
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal('rejectModal')">Cancel</button>
                    <button type="submit" class="btn-submit" style="background: #D32F2F;">Reject Application</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // ============================================================
        // SIDEBAR TOGGLE
        // ============================================================
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) {
            menuToggle.addEventListener('click', () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); });
        }
        if(overlay) {
            overlay.addEventListener('click', () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); });
        }

        // ============================================================
        // COLLAPSIBLE PROGRAM MENU
        // ============================================================
        const programToggle = document.getElementById('programToggle');
        const programSubmenu = document.getElementById('programSubmenu');
        const programIcon = document.getElementById('programIcon');
        if(programToggle) {
            programToggle.addEventListener('click', () => { 
                programSubmenu.classList.toggle('show'); 
                programIcon.classList.toggle('rotated'); 
            });
        }

        // ============================================================
        // MODAL FUNCTIONS
        // ============================================================
        function openAssessModal(id) {
            document.getElementById('assessAppId').value = id;
            document.getElementById('caseStudySummary').value = '';
            document.getElementById('recommendedAmount').value = '';
            document.getElementById('assessModal').style.display = 'flex';
        }

        function openDisburseModal(id) {
            document.getElementById('disburseAppId').value = id;
            document.getElementById('actualAmount').value = '';
            const ref = 'REF-CASH-' + new Date().getFullYear() + '-' + String(Math.floor(10000 + Math.random() * 90000)).padStart(5, '0');
            document.getElementById('disbursementRef').value = ref;
            document.getElementById('disburseModal').style.display = 'flex';
        }

        function openRejectModal(id) {
            document.getElementById('rejectAppId').value = id;
            document.getElementById('rejectModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // ============================================================
        // PROCESS APPLICATION MODAL
        // ============================================================
        function openProcessModal(id, amount, budget) {
            document.getElementById('processAppId').value = id;
            
            // Get applicant name from the card
            const card = event.target.closest('.applicant-card');
            if(card) {
                const nameEl = card.querySelector('.applicant-name');
                if(nameEl) {
                    document.getElementById('processApplicantName').textContent = nameEl.textContent.trim();
                }
            }
            
            document.getElementById('processRequestedAmount').textContent = '₱ ' + Number(amount).toLocaleString();
            document.getElementById('processAvailableBudget').textContent = '₱ ' + Number(budget).toLocaleString();
            
            document.getElementById('processModal').style.display = 'flex';
        }

        function updateProcessButton() {
            const action = document.getElementById('processAction').value;
            const btn = document.getElementById('processSubmitBtn');
            const btnText = document.getElementById('processBtnText');
            
            const labels = {
                'assess': { text: '📋 Submit Assessment', color: '#1E4A8C' },
                'disburse': { text: '💰 Confirm Disbursement', color: '#059669' },
                'reject': { text: '❌ Reject Application', color: '#D32F2F' }
            };
            
            const selected = labels[action] || labels['assess'];
            btnText.textContent = selected.text;
            btn.style.background = selected.color;
        }

        // ============================================================
        // UPDATE REJECT INSTRUCTION
        // ============================================================
        function updateRejectInstruction() {
            const reason = document.getElementById('rejectionReason').value;
            const instructions = {
                'MISSING_INDIGENCY_CERTIFICATE': 'Please secure a valid Barangay Certificate of Indigency and upload it to your profile to resume processing.',
                'INCOMPLETE_MEDICAL_RECEIPTS': 'Please provide complete and readable copies of medical receipts and/or hospital bills.',
                'NO_PROOF_OF_RESIDENCY': 'Please upload a valid proof of residency such as a barangay clearance or utility bill.',
                'INCOMPLETE_FORM': 'Please complete all required fields in the application form and resubmit.',
                'INSUFFICIENT_DOCUMENTS': 'Please submit all required supporting documents as listed in the application requirements.',
                'EXCEEDS_BUDGET': 'Your requested amount exceeds the available budget for this assistance type. Please submit a revised request.',
                'DUPLICATE_APPLICATION': 'We found a duplicate application. Please check your submitted applications.',
                'OTHER': 'Please review your application and provide the required corrections. Contact the MSWDO office for further assistance.'
            };
            document.getElementById('rejectInstruction').value = instructions[reason] || instructions['OTHER'];
        }

        // Close modals when clicking outside
        window.onclick = (e) => { 
            if(e.target.classList.contains('modal')) {
                closeModal(e.target.id);
            }
        }

        console.log('✅ Financial Assistance (Mobile POV) loaded');
        console.log('💰 Budget Balance: ₱ <?php echo number_format($budget_balance, 2); ?>');
        console.log('📊 Pending Applications: <?php echo $pending_count; ?>');
        console.log('📱 Mobile queue view enabled');
        console.log('🗄️ Database Index Status: <?php echo $index_count; ?>/<?php echo $total_indexes; ?> indexes active');
    </script>
</body>
</html>