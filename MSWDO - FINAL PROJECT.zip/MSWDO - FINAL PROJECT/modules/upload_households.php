<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$error = '';
$success = '';
$uploaded_count = 0;
$failed_count = 0;
$failed_rows = [];

// Function to classify poverty based on income
function classifyPovertyIncome($income) {
    if($income < 5000) {
        return 'Extremely Poor';
    } elseif($income >= 5000 && $income <= 10000) {
        return 'Poor';
    } elseif($income >= 10001 && $income <= 15000) {
        return 'Low Income';
    } elseif($income >= 15001 && $income <= 25000) {
        return 'Lower Middle';
    } elseif($income > 25000) {
        return 'Middle Income and Above';
    } else {
        return 'Not Classified';
    }
}

// Get actual database columns
$stmt = $pdo->query("DESCRIBE households");
$db_columns = [];
$table_cols = $stmt->fetchAll();
foreach($table_cols as $col) {
    $db_columns[] = $col['Field'];
}

// Determine available columns
$has_total_members = in_array('total_members', $db_columns);
$has_household_size = in_array('household_size', $db_columns);
$has_monthly_income = in_array('monthly_income', $db_columns);
$has_total_income = in_array('total_income', $db_columns);
$has_head_first = in_array('head_first_name', $db_columns);
$has_head_last = in_array('head_last_name', $db_columns);
$has_head_middle = in_array('head_middle_name', $db_columns);
$has_barangay = in_array('barangay', $db_columns);
$has_address = in_array('address', $db_columns);
$has_city = in_array('city_municipality', $db_columns);
$has_province = in_array('province', $db_columns);
$has_zip = in_array('zip_code', $db_columns);
$has_is_4ps = in_array('is_4ps_beneficiary', $db_columns);
$has_poverty = in_array('poverty_status', $db_columns);

$members_field = $has_total_members ? 'total_members' : 'household_size';
$income_field = $has_monthly_income ? 'monthly_income' : 'total_income';

// Handle CSV Upload
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    
    // Check file type
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if($file_ext != 'csv') {
        $error = "Please upload a valid CSV file.";
    } elseif($file['error'] != 0) {
        $error = "Error uploading file. Please try again.";
    } else {
        if(($handle = fopen($file['tmp_name'], 'r')) !== false) {
            // Get headers (first row)
            $headers = fgetcsv($handle);
            
            // Map CSV headers to database columns
            $column_mapping = [
                'first_name' => 'head_first_name',
                'last_name' => 'head_last_name',
                'middle_name' => 'head_middle_name',
                'address' => 'address',
                'barangay' => 'barangay',
                'city' => 'city_municipality',
                'province' => 'province',
                'zip_code' => 'zip_code',
                'monthly_income' => $income_field,
                'total_members' => $members_field,
                'is_4ps' => 'is_4ps_beneficiary'
            ];
            
            // Find column indices
            $indices = [];
            foreach($column_mapping as $csv_col => $db_col) {
                $indices[$csv_col] = array_search($csv_col, $headers);
            }
            
            // Check required columns
            $required = ['first_name', 'last_name', 'barangay', 'monthly_income', 'total_members'];
            $missing = [];
            foreach($required as $req) {
                if($indices[$req] === false) {
                    $missing[] = $req;
                }
            }
            
            if(!empty($missing)) {
                $error = "CSV file is missing required columns: " . implode(', ', $missing);
            } else {
                $row_number = 1;
                while(($data = fgetcsv($handle)) !== false) {
                    $row_number++;
                    
                    if(empty(array_filter($data))) continue;
                    
                    // Extract data using indices
                    $first_name = trim($data[$indices['first_name']] ?? '');
                    $last_name = trim($data[$indices['last_name']] ?? '');
                    $barangay = trim($data[$indices['barangay']] ?? '');
                    $monthly_income = floatval($data[$indices['monthly_income']] ?? 0);
                    $total_members = intval($data[$indices['total_members']] ?? 1);
                    
                    $middle_name = ($indices['middle_name'] !== false && isset($data[$indices['middle_name']])) ? trim($data[$indices['middle_name']]) : '';
                    $address = ($indices['address'] !== false && isset($data[$indices['address']])) ? trim($data[$indices['address']]) : '';
                    $city = ($indices['city'] !== false && isset($data[$indices['city']])) ? trim($data[$indices['city']]) : '';
                    $province = ($indices['province'] !== false && isset($data[$indices['province']])) ? trim($data[$indices['province']]) : '';
                    $zip_code = ($indices['zip_code'] !== false && isset($data[$indices['zip_code']])) ? trim($data[$indices['zip_code']]) : '';
                    $is_4ps = 0;
                    if($indices['is_4ps'] !== false && isset($data[$indices['is_4ps']])) {
                        $val = strtolower(trim($data[$indices['is_4ps']]));
                        $is_4ps = ($val == 'yes' || $val == 'true' || $val == '1') ? 1 : 0;
                    }
                    
                    // Validate
                    $errors = [];
                    if(empty($first_name)) $errors[] = "First name required";
                    if(empty($last_name)) $errors[] = "Last name required";
                    if(empty($barangay) && $has_barangay) $errors[] = "Barangay required";
                    if($total_members < 1) $errors[] = "Total members must be at least 1";
                    
                    if(empty($errors)) {
                        $poverty_status = classifyPovertyIncome($monthly_income);
                        
                        try {
                            // Build insert query
                            $fields = [];
                            $placeholders = [];
                            $params = [];
                            
                            if($has_head_first) { $fields[] = 'head_first_name'; $placeholders[] = '?'; $params[] = $first_name; }
                            if($has_head_last) { $fields[] = 'head_last_name'; $placeholders[] = '?'; $params[] = $last_name; }
                            if($has_head_middle && !empty($middle_name)) { $fields[] = 'head_middle_name'; $placeholders[] = '?'; $params[] = $middle_name; }
                            if($has_address && !empty($address)) { $fields[] = 'address'; $placeholders[] = '?'; $params[] = $address; }
                            if($has_barangay && !empty($barangay)) { $fields[] = 'barangay'; $placeholders[] = '?'; $params[] = $barangay; }
                            if($has_city && !empty($city)) { $fields[] = 'city_municipality'; $placeholders[] = '?'; $params[] = $city; }
                            if($has_province && !empty($province)) { $fields[] = 'province'; $placeholders[] = '?'; $params[] = $province; }
                            if($has_zip && !empty($zip_code)) { $fields[] = 'zip_code'; $placeholders[] = '?'; $params[] = $zip_code; }
                            if($has_total_members || $has_household_size) { $fields[] = $members_field; $placeholders[] = '?'; $params[] = $total_members; }
                            if($has_monthly_income || $has_total_income) { $fields[] = $income_field; $placeholders[] = '?'; $params[] = $monthly_income; }
                            if($has_is_4ps) { $fields[] = 'is_4ps_beneficiary'; $placeholders[] = '?'; $params[] = $is_4ps; }
                            if($has_poverty) { $fields[] = 'poverty_status'; $placeholders[] = '?'; $params[] = $poverty_status; }
                            
                            $fields[] = 'created_at';
                            $placeholders[] = 'NOW()';
                            
                            $sql = "INSERT INTO households (" . implode(", ", $fields) . ") VALUES (" . implode(", ", $placeholders) . ")";
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute($params);
                            $uploaded_count++;
                        } catch(PDOException $e) {
                            $failed_count++;
                            $failed_rows[] = "Row $row_number: " . $e->getMessage();
                        }
                    } else {
                        $failed_count++;
                        $failed_rows[] = "Row $row_number: " . implode(', ', $errors);
                    }
                }
                fclose($handle);
                
                if($uploaded_count > 0) {
                    $success = "Successfully uploaded $uploaded_count household records!";
                    if($failed_count > 0) {
                        $success .= " ($failed_count records failed)";
                    }
                } elseif($failed_count > 0) {
                    $error = "Failed to upload $failed_count records. Please check the format.";
                } else {
                    $error = "No records found in the CSV file.";
                }
            }
        } else {
            $error = "Unable to open the CSV file.";
        }
    }
}

// Download sample CSV
if(isset($_GET['download_sample'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="household_sample.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['first_name', 'last_name', 'middle_name', 'address', 'barangay', 'city', 'province', 'zip_code', 'monthly_income', 'total_members', 'is_4ps']);
    fputcsv($output, ['Juan', 'Dela Cruz', 'Santos', '123 Rizal St', 'Poblacion', 'Manila', 'Metro Manila', '1000', '15000', '4', 'Yes']);
    fputcsv($output, ['Maria', 'Reyes', 'Garcia', '456 Mabini St', 'San Isidro', 'Quezon City', 'Metro Manila', '1100', '8000', '3', 'No']);
    fputcsv($output, ['Jose', 'Santos', '', '789 Bonifacio St', 'Barangay 1', 'Calamba', 'Laguna', '4027', '25000', '5', 'No']);
    fclose($output);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Household Data - MSWDO</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F5F7FB;
            color: #1E2F4E;
            padding-bottom: 75px;
        }
        :root {
            --msw-blue: #1E4A8C;
            --msw-blue-dark: #0A2F6C;
            --msw-red: #D32F2F;
            --msw-yellow: #F5B042;
            --msw-white: #FFFFFF;
            --bg-light: #F9FAFE;
            --text-muted: #5B6E8C;
            --shadow-sm: 0 4px 12px rgba(0, 0, 0, 0.04);
            --radius-card: 28px;
            --radius-element: 20px;
        }
        .top-bar {
            background: var(--msw-white);
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow-sm);
            border-bottom: 3px solid var(--msw-yellow);
        }
        .logo {
            font-weight: 700;
            font-size: 1.3rem;
            background: linear-gradient(135deg, var(--msw-blue), var(--msw-blue-dark));
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .logo i {
            background: linear-gradient(135deg, var(--msw-yellow), var(--msw-red));
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            font-size: 1.5rem;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            background: var(--bg-light);
            padding: 8px 16px;
            border-radius: 40px;
            font-weight: 500;
            font-size: 0.9rem;
        }
        .user-info .role-badge {
            background: var(--msw-yellow);
            color: var(--msw-blue-dark);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .user-info a { color: var(--msw-red); text-decoration: none; }
        .container { max-width: 900px; margin: 0 auto; padding: 20px 18px 30px; }
        .upload-card {
            background: white;
            border-radius: 32px;
            padding: 32px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 3px solid var(--msw-yellow);
        }
        .header h1 { color: var(--msw-blue); margin-bottom: 8px; font-size: 1.8rem; }
        .header p { color: var(--text-muted); font-size: 0.85rem; }
        .alert {
            padding: 14px 18px;
            border-radius: 20px;
            margin-bottom: 20px;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success { background: #E8F5E9; border-left: 4px solid #2E7D32; color: #1E5A2E; }
        .alert-danger { background: #FEF2F0; border-left: 4px solid #D32F2F; color: #B91C1C; }
        .alert-info { background: #EFF6FF; border-left: 4px solid #1E4A8C; color: #1E3A6F; }
        .info-section {
            background: #F9FAFE;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid #E2E8F0;
        }
        .info-section h3 {
            color: var(--msw-blue);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 1rem;
        }
        .upload-area {
            border: 2px dashed #E2E8F0;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .upload-area:hover { border-color: var(--msw-yellow); background: #FFF9EF; }
        .upload-area i { font-size: 3rem; color: var(--msw-blue); margin-bottom: 16px; }
        .btn-upload {
            background: var(--msw-blue);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 48px;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 16px;
        }
        .btn-upload:hover { background: var(--msw-blue-dark); transform: translateY(-2px); }
        .btn-sample {
            background: transparent;
            border: 1.5px solid var(--msw-blue);
            color: var(--msw-blue);
            padding: 8px 20px;
            border-radius: 40px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-sample:hover { background: var(--msw-blue); color: white; }
        .btn-back {
            background: #F5F7FB;
            color: var(--msw-blue);
            border: 1px solid #E2E8F0;
            padding: 10px 20px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-back:hover { background: #EFF6FF; }
        .failed-rows {
            margin-top: 16px;
            max-height: 200px;
            overflow-y: auto;
            font-size: 0.75rem;
            background: #FEF2F0;
            border-radius: 16px;
            padding: 12px;
        }
        .failed-rows ul { margin-left: 20px; color: #B91C1C; }
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--msw-white);
            display: flex;
            justify-content: space-around;
            padding: 10px 20px 18px;
            border-top: 1px solid rgba(30, 74, 140, 0.1);
            z-index: 20;
        }
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            font-size: 0.7rem;
            color: var(--text-muted);
            gap: 4px;
        }
        .nav-item.active { color: var(--msw-red); }
        @media (max-width: 600px) {
            .upload-card { padding: 20px; }
            .upload-area { padding: 30px 20px; }
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <div class="top-bar">
            <div class="logo">
                <i class="fas fa-hand-holding-heart"></i>
                <span>MSWDO Portal</span>
            </div>
            <div class="user-info">
                <span class="role-badge"><?php echo ucfirst(str_replace('_', ' ', $role)); ?></span>
                <span><i class="fas fa-user-circle" style="color: var(--msw-yellow);"></i> <?php echo htmlspecialchars($full_name); ?></span>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="container">
            <div class="upload-card">
                <div class="header">
                    <i class="fas fa-upload" style="font-size: 3rem; color: var(--msw-red);"></i>
                    <h1>Upload Household Data</h1>
                    <p>Bulk upload household records using CSV file</p>
                </div>

                <?php if($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <?php if($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo $success; ?></span>
                    </div>
                <?php endif; ?>

                <?php if(!empty($failed_rows)): ?>
                    <div class="failed-rows">
                        <strong><i class="fas fa-exclamation-triangle"></i> Failed Records:</strong>
                        <ul>
                            <?php foreach($failed_rows as $row): ?>
                                <li><?php echo htmlspecialchars($row); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="info-section">
                    <h3><i class="fas fa-info-circle"></i> CSV File Format</h3>
                    <p style="margin-bottom: 12px;">Your CSV file MUST have these exact column headers:</p>
                    <ul style="margin-left: 20px; margin-bottom: 16px; background: #FFF9EF; padding: 12px; border-radius: 12px;">
                        <li><strong>first_name</strong> - First name of household head (required)</li>
                        <li><strong>last_name</strong> - Last name of household head (required)</li>
                        <li><strong>middle_name</strong> - Middle name (optional)</li>
                        <li><strong>address</strong> - Street address (optional)</li>
                        <li><strong>barangay</strong> - Barangay (required)</li>
                        <li><strong>city</strong> - City/Municipality (optional)</li>
                        <li><strong>province</strong> - Province (optional)</li>
                        <li><strong>zip_code</strong> - ZIP code (optional)</li>
                        <li><strong>monthly_income</strong> - Monthly household income (required)</li>
                        <li><strong>total_members</strong> - Number of household members (required)</li>
                        <li><strong>is_4ps</strong> - 4Ps beneficiary (Yes/No or 1/0) (optional)</li>
                    </ul>
                    <p><strong>⚠️ Note:</strong> The first row of your CSV must contain these EXACT column names.</p>
                </div>

                <div class="info-section">
                    <h3><i class="fas fa-chart-line"></i> Poverty Classification (Auto)</h3>
                    <ul style="margin-left: 20px;">
                        <li><strong>Below ₱5,000</strong> → Extremely Poor</li>
                        <li><strong>₱5,000 - ₱10,000</strong> → Poor</li>
                        <li><strong>₱10,001 - ₱15,000</strong> → Low Income</li>
                        <li><strong>₱15,001 - ₱25,000</strong> → Lower Middle</li>
                        <li><strong>Above ₱25,000</strong> → Middle Income and Above</li>
                    </ul>
                </div>

                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="upload-area" onclick="document.getElementById('csv_file').click();">
                        <i class="fas fa-file-csv"></i>
                        <p>Click to select CSV file or drag and drop</p>
                        <p style="font-size: 0.7rem; margin-top: 8px;">Supported format: .csv</p>
                        <input type="file" name="csv_file" id="csv_file" accept=".csv" style="display: none;" required>
                    </div>
                    
                    <div style="display: flex; gap: 12px; justify-content: center; margin-top: 20px; flex-wrap: wrap;">
                        <button type="button" class="btn-sample" onclick="window.location.href='?download_sample=1'">
                            <i class="fas fa-download"></i> Download Sample CSV
                        </button>
                        <button type="submit" class="btn-upload">
                            <i class="fas fa-upload"></i> Upload CSV
                        </button>
                        <a href="household.php" class="btn-back">
                            <i class="fas fa-arrow-left"></i> Back to Households
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <div class="bottom-nav">
            <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
            <a href="household.php" class="nav-item active">
                <i class="fas fa-users"></i>
                <span>Households</span>
            </a>
            <a href="reports.php" class="nav-item">
                <i class="fas fa-file-alt"></i>
                <span>Reports</span>
            </a>
        </div>
    </div>

    <script>
        document.getElementById('csv_file').addEventListener('change', function() {
            if(this.files.length > 0) {
                this.form.submit();
            }
        });
        
        const dropZone = document.querySelector('.upload-area');
        dropZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.style.borderColor = '#F5B042';
            this.style.background = '#FFF9EF';
        });
        dropZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            this.style.borderColor = '#E2E8F0';
            this.style.background = 'transparent';
        });
        dropZone.addEventListener('drop', function(e) {
            e.preventDefault();
            this.style.borderColor = '#E2E8F0';
            this.style.background = 'transparent';
            const file = e.dataTransfer.files[0];
            if(file && file.name.endsWith('.csv')) {
                document.getElementById('csv_file').files = e.dataTransfer.files;
                document.getElementById('csv_file').form.submit();
            } else {
                alert('Please upload a CSV file.');
            }
        });
    </script>
</body>
</html>