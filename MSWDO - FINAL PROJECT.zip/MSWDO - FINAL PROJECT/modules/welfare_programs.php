<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$program = isset($_GET['program']) ? $_GET['program'] : '';
$error = '';
$success = '';

// Get user's household
$stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
$stmt->execute([$user_id]);
$household = $stmt->fetch();

// Program details
$programs = [
    'solo_parent' => [
        'name' => 'Solo Parent Program',
        'icon' => '👩‍👧',
        'color' => '#e74c3c',
        'description' => 'Financial and social assistance for solo parents raising children alone.',
        'requirements' => [
            'Must be a solo parent',
            'Resident of the municipality',
            'Have dependent children',
            'Income below poverty threshold'
        ],
        'benefits' => [
            'Monthly stipend',
            'Educational assistance for children',
            'Medical assistance',
            'Skills training opportunities'
        ],
        'documents' => [
            'Birth certificate of children',
            'Barangay certification',
            'Proof of income',
            'Valid ID'
        ]
    ],
    'senior_citizen' => [
        'name' => 'Senior Citizen Program',
        'icon' => '👴',
        'color' => '#3498db',
        'description' => 'Benefits and privileges for senior citizens aged 60 and above.',
        'requirements' => [
            'Age 60 years old and above',
            'Resident of the municipality',
            'Registered senior citizen'
        ],
        'benefits' => [
            'Social pension',
            'Medical and dental services',
            'Transportation discount',
            'Special discounts on select establishments'
        ],
        'documents' => [
            'Birth certificate',
            'Senior citizen ID',
            'Barangay clearance',
            '2x2 photo'
        ]
    ],
    'pwd' => [
        'name' => 'Persons with Disability (PWD) Program',
        'icon' => '♿',
        'color' => '#27ae60',
        'description' => 'Support and assistance for persons with disabilities.',
        'requirements' => [
            'Medical certification of disability',
            'Resident of the municipality',
            'Registered PWD'
        ],
        'benefits' => [
            'Monthly assistance',
            'Medical assistance',
            'Livelihood support',
            'Accessible services'
        ],
        'documents' => [
            'Medical certificate',
            'Barangay certification',
            'Valid ID',
            'PWD ID application form'
        ]
    ],
    'aics' => [
        'name' => 'Assistance to Individuals in Crisis Situation (AICS)',
        'icon' => '💰',
        'color' => '#f39c12',
        'description' => 'Emergency financial and material assistance for individuals in crisis.',
        'requirements' => [
            'Experiencing crisis situation',
            'Resident of the municipality',
            'Proof of income'
        ],
        'benefits' => [
            'Financial assistance',
            'Medical assistance',
            'Burial assistance',
            'Food packs'
        ],
        'documents' => [
            'Barangay certification',
            'Medical certificate (if applicable)',
            'Police/accident report (if applicable)',
            'Valid ID'
        ]
    ]
];

$current_program = $programs[$program] ?? null;

// Handle application submission
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply'])) {
    if(!$household) {
        $error = "Please complete your household data first before applying.";
    } else {
        $household_id = $household['id'];
        $program_type = $_POST['program_type'];
        $application_data = [
            'needs_assessment' => $_POST['needs_assessment'] ?? '',
            'emergency_type' => $_POST['emergency_type'] ?? null,
            'monthly_income' => $_POST['monthly_income'] ?? null,
            'additional_info' => $_POST['additional_info'] ?? ''
        ];
        
        // Check if already applied
        $stmt = $pdo->prepare("SELECT id FROM welfare_applications WHERE user_id = ? AND program_type = ? AND status IN ('pending', 'approved')");
        $stmt->execute([$user_id, $program_type]);
        if($stmt->fetch()) {
            $error = "You already have a pending or approved application for this program.";
        } else {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO welfare_applications (user_id, household_id, program_type, status, application_data, created_at)
                    VALUES (?, ?, ?, 'pending', ?, NOW())
                ");
                $stmt->execute([$user_id, $household_id, $program_type, json_encode($application_data)]);
                $success = "Your application has been submitted successfully! Please wait for review.";
                
                // Log application
                $log_stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address, created_at) VALUES (?, 'application', ?, ?, NOW())");
                $log_stmt->execute([$user_id, "Submitted application for: $program_type", $_SERVER['REMOTE_ADDR']]);
                
            } catch(PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Get user's applications
$stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$my_applications = $stmt->fetchAll();

// If staff/admin, get all pending applications
$pending_applications = [];
if($role != 'resident') {
    $stmt = $pdo->prepare("
        SELECT wa.*, u.full_name as applicant_name, u.username, h.barangay 
        FROM welfare_applications wa
        LEFT JOIN users u ON wa.user_id = u.id
        LEFT JOIN households h ON wa.household_id = h.id
        WHERE wa.status = 'pending'
        ORDER BY wa.created_at ASC
    ");
    $stmt->execute();
    $pending_applications = $stmt->fetchAll();
}

// Handle application review (staff/admin)
if(isset($_POST['review_application']) && $role != 'resident') {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    $review_notes = $_POST['review_notes'] ?? '';
    
    $status = $action == 'approve' ? 'approved' : 'rejected';
    
    $stmt = $pdo->prepare("
        UPDATE welfare_applications 
        SET status = ?, reviewed_by = ?, review_notes = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([$status, $_SESSION['user_id'], $review_notes, $application_id]);
    
    $success = "Application " . ($status == 'approved' ? 'approved' : 'rejected') . " successfully!";
    
    // Refresh pending list
    $stmt = $pdo->prepare("
        SELECT wa.*, u.full_name as applicant_name, u.username, h.barangay 
        FROM welfare_applications wa
        LEFT JOIN users u ON wa.user_id = u.id
        LEFT JOIN households h ON wa.household_id = h.id
        WHERE wa.status = 'pending'
        ORDER BY wa.created_at ASC
    ");
    $stmt->execute();
    $pending_applications = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Welfare Programs - MSWDO</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .program-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 30px;
            text-align: center;
            border-radius: var(--radius-lg);
            margin-bottom: 25px;
        }
        .program-icon {
            font-size: 4rem;
            margin-bottom: 10px;
        }
        .info-section {
            background: var(--gray-100);
            padding: 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
        }
        .info-section h4 {
            margin-bottom: 15px;
            color: var(--primary);
        }
        .info-list {
            list-style: none;
            padding-left: 0;
        }
        .info-list li {
            padding: 8px 0;
            padding-left: 25px;
            position: relative;
        }
        .info-list li:before {
            content: "✓";
            position: absolute;
            left: 0;
            color: var(--success);
            font-weight: bold;
        }
        .application-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid;
            box-shadow: var(--shadow-sm);
        }
        .status-pending { border-left-color: #f39c12; }
        .status-approved { border-left-color: #27ae60; }
        .status-rejected { border-left-color: #e74c3c; }
        .status-completed { border-left-color: #3498db; }
        .review-card {
            background: white;
            border-radius: var(--radius-lg);
            margin-bottom: 15px;
            overflow: hidden;
        }
        .programs-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        .program-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: var(--gray-800);
            transition: transform 0.3s;
            border: 1px solid var(--gray-200);
        }
        .program-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-md);
        }
        @media (max-width: 768px) {
            .programs-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="page-wrapper">
        <div class="top-bar">
            <a href="<?php echo $role == 'resident' ? '../dashboards/resident_dashboard.php' : '../dashboards/staff_dashboard.php'; ?>" class="nav-item" style="flex-direction: row; gap: var(--spacing-xs);">
                ← Back
            </a>
            <div class="logo" style="font-size: 1.25rem;">🎯 MSWDO Programs</div>
            <div style="width: 80px;"></div>
        </div>
        
        <div class="container">
            <?php if($error): ?>
                <div class="alert alert-danger">⚠️ <?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="alert alert-success">✅ <?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if($current_program): ?>
                <!-- Single Program View -->
                <div class="program-header" style="background: linear-gradient(135deg, <?php echo $current_program['color']; ?>, <?php echo $current_program['color']; ?>cc);">
                    <div class="program-icon"><?php echo $current_program['icon']; ?></div>
                    <h2><?php echo $current_program['name']; ?></h2>
                    <p><?php echo $current_program['description']; ?></p>
                </div>
                
                <div class="info-section">
                    <h4>📋 Requirements</h4>
                    <ul class="info-list">
                        <?php foreach($current_program['requirements'] as $req): ?>
                            <li><?php echo $req; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="info-section">
                    <h4>✨ Benefits</h4>
                    <ul class="info-list">
                        <?php foreach($current_program['benefits'] as $benefit): ?>
                            <li><?php echo $benefit; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="info-section">
                    <h4>📄 Required Documents</h4>
                    <ul class="info-list">
                        <?php foreach($current_program['documents'] as $doc): ?>
                            <li><?php echo $doc; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <?php if($role == 'resident'): ?>
                    <form method="POST" action="">
                        <input type="hidden" name="program_type" value="<?php echo $program; ?>">
                        
                        <div class="info-section">
                            <h4>📝 Application Form</h4>
                            
                            <div class="form-group">
                                <label class="form-label">Needs Assessment / Situation</label>
                                <textarea name="needs_assessment" class="form-control" rows="4" placeholder="Please describe your current situation and why you need this assistance..." required></textarea>
                            </div>
                            
                            <?php if($program == 'aics'): ?>
                            <div class="form-group">
                                <label class="form-label">Type of Emergency/Crisis</label>
                                <select name="emergency_type" class="form-control">
                                    <option value="">Select...</option>
                                    <option value="medical">Medical Emergency</option>
                                    <option value="death">Death/Burial</option>
                                    <option value="disaster">Disaster/Typhoon</option>
                                    <option value="accident">Accident</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <?php endif; ?>
                            
                            <div class="form-group">
                                <label class="form-label">Estimated Monthly Household Income (₱)</label>
                                <input type="number" name="monthly_income" class="form-control" placeholder="e.g., 5000">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Additional Information</label>
                                <textarea name="additional_info" class="form-control" rows="3" placeholder="Any other relevant information..."></textarea>
                            </div>
                        </div>
                        
                        <button type="submit" name="apply" class="btn btn-primary">📤 Submit Application</button>
                        <a href="welfare_programs.php" class="btn btn-outline">← Back to Programs</a>
                    </form>
                <?php endif; ?>
                
            <?php else: ?>
                <!-- Programs Grid View -->
                <div class="programs-grid">
                    <?php foreach($programs as $key => $prog): ?>
                        <a href="?program=<?php echo $key; ?>" class="program-card">
                            <div style="font-size: 3rem;"><?php echo $prog['icon']; ?></div>
                            <h3><?php echo $prog['name']; ?></h3>
                            <p class="text-muted" style="font-size: 0.8rem;"><?php echo substr($prog['description'], 0, 80); ?>...</p>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- My Applications -->
            <?php if($role == 'resident' && count($my_applications) > 0): ?>
                <div class="card" style="margin-top: 30px;">
                    <div class="card-header">
                        <h3>📋 My Applications</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach($my_applications as $app): ?>
                            <div class="application-card status-<?php echo $app['status']; ?>">
                                <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
                                    <strong><?php echo ucfirst(str_replace('_', ' ', $app['program_type'])); ?></strong>
                                    <span class="status-badge status-<?php echo $app['status']; ?>">
                                        <?php echo ucfirst($app['status']); ?>
                                    </span>
                                </div>
                                <div style="font-size: 0.8rem; color: var(--gray-600); margin-top: 8px;">
                                    Applied: <?php echo date('F d, Y', strtotime($app['created_at'])); ?>
                                </div>
                                <?php if($app['review_notes']): ?>
                                    <div style="margin-top: 8px; padding: 8px; background: var(--gray-100); border-radius: var(--radius-md); font-size: 0.8rem;">
                                        <strong>Review Notes:</strong> <?php echo htmlspecialchars($app['review_notes']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Pending Applications for Staff/Admin -->
            <?php if($role != 'resident' && count($pending_applications) > 0): ?>
                <div class="card" style="margin-top: 30px;">
                    <div class="card-header">
                        <h3>⏳ Pending Applications for Review</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach($pending_applications as $app): ?>
                            <div class="review-card">
                                <div style="padding: 15px; background: var(--gray-100);">
                                    <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
                                        <strong><?php echo htmlspecialchars($app['applicant_name']); ?></strong>
                                        <span><?php echo ucfirst(str_replace('_', ' ', $app['program_type'])); ?></span>
                                    </div>
                                    <div style="font-size: 0.8rem; color: var(--gray-600);">
                                        Barangay: <?php echo htmlspecialchars($app['barangay'] ?? 'N/A'); ?> | 
                                        Applied: <?php echo date('M d, Y', strtotime($app['created_at'])); ?>
                                    </div>
                                </div>
                                
                                <?php 
                                $app_data = json_decode($app['application_data'], true);
                                if($app_data): 
                                ?>
                                    <div style="padding: 15px; border-bottom: 1px solid var(--gray-200);">
                                        <div><strong>Needs Assessment:</strong> <?php echo nl2br(htmlspecialchars($app_data['needs_assessment'] ?? 'N/A')); ?></div>
                                        <?php if(isset($app_data['emergency_type']) && $app_data['emergency_type']): ?>
                                            <div style="margin-top: 8px;"><strong>Emergency Type:</strong> <?php echo htmlspecialchars($app_data['emergency_type']); ?></div>
                                        <?php endif; ?>
                                        <?php if(isset($app_data['monthly_income']) && $app_data['monthly_income']): ?>
                                            <div><strong>Monthly Income:</strong> ₱ <?php echo number_format($app_data['monthly_income'], 2); ?></div>
                                        <?php endif; ?>
                                        <?php if(isset($app_data['additional_info']) && $app_data['additional_info']): ?>
                                            <div><strong>Additional Info:</strong> <?php echo nl2br(htmlspecialchars($app_data['additional_info'])); ?></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <form method="POST" action="" style="padding: 15px; display: flex; gap: 10px; flex-wrap: wrap;">
                                    <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                    <textarea name="review_notes" class="form-control" placeholder="Review notes / reason for decision..." rows="2" style="flex: 2;"></textarea>
                                    <div style="display: flex; gap: 8px;">
                                        <button type="submit" name="review_application" value="approve" class="btn btn-success">✅ Approve</button>
                                        <button type="submit" name="review_application" value="reject" class="btn btn-danger">❌ Reject</button>
                                    </div>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>