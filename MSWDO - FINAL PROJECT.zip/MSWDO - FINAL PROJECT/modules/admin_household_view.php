<?php
session_start();
require_once '../config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Allow admin, staff, social_worker, encoder
$allowed_roles = ['admin', 'staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];

$household_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$stmt = $pdo->prepare("SELECT * FROM households WHERE id = ?");
$stmt->execute([$household_id]);
$household = $stmt->fetch();

if(!$household) {
    header("Location: admin_household.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM household_members WHERE household_id = ? ORDER BY id");
$stmt->execute([$household_id]);
$members = $stmt->fetchAll();

function classifyPovertyIncome($income) {
    if($income < 5000) return 'Extremely Poor';
    elseif($income >= 5000 && $income <= 10000) return 'Poor';
    elseif($income >= 10001 && $income <= 15000) return 'Low Income';
    elseif($income >= 15001 && $income <= 25000) return 'Lower Middle';
    else return 'Middle Income and Above';
}

$poverty_status = $household['poverty_status'] ?? classifyPovertyIncome($household['monthly_income'] ?? 0);

$doc_number = 'MSWDO-HH-' . date('Y') . '-' . str_pad($household_id, 5, '0', STR_PAD_LEFT);
$date_generated = date('F d, Y');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Household Details - MSWDO Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lucida+Calligraphy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: #E5E7EB;
            color: #334155;
            padding-bottom: 75px;
        }

        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 25px -3px rgb(0 0 0 / 0.15);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        .app { display: flex; min-height: 100vh; }

        /* SIDEBAR */
        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0; left: 0; bottom: 0;
            overflow-y: auto;
            z-index: 40;
            transition: transform 0.3s ease;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 28px; }
        .nav-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--gray-400); margin-bottom: 12px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; margin-bottom: 4px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; transition: all 0.2s ease; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }

        /* MAIN */
        .main-content { flex: 1; margin-left: 280px; padding: 24px 40px 80px 40px; }

        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--gray-300); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--white); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        /* ACTION BAR */
        .action-bar { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
        .btn-action {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 10px 20px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.8rem;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .btn-pdf {
            background: linear-gradient(135deg, #DC2626, #991B1B);
            color: white;
            box-shadow: 0 4px 12px rgba(220,38,38,0.3);
        }
        .btn-pdf:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(220,38,38,0.4); }
        .btn-back { background: var(--white); color: var(--primary); border: 1px solid var(--gray-200); }
        .btn-back:hover { background: var(--gray-50); }

        /* DOCUMENT */
        .document-wrapper {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            box-shadow: var(--shadow-lg);
            border-radius: 4px;
            overflow: hidden;
        }

        .document {
            padding: 40px 45px 30px 45px;
            background: white;
            font-family: Arial, sans-serif;
            font-size: 12pt;
            color: #000;
            line-height: 1.5;
        }

        /* LETTERHEAD */
        .doc-header {
            display: table;
            width: 100%;
            table-layout: fixed;
            padding-bottom: 12px;
            border-bottom: 3px double #000;
            margin-bottom: 22px;
            border-collapse: collapse;
        }
        .doc-header-logo-left {
            display: table-cell;
            width: 100px;
            vertical-align: middle;
            text-align: left;
        }
        .doc-header-center {
            display: table-cell;
            vertical-align: middle;
            text-align: center;
            line-height: 1.4;
            font-family: Arial, sans-serif;
            font-size: 12pt;
            padding: 0 10px;
        }
        .doc-header-logo-right {
            display: table-cell;
            width: 100px;
            vertical-align: middle;
            text-align: right;
        }
        .doc-header-logo-left img,
        .doc-header-logo-right img {
            display: inline-block;
            width: 85px;
            height: 85px;
            object-fit: contain;
            vertical-align: middle;
        }
        .doc-header-center .line1 {
            font-family: Arial, sans-serif;
            font-size: 12pt;
            font-weight: normal;
            color: #000;
        }
        .doc-header-center .line2 {
            font-family: Arial, sans-serif;
            font-size: 12pt;
            font-weight: bold;
            color: #000;
        }
        .doc-header-center .line3 {
            font-family: Arial, sans-serif;
            font-size: 12pt;
            font-weight: bold;
            color: #000;
        }
        .doc-header-center .office-title {
            font-family: 'Lucida Calligraphy', 'Lucida Handwriting', cursive;
            font-style: normal;
            font-weight: normal;
            font-size: 12pt;
            margin-top: 6px;
            color: #000;
        }

        /* TITLE */
        .doc-title-block { text-align: center; margin: 18px 0 22px 0; font-family: Arial, sans-serif; }
        .doc-title-block .doc-title {
            font-size: 15pt;
            font-weight: 700;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            text-decoration: underline;
            text-underline-offset: 4px;
            margin-bottom: 8px;
        }
        .doc-title-block .doc-meta {
            font-size: 10pt;
            color: #333;
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }

        /* SECTIONS */
        .doc-section { margin-bottom: 18px; font-family: Arial, sans-serif; }
        .doc-section-title {
            font-size: 12pt;
            font-weight: 700;
            background: #F1F5F9;
            padding: 7px 12px;
            border-left: 4px solid #1E4A8C;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        .doc-section-body { padding: 0 6px; }

        .doc-info-table { width: 100%; border-collapse: collapse; font-family: Arial, sans-serif; }
        .doc-info-table td {
            padding: 6px 8px;
            vertical-align: top;
            border-bottom: 1px dotted #CBD5E1;
            font-size: 12pt;
        }
        .doc-info-table td.label { width: 32%; font-weight: 600; color: #334155; }
        .doc-info-table td.value { color: #000; }
        .doc-info-table tr:last-child td { border-bottom: none; }

        .doc-members-table { width: 100%; border-collapse: collapse; font-size: 11pt; margin-top: 4px; font-family: Arial, sans-serif; }
        .doc-members-table th {
            background: #1E4A8C;
            color: white;
            padding: 8px 10px;
            text-align: left;
            font-weight: 600;
            font-size: 11pt;
            text-transform: uppercase;
            border: 1px solid #0A2F6C;
        }
        .doc-members-table td { padding: 6px 10px; border: 1px solid #CBD5E1; color: #000; font-size: 11pt; }
        .doc-members-table tr:nth-child(even) td { background: #F8FAFC; }
        .doc-members-table tr.no-members td { text-align: center; padding: 16px; font-style: italic; color: #64748B; }

        .doc-signature-block {
            display: flex;
            justify-content: space-between;
            gap: 40px;
            margin-top: 50px;
            padding-top: 12px;
            font-family: Arial, sans-serif;
        }
        .doc-signature-item { flex: 1; text-align: center; }
        .doc-signature-item .sig-line {
            border-top: 1px solid #000;
            margin-top: 50px;
            padding-top: 6px;
            font-size: 12pt;
            font-weight: 700;
            text-transform: uppercase;
        }
        .doc-signature-item .sig-role { font-size: 10pt; color: #475569; font-style: italic; margin-top: 2px; }

        /* SCREEN FOOTER */
        .doc-footer {
            margin-top: 30px;
            padding-top: 12px;
            border-top: 2px solid #000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12pt;
            color: #1E293B;
            gap: 12px;
            font-family: Arial, sans-serif;
        }
        .doc-footer .footer-left,
        .doc-footer .footer-right {
            display: flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }
        .doc-footer i { color: #1E4A8C; font-size: 14pt; margin-right: 4px; }

        /* BOTTOM NAV */
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: var(--white); display: flex; justify-content: space-around; padding: 8px 16px 12px; border-top: 1px solid var(--gray-200); z-index: 100; }
        .bottom-nav .nav-item { display: flex; flex-direction: column; align-items: center; font-size: 0.7rem; color: var(--gray-600); text-decoration: none; }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .menu-toggle:hover { background: var(--gray-100); }

        .sidebar-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 39; display: none; }
        .sidebar-overlay.active { display: block; }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .menu-toggle { display: block; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .document { padding: 20px 16px; }
            .doc-header-logo-left img,
            .doc-header-logo-right img { width: 60px; height: 60px; }
            .doc-signature-block { flex-direction: column; gap: 20px; }
            .doc-members-table { font-size: 9pt; }
            .doc-members-table th, .doc-members-table td { padding: 4px 6px; }
            .doc-info-table td { font-size: 10pt; }
            .doc-footer { flex-direction: column; align-items: flex-start; gap: 6px; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Administrator</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="manage_users.php" class="nav-item">
                    <i class="fas fa-users-cog"></i> <span>User Management</span>
                </a>
                <a href="admin_household.php" class="nav-item active">
                    <i class="fas fa-home"></i> <span>All Households</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="admin_povertyanalysis.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Poverty Analysis</span>
                </a>
                <a href="admin_reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
                <a href="../admin/recycle_bin.php" class="nav-item">
                    <i class="fas fa-trash-restore"></i> <span>Recycle Bin</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="admin_profile.php" class="nav-item">
                    <i class="fas fa-user-cog"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Household Details</h1>
                    <p>Complete household information</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="action-bar">
            <a href="admin_household_pdf.php?id=<?php echo $household_id; ?>" target="_blank" class="btn-action btn-pdf">
                <i class="fas fa-file-pdf"></i> Download as PDF
            </a>
            <a href="admin_household.php" class="btn-action btn-back">
                <i class="fas fa-arrow-left"></i> Back to Households
            </a>
        </div>

        <div class="document-wrapper">
            <div class="document">

                <div class="doc-header">
                    <div class="doc-header-logo-left">
                        <img src="../assets/img/cantilan_logo.png" alt="Cantilan Logo">
                    </div>
                    <div class="doc-header-center">
                        <div class="line1">Republic of the Philippines</div>
                        <div class="line2">PROVINCE OF SURIGAO DEL SUR</div>
                        <div class="line3">MUNICIPALITY OF CANTILAN</div>
                        <div class="office-title">MUNICIPAL SOCIAL WELFARE AND DEVELOPMENT OFFICE</div>
                    </div>
                    <div class="doc-header-logo-right">
                        <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                    </div>
                </div>

                <div class="doc-title-block">
                    <div class="doc-title">Household Data Record</div>
                    <div class="doc-meta">
                        <span><strong>Document No:</strong> <?php echo $doc_number; ?></span>
                        <span><strong>Date Generated:</strong> <?php echo $date_generated; ?></span>
                    </div>
                </div>

                <div class="doc-section">
                    <div class="doc-section-title">I. Household Head Information</div>
                    <div class="doc-section-body">
                        <table class="doc-info-table">
                            <tr>
                                <td class="label">Full Name</td>
                                <td class="value">
                                    <?php 
                                    $middle = $household['head_middle_name'] ? ' ' . $household['head_middle_name'] : '';
                                    echo htmlspecialchars($household['head_first_name'] . $middle . ' ' . $household['head_last_name']); 
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="label">Relation to Head</td>
                                <td class="value"><?php echo htmlspecialchars($household['relation_to_head'] ?? 'Self'); ?></td>
                            </tr>
                            <?php if(!empty($household['contact_number'])): ?>
                            <tr>
                                <td class="label">Contact Number</td>
                                <td class="value"><?php echo htmlspecialchars($household['contact_number']); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if(!empty($household['email'])): ?>
                            <tr>
                                <td class="label">Email Address</td>
                                <td class="value"><?php echo htmlspecialchars($household['email']); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td class="label">Total Members</td>
                                <td class="value"><?php echo count($members); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="doc-section">
                    <div class="doc-section-title">II. Address Information</div>
                    <div class="doc-section-body">
                        <table class="doc-info-table">
                            <tr>
                                <td class="label">Street / House No.</td>
                                <td class="value"><?php echo htmlspecialchars($household['address'] ?? 'Not specified'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Barangay</td>
                                <td class="value"><?php echo htmlspecialchars($household['barangay'] ?? 'Not specified'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">City / Municipality</td>
                                <td class="value"><?php echo htmlspecialchars($household['city_municipality'] ?? 'Cantilan'); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Province</td>
                                <td class="value"><?php echo htmlspecialchars($household['province'] ?? 'Surigao del Sur'); ?></td>
                            </tr>
                            <?php if(!empty($household['zip_code'])): ?>
                            <tr>
                                <td class="label">ZIP Code</td>
                                <td class="value"><?php echo htmlspecialchars($household['zip_code']); ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>

                <div class="doc-section">
                    <div class="doc-section-title">III. Economic Information</div>
                    <div class="doc-section-body">
                        <table class="doc-info-table">
                            <tr>
                                <td class="label">Monthly Household Income</td>
                                <td class="value">₱ <?php echo number_format($household['monthly_income'] ?? 0, 2); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Poverty Classification</td>
                                <td class="value"><?php echo $poverty_status; ?></td>
                            </tr>
                            <tr>
                                <td class="label">4Ps Beneficiary</td>
                                <td class="value"><?php echo ($household['is_4ps_beneficiary'] ?? 0) == 1 ? 'Yes' : 'No'; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="doc-section">
                    <div class="doc-section-title">IV. Household Members</div>
                    <div class="doc-section-body">
                        <table class="doc-members-table">
                            <thead>
                                <tr>
                                    <th style="width: 6%;">#</th>
                                    <th style="width: 30%;">Full Name</th>
                                    <th style="width: 18%;">Relationship</th>
                                    <th style="width: 8%;">Age</th>
                                    <th style="width: 15%;">Gender</th>
                                    <th style="width: 23%;">Occupation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($members) > 0): ?>
                                    <?php foreach($members as $index => $member): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars($member['first_name'] . ' ' . ($member['last_name'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($member['relationship'] ?? 'N/A'); ?></td>
                                            <td><?php echo $member['age'] ?? 'N/A'; ?></td>
                                            <td><?php echo htmlspecialchars($member['gender'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($member['occupation'] ?? 'N/A'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr class="no-members"><td colspan="6">No household members recorded.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php if(!empty($household['gps_latitude']) && !empty($household['gps_longitude'])): ?>
                <div class="doc-section">
                    <div class="doc-section-title">V. GPS Location</div>
                    <div class="doc-section-body">
                        <table class="doc-info-table">
                            <tr>
                                <td class="label">Latitude</td>
                                <td class="value"><?php echo htmlspecialchars($household['gps_latitude']); ?></td>
                            </tr>
                            <tr>
                                <td class="label">Longitude</td>
                                <td class="value"><?php echo htmlspecialchars($household['gps_longitude']); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

                <div class="doc-signature-block">
                    <div class="doc-signature-item">
                        <div class="sig-line">Prepared by:</div>
                        <div class="sig-role">MSWDO Staff / Encoder</div>
                    </div>
                    <div class="doc-signature-item">
                        <div class="sig-line">Certified Correct:</div>
                        <div class="sig-role">MSWDO Officer</div>
                    </div>
                </div>

                <div class="doc-footer">
                    <div class="footer-left">
                        <i class="fab fa-facebook"></i>
                        <span>Cantilan Municipal Social Welfare &amp; Development Office</span>
                    </div>
                    <div class="footer-right">
                        <i class="fas fa-envelope"></i>
                        <span>mswdo.cantilan@gmail.com</span>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="admin_household.php" class="nav-item active"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Poverty</span></a>
        <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
        });
    }
    if(overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
    }
</script>
</body>
</html>