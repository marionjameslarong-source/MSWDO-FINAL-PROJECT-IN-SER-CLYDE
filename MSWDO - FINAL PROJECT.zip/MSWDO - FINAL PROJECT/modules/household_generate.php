<?php
// ============================================================================
// HOUSEHOLD GENERATOR — Receives edited form data → generates PDF or Word
// File: modules/household_generate.php
// ============================================================================
session_start();
require_once '../config/database.php';
require_once '../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if(!isset($_SESSION['user_id'])) { header("Location: ../index.php"); exit(); }
$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) { header("Location: ../index.php"); exit(); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: household.php");
    exit();
}

$format = $_POST['format'] ?? 'pdf';

// ----- COLLECT EDITED DATA -----
$household_id = intval($_POST['household_id'] ?? 0);
$doc_number = $_POST['doc_number'] ?? '';
$date_generated = $_POST['date_generated'] ?? date('F d, Y');

$head_first_name = trim($_POST['head_first_name'] ?? '');
$head_middle_name = trim($_POST['head_middle_name'] ?? '');
$head_last_name = trim($_POST['head_last_name'] ?? '');
$relation_to_head = trim($_POST['relation_to_head'] ?? 'Self');
$total_members = intval($_POST['total_members'] ?? 0);

$address = trim($_POST['address'] ?? '');
$barangay = trim($_POST['barangay'] ?? '');
$city = trim($_POST['city_municipality'] ?? '');
$province = trim($_POST['province'] ?? '');

$monthly_income = floatval($_POST['monthly_income'] ?? 0);
$poverty_status = trim($_POST['poverty_status'] ?? '');
$is_4ps = intval($_POST['is_4ps_beneficiary'] ?? 0);

$gps_lat = trim($_POST['gps_latitude'] ?? '');
$gps_lng = trim($_POST['gps_longitude'] ?? '');

// Members
$member_names = $_POST['member_name'] ?? [];
$member_rels = $_POST['member_relationship'] ?? [];
$member_ages = $_POST['member_age'] ?? [];
$member_genders = $_POST['member_gender'] ?? [];
$member_occs = $_POST['member_occupation'] ?? [];

$members = [];
foreach ($member_names as $i => $name) {
    $name = trim($name);
    if ($name === '') continue; // skip empty rows
    $members[] = [
        'name' => $name,
        'relationship' => trim($member_rels[$i] ?? ''),
        'age' => trim($member_ages[$i] ?? ''),
        'gender' => trim($member_genders[$i] ?? ''),
        'occupation' => trim($member_occs[$i] ?? ''),
    ];
}

$full_name = trim($head_first_name . ' ' . $head_middle_name . ' ' . $head_last_name);
$income_display = 'PHP ' . number_format($monthly_income, 2);
$four_ps_display = ($is_4ps == 1) ? 'Yes' : 'No';

function e($t) { return htmlspecialchars($t ?? '', ENT_QUOTES, 'UTF-8'); }

// ----- LOGOS -----
function imageToBase64($path) {
    if (!$path || !file_exists($path)) return '';
    $data = file_get_contents($path);
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $mime = ($ext === 'jpg' || $ext === 'jpeg') ? 'image/jpeg' : 'image/png';
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

$cantilan_src = imageToBase64(__DIR__ . '/../assets/img/cantilan_logo.png');
$osca_src = imageToBase64(__DIR__ . '/../assets/img/osca_logo.png');
$logo_left = $cantilan_src ? '<img src="' . $cantilan_src . '" style="width:0.85in; height:0.85in;">' : '';
$logo_right = $osca_src ? '<img src="' . $osca_src . '" style="width:0.85in; height:0.85in;">' : '';

// ----- MEMBER ROWS HTML -----
$member_rows = '';
if (count($members) > 0) {
    foreach ($members as $i => $m) {
        $member_rows .= "<tr>"
            . "<td style='text-align:center;'>" . ($i + 1) . "</td>"
            . "<td>" . e($m['name']) . "</td>"
            . "<td>" . e($m['relationship']) . "</td>"
            . "<td style='text-align:center;'>" . e($m['age']) . "</td>"
            . "<td>" . e($m['gender']) . "</td>"
            . "<td>" . e($m['occupation']) . "</td>"
            . "</tr>";
    }
} else {
    $member_rows = "<tr><td colspan='6' style='text-align:center; font-style:italic; color:#666; padding:10px;'>No household members recorded.</td></tr>";
}

$gps_section = '';
if ($gps_lat !== '' && $gps_lng !== '') {
    $gps_section = "
        <div class='section'>
            <div class='section-title'>V. GPS LOCATION</div>
            <table class='info-table'>
                <tr><td class='label'>Latitude</td><td class='value'>" . e($gps_lat) . "</td></tr>
                <tr><td class='label'>Longitude</td><td class='value'>" . e($gps_lng) . "</td></tr>
            </table>
        </div>
    ";
}

// ----- SHARED HTML TEMPLATE (used by both PDF and Word) -----
$body_html = "
    <div class='doc-title-block'>
        <div class='doc-title'>Household Data Record</div>
        <div class='doc-meta'>
            <span><strong>Document No:</strong> {$doc_number}</span>
            <span><strong>Date Generated:</strong> {$date_generated}</span>
        </div>
    </div>

    <div class='section'>
        <div class='section-title'>I. HOUSEHOLD HEAD INFORMATION</div>
        <table class='info-table'>
            <tr><td class='label'>Full Name</td><td class='value'>" . e($full_name) . "</td></tr>
            <tr><td class='label'>Relation to Head</td><td class='value'>" . e($relation_to_head) . "</td></tr>
            <tr><td class='label'>Total Members</td><td class='value'>" . e($total_members) . "</td></tr>
        </table>
    </div>

    <div class='section'>
        <div class='section-title'>II. ADDRESS INFORMATION</div>
        <table class='info-table'>
            <tr><td class='label'>Street / House No.</td><td class='value'>" . e($address) . "</td></tr>
            <tr><td class='label'>Barangay</td><td class='value'>" . e($barangay) . "</td></tr>
            <tr><td class='label'>City / Municipality</td><td class='value'>" . e($city) . "</td></tr>
            <tr><td class='label'>Province</td><td class='value'>" . e($province) . "</td></tr>
        </table>
    </div>

    <div class='section'>
        <div class='section-title'>III. ECONOMIC INFORMATION</div>
        <table class='info-table'>
            <tr><td class='label'>Monthly Household Income</td><td class='value'>{$income_display}</td></tr>
            <tr><td class='label'>Poverty Classification</td><td class='value'>" . e($poverty_status) . "</td></tr>
            <tr><td class='label'>4Ps Beneficiary</td><td class='value'>{$four_ps_display}</td></tr>
        </table>
    </div>

    <div class='section'>
        <div class='section-title'>IV. HOUSEHOLD MEMBERS</div>
        <table class='members-table'>
            <thead>
                <tr>
                    <th style='width:7%; text-align:center;'>#</th>
                    <th style='width:28%;'>FULL NAME</th>
                    <th style='width:18%;'>RELATIONSHIP</th>
                    <th style='width:8%; text-align:center;'>AGE</th>
                    <th style='width:14%;'>GENDER</th>
                    <th style='width:25%;'>OCCUPATION</th>
                </tr>
            </thead>
            <tbody>
                {$member_rows}
            </tbody>
        </table>
    </div>

    {$gps_section}

    <div class='signature-block'>
        <table>
            <tr>
                <td>
                    <div class='sig-line'>PREPARED BY:</div>
                    <div class='sig-role'>MSWDO Staff / Encoder</div>
                </td>
                <td>
                    <div class='sig-line'>CERTIFIED CORRECT:</div>
                    <div class='sig-role'>MSWDO Officer / OSCA Head</div>
                </td>
            </tr>
        </table>
    </div>
";

// ============================================================================
// GENERATE PDF
// ============================================================================
if ($format === 'pdf') {
    $html = <<<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
    @page { size: A4; margin: 1in 1in 1in 1in; }
    * { font-family: Arial, Helvetica, sans-serif; font-size: 12pt; color: #000; }
    body { font-family: Arial; font-size: 12pt; color: #000; line-height: 1.4; }
    .pdf-header { position: fixed; top: -0.75in; left: 0; right: 0; width: 100%; height: 0.85in; border-bottom: 3px double #000; padding-bottom: 4px; }
    .pdf-header table { width: 100%; border-collapse: collapse; table-layout: fixed; }
    .pdf-header td { vertical-align: middle; border: none; padding: 0; }
    .pdf-header .logo-cell { width: 1in; text-align: center; }
    .pdf-header .logo-cell img { width: 0.85in; height: 0.85in; }
    .pdf-header .center-cell { text-align: center; line-height: 1.25; }
    .pdf-header .line1 { font-family: Arial; font-size: 12pt; font-weight: normal; }
    .pdf-header .line2 { font-family: Arial; font-size: 12pt; font-weight: bold; }
    .pdf-header .line3 { font-family: Arial; font-size: 12pt; font-weight: bold; }
    .pdf-header .office-title { font-family: Arial; font-size: 12pt; font-style: italic; font-weight: bold; margin-top: 2px; }
    .pdf-footer { position: fixed; bottom: -0.75in; left: 0; right: 0; width: 100%; height: 0.7in; border-top: 2px solid #000; padding-top: 6px; }
    .pdf-footer table { width: 100%; border-collapse: collapse; }
    .pdf-footer td { border: none; padding: 0; font-family: Arial; font-size: 12pt; vertical-align: middle; }
    .pdf-footer .footer-left { text-align: left; }
    .pdf-footer .footer-right { text-align: right; }
    .pdf-footer .stamp { text-align: center; font-family: Arial; font-size: 9pt; color: #666; font-style: italic; margin-top: 4px; }
    .content { margin-top: 0.2in; }
    .doc-title-block { text-align: center; margin: 12px 0 20px 0; }
    .doc-title { font-size: 14pt; font-weight: bold; text-transform: uppercase; letter-spacing: 2px; text-decoration: underline; margin-bottom: 8px; }
    .doc-meta { font-size: 12pt; text-align: center; }
    .doc-meta span { display: inline-block; margin: 0 15px; }
    .section { margin-bottom: 14px; }
    .section-title { font-size: 12pt; font-weight: bold; background-color: #F1F5F9; padding: 6px 10px; border-left: 4px solid #1E4A8C; margin-bottom: 8px; text-transform: uppercase; }
    .info-table { width: 100%; border-collapse: collapse; }
    .info-table td { font-size: 12pt; padding: 5px 8px; vertical-align: top; border-bottom: 1px dotted #999; }
    .info-table td.label { width: 32%; font-weight: bold; }
    .info-table tr:last-child td { border-bottom: none; }
    .members-table { width: 100%; border-collapse: collapse; }
    .members-table th { font-size: 12pt; background-color: #1E4A8C; color: #FFF; padding: 6px 8px; text-align: left; font-weight: bold; border: 1px solid #0A2F6C; }
    .members-table td { font-size: 12pt; padding: 5px 8px; border: 1px solid #CCC; }
    .signature-block { margin-top: 40px; }
    .signature-block table { width: 100%; border-collapse: collapse; }
    .signature-block td { width: 50%; text-align: center; border: none; padding: 0 20px; vertical-align: bottom; }
    .sig-line { border-top: 1px solid #000; padding-top: 4px; font-size: 12pt; font-weight: bold; text-transform: uppercase; margin-top: 40px; }
    .sig-role { font-size: 12pt; font-style: italic; color: #333; margin-top: 2px; }
    .section, .signature-block, .doc-title-block { page-break-inside: avoid; }
    .members-table tr { page-break-inside: avoid; }
</style>
</head>
<body>
<div class="pdf-header">
    <table>
        <tr>
            <td class="logo-cell">{$logo_left}</td>
            <td class="center-cell">
                <div class="line1">Republic of the Philippines</div>
                <div class="line2">PROVINCE OF SURIGAO DEL SUR</div>
                <div class="line3">MUNICIPALITY OF CANTILAN</div>
                <div class="office-title">OFFICE OF THE SENIOR CITIZENS AFFAIRS</div>
            </td>
            <td class="logo-cell">{$logo_right}</td>
        </tr>
    </table>
</div>
<div class="pdf-footer">
    <table>
        <tr>
            <td class="footer-left">Office for the Senior Citizens Affairs &ndash; LGU Cantilan</td>
            <td class="footer-right">oscacantilan@gmail.com</td>
        </tr>
    </table>
    <div class="stamp">
        This document is system-generated by MSWDO Portal. Unauthorized reproduction is prohibited. | Generated on {$date_generated}
    </div>
</div>
<div class="content">
    {$body_html}
</div>
</body>
</html>
HTML;

    $options = new Options();
    $options->set('isRemoteEnabled', true);
    $options->set('isHtml5ParserEnabled', true);
    $options->set('chroot', realpath(__DIR__ . '/..'));
    $options->set('defaultFont', 'Arial');
    $options->set('dpi', 120);

    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    $filename = 'Household_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $head_last_name) . '_' . $household_id . '.pdf';
    $dompdf->stream($filename, ['Attachment' => true]);
    exit();
}

// ============================================================================
// GENERATE WORD (.docx)
// ============================================================================
if ($format === 'word') {
    // Use HTML-to-Word trick: browsers/Word handle .doc HTML content as Word
    $filename = 'Household_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $head_last_name) . '_' . $household_id . '.doc';

    header('Content-Type: application/msword');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    header('Pragma: public');

    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">';
    echo '<head><meta charset="utf-8">';
    echo '<style>';
    echo '@page WordSection1 { size: 8.27in 11.69in; margin: 1in 1in 1in 1in; }';
    echo 'body { font-family: Arial; font-size: 12pt; }';
    echo '.doc-title { font-size: 14pt; font-weight: bold; text-align: center; text-transform: uppercase; text-decoration: underline; }';
    echo '.doc-meta { text-align: center; margin-bottom: 20px; }';
    echo '.section-title { font-size: 12pt; font-weight: bold; background: #F1F5F9; padding: 6px 10px; border-left: 4px solid #1E4A8C; text-transform: uppercase; margin-top: 14px; }';
    echo '.info-table { width: 100%; border-collapse: collapse; }';
    echo '.info-table td { font-size: 12pt; padding: 5px 8px; border-bottom: 1px dotted #999; }';
    echo '.info-table td.label { width: 32%; font-weight: bold; }';
    echo '.members-table { width: 100%; border-collapse: collapse; }';
    echo '.members-table th { font-size: 12pt; background: #1E4A8C; color: #FFF; padding: 6px 8px; text-align: left; border: 1px solid #0A2F6C; }';
    echo '.members-table td { font-size: 12pt; padding: 5px 8px; border: 1px solid #CCC; }';
    echo '.sig-line { border-top: 1px solid #000; padding-top: 4px; font-size: 12pt; font-weight: bold; text-transform: uppercase; margin-top: 40px; text-align: center; }';
    echo '.sig-role { font-size: 12pt; font-style: italic; text-align: center; margin-top: 2px; }';
    echo '</style></head><body>';

    // Header for Word (Word doesn't auto-repeat HTML headers, so add it inline)
    echo '<div style="text-align:center; border-bottom: 3px double #000; padding-bottom: 6px; margin-bottom: 14px;">';
    echo '<table style="width:100%; border-collapse: collapse;"><tr>';
    echo '<td style="width:1in; text-align:center; vertical-align:middle;">' . $logo_left . '</td>';
    echo '<td style="text-align:center; vertical-align:middle;">';
    echo '<div style="font-size:12pt;">Republic of the Philippines</div>';
    echo '<div style="font-size:12pt; font-weight:bold;">PROVINCE OF SURIGAO DEL SUR</div>';
    echo '<div style="font-size:12pt; font-weight:bold;">MUNICIPALITY OF CANTILAN</div>';
    echo '<div style="font-size:12pt; font-style:italic; font-weight:bold;">OFFICE OF THE SENIOR CITIZENS AFFAIRS</div>';
    echo '</td>';
    echo '<td style="width:1in; text-align:center; vertical-align:middle;">' . $logo_right . '</td>';
    echo '</tr></table></div>';

    echo $body_html;

    echo '</body></html>';
    exit();
}

// Unknown format
header("Location: household.php");
exit();