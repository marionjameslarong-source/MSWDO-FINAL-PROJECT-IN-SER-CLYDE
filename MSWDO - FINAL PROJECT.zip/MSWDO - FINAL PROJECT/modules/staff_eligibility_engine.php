<?php
// ============================================================================
// PROGRAM-BASED ELIGIBILITY ENGINE - Dynamic Program Decision Grid
// Two-Tier: Legitimacy Verification → Assistance Trigger Rules
// File: staff_eligibility_engine.php
// ============================================================================
session_start();
require_once '../config/database.php';

// Access control
if(!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['staff', 'social_worker', 'admin', 'vawc_desk_officer'])) {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$is_vawc_officer = in_array($role, ['admin', 'vawc_desk_officer']);

// Recycle bin badge
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
    $deleted_count = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $deleted_count = 0;
}

// ============================================================================
// 1. AUTO-CREATE + AUTO-REPAIR TABLES
// ============================================================================

function ensureProgramEngineTables($pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS eligibility_assessments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            application_id INT NULL,
            household_id INT NULL,
            applicant_user_id INT NULL,
            applicant_name VARCHAR(200) NOT NULL,
            barangay VARCHAR(100),
            contact_number VARCHAR(50),
            program_type VARCHAR(50) NOT NULL DEFAULT 'UNKNOWN',
            total_household_income DECIMAL(12,2) DEFAULT 0,
            pwd_count INT DEFAULT 0,
            senior_count INT DEFAULT 0,
            children_under_5_count INT DEFAULT 0,
            is_solo_parent TINYINT DEFAULT 0,
            total_members INT DEFAULT 1,
            vulnerability_score INT DEFAULT 0,
            decision VARCHAR(50) DEFAULT 'PENDING',
            priority_level VARCHAR(30) DEFAULT 'Low',
            decision_reason TEXT,
            rule_trace TEXT,
            status VARCHAR(50) DEFAULT 'AUTO_RECOMMENDATION',
            reviewed_by_staff_id INT NULL,
            review_notes TEXT,
            reviewed_at DATETIME NULL,
            override_decision VARCHAR(50) NULL,
            assessed_by_staff_id INT NULL,
            is_vawc_case TINYINT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_decision (decision),
            INDEX idx_priority (priority_level),
            INDEX idx_barangay (barangay),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS resident_sector_profiles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL UNIQUE,
            is_verified_solo_parent TINYINT DEFAULT 0,
            solo_parent_id_number VARCHAR(50),
            minor_dependents_count INT DEFAULT 0,
            is_verified_senior TINYINT DEFAULT 0,
            senior_id_number VARCHAR(50),
            has_active_pension TINYINT DEFAULT 0,
            is_verified_pwd TINYINT DEFAULT 0,
            pwd_id_number VARCHAR(50),
            disability_type VARCHAR(100),
            has_active_vawc_blotter TINYINT DEFAULT 0,
            vawc_case_reference VARCHAR(100),
            monthly_income DECIMAL(12,2) DEFAULT 0,
            is_cantilan_resident TINYINT DEFAULT 1,
            has_fraud_flag TINYINT DEFAULT 0,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS auto_rejection_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            applicant_user_id INT,
            applicant_name VARCHAR(200),
            program_type VARCHAR(50),
            tier_failed VARCHAR(30),
            rejection_code VARCHAR(50),
            rejection_reason TEXT,
            logged_by_staff_id INT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS eligibility_appeals (
            id INT AUTO_INCREMENT PRIMARY KEY,
            assessment_id INT NOT NULL,
            appellant_name VARCHAR(200) NOT NULL,
            appeal_reason TEXT NOT NULL,
            crisis_type VARCHAR(100),
            supporting_documents TEXT,
            status VARCHAR(50) DEFAULT 'PENDING_REVIEW',
            reviewed_by_staff_id INT NULL,
            review_notes TEXT,
            reviewed_at DATETIME NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_appeal_assessment (assessment_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}

function autoRepairTableSchemas($pdo) {
    $required_columns = [
        'eligibility_assessments' => [
            'program_type' => "VARCHAR(50) NOT NULL DEFAULT 'UNKNOWN'",
            'application_id' => "INT NULL",
            'household_id' => "INT NULL",
            'applicant_user_id' => "INT NULL",
            'contact_number' => "VARCHAR(50)",
            'total_household_income' => "DECIMAL(12,2) DEFAULT 0",
            'pwd_count' => "INT DEFAULT 0",
            'senior_count' => "INT DEFAULT 0",
            'children_under_5_count' => "INT DEFAULT 0",
            'is_solo_parent' => "TINYINT DEFAULT 0",
            'total_members' => "INT DEFAULT 1",
            'vulnerability_score' => "INT DEFAULT 0",
            'decision' => "VARCHAR(50) DEFAULT 'PENDING'",
            'priority_level' => "VARCHAR(30) DEFAULT 'Low'",
            'decision_reason' => "TEXT",
            'rule_trace' => "TEXT",
            'status' => "VARCHAR(50) DEFAULT 'AUTO_RECOMMENDATION'",
            'reviewed_by_staff_id' => "INT NULL",
            'review_notes' => "TEXT",
            'reviewed_at' => "DATETIME NULL",
            'override_decision' => "VARCHAR(50) NULL",
            'assessed_by_staff_id' => "INT NULL",
            'is_vawc_case' => "TINYINT DEFAULT 0",
            'created_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP",
            'updated_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
        ],
        'resident_sector_profiles' => [
            'is_verified_solo_parent' => "TINYINT DEFAULT 0",
            'solo_parent_id_number' => "VARCHAR(50)",
            'minor_dependents_count' => "INT DEFAULT 0",
            'is_verified_senior' => "TINYINT DEFAULT 0",
            'senior_id_number' => "VARCHAR(50)",
            'has_active_pension' => "TINYINT DEFAULT 0",
            'is_verified_pwd' => "TINYINT DEFAULT 0",
            'pwd_id_number' => "VARCHAR(50)",
            'disability_type' => "VARCHAR(100)",
            'has_active_vawc_blotter' => "TINYINT DEFAULT 0",
            'vawc_case_reference' => "VARCHAR(100)",
            'monthly_income' => "DECIMAL(12,2) DEFAULT 0",
            'is_cantilan_resident' => "TINYINT DEFAULT 1",
            'has_fraud_flag' => "TINYINT DEFAULT 0",
        ],
    ];
    
    foreach ($required_columns as $table => $columns) {
        try {
            $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
            $stmt->execute([$table]);
            if ($stmt->rowCount() == 0) continue;
            
            $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
            $existing = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($columns as $col_name => $col_def) {
                if (!in_array($col_name, $existing)) {
                    try {
                        $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$col_name` $col_def");
                    } catch (PDOException $e) {}
                }
            }
        } catch (PDOException $e) {}
    }
}

try {
    ensureProgramEngineTables($pdo);
    autoRepairTableSchemas($pdo);
} catch (PDOException $e) {}

// ============================================================================
// 2. AUTO-DETECT welfare_applications columns
// ============================================================================

$program_column = null;
$status_column = 'status';
$appdata_column = 'application_data';
$existing_welfare_cols = [];
$welfare_table_exists = false;

try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'welfare_applications'");
    $welfare_table_exists = $stmt->rowCount() > 0;
    
    if ($welfare_table_exists) {
        $col_stmt = $pdo->query("SHOW COLUMNS FROM welfare_applications");
        $existing_welfare_cols = $col_stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $candidates = ['program_type', 'application_type', 'application_program', 'program', 'type', 'category', 'assistance_type'];
        foreach ($candidates as $c) {
            if (in_array($c, $existing_welfare_cols)) { $program_column = $c; break; }
        }
        
        $status_candidates = ['status', 'application_status', 'app_status', 'state'];
        foreach ($status_candidates as $c) {
            if (in_array($c, $existing_welfare_cols)) { $status_column = $c; break; }
        }
        
        $appdata_candidates = ['application_data', 'form_data', 'data', 'details', 'metadata'];
        foreach ($appdata_candidates as $c) {
            if (in_array($c, $existing_welfare_cols)) { $appdata_column = $c; break; }
        }
    }
} catch (PDOException $e) {}

// ============================================================================
// 3. POVERTY CLASSIFICATION HELPER (3-Class Standard)
// ============================================================================

function getPovertyClass($income) {
    $income = floatval($income);
    if ($income >= 5000 && $income <= 10000) {
        return 'POOR';
    } elseif ($income > 10000 && $income <= 25000) {
        return 'MIDDLE-CLASS';
    } elseif ($income > 25000) {
        return 'RICH';
    }
    return 'NOT CLASSIFIED';
}

// ============================================================================
// 4. PROGRAM-BASED EVALUATION
// ============================================================================

function evaluateProgramBasedAssistance($applicantId, $programType, $submittedEvidence, $pdo) {
    $programType = strtoupper($programType);
    $trace = [];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'resident'");
    $stmt->execute([$applicantId]);
    $resident = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$resident) {
        return [
            'status' => 'REJECTED', 'priority' => 'Low',
            'reason' => 'Applicant profile does not exist in the official resident database.',
            'tier_failed' => 'TIER_1_LEGITIMACY', 'rejection_code' => 'RESIDENT_NOT_FOUND',
            'trace' => ['Tier 1: Resident lookup FAILED']
        ];
    }
    
    $stmt = $pdo->prepare("SELECT * FROM resident_sector_profiles WHERE user_id = ?");
    $stmt->execute([$applicantId]);
    $sectorProfile = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    
    $trace[] = "Tier 1: Resident found — " . $resident['full_name'];
    $trace[] = "Tier 1: Sector profile loaded";
    
    if (($sectorProfile['has_fraud_flag'] ?? 0) == 1) {
        return [
            'status' => 'REJECTED', 'priority' => 'Low',
            'reason' => 'Applicant has an active fraud flag in the municipal registry.',
            'tier_failed' => 'TIER_1_LEGITIMACY', 'rejection_code' => 'FRAUD_FLAG_ACTIVE',
            'trace' => array_merge($trace, ['Tier 1: FRAUD FLAG → REJECTED'])
        ];
    }
    
    switch ($programType) {
        case 'SOLO_PARENT':
            if (($sectorProfile['is_verified_solo_parent'] ?? 0) != 1) {
                return ['status' => 'REJECTED', 'priority' => 'Low',
                    'reason' => 'No active, verified Solo Parent ID found on record.',
                    'tier_failed' => 'TIER_1_LEGITIMACY', 'rejection_code' => 'UNVERIFIED_SOLO_PARENT_ID',
                    'trace' => array_merge($trace, ['Tier 1: Solo Parent ID NOT VERIFIED → REJECTED'])];
            }
            $trace[] = "Tier 1: Solo Parent ID VERIFIED";
            
            $income = floatval($sectorProfile['monthly_income'] ?? 0);
            $dependents = intval($sectorProfile['minor_dependents_count'] ?? 0);
            $povertyClass = getPovertyClass($income);
            
            $trace[] = "Tier 2: Poverty Class = $povertyClass (Income: ₱" . number_format($income, 2) . ")";
            
            if ($povertyClass === 'POOR' || $povertyClass === 'MIDDLE-CLASS' || $dependents >= 2) {
                $trace[] = "Tier 2: $povertyClass OR $dependents minors ≥ 2 → APPROVED High";
                return ['status' => 'APPROVED', 'priority' => 'High',
                    'reason' => "Verified Solo Parent classified as $povertyClass" . ($dependents >= 2 ? " with $dependents minor dependents" : "") . ".",
                    'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
            }
            $trace[] = "Tier 2: RICH classification without dependents → WAITLISTED";
            return ['status' => 'WAITLISTED', 'priority' => 'Low',
                'reason' => 'Profile verified, but economic classification exceeds baseline budget priority.',
                'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
        
        case 'SENIOR_CITIZEN':
            if (($sectorProfile['is_verified_senior'] ?? 0) != 1) {
                return ['status' => 'REJECTED', 'priority' => 'Low',
                    'reason' => 'Applicant does not match Senior Citizen requirements.',
                    'tier_failed' => 'TIER_1_LEGITIMACY', 'rejection_code' => 'UNVERIFIED_SENIOR_ID',
                    'trace' => array_merge($trace, ['Tier 1: Senior ID NOT VERIFIED → REJECTED'])];
            }
            $trace[] = "Tier 1: Senior ID VERIFIED";
            if (($sectorProfile['has_active_pension'] ?? 0) == 0) {
                $trace[] = "Tier 2: No active pension → APPROVED Critical";
                return ['status' => 'APPROVED', 'priority' => 'Critical',
                    'reason' => 'Verified Indigent Senior Citizen with no regular pension source.',
                    'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
            }
            $trace[] = "Tier 2: Has pension → PENDING_MANUAL_REVIEW";
            return ['status' => 'PENDING_MANUAL_REVIEW', 'priority' => 'Medium',
                'reason' => 'Verified senior with existing pension; requires manual casework validation.',
                'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
        
        case 'PWD':
            if (($sectorProfile['is_verified_pwd'] ?? 0) != 1) {
                return ['status' => 'REJECTED', 'priority' => 'Low',
                    'reason' => 'No matching verified PWD registry identifier found.',
                    'tier_failed' => 'TIER_1_LEGITIMACY', 'rejection_code' => 'UNVERIFIED_PWD_ID',
                    'trace' => array_merge($trace, ['Tier 1: PWD ID NOT VERIFIED → REJECTED'])];
            }
            $trace[] = "Tier 1: PWD ID VERIFIED";
            $disabilityType = $sectorProfile['disability_type'] ?? '';
            if (in_array($disabilityType, ['Severe Physical', 'Intellectual', 'Visual Impairment'])) {
                $trace[] = "Tier 2: Severe disability → APPROVED Critical";
                return ['status' => 'APPROVED', 'priority' => 'Critical',
                    'reason' => 'Verified PWD with categorized high-severity maintenance requirements.',
                    'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
            }
            $trace[] = "Tier 2: Standard disability → APPROVED Medium";
            return ['status' => 'APPROVED', 'priority' => 'Medium',
                'reason' => 'Verified PWD eligible for standard financial subsidy parameters.',
                'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
        
        case 'AICS':
            $crisisType = $submittedEvidence['crisis_type'] ?? '';
            $validCrises = ['Medical Assistance', 'Burial Assistance', 'Transportation Aid'];
            if (!in_array($crisisType, $validCrises)) {
                return ['status' => 'REJECTED', 'priority' => 'Low',
                    'reason' => 'Invalid AICS crisis categorization.',
                    'tier_failed' => 'TIER_1_LEGITIMACY', 'rejection_code' => 'INVALID_CRISIS_TYPE',
                    'trace' => array_merge($trace, ["Tier 1: Crisis type invalid → REJECTED"])];
            }
            $trace[] = "Tier 1: Crisis type valid";
            $hasIndigency = intval($submittedEvidence['has_barangay_indigency'] ?? 0);
            $hasReceipts = intval($submittedEvidence['has_official_receipts'] ?? 0);
            if ($hasIndigency == 1 && $hasReceipts == 1) {
                $trace[] = "Tier 2: Indigency + Receipts → APPROVED";
                return ['status' => 'APPROVED', 'priority' => 'High',
                    'reason' => 'Resident profile validated with structural medical or funeral evidence.',
                    'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
            }
            $trace[] = "Tier 2: Missing documents → RETURNED";
            return ['status' => 'RETURNED_FOR_CORRECTION', 'priority' => 'Medium',
                'reason' => 'Missing mandatory documents (Barangay Indigency Certificate or medical files).',
                'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
        
        case 'VAWC':
            if (($sectorProfile['has_active_vawc_blotter'] ?? 0) == 1) {
                $trace[] = "Tier 2: Active blotter → IMMEDIATE CRITICAL";
                return ['status' => 'APPROVED', 'priority' => 'IMMEDIATE_CRITICAL',
                    'reason' => 'Protective emergency framework trigger. Immediate allocation approved.',
                    'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
            }
            $trace[] = "Tier 2: No active blotter → PENDING_MANUAL_REVIEW";
            return ['status' => 'PENDING_MANUAL_REVIEW', 'priority' => 'High',
                'reason' => 'No active blotter reference. Forwarding for manual verification.',
                'tier_failed' => null, 'rejection_code' => null, 'trace' => $trace];
        
        default:
            return ['status' => 'REJECTED', 'priority' => 'Low',
                'reason' => 'Unknown municipal assistance program designation.',
                'tier_failed' => 'TIER_1_LEGITIMACY', 'rejection_code' => 'UNKNOWN_PROGRAM',
                'trace' => array_merge($trace, ["Unknown program → REJECTED"])];
    }
}

// ============================================================================
// 5. HANDLE POST ACTIONS
// ============================================================================

$assessment_success = '';
$assessment_error = '';
$review_success = '';
$review_error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['run_assessment'])) {
    try {
        $application_id = intval($_POST['application_id'] ?? 0);
        $user_id_sel = intval($_POST['applicant_user_id'] ?? 0);
        $program_type = strtoupper(trim($_POST['program_type'] ?? ''));
        $assessment_notes = trim($_POST['assessment_notes'] ?? '');
        
        if (!$application_id && !$user_id_sel) throw new Exception("Please select an application.");
        if (!$program_type) throw new Exception("Program type is required.");
        
        $target_user_id = $user_id_sel;
        $app_row = null;
        
        if ($application_id && $welfare_table_exists) {
            $stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE id = ?");
            $stmt->execute([$application_id]);
            $app_row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($app_row) $target_user_id = intval($app_row['user_id'] ?? $target_user_id);
        }
        
        if (!$target_user_id) throw new Exception("Cannot resolve applicant user ID.");
        
        $stmt = $pdo->prepare("SELECT full_name, contact_number FROM users WHERE id = ?");
        $stmt->execute([$target_user_id]);
        $user_row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $applicant_name = $user_row['full_name'] ?? 'Unknown';
        $contact_number = $user_row['contact_number'] ?? '';
        
        $stmt = $pdo->prepare("SELECT * FROM resident_sector_profiles WHERE user_id = ?");
        $stmt->execute([$target_user_id]);
        $sp = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $barangay = $sp['barangay'] ?? '';
        $income = floatval($sp['monthly_income'] ?? 0);
        
        if (!$barangay && $app_row && !empty($app_row[$appdata_column])) {
            $appData = json_decode($app_row[$appdata_column], true) ?: [];
            $barangay = $appData['barangay'] ?? '';
        }
        
        $submittedEvidence = [
            'crisis_type' => trim($_POST['crisis_type'] ?? ''),
            'has_barangay_indigency' => isset($_POST['has_barangay_indigency']) ? 1 : 0,
            'has_official_receipts' => isset($_POST['has_official_receipts']) ? 1 : 0
        ];
        
        $result = evaluateProgramBasedAssistance($target_user_id, $program_type, $submittedEvidence, $pdo);
        
        $scoreMap = ['IMMEDIATE_CRITICAL' => 100, 'Critical' => 90, 'High' => 70, 'Medium' => 50, 'Low' => 25];
        $priority = $result['priority'] ?? 'Low';
        $score = $scoreMap[$priority] ?? 25;
        $isVawc = ($program_type === 'VAWC') ? 1 : 0;
        
        $stmt = $pdo->prepare("
            INSERT INTO eligibility_assessments (
                application_id, applicant_user_id, applicant_name, barangay, contact_number,
                program_type, total_household_income, total_members,
                vulnerability_score, decision, priority_level, decision_reason, rule_trace,
                status, assessed_by_staff_id, review_notes, is_vawc_case
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'AUTO_RECOMMENDATION', ?, ?, ?)
        ");
        $stmt->execute([
            $application_id ?: null, $target_user_id, $applicant_name, $barangay, $contact_number,
            $program_type, $income, 1,
            $score, $result['status'], $priority, $result['reason'], json_encode($result['trace']),
            $user_id, $assessment_notes, $isVawc
        ]);
        
        $new_id = $pdo->lastInsertId();
        
        if ($result['status'] === 'REJECTED') {
            $stmt = $pdo->prepare("
                INSERT INTO auto_rejection_log 
                (applicant_user_id, applicant_name, program_type, tier_failed, rejection_code, rejection_reason, logged_by_staff_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $target_user_id, $applicant_name, $program_type,
                $result['tier_failed'] ?? 'TIER_2_TRIGGERS',
                $result['rejection_code'] ?? 'UNSPECIFIED',
                $result['reason'], $user_id
            ]);
        }
        
        $assessment_success = "✅ Assessment #$new_id complete! Program: <strong>$program_type</strong> — Status: <strong>{$result['status']}</strong> — Priority: <strong>$priority</strong>";
    } catch(Exception $e) {
        $assessment_error = "Error: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['review_decision'])) {
    try {
        $stmt = $pdo->prepare("
            UPDATE eligibility_assessments 
            SET status = ?, override_decision = ?, review_notes = ?, reviewed_by_staff_id = ?, reviewed_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([
            $_POST['review_status'], $_POST['override_decision'] ?? null,
            $_POST['review_notes'] ?? '', $user_id, intval($_POST['assessment_id'])
        ]);
        $review_success = "Decision finalized.";
    } catch(PDOException $e) { $review_error = "Failed: " . $e->getMessage(); }
}

// ============================================================================
// 6. LIVE ANALYTICS FROM welfare_applications
// ============================================================================

$live_program_stats = [
    'SOLO_PARENT' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'Solo Parent'],
    'SENIOR_CITIZEN' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'Senior Citizen'],
    'PWD' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'PWD'],
    'AICS' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'AICS'],
    'VAWC' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'VAWC']
];

$live_total = 0;
$live_pending = 0;
$live_approved = 0;
$live_rejected = 0;

try {
    if ($welfare_table_exists && $program_column) {
        $stmt = $pdo->query("
            SELECT `$program_column` as program, `$status_column` as status, COUNT(*) as count 
            FROM welfare_applications 
            GROUP BY `$program_column`, `$status_column`
        ");
        $rows = $stmt->fetchAll();
        
        foreach ($rows as $row) {
            $pt = strtoupper($row['program'] ?? '');
            $st = strtolower($row['status'] ?? '');
            $count = intval($row['count'] ?? 0);
            
            if (isset($live_program_stats[$pt])) {
                $live_program_stats[$pt]['total'] += $count;
                if ($st === 'pending') {
                    $live_program_stats[$pt]['pending'] = $count;
                    $live_pending += $count;
                } elseif ($st === 'approved') {
                    $live_program_stats[$pt]['approved'] = $count;
                    $live_approved += $count;
                } elseif ($st === 'rejected') {
                    $live_program_stats[$pt]['rejected'] = $count;
                    $live_rejected += $count;
                }
                $live_total += $count;
            }
        }
    }
} catch (PDOException $e) {}

// Live barangay distribution
$live_barangay_stats = [];
try {
    if ($welfare_table_exists && $appdata_column) {
        $stmt = $pdo->query("
            SELECT `$appdata_column` as data
            FROM welfare_applications
            WHERE `$appdata_column` IS NOT NULL
        ");
        foreach ($stmt->fetchAll() as $row) {
            $data = json_decode($row['data'] ?? '{}', true);
            if (!is_array($data)) continue;
            $brgy = trim($data['barangay'] ?? '');
            if (empty($brgy)) continue;
            if (!isset($live_barangay_stats[$brgy])) {
                $live_barangay_stats[$brgy] = ['total' => 0];
            }
            $live_barangay_stats[$brgy]['total']++;
        }
        uasort($live_barangay_stats, fn($a, $b) => $b['total'] - $a['total']);
        $live_barangay_stats = array_slice($live_barangay_stats, 0, 10, true);
    }
} catch (PDOException $e) {}

// Recent live applications
$live_recent_applications = [];
try {
    if ($welfare_table_exists && $program_column) {
        $stmt = $pdo->query("
            SELECT wa.id, wa.`$program_column` as program_type, wa.`$status_column` as status, 
                   wa.created_at, u.full_name, u.username,
                   JSON_EXTRACT(wa.`$appdata_column`, '$.case_no') as case_no,
                   JSON_EXTRACT(wa.`$appdata_column`, '$.red_alert') as red_alert
            FROM welfare_applications wa
            JOIN users u ON wa.user_id = u.id
            ORDER BY wa.created_at DESC
            LIMIT 10
        ");
        $live_recent_applications = $stmt->fetchAll();
    }
} catch (PDOException $e) {}

// ============================================================================
// 7. FETCH ENGINE DATA
// ============================================================================

$pending_applications = [];
$dropdown_error = '';

if ($welfare_table_exists && $program_column) {
    try {
        $sql = "
            SELECT wa.id, wa.`$program_column` AS program_type, wa.user_id, 
                   u.full_name, u.contact_number, u.username,
                   sp.is_verified_solo_parent, sp.is_verified_senior, 
                   sp.is_verified_pwd, sp.has_active_vawc_blotter
            FROM welfare_applications wa
            JOIN users u ON wa.user_id = u.id
            LEFT JOIN resident_sector_profiles sp ON sp.user_id = u.id
            ORDER BY wa.id DESC 
            LIMIT 300
        ";
        $stmt = $pdo->query($sql);
        $pending_applications = $stmt->fetchAll();
    } catch (PDOException $e) {
        $dropdown_error = "Could not load applications: " . $e->getMessage();
    }
} else if (!$welfare_table_exists) {
    $dropdown_error = "welfare_applications table does not exist.";
} else {
    $dropdown_error = "No program-type column found.";
}

$decision_stats = ['total'=>0,'approved'=>0,'rejected'=>0,'waitlisted'=>0,'pending_manual'=>0,'returned'=>0,'immediate_critical'=>0];
try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN decision = 'APPROVED' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN decision = 'REJECTED' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN decision = 'WAITLISTED' THEN 1 ELSE 0 END) as waitlisted,
            SUM(CASE WHEN decision = 'PENDING_MANUAL_REVIEW' THEN 1 ELSE 0 END) as pending_manual,
            SUM(CASE WHEN decision = 'RETURNED_FOR_CORRECTION' THEN 1 ELSE 0 END) as returned,
            SUM(CASE WHEN priority_level = 'IMMEDIATE_CRITICAL' THEN 1 ELSE 0 END) as immediate_critical
        FROM eligibility_assessments
    ");
    $decision_stats = $stmt->fetch() ?: $decision_stats;
} catch (PDOException $e) {}

$sector_distribution = [];
try {
    $stmt = $pdo->query("
        SELECT program_type, COUNT(*) as total,
            SUM(CASE WHEN decision = 'APPROVED' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN decision = 'REJECTED' THEN 1 ELSE 0 END) as rejected
        FROM eligibility_assessments
        GROUP BY program_type
    ");
    $sector_distribution = $stmt->fetchAll();
} catch (PDOException $e) {}

$rejection_breakdown = [];
try {
    $stmt = $pdo->query("
        SELECT rejection_code, COUNT(*) as total 
        FROM auto_rejection_log 
        GROUP BY rejection_code 
        ORDER BY total DESC LIMIT 10
    ");
    $rejection_breakdown = $stmt->fetchAll();
} catch (PDOException $e) {}

$pending_reviews = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM eligibility_assessments WHERE status = 'AUTO_RECOMMENDATION'");
    $pending_reviews = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {}

$assessments = [];
try {
    $stmt = $pdo->query("
        SELECT ea.*, u.full_name as assessor_name
        FROM eligibility_assessments ea
        LEFT JOIN users u ON ea.assessed_by_staff_id = u.id
        ORDER BY ea.created_at DESC LIMIT 100
    ");
    $assessments = $stmt->fetchAll();
} catch (PDOException $e) {}

// Filter
$filter_program = $_GET['filter_program'] ?? '';
$filter_decision = $_GET['filter_decision'] ?? '';
if ($filter_program || $filter_decision) {
    try {
        $where = ["1=1"]; $params = [];
        if ($filter_program) { $where[] = "program_type = ?"; $params[] = $filter_program; }
        if ($filter_decision) { $where[] = "decision = ?"; $params[] = $filter_decision; }
        $stmt = $pdo->prepare("SELECT ea.*, u.full_name as assessor_name FROM eligibility_assessments ea LEFT JOIN users u ON ea.assessed_by_staff_id = u.id WHERE " . implode(" AND ", $where) . " ORDER BY ea.created_at DESC LIMIT 100");
        $stmt->execute($params);
        $assessments = $stmt->fetchAll();
    } catch (PDOException $e) {}
}

// Helpers
function maskVawcData($assessment, $isVawcOfficer) {
    if (($assessment['program_type'] ?? '') !== 'VAWC') return $assessment;
    if ($isVawcOfficer) return $assessment;
    $assessment['applicant_name'] = 'Secure Crisis Case';
    $assessment['contact_number'] = '***';
    $assessment['decision_reason'] = 'Restricted — VAWC confidentiality (RA 9262)';
    $assessment['rule_trace'] = '[]';
    return $assessment;
}
function decisionBadgeClass($decision) {
    switch($decision) {
        case 'APPROVED': return 'decision-approved';
        case 'REJECTED': return 'decision-rejected';
        case 'WAITLISTED': return 'decision-waitlisted';
        case 'PENDING_MANUAL_REVIEW': return 'decision-pending';
        case 'RETURNED_FOR_CORRECTION': return 'decision-returned';
        default: return 'decision-pending';
    }
}
function priorityBadgeClass($p) {
    switch($p) {
        case 'IMMEDIATE_CRITICAL': return 'prio-immediate';
        case 'Critical': return 'prio-critical';
        case 'High': return 'prio-high';
        case 'Medium': return 'prio-medium';
        default: return 'prio-low';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Program Eligibility Engine - MSWDO Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
     <?= renderPwaMetaTags() ?>
\
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; color: #334155; padding-bottom: 75px; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F;
            --accent: #F5B042; --success: #059669; --warning: #F59E0B; --critical: #DC2626;
            --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9; --gray-200: #E2E8F0;
            --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B; --gray-600: #475569;
            --gray-700: #334155; --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --radius-md: 0.75rem; --radius-lg: 1rem; --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed; top: 0; left: 0; height: 100%; width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%); transition: transform 0.3s ease;
            z-index: 1000; overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.5); backdrop-filter: blur(4px); z-index: 999; display: none; }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        /* ============================================================
           UPDATED: MSWDO Logo Image replaces Font Awesome icon
           ============================================================ */
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label { font-size: 0.62rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--gray-400); margin-bottom: 8px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; font-size: 0.85rem; font-weight: 500; transition: all 0.2s ease; margin-bottom: 2px; }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25); }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu { margin-left: 32px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 500px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 12px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; font-size: 0.8rem; font-weight: 500; transition: all 0.2s; margin-bottom: 2px; }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25); }
        .submenu-item.active i { color: var(--accent); }
        
        .main-content { width: 100%; min-height: 100vh; padding: 16px; }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        .top-bar { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(12px); padding: 14px 20px; border-radius: var(--radius-xl); display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; border: 1px solid rgba(255, 255, 255, 0.6); box-shadow: var(--shadow-sm); }
        .menu-toggle { background: none; border: none; font-size: 1.3rem; cursor: pointer; padding: 8px; color: var(--gray-600); border-radius: var(--radius-md); transition: background 0.2s; }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 { font-size: 1.3rem; font-weight: 800; color: var(--gray-800); letter-spacing: -0.02em; }
        .page-title p { font-size: 0.7rem; color: var(--gray-500); margin-top: 2px; }
        .user-menu { display: flex; align-items: center; gap: 12px; background: linear-gradient(135deg, #FFFFFF, #F8FAFC); padding: 6px 14px 6px 6px; border-radius: 40px; text-decoration: none; color: inherit; border: 1px solid var(--gray-200); box-shadow: var(--shadow-sm); transition: all 0.2s; }
        .user-menu:hover { box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); transform: translateY(-1px); }
        .user-avatar { width: 34px; height: 34px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25); }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 600; }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }
        .alert { padding: 12px 16px; border-radius: var(--radius-lg); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; font-size: 0.85rem; }
        .alert-success { background: #D1FAE5; color: #065F46; border-left: 4px solid var(--success); }
        .alert-error { background: #FEE2E2; color: #991B1B; border-left: 4px solid var(--secondary); }
        .alert-info { background: #EFF6FF; color: #1E4A8C; border-left: 4px solid var(--primary); }
        .alert-warning { background: #FEF3C7; color: #92400E; border-left: 4px solid var(--warning); }

        .live-analytics-bar { background: white; border: 1px solid var(--gray-200); border-radius: var(--radius-lg); padding: 14px 18px; margin-bottom: 16px; }
        .live-bar-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; padding-bottom: 12px; border-bottom: 1px solid var(--gray-100); margin-bottom: 12px; }
        .live-bar-title { display: flex; align-items: center; gap: 8px; font-size: 0.8rem; font-weight: 700; color: var(--gray-700); text-transform: uppercase; letter-spacing: 0.5px; }
        .live-dot { width: 8px; height: 8px; border-radius: 50%; background: #10B981; box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2); animation: livePulse 1.6s ease-in-out infinite; }
        @keyframes livePulse { 0%, 100% { box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2); } 50% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); } }
        .live-bar-stats { display: flex; align-items: center; gap: 8px; font-size: 0.78rem; color: var(--gray-600); flex-wrap: wrap; }
        .live-bar-stats .sep { color: var(--gray-300); }
        .live-bar-stats strong { font-weight: 700; }

        .live-program-strip { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; }
        .live-program-chip { display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: var(--gray-50); border-radius: 10px; font-size: 0.72rem; transition: all 0.2s; }
        .live-program-chip:hover { background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .chip-icon { width: 22px; height: 22px; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.65rem; flex-shrink: 0; }
        .chip-label { color: var(--gray-600); font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .chip-total { margin-left: auto; font-weight: 700; color: var(--gray-800); font-size: 0.85rem; }
        .chip-pending { background: #FEF3C7; color: #B45309; padding: 1px 6px; border-radius: 8px; font-size: 0.6rem; font-weight: 700; white-space: nowrap; }

        .compact-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
        .compact-card { background: white; border: 1px solid var(--gray-200); border-radius: var(--radius-lg); padding: 12px 16px; }
        .compact-card-header { font-size: 0.72rem; font-weight: 700; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
        .compact-card-header i { color: var(--primary); }

        .compact-app-item { display: flex; align-items: center; gap: 10px; padding: 6px 0; border-bottom: 1px solid var(--gray-100); }
        .compact-app-item:last-child { border-bottom: none; }
        .compact-icon { width: 26px; height: 26px; border-radius: 7px; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.7rem; flex-shrink: 0; }
        .compact-info { flex: 1; min-width: 0; }
        .compact-name { font-size: 0.75rem; font-weight: 600; color: var(--gray-800); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .compact-meta { font-size: 0.62rem; color: var(--gray-500); margin-top: 1px; }
        .compact-status { font-size: 0.55rem; font-weight: 700; padding: 2px 7px; border-radius: 8px; text-transform: uppercase; letter-spacing: 0.3px; flex-shrink: 0; }
        .compact-status.pending { background: #FEF3C7; color: #B45309; }
        .compact-status.approved { background: #D1FAE5; color: #065F46; }
        .compact-status.rejected { background: #FEE2E2; color: #991B1B; }
        .red-dot { font-size: 0.7rem; margin-left: 2px; }

        .compact-barangay-item { display: flex; align-items: center; gap: 10px; padding: 6px 0; border-bottom: 1px solid var(--gray-100); }
        .compact-barangay-item:last-child { border-bottom: none; }
        .brgy-name { font-size: 0.72rem; font-weight: 500; color: var(--gray-700); min-width: 90px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .brgy-bar { flex: 1; height: 6px; background: var(--gray-100); border-radius: 6px; overflow: hidden; }
        .brgy-bar-fill { height: 100%; background: linear-gradient(90deg, #1E4A8C, #3B82F6); border-radius: 6px; transition: width 0.4s ease; }
        .brgy-count { font-size: 0.7rem; font-weight: 700; color: var(--primary); min-width: 24px; text-align: right; }
        .compact-empty { text-align: center; padding: 16px; color: var(--gray-400); font-size: 0.75rem; }

        .section-header { font-size: 0.8rem; font-weight: 700; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; margin: 24px 0 12px; display: flex; align-items: center; gap: 8px; }

        .card { background: white; border-radius: var(--radius-xl); border: 1px solid var(--gray-200); padding: 20px; margin-bottom: 24px; box-shadow: var(--shadow-sm); }
        .card h4 { font-size: 0.95rem; color: var(--primary); margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }

        .table-container { background: white; border-radius: var(--radius-xl); border: 1px solid var(--gray-200); overflow-x: auto; box-shadow: var(--shadow-sm); }
        .table { width: 100%; border-collapse: collapse; font-size: 0.8rem; min-width: 1000px; }
        .table th { padding: 12px 16px; background: linear-gradient(180deg, #F8FAFC, #F1F5F9); font-weight: 700; border-bottom: 2px solid var(--accent); text-align: left; font-size: 0.68rem; color: var(--gray-600); text-transform: uppercase; letter-spacing: 0.05em; }
        .table td { padding: 12px 16px; border-bottom: 1px solid var(--gray-100); vertical-align: middle; }
        .table tr:hover td { background: var(--gray-50); }
        .decision-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; }
        .decision-approved { background: #D1FAE5; color: #065F46; border: 1px solid #059669; }
        .decision-rejected { background: #FEE2E2; color: #991B1B; border: 1px solid #DC2626; }
        .decision-waitlisted { background: #DBEAFE; color: #1E40AF; border: 1px solid #3B82F6; }
        .decision-pending { background: #FEF3C7; color: #92400E; border: 1px solid #F59E0B; }
        .decision-returned { background: #FCE7F3; color: #9D174D; border: 1px solid #BE185D; }
        .prio-badge { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 0.6rem; font-weight: 700; }
        .prio-immediate { background: #7F1D1D; color: #FFF; animation: pulseRed 1.5s infinite; }
        .prio-critical { background: #DC2626; color: #FFF; }
        .prio-high { background: #F59E0B; color: #FFF; }
        .prio-medium { background: #3B82F6; color: #FFF; }
        .prio-low { background: #94A3B8; color: #FFF; }
        @keyframes pulseRed { 0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.7); } 50% { box-shadow: 0 0 0 6px rgba(220,38,38,0); } }
        .program-tag { display: inline-block; padding: 3px 10px; border-radius: 8px; font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .prog-solo_parent { background: #FCE7F3; color: #9D174D; }
        .prog-senior_citizen { background: #DBEAFE; color: #1E40AF; }
        .prog-pwd { background: #EDE9FE; color: #5B21B6; }
        .prog-aics { background: #FFEDD5; color: #9A3412; }
        .prog-vawc { background: #831843; color: #FFF; }
        .vawc-mask { background: #831843; color: white; padding: 2px 8px; border-radius: 8px; font-size: 0.65rem; font-weight: 700; }
        .btn { padding: 10px 20px; border-radius: var(--radius-md); border: none; font-weight: 700; font-size: 0.85rem; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; transition: all 0.2s; }
        .btn-primary { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-secondary { background: var(--gray-100); color: var(--gray-700); border: 1px solid var(--gray-200); }
        .btn-secondary:hover { background: var(--gray-200); }
        .btn-success { background: linear-gradient(135deg, #059669, #047857); color: white; }
        .btn-sm { padding: 6px 12px; font-size: 0.75rem; }
        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
        @media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; color: var(--gray-600); margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.04em; }
        .form-group label .req { color: var(--secondary); }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 12px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-family: inherit; font-size: 0.85rem; background: white; transition: all 0.2s; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(30,74,140,0.1); }
        .form-group textarea { resize: vertical; min-height: 60px; }
        .rule-grid-box { background: linear-gradient(135deg, #F8FAFC, #F1F5F9); border-radius: var(--radius-md); padding: 14px; font-size: 0.75rem; color: var(--gray-600); border-left: 4px solid var(--primary); margin-bottom: 12px; }
        .rule-grid-box strong { color: var(--gray-800); display: block; margin-bottom: 4px; }
        .rule-grid-box code { background: white; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; color: var(--primary); font-weight: 600; }
        .modal { display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(4px); z-index: 1100; align-items: center; justify-content: center; padding: 20px; }
        .modal.open { display: flex; }
        .modal-content { background: white; border-radius: var(--radius-xl); max-width: 650px; width: 100%; padding: 24px; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.2); }
        .trace-list { background: #0F172A; color: #A7F3D0; font-family: monospace; font-size: 0.7rem; padding: 12px; border-radius: 8px; line-height: 1.6; }
        .trace-list li { list-style: none; padding: 2px 0; }
        .trace-list li:before { content: "▸ "; color: #60A5FA; }
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(12px); display: flex; justify-content: space-around; padding: 8px 16px 12px; border-top: 1px solid var(--gray-200); z-index: 100; box-shadow: 0 -4px 12px rgba(0,0,0,0.04); }
        .bottom-nav .nav-item { display: flex; flex-direction: column; align-items: center; font-size: 0.68rem; color: var(--gray-600); text-decoration: none; font-weight: 600; padding: 6px 8px; border-radius: var(--radius-md); transition: all 0.2s; }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        @media (max-width: 992px) { 
            .live-program-strip { grid-template-columns: repeat(3, 1fr); }
            .compact-row { grid-template-columns: 1fr; }
        }
        @media (max-width: 600px) { 
            .live-program-strip { grid-template-columns: repeat(2, 1fr); }
            .live-bar-stats { font-size: 0.7rem; gap: 4px; }
            .chip-pending { display: none; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <!-- ============================================================
                     UPDATED: MSWDO Logo Image replaces Font Awesome icon
                     ============================================================ -->
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Staff Portal</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> <span>Dashboard</span></a>
                <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i> <span>Community Service</span></a>
                <a href="household.php" class="nav-item"><i class="fas fa-users"></i> <span>Household Records</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Applications</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                    <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                    <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                    <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                    <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
                </div>
                <a href="mswdstaff_idapplication.php" class="nav-item"><i class="fas fa-id-card"></i> <span>ID Applications</span></a>
                <a href="staff_eligibility_engine.php" class="nav-item active"><i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span></a>
                <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> <span>Reports</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i> <span>Profile</span></a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1><i class="fas fa-balance-scale" style="color: var(--primary);"></i> Program Eligibility Engine</h1>
                <p>Dynamic Program Decision Grid — Legitimacy + Trigger Rules</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-tie"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small><?php echo ucfirst(str_replace('_', ' ', $role)); ?></small>
                </div>
            </a>
        </div>

        <?php if($assessment_success): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $assessment_success; ?></div><?php endif; ?>
        <?php if($assessment_error): ?><div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $assessment_error; ?></div><?php endif; ?>
        <?php if($review_success): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $review_success; ?></div><?php endif; ?>
        <?php if($review_error): ?><div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $review_error; ?></div><?php endif; ?>

        <?php if (!empty($dropdown_error)): ?>
            <div class="alert alert-error" style="font-size: 0.75rem;">
                <i class="fas fa-exclamation-triangle"></i>
                <div><strong>Notice:</strong> <?php echo htmlspecialchars($dropdown_error); ?></div>
            </div>
        <?php endif; ?>

        <?php if($pending_reviews > 0): ?>
            <div class="alert alert-warning">
                <i class="fas fa-user-check"></i>
                <strong><?php echo $pending_reviews; ?></strong> assessment(s) awaiting human review.
            </div>
        <?php endif; ?>

        <!-- LIVE ANALYTICS -->
        <div class="live-analytics-bar">
            <div class="live-bar-header">
                <div class="live-bar-title">
                    <span class="live-dot"></span>
                    Live Resident Applications
                </div>
                <div class="live-bar-stats">
                    <span><strong><?php echo number_format($live_total); ?></strong> Total</span>
                    <span class="sep">•</span>
                    <span style="color: #B45309;"><strong><?php echo number_format($live_pending); ?></strong> Pending</span>
                    <span class="sep">•</span>
                    <span style="color: #059669;"><strong><?php echo number_format($live_approved); ?></strong> Approved</span>
                    <span class="sep">•</span>
                    <span style="color: #991B1B;"><strong><?php echo number_format($live_rejected); ?></strong> Rejected</span>
                </div>
            </div>

            <div class="live-program-strip">
                <?php 
                $program_meta = [
                    'SOLO_PARENT' => ['icon' => 'fa-female', 'color' => '#EC4899'],
                    'SENIOR_CITIZEN' => ['icon' => 'fa-user-graduate', 'color' => '#3B82F6'],
                    'PWD' => ['icon' => 'fa-wheelchair', 'color' => '#8B5CF6'],
                    'AICS' => ['icon' => 'fa-coins', 'color' => '#F97316'],
                    'VAWC' => ['icon' => 'fa-shield-alt', 'color' => '#831843']
                ];
                foreach($live_program_stats as $key => $stats): 
                    $meta = $program_meta[$key] ?? ['icon' => 'fa-file', 'color' => '#64748B'];
                ?>
                    <div class="live-program-chip">
                        <span class="chip-icon" style="background: <?php echo $meta['color']; ?>;">
                            <i class="fas <?php echo $meta['icon']; ?>"></i>
                        </span>
                        <span class="chip-label"><?php echo $stats['label']; ?></span>
                        <span class="chip-total"><?php echo $stats['total']; ?></span>
                        <?php if($stats['pending'] > 0): ?>
                            <span class="chip-pending"><?php echo $stats['pending']; ?> pending</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- COMPACT RECENT + BARANGAY ROW -->
        <div class="compact-row">
            <div class="compact-card">
                <div class="compact-card-header">
                    <i class="fas fa-clock"></i> Recent Applications
                </div>
                <?php if(count($live_recent_applications) > 0): 
                    $shown = 0;
                    foreach($live_recent_applications as $app): 
                        if($shown >= 4) break;
                        $pt = strtoupper($app['program_type'] ?? '');
                        $meta = $program_meta[$pt] ?? ['icon' => 'fa-file', 'color' => '#64748B'];
                        $st = strtolower($app['status'] ?? '');
                        $has_red = !empty($app['red_alert']) && $app['red_alert'] != 0;
                        $shown++;
                ?>
                    <div class="compact-app-item">
                        <span class="compact-icon" style="background: <?php echo $meta['color']; ?>;">
                            <i class="fas <?php echo $meta['icon']; ?>"></i>
                        </span>
                        <div class="compact-info">
                            <div class="compact-name">
                                <?php echo htmlspecialchars($app['full_name'] ?? 'Unknown'); ?>
                                <?php if($has_red): ?><span class="red-dot">🚨</span><?php endif; ?>
                            </div>
                            <div class="compact-meta"><?php echo str_replace('_', ' ', $pt); ?> • <?php echo date('M d', strtotime($app['created_at'])); ?></div>
                        </div>
                        <span class="compact-status <?php echo $st; ?>"><?php echo $st; ?></span>
                    </div>
                <?php endforeach; else: ?>
                    <div class="compact-empty">No applications yet</div>
                <?php endif; ?>
            </div>

            <div class="compact-card">
                <div class="compact-card-header">
                    <i class="fas fa-map-marked-alt"></i> Top Barangays
                </div>
                <?php if(count($live_barangay_stats) > 0): 
                    $max_live = max(array_map(fn($b) => $b['total'], $live_barangay_stats)) ?: 1;
                    $shown = 0;
                    foreach($live_barangay_stats as $brgy => $b): 
                        if($shown >= 4) break;
                        $pct = min(($b['total'] / $max_live) * 100, 100);
                        $shown++;
                ?>
                    <div class="compact-barangay-item">
                        <span class="brgy-name"><?php echo htmlspecialchars($brgy); ?></span>
                        <span class="brgy-bar">
                            <span class="brgy-bar-fill" style="width:<?php echo $pct; ?>%;"></span>
                        </span>
                        <span class="brgy-count"><?php echo $b['total']; ?></span>
                    </div>
                <?php endforeach; else: ?>
                    <div class="compact-empty">No barangay data</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ENGINE ANALYTICS -->
        <div class="live-analytics-bar">
            <div class="live-bar-header">
                <div class="live-bar-title">
                    <i class="fas fa-cogs" style="color: var(--primary); font-size: 0.9rem;"></i>
                    Engine Assessment Analytics
                </div>
                <div class="live-bar-stats">
                    <span><strong><?php echo number_format($decision_stats['total'] ?? 0); ?></strong> Assessed</span>
                    <span class="sep">•</span>
                    <span style="color: #059669;"><strong><?php echo number_format($decision_stats['approved'] ?? 0); ?></strong> Approved</span>
                    <span class="sep">•</span>
                    <span style="color: #991B1B;"><strong><?php echo number_format($decision_stats['rejected'] ?? 0); ?></strong> Rejected</span>
                    <span class="sep">•</span>
                    <span style="color: #B45309;"><strong><?php echo number_format($decision_stats['pending_manual'] ?? 0); ?></strong> Manual</span>
                    <span class="sep">•</span>
                    <span style="color: #7F1D1D;"><strong><?php echo number_format($decision_stats['immediate_critical'] ?? 0); ?></strong> Critical</span>
                </div>
            </div>

            <div class="compact-row" style="margin-bottom: 0;">
                <div class="compact-card" style="padding: 10px 12px;">
                    <div class="compact-card-header" style="margin-bottom: 8px;">
                        <i class="fas fa-chart-pie"></i> Sector Approval
                    </div>
                    <div style="position: relative; height: 140px;">
                        <canvas id="sectorChart"></canvas>
                    </div>
                </div>

                <div class="compact-card" style="padding: 10px 12px;">
                    <div class="compact-card-header" style="margin-bottom: 8px;">
                        <i class="fas fa-ban"></i> Rejection Reasons
                    </div>
                    <div style="position: relative; height: 140px;">
                        <canvas id="rejectionChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- RUN ASSESSMENT FORM -->
        <div class="card" style="margin-top: 16px;">
            <h4><i class="fas fa-magic"></i> Run Program-Based Assessment</h4>
            
            <div class="rule-grid-box">
                <strong>⚙️ Two-Tier Decision Process:</strong>
                <div style="margin-top:6px;">
                    <code>TIER 1</code> Legitimacy Check — Is the applicant's sector ID verified?<br>
                    <code>TIER 2</code> Trigger Rules — Do they meet the program's assistance triggers?
                </div>
                <div style="margin-top:8px; padding-top:8px; border-top:1px dashed #CBD5E1;">
                    <strong>📊 Poverty Classification (3-Class):</strong><br>
                    • ₱5,000 - ₱10,000 → <strong style="color:#DC2626;">POOR</strong><br>
                    • ₱10,001 - ₱25,000 → <strong style="color:#1E4A8C;">MIDDLE-CLASS</strong><br>
                    • ₱25,001 and above → <strong style="color:#B45309;">RICH</strong>
                </div>
            </div>

            <form method="POST" id="assessForm">
                <input type="hidden" name="run_assessment" value="1">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label><i class="fas fa-file-alt"></i> Select Applicant <span class="req">*</span></label>
                        <select name="application_id" id="selectApplication" required onchange="autoSetProgram()">
                            <option value="">— Select a resident application —</option>
                            <?php foreach($pending_applications as $app): 
                                $p = strtoupper($app['program_type'] ?? 'UNKNOWN');
                                $idBadge = '';
                                if ($p === 'SOLO_PARENT' && empty($app['is_verified_solo_parent'])) $idBadge = ' ⚠️ unverified';
                                if ($p === 'SENIOR_CITIZEN' && empty($app['is_verified_senior'])) $idBadge = ' ⚠️ unverified';
                                if ($p === 'PWD' && empty($app['is_verified_pwd'])) $idBadge = ' ⚠️ unverified';
                            ?>
                                <option value="<?php echo $app['id']; ?>" 
                                        data-program="<?php echo htmlspecialchars($p); ?>"
                                        data-user="<?php echo $app['user_id']; ?>">
                                    [<?php echo str_replace('_', ' ', $p); ?>] 
                                    <?php echo htmlspecialchars($app['full_name'] ?? 'Unknown'); ?> 
                                    — <?php echo htmlspecialchars($app['username'] ?? ''); ?>
                                    <?php echo $idBadge; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-folder"></i> Program Type <span class="req">*</span></label>
                        <select name="program_type" id="program_type" required>
                            <option value="">— Auto-set when you pick an applicant —</option>
                            <option value="SOLO_PARENT">Solo Parent</option>
                            <option value="SENIOR_CITIZEN">Senior Citizen</option>
                            <option value="PWD">PWD</option>
                            <option value="AICS">AICS</option>
                            <option value="VAWC">VAWC</option>
                        </select>
                    </div>
                </div>

                <div id="aicsBlock" style="display:none; background: #FFF9EF; padding: 16px; border-radius: var(--radius-md); border-left: 4px solid var(--accent); margin-bottom: 16px;">
                    <strong style="font-size: 0.8rem; color: #92400E;"><i class="fas fa-triangle-exclamation"></i> AICS Evidence Requirements</strong>
                    <div class="form-grid" style="margin-top: 12px;">
                        <div class="form-group">
                            <label>Crisis Type <span class="req">*</span></label>
                            <select name="crisis_type">
                                <option value="">— Select —</option>
                                <option value="Medical Assistance">Medical Assistance</option>
                                <option value="Burial Assistance">Burial Assistance</option>
                                <option value="Transportation Aid">Transportation Aid</option>
                            </select>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:10px; padding-top:18px;">
                            <label style="display:flex; gap:8px; align-items:center; font-size:0.85rem; cursor:pointer;">
                                <input type="checkbox" name="has_barangay_indigency" value="1"> Has Barangay Indigency Certificate
                            </label>
                            <label style="display:flex; gap:8px; align-items:center; font-size:0.85rem; cursor:pointer;">
                                <input type="checkbox" name="has_official_receipts" value="1"> Has Official Receipts / Funeral Contract
                            </label>
                        </div>
                    </div>
                </div>

                <div id="vawcBlock" style="display:none; background: #FCE7F3; padding: 14px; border-radius: var(--radius-md); border-left: 4px solid #831843; margin-bottom: 16px; font-size: 0.8rem; color: #831843;">
                    <strong><i class="fas fa-lock"></i> VAWC Confidentiality Notice</strong>
                    <p style="margin-top: 4px;">Only <code>vawc_desk_officer</code> and <code>admin</code> roles can view applicant details.</p>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-pen"></i> Assessment Notes</label>
                    <textarea name="assessment_notes" placeholder="Optional notes..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
                    <i class="fas fa-calculator"></i> Run Program Decision Engine
                </button>
            </form>
        </div>

        <!-- Assessment Results Table -->
        <div style="font-size: 1rem; font-weight: 700; margin: 24px 0 16px; display: flex; align-items: center; gap: 8px; border-left: 4px solid var(--secondary); padding-left: 12px; color: var(--gray-800);">
            <i class="fas fa-list"></i> Assessment Results
            <span style="font-size: 0.7rem; font-weight: 500; color: var(--gray-500); margin-left: auto;">Showing <?php echo count($assessments); ?> records</span>
        </div>

        <div class="card" style="padding: 12px 20px;">
            <form method="GET" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
                <select name="filter_program" style="padding: 8px 12px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-size: 0.8rem;">
                    <option value="">All Programs</option>
                    <option value="SOLO_PARENT" <?php echo $filter_program == 'SOLO_PARENT' ? 'selected' : ''; ?>>Solo Parent</option>
                    <option value="SENIOR_CITIZEN" <?php echo $filter_program == 'SENIOR_CITIZEN' ? 'selected' : ''; ?>>Senior Citizen</option>
                    <option value="PWD" <?php echo $filter_program == 'PWD' ? 'selected' : ''; ?>>PWD</option>
                    <option value="AICS" <?php echo $filter_program == 'AICS' ? 'selected' : ''; ?>>AICS</option>
                    <option value="VAWC" <?php echo $filter_program == 'VAWC' ? 'selected' : ''; ?>>VAWC</option>
                </select>
                <select name="filter_decision" style="padding: 8px 12px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-size: 0.8rem;">
                    <option value="">All Decisions</option>
                    <option value="APPROVED" <?php echo $filter_decision == 'APPROVED' ? 'selected' : ''; ?>>Approved</option>
                    <option value="REJECTED" <?php echo $filter_decision == 'REJECTED' ? 'selected' : ''; ?>>Rejected</option>
                    <option value="WAITLISTED" <?php echo $filter_decision == 'WAITLISTED' ? 'selected' : ''; ?>>Waitlisted</option>
                    <option value="PENDING_MANUAL_REVIEW" <?php echo $filter_decision == 'PENDING_MANUAL_REVIEW' ? 'selected' : ''; ?>>Pending Manual</option>
                    <option value="RETURNED_FOR_CORRECTION" <?php echo $filter_decision == 'RETURNED_FOR_CORRECTION' ? 'selected' : ''; ?>>Returned</option>
                </select>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
                <a href="staff_eligibility_engine.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i> Clear</a>
            </form>
        </div>

        <div class="table-container">
            <?php if(count($assessments) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th><th>Program</th><th>Applicant</th><th>Barangay</th>
                        <th>Decision</th><th>Priority</th><th>Reason</th><th>Status</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($assessments as $a): 
                        $masked = maskVawcData($a, $is_vawc_officer);
                        $progClass = 'prog-' . strtolower($a['program_type'] ?? 'unknown');
                    ?>
                    <tr>
                        <td><strong>#<?php echo $a['id']; ?></strong></td>
                        <td><span class="program-tag <?php echo $progClass; ?>"><?php echo str_replace('_', ' ', $a['program_type'] ?? 'UNKNOWN'); ?></span></td>
                        <td>
                            <?php if(($a['program_type'] ?? '') === 'VAWC' && !$is_vawc_officer): ?>
                                <span class="vawc-mask"><i class="fas fa-lock"></i> Secure Crisis Case</span>
                            <?php else: ?>
                                <strong><?php echo htmlspecialchars($masked['applicant_name']); ?></strong>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($masked['barangay'] ?? ''); ?></td>
                        <td><span class="decision-badge <?php echo decisionBadgeClass($a['decision']); ?>"><?php echo $a['decision']; ?></span></td>
                        <td><span class="prio-badge <?php echo priorityBadgeClass($a['priority_level']); ?>"><?php echo str_replace('_', ' ', $a['priority_level']); ?></span></td>
                        <td style="font-size:0.7rem; color:var(--gray-600); max-width: 240px;"><?php echo htmlspecialchars($masked['decision_reason'] ?? ''); ?></td>
                        <td><span style="font-size:0.65rem; color:var(--gray-500);"><?php echo htmlspecialchars($a['status']); ?></span></td>
                        <td><button class="btn btn-primary btn-sm" onclick='openReviewModal(<?php echo json_encode($masked); ?>)'><i class="fas fa-clipboard-check"></i> Review</button></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
                <div style="text-align: center; padding: 60px 20px; color: var(--gray-500);">
                    <i class="fas fa-clipboard-list" style="font-size: 3rem; opacity: 0.3; margin-bottom: 16px; display: block;"></i>
                    <p>No assessments yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <div class="modal" id="reviewModal">
        <div class="modal-content">
            <h3 style="margin-bottom: 12px; font-weight: 800;"><i class="fas fa-clipboard-check" style="color: var(--primary);"></i> Human Review & Override</h3>
            <div id="reviewDetails" style="background: var(--gray-50); padding: 16px; border-radius: var(--radius-lg); margin-bottom: 16px;"></div>
            <h4 style="font-size: 0.85rem; color: var(--gray-700); margin-bottom: 8px; font-weight: 700;"><i class="fas fa-code-branch"></i> Rule Trace Log</h4>
            <ul id="reviewTrace" class="trace-list" style="margin-bottom: 16px;"></ul>
            <form method="POST">
                <input type="hidden" name="review_decision" value="1">
                <input type="hidden" name="assessment_id" id="review_assessment_id">
                <div class="form-group">
                    <label>Final Decision <span class="req">*</span></label>
                    <select name="review_status" required>
                        <option value="APPROVED">✅ Approve as-is</option>
                        <option value="OVERRIDDEN">✏️ Override decision</option>
                        <option value="REJECTED">❌ Reject</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Override Decision</label>
                    <select name="override_decision">
                        <option value="">— No override —</option>
                        <option value="APPROVED">Approved</option>
                        <option value="REJECTED">Rejected</option>
                        <option value="WAITLISTED">Waitlisted</option>
                        <option value="PENDING_MANUAL_REVIEW">Pending Manual Review</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Review Notes <span class="req">*</span></label>
                    <textarea name="review_notes" required placeholder="Document findings..."></textarea>
                </div>
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('reviewModal').classList.remove('open')">Cancel</button>
                    <button type="submit" class="btn btn-success"><i class="fas fa-check"></i> Finalize</button>
                </div>
            </form>
        </div>
    </div>

    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="staff_eligibility_engine.php" class="nav-item active"><i class="fas fa-balance-scale"></i><span>Eligibility</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };
        
        const progToggle = document.getElementById('programToggle');
        const progSub = document.getElementById('programSubmenu');
        const progIcon = document.getElementById('programIcon');
        if(progToggle) progToggle.onclick = () => { progSub.classList.toggle('show'); progIcon.classList.toggle('rotated'); };

        function autoSetProgram() {
            const sel = document.getElementById('selectApplication');
            const opt = sel.options[sel.selectedIndex];
            const prog = opt.dataset.program;
            if (prog) {
                document.getElementById('program_type').value = prog;
                toggleProgramBlocks(prog);
            }
        }
        
        document.getElementById('program_type').addEventListener('change', function() {
            toggleProgramBlocks(this.value);
        });
        
        function toggleProgramBlocks(prog) {
            document.getElementById('aicsBlock').style.display = (prog === 'AICS') ? 'block' : 'none';
            document.getElementById('vawcBlock').style.display = (prog === 'VAWC') ? 'block' : 'none';
        }

        // Engine sector chart
        const sectorCtx = document.getElementById('sectorChart')?.getContext('2d');
        if(sectorCtx) {
            <?php
            $sectorLabels = []; $sectorApproved = [];
            foreach($sector_distribution as $s) {
                $sectorLabels[] = str_replace('_', ' ', $s['program_type'] ?? '');
                $sectorApproved[] = intval($s['approved'] ?? 0);
            }
            if (empty($sectorLabels)) { $sectorLabels = ['No Data']; $sectorApproved = [0]; }
            ?>
            new Chart(sectorCtx, {
                type: 'doughnut',
                data: {
                    labels: <?php echo json_encode($sectorLabels); ?>,
                    datasets: [{
                        data: <?php echo json_encode($sectorApproved); ?>,
                        backgroundColor: ['#EC4899', '#3B82F6', '#8B5CF6', '#F97316', '#831843', '#0EA5E9'],
                        borderWidth: 0
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    cutout: '65%',
                    plugins: { 
                        legend: { 
                            position: 'right',
                            labels: { 
                                font: { size: 9 }, 
                                boxWidth: 8, 
                                padding: 6 
                            } 
                        } 
                    } 
                }
            });
        }

        // Engine rejection chart
        const rejCtx = document.getElementById('rejectionChart')?.getContext('2d');
        if(rejCtx) {
            <?php
            $rejLabels = []; $rejData = [];
            foreach($rejection_breakdown as $r) {
                $rejLabels[] = str_replace('_', ' ', $r['rejection_code'] ?? '');
                $rejData[] = intval($r['total'] ?? 0);
            }
            if (empty($rejLabels)) { $rejLabels = ['No Rejections']; $rejData = [0]; }
            ?>
            new Chart(rejCtx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($rejLabels); ?>,
                    datasets: [{
                        data: <?php echo json_encode($rejData); ?>,
                        backgroundColor: '#DC2626',
                        borderRadius: 4,
                        barThickness: 12
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    scales: { 
                        y: { 
                            beginAtZero: true, 
                            ticks: { font: { size: 9 }, precision: 0 },
                            grid: { display: false }
                        },
                        x: {
                            ticks: { font: { size: 8 } },
                            grid: { display: false }
                        }
                    }, 
                    plugins: { 
                        legend: { display: false },
                        tooltip: { titleFont: { size: 10 }, bodyFont: { size: 10 } }
                    } 
                }
            });
        }

        function openReviewModal(a) {
            document.getElementById('review_assessment_id').value = a.id;
            const details = `
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; font-size:0.8rem;">
                    <div><strong>Program:</strong><br>${a.program_type}</div>
                    <div><strong>Applicant:</strong><br>${escapeHtml(a.applicant_name)}</div>
                    <div><strong>Barangay:</strong><br>${escapeHtml(a.barangay || '')}</div>
                    <div><strong>Decision:</strong><br>${a.decision}</div>
                    <div><strong>Priority:</strong><br>${a.priority_level}</div>
                    <div><strong>Status:</strong><br>${a.status}</div>
                    <div style="grid-column: span 2;"><strong>Reason:</strong><br>${escapeHtml(a.decision_reason || '')}</div>
                </div>
            `;
            document.getElementById('reviewDetails').innerHTML = details;
            let trace = [];
            try { trace = JSON.parse(a.rule_trace || '[]'); } catch(e) {}
            const traceHtml = trace.length > 0 ? trace.map(t => `<li>${escapeHtml(t)}</li>`).join('') : '<li>No trace available</li>';
            document.getElementById('reviewTrace').innerHTML = traceHtml;
            document.getElementById('reviewModal').classList.add('open');
        }

        function escapeHtml(t) { if(!t) return ''; const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
        document.querySelectorAll('.modal').forEach(m => m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); }));
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>