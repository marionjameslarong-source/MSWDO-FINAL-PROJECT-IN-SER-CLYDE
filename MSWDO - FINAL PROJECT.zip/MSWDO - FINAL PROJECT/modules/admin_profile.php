<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];

// ============================================================
// 1. CHECK/CREATE ADMIN PROFILE TABLE
// ============================================================
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'admin_profiles'");
    if($stmt->rowCount() == 0) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS admin_profiles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL UNIQUE,
                admin_id VARCHAR(50) UNIQUE,
                office_designation VARCHAR(100),
                system_access_clearance TEXT,
                active_system_status VARCHAR(50) DEFAULT 'ACTIVE_SUPER_ADMIN',
                hardware_device_mac_address VARCHAR(50),
                device_biometric_signature VARCHAR(100),
                mobile_os_fingerprint VARCHAR(100),
                enforce_strict_hardware_lock TINYINT DEFAULT 0,
                device_binding_date DATETIME,
                last_device_verification DATETIME,
                session_token VARCHAR(255),
                session_expires_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        
        $admin_id = 'adm_master_' . str_pad($user_id, 4, '0', STR_PAD_LEFT);
        $default_clearance = json_encode([
            'can_override_poverty_status' => true,
            'can_view_encrypted_vawc_files' => true,
            'can_modify_municipal_budget_ledgers' => true,
            'can_purge_local_device_caches' => true
        ]);
        
        $stmt = $pdo->prepare("
            INSERT INTO admin_profiles (user_id, admin_id, office_designation, system_access_clearance, active_system_status)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $admin_id, 'OFFICE_OF_THE_MUNICIPAL_ADMINISTRATOR', $default_clearance, 'ACTIVE_SUPER_ADMIN']);
    }
} catch(PDOException $e) {}

// ============================================================
// 2. CHECK/CREATE SYSTEM_CONFIG TABLE
// ============================================================
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'system_config'");
    if($stmt->rowCount() == 0) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS system_config (
                id INT AUTO_INCREMENT PRIMARY KEY,
                config_key VARCHAR(100) UNIQUE,
                config_value DECIMAL(15,2),
                description TEXT,
                updated_by_admin_id VARCHAR(50),
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                justification TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        $default_configs = [
            ['global_poverty_threshold_per_capita', 4500.00, 'Global poverty threshold per capita in PHP'],
            ['global_food_line_threshold_per_capita', 3000.00, 'Global food line threshold per capita in PHP'],
            ['maximum_single_aics_payout_limit', 15000.00, 'Maximum single AICS payout limit in PHP'],
            ['mandatory_community_service_default_hours', 16.00, 'Mandatory community service default hours']
        ];
        
        foreach($default_configs as $config) {
            $stmt = $pdo->prepare("INSERT INTO system_config (config_key, config_value, description) VALUES (?, ?, ?)");
            $stmt->execute([$config[0], $config[1], $config[2]]);
        }
    }
} catch(PDOException $e) {}

// ============================================================
// 3. CHECK/CREATE ADMIN_AUDIT_LOGS TABLE
// ============================================================
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'admin_audit_logs'");
    if($stmt->rowCount() == 0) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS admin_audit_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                admin_id VARCHAR(50) NOT NULL,
                action_type VARCHAR(100) NOT NULL,
                action_description TEXT,
                target_table VARCHAR(100),
                target_record_id VARCHAR(50),
                old_values TEXT,
                new_values TEXT,
                ip_address VARCHAR(45),
                user_agent TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_admin_id (admin_id),
                INDEX idx_created_at (created_at)
            )
        ");
    }
} catch(PDOException $e) {}

// ============================================================
// 4. GET ADMIN PROFILE DATA
// ============================================================
$admin_profile = null;
$system_clearance = [];
$active_status = 'ACTIVE_SUPER_ADMIN';
$admin_id = null;
$device_bound = false;
$device_mac = null;
$biometric_signature = null;
$os_fingerprint = null;
$hardware_lock = false;
$session_token = null;
$session_expires = null;
$device_binding_date = null;

try {
    $stmt = $pdo->prepare("SELECT * FROM admin_profiles WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $admin_profile = $stmt->fetch();
    
    if($admin_profile) {
        $admin_id = $admin_profile['admin_id'];
        $active_status = $admin_profile['active_system_status'] ?? 'ACTIVE_SUPER_ADMIN';
        $system_clearance = json_decode($admin_profile['system_access_clearance'] ?? '{}', true);
        $device_mac = $admin_profile['hardware_device_mac_address'];
        $device_bound = !empty($admin_profile['hardware_device_mac_address']);
        $biometric_signature = $admin_profile['device_biometric_signature'];
        $os_fingerprint = $admin_profile['mobile_os_fingerprint'];
        $hardware_lock = (bool)($admin_profile['enforce_strict_hardware_lock'] ?? 0);
        $session_token = $admin_profile['session_token'];
        $session_expires = $admin_profile['session_expires_at'];
        $device_binding_date = $admin_profile['device_binding_date'];
    }
} catch(PDOException $e) {
    $admin_profile = null;
}

// ============================================================
// 5. GET SYSTEM CONFIGURATIONS
// ============================================================
$system_configs = [];
try {
    $stmt = $pdo->query("SELECT * FROM system_config ORDER BY config_key");
    $system_configs = $stmt->fetchAll();
} catch(PDOException $e) {
    $system_configs = [];
}

// ============================================================
// 6. GET RECENT ADMIN AUDIT LOGS
// ============================================================
$audit_logs = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM admin_audit_logs WHERE admin_id = ? ORDER BY created_at DESC LIMIT 20");
    $stmt->execute([$admin_id]);
    $audit_logs = $stmt->fetchAll();
} catch(PDOException $e) {
    $audit_logs = [];
}

// ============================================================
// 7. HANDLE DEVICE BINDING
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bind_device'])) {
    $hardware_mac = trim($_POST['hardware_device_mac_address'] ?? '');
    $biometric_sig = trim($_POST['device_biometric_signature'] ?? '');
    $os_fingerprint = trim($_POST['mobile_os_fingerprint'] ?? '');
    $enforce_lock = isset($_POST['enforce_strict_hardware_lock']) ? 1 : 0;
    
    $errors = [];
    if(empty($hardware_mac)) $errors[] = "Hardware MAC address is required.";
    if(empty($biometric_sig)) $errors[] = "Biometric signature is required.";
    if(empty($os_fingerprint)) $errors[] = "Mobile OS fingerprint is required.";
    
    if(empty($errors)) {
        try {
            $session_token = bin2hex(random_bytes(32));
            $session_expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
            
            $stmt = $pdo->prepare("
                UPDATE admin_profiles 
                SET hardware_device_mac_address = ?,
                    device_biometric_signature = ?,
                    mobile_os_fingerprint = ?,
                    enforce_strict_hardware_lock = ?,
                    device_binding_date = NOW(),
                    session_token = ?,
                    session_expires_at = ?
                WHERE user_id = ?
            ");
            $stmt->execute([$hardware_mac, $biometric_sig, $os_fingerprint, $enforce_lock, $session_token, $session_expires, $user_id]);
            
            logAdminAction($pdo, $admin_id, 'DEVICE_BINDING', 'Device bound to admin account', 'admin_profiles', $admin_id);
            
            $device_success = "Device bound successfully! Session token generated.";
            $device_bound = true;
            $device_mac = $hardware_mac;
            $biometric_signature = $biometric_sig;
            $os_fingerprint = $os_fingerprint;
            $hardware_lock = $enforce_lock;
            
        } catch(PDOException $e) {
            $device_error = "Failed to bind device: " . $e->getMessage();
        }
    } else {
        $device_error = implode("<br>", $errors);
    }
}

// ============================================================
// 8. HANDLE SYSTEM CONFIG UPDATE
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_system_config'])) {
    $justification = trim($_POST['administrative_justification'] ?? '');
    $config_updates = [];
    
    foreach($system_configs as $config) {
        $key = $config['config_key'];
        $value = $_POST['config_' . $key] ?? null;
        if($value !== null && is_numeric($value)) {
            $config_updates[$key] = (float)$value;
        }
    }
    
    if(empty($justification)) {
        $config_error = "Administrative justification is required for system configuration changes.";
    } elseif(empty($config_updates)) {
        $config_error = "No valid configuration values provided.";
    } else {
        try {
            $pdo->beginTransaction();
            
            foreach($config_updates as $key => $value) {
                $stmt = $pdo->prepare("
                    UPDATE system_config 
                    SET config_value = ?, 
                        updated_by_admin_id = ?,
                        justification = ?,
                        updated_at = NOW()
                    WHERE config_key = ?
                ");
                $stmt->execute([$value, $admin_id, $justification, $key]);
            }
            
            logAdminAction($pdo, $admin_id, 'SYSTEM_CONFIG_UPDATE', 'Updated system configurations', 'system_config', null, null, json_encode($config_updates));
            
            $pdo->commit();
            $config_success = "System configurations updated successfully!";
            
            $stmt = $pdo->query("SELECT * FROM system_config ORDER BY config_key");
            $system_configs = $stmt->fetchAll();
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            $config_error = "Failed to update system configurations: " . $e->getMessage();
        }
    }
}

// ============================================================
// 9. HANDLE SESSION REFRESH
// ============================================================
if(isset($_GET['refresh_session']) && $_GET['refresh_session'] == 1) {
    try {
        $new_token = bin2hex(random_bytes(32));
        $new_expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        $stmt = $pdo->prepare("
            UPDATE admin_profiles 
            SET session_token = ?, 
                session_expires_at = ?
            WHERE user_id = ?
        ");
        $stmt->execute([$new_token, $new_expires, $user_id]);
        
        logAdminAction($pdo, $admin_id, 'SESSION_REFRESH', 'Admin session refreshed', 'admin_profiles', $admin_id);
        
        $session_refresh_success = "Session refreshed successfully! Expires: " . date('F d, Y h:i A', strtotime($new_expires));
        $session_token = $new_token;
        $session_expires = $new_expires;
        
    } catch(PDOException $e) {
        $session_refresh_error = "Failed to refresh session.";
    }
}

// ============================================================
// 10. HANDLE PROFILE UPDATE
// ============================================================
$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $new_full_name = trim($_POST['full_name'] ?? '');
    $new_email = trim($_POST['email'] ?? '');
    $new_contact = trim($_POST['contact_number'] ?? '');
    $new_designation = trim($_POST['office_designation'] ?? '');
    
    $errors = [];
    if(empty($new_full_name)) $errors[] = "Full name is required.";
    if(!empty($new_email) && !filter_var($new_email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    
    if(empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, contact_number = ? WHERE id = ?");
            $stmt->execute([$new_full_name, $new_email, $new_contact, $user_id]);
            
            if(!empty($new_designation)) {
                $stmt = $pdo->prepare("UPDATE admin_profiles SET office_designation = ? WHERE user_id = ?");
                $stmt->execute([$new_designation, $user_id]);
            }
            
            logAdminAction($pdo, $admin_id, 'PROFILE_UPDATE', 'Admin profile updated', 'users', $user_id);
            
            $pdo->commit();
            
            $success = "Profile updated successfully!";
            $_SESSION['full_name'] = $new_full_name;
            $user['full_name'] = $new_full_name;
            $user['email'] = $new_email;
            $user['contact_number'] = $new_contact;
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = "Database error. Please try again.";
        }
    } else {
        $error = implode("<br>", $errors);
    }
}

// ============================================================
// 11. HANDLE PASSWORD CHANGE
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $errors = [];
    if(empty($current_password)) $errors[] = "Current password is required.";
    if(empty($new_password)) $errors[] = "New password is required.";
    if(strlen($new_password) < 6) $errors[] = "New password must be at least 6 characters.";
    if($new_password !== $confirm_password) $errors[] = "New passwords do not match.";
    
    if(empty($errors)) {
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $db_user = $stmt->fetch();
        
        if($db_user && password_verify($current_password, $db_user['password'])) {
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed, $user_id]);
            
            logAdminAction($pdo, $admin_id, 'PASSWORD_CHANGE', 'Admin password changed', 'users', $user_id);
            
            $password_success = "Password changed successfully!";
        } else {
            $password_error = "Current password is incorrect.";
        }
    } else {
        $password_error = implode("<br>", $errors);
    }
}

// ============================================================
// 12. HELPER FUNCTION: LOG ADMIN ACTION
// ============================================================
function logAdminAction($pdo, $admin_id, $action_type, $description, $target_table = null, $target_record_id = null, $old_values = null, $new_values = null) {
    try {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $stmt = $pdo->prepare("
            INSERT INTO admin_audit_logs (admin_id, action_type, action_description, target_table, target_record_id, old_values, new_values, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $admin_id,
            $action_type,
            $description,
            $target_table,
            $target_record_id,
            $old_values,
            $new_values,
            $ip_address,
            $user_agent
        ]);
    } catch(PDOException $e) {}
}

// ============================================================
// 13. GET USER DATA
// ============================================================
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if(!$user) {
    header("Location: ../index.php");
    exit();
}

// Get deleted count for recycle bin badge
$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
$deleted_count = $stmt->fetch()['total'];

// Get system statistics
$stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
$total_users = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM households");
$total_households = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications");
$total_applications = $stmt->fetch()['total'];

// Check if session is still valid
$session_valid = false;
if($session_token && $session_expires) {
    $session_valid = (strtotime($session_expires) > time());
}

// Format clearance for display
$clearance_items = [];
if(!empty($system_clearance)) {
    foreach($system_clearance as $key => $value) {
        $clearance_items[] = [
            'key' => $key,
            'label' => ucfirst(str_replace('_', ' ', $key)),
            'value' => $value
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Admin Profile - MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   
    <?= renderPwaMetaTags() ?>

   <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 10px; }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.6rem; color: var(--gray-500); }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--gray-500);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
        }
        .nav-item i { width: 20px; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }

        /* Top Bar */
        .top-bar {
            background: var(--white);
            padding: 12px 20px;
            border-radius: var(--radius-lg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
        }
        .page-title h1 { 
            font-size: 1.3rem; 
            font-weight: 600; 
            color: var(--gray-800); 
        }
        .page-title p { 
            font-size: 0.7rem; 
            color: var(--gray-500); 
            margin-top: 2px; 
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            background: var(--gray-50);
            padding: 6px 12px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 500; }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }

        /* Stats Row */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-box {
            background: white;
            padding: 16px;
            border-radius: var(--radius-lg);
            text-align: center;
            border: 1px solid var(--gray-200);
        }
        .stat-number { font-size: 1.8rem; font-weight: 700; color: var(--primary); }
        .stat-label { font-size: 0.7rem; color: var(--gray-500); }

        /* Admin Clearance Card */
        .clearance-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 16px 20px;
            margin-bottom: 24px;
        }
        .clearance-card .section-header {
            font-size: 0.75rem;
            font-weight: 700;
            color: #475569;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .clearance-card .clearance-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 0;
            border-bottom: 1px solid #F1F5F9;
        }
        .clearance-card .clearance-item:last-child {
            border-bottom: none;
        }
        .clearance-card .clearance-label {
            font-size: 0.8rem;
            color: var(--gray-600);
        }
        .clearance-card .clearance-status {
            font-size: 0.7rem;
            font-weight: 600;
            padding: 2px 10px;
            border-radius: 12px;
        }
        .clearance-status.granted {
            background: #D1FAE5;
            color: #065F46;
        }
        .clearance-status.denied {
            background: #FEE2E2;
            color: #991B1B;
        }

        /* Device Binding Card */
        .device-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 16px 20px;
            margin-bottom: 24px;
        }
        .device-card .section-header {
            font-size: 0.75rem;
            font-weight: 700;
            color: #475569;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .device-card .device-status {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }
        .device-card .device-status .status-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
        }
        .device-card .device-status .status-dot.bound {
            background: #059669;
        }
        .device-card .device-status .status-dot.unbound {
            background: #D32F2F;
        }

        /* System Config Card */
        .config-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 16px 20px;
            margin-bottom: 24px;
        }
        .config-card .section-header {
            font-size: 0.75rem;
            font-weight: 700;
            color: #475569;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Profile Card */
        .profile-card {
            max-width: 900px;
            margin: 0 auto;
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 24px;
        }
        .profile-header {
            background: var(--gray-100);
            padding: 24px;
            text-align: center;
            border-bottom: 1px solid var(--gray-200);
            position: relative;
        }
        .profile-header i {
            font-size: 2.5rem;
            margin-bottom: 12px;
            background: var(--white);
            padding: 16px;
            border-radius: 50%;
            color: var(--primary);
        }
        .profile-header h2 { font-size: 1.2rem; font-weight: 600; color: var(--gray-800); }
        .profile-header p { font-size: 0.75rem; color: var(--gray-500); }
        .profile-header .admin-badge {
            position: absolute;
            top: 16px;
            right: 16px;
            background: var(--primary);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
        }
        .profile-header .session-badge {
            position: absolute;
            top: 16px;
            left: 16px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
        }
        .session-badge.active {
            background: #D1FAE5;
            color: #065F46;
        }
        .session-badge.inactive {
            background: #FEE2E2;
            color: #991B1B;
        }
        .profile-body { padding: 24px; }

        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-600);
            margin-bottom: 6px;
        }
        .form-group label i { margin-right: 6px; color: var(--accent); }
        input, select, textarea {
            width: 100%;
            padding: 10px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        input:focus, select:focus, textarea:focus {
            border-color: var(--accent);
            outline: none;
            box-shadow: 0 0 0 3px rgba(245,176,66,0.15);
        }
        input:disabled {
            background: var(--gray-50);
            color: var(--gray-500);
        }
        textarea {
            resize: vertical;
            min-height: 60px;
        }
        .btn-primary {
            width: 100%;
            background: var(--primary);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-primary:hover { background: var(--primary-dark); }
        .btn-secondary {
            width: 100%;
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
            padding: 10px 20px;
            border-radius: var(--radius-md);
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-secondary:hover { background: var(--gray-200); }
        .btn-success {
            width: 100%;
            background: #059669;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-success:hover { background: #047857; }
        .btn-danger {
            width: 100%;
            background: #D32F2F;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-danger:hover { background: #B71C1C; }
        .btn-sm {
            padding: 6px 16px;
            width: auto;
            font-size: 0.75rem;
        }
        .alert {
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85rem;
        }
        .alert-success { background: #ECFDF5; border-left: 4px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 4px solid var(--secondary); color: #991B1B; }
        .alert-info { background: #EFF6FF; border-left: 4px solid var(--primary); color: #1E4A8C; }
        .alert-warning { background: #FFF9EF; border-left: 4px solid var(--accent); color: #7B5E2A; }
        hr { margin: 24px 0; border: 0; height: 1px; background: var(--gray-200); }
        small { font-size: 0.7rem; color: var(--gray-500); display: block; margin-top: 4px; }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
            margin-bottom: 20px;
        }
        .info-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: var(--gray-50);
            border-radius: var(--radius-md);
        }
        .info-icon {
            width: 36px;
            height: 36px;
            background: var(--white);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
        }
        .info-label { font-size: 0.65rem; color: var(--gray-500); margin-bottom: 2px; }
        .info-value { font-size: 0.85rem; font-weight: 500; color: var(--gray-800); }
        .info-value code {
            font-size: 0.7rem;
            background: var(--gray-100);
            padding: 2px 6px;
            border-radius: 4px;
        }
        .config-row {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 0;
            border-bottom: 1px solid #F1F5F9;
        }
        .config-row:last-child {
            border-bottom: none;
        }
        .config-row .config-label {
            flex: 1;
            font-size: 0.8rem;
            color: var(--gray-600);
        }
        .config-row .config-value {
            width: 150px;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--gray-800);
        }
        .config-row .config-input {
            width: 150px;
            padding: 6px 10px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.8rem;
        }

        /* Audit Logs */
        .audit-table-container {
            overflow-x: auto;
            margin-top: 8px;
        }
        .audit-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.75rem;
            min-width: 500px;
        }
        .audit-table th {
            padding: 8px 12px;
            background: var(--gray-50);
            font-weight: 600;
            border-bottom: 2px solid var(--accent);
            text-align: left;
        }
        .audit-table td {
            padding: 6px 12px;
            border-bottom: 1px solid var(--gray-200);
        }
        .audit-action {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.6rem;
            font-weight: 600;
        }
        .audit-action.PROFILE_UPDATE { background: #DBEAFE; color: #1E40AF; }
        .audit-action.DEVICE_BINDING { background: #D1FAE5; color: #065F46; }
        .audit-action.SYSTEM_CONFIG_UPDATE { background: #FEF3C7; color: #B45309; }
        .audit-action.SESSION_REFRESH { background: #E0F2FE; color: #0369A1; }
        .audit-action.PASSWORD_CHANGE { background: #FCE4EC; color: #C2185B; }

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.7rem;
            color: var(--gray-600);
            text-decoration: none;
            position: relative;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        .nav-badge {
            position: absolute;
            top: -8px;
            right: -12px;
            background: var(--secondary);
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.6rem;
        }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .info-grid { grid-template-columns: 1fr; }
            .config-row { flex-wrap: wrap; }
            .config-row .config-input { width: 100%; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Administrator</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <!-- MAIN SECTION -->
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="../modules/manage_users.php" class="nav-item"><i class="fas fa-users-cog"></i> User Management</a>
                <a href="../modules/admin_household.php" class="nav-item"><i class="fas fa-home"></i> All Households</a>
            </div>
            <!-- SYSTEM SECTION -->
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="../modules/admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i> Poverty Analysis</a>
                <a href="../modules/admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="../admin/recycle_bin.php" class="nav-item"><i class="fas fa-trash-restore"></i> Recycle Bin
                    <?php if($deleted_count > 0): ?>
                        <span class="nav-badge"><?php echo $deleted_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <!-- ACCOUNT SECTION -->
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="admin_profile.php" class="nav-item active"><i class="fas fa-user-cog"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Admin Profile</h1>
                <p>Manage your account, security clearances, and system configurations</p>
            </div>
            <a href="admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Stats -->
        <div class="stats-row">
            <div class="stat-box"><div class="stat-number"><?php echo $total_users; ?></div><div class="stat-label">Total Users</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $total_households; ?></div><div class="stat-label">Households</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $total_applications; ?></div><div class="stat-label">Applications</div></div>
        </div>

        <!-- 1. ADMIN CLEARANCE CARD -->
        <div class="clearance-card">
            <div class="section-header"><i class="fas fa-shield-alt" style="color: var(--primary);"></i> System Access Clearance</div>
            <div style="margin-bottom: 8px; font-size: 0.7rem; color: var(--gray-500);">
                Admin ID: <strong><?php echo htmlspecialchars($admin_id); ?></strong>
                <span style="margin-left: 12px;">Status: <span class="status-badge" style="background:#D1FAE5;color:#065F46;"><?php echo $active_status; ?></span></span>
            </div>
            <?php if(!empty($clearance_items)): ?>
                <?php foreach($clearance_items as $item): ?>
                <div class="clearance-item">
                    <span class="clearance-label"><?php echo $item['label']; ?></span>
                    <span class="clearance-status <?php echo $item['value'] ? 'granted' : 'denied'; ?>">
                        <?php echo $item['value'] ? '✅ Granted' : '❌ Denied'; ?>
                    </span>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align:center; padding:12px; color:#94A3B8;">No clearance data available</div>
            <?php endif; ?>
        </div>

        <!-- 2. DEVICE BINDING CARD -->
        <div class="device-card">
            <div class="section-header"><i class="fas fa-fingerprint" style="color: var(--secondary);"></i> Device Lock & Binding</div>
            <div class="device-status">
                <span class="status-dot <?php echo $device_bound ? 'bound' : 'unbound'; ?>"></span>
                <span style="font-weight: 600;"><?php echo $device_bound ? 'Device Bound' : 'Device Not Bound'; ?></span>
                <?php if($hardware_lock): ?>
                    <span class="status-badge" style="background:#FEF3C7;color:#B45309;">🔒 Strict Hardware Lock</span>
                <?php endif; ?>
                <?php if($device_binding_date): ?>
                    <span style="font-size:0.7rem; color:var(--gray-500); margin-left:auto;">Bound: <?php echo date('M d, Y h:i A', strtotime($device_binding_date)); ?></span>
                <?php endif; ?>
            </div>
            
            <?php if($device_bound): ?>
            <div class="info-grid" style="margin-top:8px;">
                <div class="info-item">
                    <div><span class="info-label">MAC Address</span><div class="info-value"><code><?php echo htmlspecialchars($device_mac); ?></code></div></div>
                </div>
                <div class="info-item">
                    <div><span class="info-label">Biometric Signature</span><div class="info-value"><code><?php echo htmlspecialchars(substr($biometric_signature, 0, 20)) . '...'; ?></code></div></div>
                </div>
                <div class="info-item">
                    <div><span class="info-label">OS Fingerprint</span><div class="info-value"><?php echo htmlspecialchars($os_fingerprint); ?></div></div>
                </div>
                <div class="info-item">
                    <div><span class="info-label">Session Token</span><div class="info-value"><code><?php echo htmlspecialchars(substr($session_token, 0, 20)) . '...'; ?></code></div></div>
                </div>
            </div>
            <?php endif; ?>
            
            <form method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group" style="margin-bottom:0;">
                        <label>Hardware MAC Address</label>
                        <input type="text" name="hardware_device_mac_address" placeholder="00:1A:2B:3C:4D:5E" value="<?php echo htmlspecialchars($device_mac ?? ''); ?>" <?php echo $device_bound ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                        <label>Biometric Signature</label>
                        <input type="text" name="device_biometric_signature" placeholder="bio_hash_..." value="<?php echo htmlspecialchars($biometric_signature ?? ''); ?>" <?php echo $device_bound ? 'disabled' : ''; ?>>
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top:16px;">
                    <div class="form-group" style="margin-bottom:0;">
                        <label>Mobile OS Fingerprint</label>
                        <input type="text" name="mobile_os_fingerprint" placeholder="iOS_19.4_SecureEnclave" value="<?php echo htmlspecialchars($os_fingerprint ?? ''); ?>" <?php echo $device_bound ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group" style="margin-bottom:0; display:flex; align-items:center; gap:12px; padding-top:24px;">
                        <label style="margin-bottom:0;">
                            <input type="checkbox" name="enforce_strict_hardware_lock" value="1" <?php echo $hardware_lock ? 'checked' : ''; ?> <?php echo $device_bound ? 'disabled' : ''; ?>>
                            Enforce Strict Hardware Lock
                        </label>
                    </div>
                </div>
                <?php if($device_bound): ?>
                    <div style="margin-top:12px; display:flex; gap:8px;">
                        <a href="?refresh_session=1" class="btn-success btn-sm" style="width:auto; padding:8px 20px;">
                            <i class="fas fa-sync-alt"></i> Refresh Session
                        </a>
                        <button type="button" class="btn-danger btn-sm" style="width:auto; padding:8px 20px;" onclick="if(confirm('Unbind this device?')){document.getElementById('unbindForm').submit();}">
                            <i class="fas fa-unlink"></i> Unbind Device
                        </button>
                    </div>
                <?php else: ?>
                    <button type="submit" name="bind_device" class="btn-primary" style="margin-top:16px;">
                        <i class="fas fa-link"></i> Bind Device
                    </button>
                <?php endif; ?>
                
                <?php if(isset($device_success)): ?>
                    <div class="alert alert-success" style="margin-top:12px;"><i class="fas fa-check-circle"></i> <?php echo $device_success; ?></div>
                <?php endif; ?>
                <?php if(isset($device_error)): ?>
                    <div class="alert alert-danger" style="margin-top:12px;"><i class="fas fa-exclamation-triangle"></i> <?php echo $device_error; ?></div>
                <?php endif; ?>
                <?php if(isset($session_refresh_success)): ?>
                    <div class="alert alert-success" style="margin-top:12px;"><i class="fas fa-check-circle"></i> <?php echo $session_refresh_success; ?></div>
                <?php endif; ?>
                <?php if(isset($session_refresh_error)): ?>
                    <div class="alert alert-danger" style="margin-top:12px;"><i class="fas fa-exclamation-triangle"></i> <?php echo $session_refresh_error; ?></div>
                <?php endif; ?>
            </form>
            
            <form id="unbindForm" method="POST" style="display:none;">
                <input type="hidden" name="unbind_device" value="1">
            </form>
        </div>

        <!-- 3. SYSTEM CONFIGURATIONS CARD -->
        <div class="config-card">
            <div class="section-header"><i class="fas fa-sliders-h" style="color: var(--accent);"></i> Municipal Parameter Thresholds</div>
            <form method="POST">
                <?php if(isset($config_success)): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $config_success; ?></div>
                <?php endif; ?>
                <?php if(isset($config_error)): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $config_error; ?></div>
                <?php endif; ?>
                
                <?php foreach($system_configs as $config): ?>
                <div class="config-row">
                    <div class="config-label">
                        <strong><?php echo ucfirst(str_replace('_', ' ', $config['config_key'])); ?></strong>
                        <div style="font-size:0.65rem; color:var(--gray-400);"><?php echo htmlspecialchars($config['description'] ?? ''); ?></div>
                    </div>
                    <div class="config-value">
                        <?php if($config['updated_by_admin_id']): ?>
                            <small style="color:var(--gray-400);">Last updated by: <?php echo htmlspecialchars($config['updated_by_admin_id']); ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="config-input">
                        <input type="number" step="0.01" name="config_<?php echo $config['config_key']; ?>" value="<?php echo $config['config_value']; ?>" style="padding:6px 10px; border:1px solid var(--gray-200); border-radius:var(--radius-md); width:100%; font-size:0.8rem;">
                    </div>
                </div>
                <?php endforeach; ?>
                
                <div class="form-group" style="margin-top:16px;">
                    <label><i class="fas fa-pen"></i> Administrative Justification <span style="color:var(--secondary);">*</span></label>
                    <textarea name="administrative_justification" rows="2" placeholder="Explain why these system parameters are being updated..." required></textarea>
                </div>
                
                <button type="submit" name="update_system_config" class="btn-primary" style="background: var(--accent); color: #1E293B;">
                    <i class="fas fa-save"></i> Update System Configurations
                </button>
            </form>
        </div>

        <!-- 4. PROFILE CARD -->
        <div class="profile-card">
            <div class="profile-header">
                <div class="admin-badge"><i class="fas fa-user-shield"></i> Super Admin</div>
                <div class="session-badge <?php echo $session_valid ? 'active' : 'inactive'; ?>">
                    <?php echo $session_valid ? '🔓 Session Active' : '🔒 Session Expired'; ?>
                </div>
                <i class="fas fa-user-shield"></i>
                <h2><?php echo htmlspecialchars($user['full_name']); ?></h2>
                <p>Administrator • <?php echo htmlspecialchars($user['username']); ?></p>
                <p style="font-size:0.65rem; color:var(--gray-400); margin-top:4px;">
                    <?php echo htmlspecialchars($admin_profile['office_designation'] ?? 'OFFICE_OF_THE_MUNICIPAL_ADMINISTRATOR'); ?>
                </p>
            </div>

            <div class="profile-body">
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-user"></i></div>
                        <div>
                            <div class="info-label">Username</div>
                            <div class="info-value"><?php echo htmlspecialchars($user['username']); ?></div>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-calendar-plus"></i></div>
                        <div>
                            <div class="info-label">Member Since</div>
                            <div class="info-value"><?php echo date('F d, Y', strtotime($user['created_at'] ?? date('Y-m-d'))); ?></div>
                        </div>
                    </div>
                </div>

                <hr>

                <form method="POST">
                    <?php if($success): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if($error): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Full Name</label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Contact Number</label>
                        <input type="text" name="contact_number" value="<?php echo htmlspecialchars($user['contact_number'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-building"></i> Office Designation</label>
                        <input type="text" name="office_designation" value="<?php echo htmlspecialchars($admin_profile['office_designation'] ?? 'OFFICE_OF_THE_MUNICIPAL_ADMINISTRATOR'); ?>">
                    </div>
                    <button type="submit" name="update_profile" class="btn-primary"><i class="fas fa-save"></i> Update Profile</button>
                </form>

                <hr>

                <form method="POST">
                    <?php if(isset($password_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $password_success; ?></div>
                    <?php endif; ?>
                    <?php if(isset($password_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $password_error; ?></div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Current Password</label>
                        <input type="password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-key"></i> New Password</label>
                        <input type="password" name="new_password" required>
                        <small>Minimum 6 characters</small>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-check-circle"></i> Confirm New Password</label>
                        <input type="password" name="confirm_password" required>
                    </div>
                    <button type="submit" name="change_password" class="btn-secondary"><i class="fas fa-key"></i> Change Password</button>
                </form>
            </div>
        </div>

        <!-- 5. ADMIN AUDIT LOGS -->
        <div class="profile-card">
            <div class="profile-header" style="background: var(--gray-50);">
                <h3 style="font-size: 1rem; color: var(--primary);"><i class="fas fa-history"></i> Security Audit Logs</h3>
                <p style="font-size:0.7rem; color:var(--gray-500);">Recent administrative actions</p>
            </div>
            <div class="profile-body">
                <?php if(count($audit_logs) > 0): ?>
                <div class="audit-table-container">
                    <table class="audit-table">
                        <thead>
                            <tr>
                                <th>Action</th>
                                <th>Description</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($audit_logs as $log): ?>
                            <tr>
                                <td><span class="audit-action <?php echo $log['action_type']; ?>"><?php echo str_replace('_', ' ', $log['action_type']); ?></span></td>
                                <td><?php echo htmlspecialchars($log['action_description']); ?></td>
                                <td style="font-size:0.65rem; color:var(--gray-400);"><?php echo date('M d, Y h:i A', strtotime($log['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div style="text-align:center; padding:20px; color:#94A3B8;">
                    <i class="fas fa-info-circle"></i> No audit logs available
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="../modules/manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="../modules/admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="../modules/admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="../modules/admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Poverty</span></a>
        <a href="admin_profile.php" class="nav-item active"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };
        
        setTimeout(function() {
            document.querySelectorAll('.alert-success').forEach(function(el) {
                el.style.transition = 'opacity 0.5s ease';
                el.style.opacity = '0';
                setTimeout(function() { el.remove(); }, 500);
            });
        }, 5000);
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>