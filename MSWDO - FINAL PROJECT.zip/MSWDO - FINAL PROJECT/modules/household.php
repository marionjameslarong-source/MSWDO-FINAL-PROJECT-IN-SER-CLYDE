<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Allow only staff roles
$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];

// ============================================================
// CREATE/ALTER DELETED HOUSEHOLDS TABLE
// ============================================================
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'deleted_households'");
    if($stmt->rowCount() == 0) {
        $pdo->exec("
            CREATE TABLE deleted_households (
                id INT AUTO_INCREMENT PRIMARY KEY,
                original_id INT NOT NULL,
                head_first_name VARCHAR(100) NOT NULL,
                head_last_name VARCHAR(100) NOT NULL,
                barangay VARCHAR(100),
                address TEXT,
                monthly_income DECIMAL(12,2),
                total_members INT DEFAULT 1,
                is_4ps_beneficiary TINYINT(1) DEFAULT 0,
                gps_latitude DECIMAL(10,8),
                gps_longitude DECIMAL(11,8),
                deleted_by INT NOT NULL,
                deleted_by_name VARCHAR(100) NOT NULL,
                deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                permanent_deleted_at TIMESTAMP NULL,
                poverty_status VARCHAR(50),
                verification_status VARCHAR(50),
                created_at TIMESTAMP NULL,
                INDEX idx_original_id (original_id),
                INDEX idx_deleted_by (deleted_by),
                INDEX idx_deleted_at (deleted_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    } else {
        $stmt = $pdo->query("SHOW COLUMNS FROM deleted_households LIKE 'verification_status'");
        if($stmt->rowCount() == 0) {
            $pdo->exec("ALTER TABLE deleted_households ADD COLUMN verification_status VARCHAR(50) NULL");
        }
        $stmt = $pdo->query("SHOW COLUMNS FROM deleted_households LIKE 'created_at'");
        if($stmt->rowCount() == 0) {
            $pdo->exec("ALTER TABLE deleted_households ADD COLUMN created_at TIMESTAMP NULL");
        }
    }
} catch(PDOException $e) {
    error_log("Failed to setup deleted_households table: " . $e->getMessage());
}

// ============================================================
// CHECK IF POVERTY_STATUS COLUMN EXISTS
// ============================================================
$has_poverty_status = false;
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM households LIKE 'poverty_status'");
    $has_poverty_status = $stmt->rowCount() > 0;
} catch(PDOException $e) {
    $has_poverty_status = false;
}

// ============================================================
// DATABASE INDEXING OPTIMIZATION
// ============================================================
function indexExists($pdo, $tableName, $indexName) {
    try {
        $stmt = $pdo->prepare("SHOW INDEX FROM $tableName WHERE Key_name = ?");
        $stmt->execute([$indexName]);
        return $stmt->rowCount() > 0;
    } catch(PDOException $e) {
        return false;
    }
}

function createOptimizationIndexes($pdo) {
    $messages = [];
    $indexes = [
        ['table' => 'households', 'name' => 'idx_household_verification', 'sql' => "CREATE INDEX idx_household_verification ON households (verification_status)"],
        ['table' => 'households', 'name' => 'idx_household_geo_poverty', 'sql' => "CREATE INDEX idx_household_geo_poverty ON households (barangay, poverty_status)"],
        ['table' => 'households', 'name' => 'idx_household_user_id', 'sql' => "CREATE INDEX idx_household_user_id ON households (user_id)"],
        ['table' => 'welfare_applications', 'name' => 'idx_financial_aid_status', 'sql' => "CREATE INDEX idx_financial_aid_status ON welfare_applications (status, program_type)"],
        ['table' => 'welfare_applications', 'name' => 'idx_applications_user_id', 'sql' => "CREATE INDEX idx_applications_user_id ON welfare_applications (user_id)"],
        ['table' => 'users', 'name' => 'idx_users_role', 'sql' => "CREATE INDEX idx_users_role ON users (role)"],
        ['table' => 'verification_audit_logs', 'name' => 'idx_audit_household_id', 'sql' => "CREATE INDEX idx_audit_household_id ON verification_audit_logs (household_id)"]
    ];
    
    foreach($indexes as $index) {
        try {
            if(!indexExists($pdo, $index['table'], $index['name'])) {
                $pdo->exec($index['sql']);
                $messages[] = "✅ Created index: {$index['name']} on {$index['table']}";
            } else {
                $messages[] = "✓ Index already exists: {$index['name']}";
            }
        } catch(PDOException $e) {
            $messages[] = "⚠️ Failed to create index: {$index['name']} - " . $e->getMessage();
        }
    }
    return $messages;
}

$index_messages = [];
try {
    $index_messages = createOptimizationIndexes($pdo);
} catch(PDOException $e) {}

// ============================================================
// POVERTY STATUS CALCULATION FUNCTION - 3 CLASSES
// ============================================================
function calculatePovertyStatus($income, $rosterSize) {
    $poverty_line_per_capita = 4500.00;
    $rich_threshold_per_capita = 25000.00;
    if ($rosterSize <= 0) return "POOR";
    $perCapitaIncome = $income / $rosterSize;
    if ($perCapitaIncome < $poverty_line_per_capita) return "POOR";
    else if ($perCapitaIncome >= $poverty_line_per_capita && $perCapitaIncome < $rich_threshold_per_capita) return "MIDDLE_CLASS";
    else return "RICH";
}

function getPovertyBadge($status) {
    switch($status) {
        case 'POOR': return '<span class="poverty-badge badge-poor"><i class="fas fa-exclamation-triangle"></i> Poor</span>';
        case 'MIDDLE_CLASS': return '<span class="poverty-badge badge-middle-class"><i class="fas fa-chart-line"></i> Middle-Class</span>';
        case 'RICH': return '<span class="poverty-badge badge-rich"><i class="fas fa-crown"></i> Rich</span>';
        default: return '<span class="poverty-badge badge-unknown"><i class="fas fa-question-circle"></i> Not Classified</span>';
    }
}

// ============================================================
// 1. HANDLE APPROVE (Direct Approve)
// ============================================================
if(isset($_POST['approve_household'])) {
    $household_id = intval($_POST['household_id'] ?? 0);
    $verification_notes = trim($_POST['verification_notes'] ?? '');
    
    if($household_id > 0) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT verification_status, user_id FROM households WHERE id = ?");
            $stmt->execute([$household_id]);
            $current = $stmt->fetch();
            $previous_status = $current['verification_status'] ?? 'pending_review';
            
            $stmt = $pdo->prepare("UPDATE households SET verification_status = 'verified_approved', verified_by = ?, verified_by_name = ?, verified_at = NOW(), verification_notes = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$user_id, $full_name, $verification_notes, $household_id]);
            
            $log_id = 'log_' . uniqid();
            $stmt = $pdo->prepare("INSERT INTO verification_audit_logs (log_id, household_id, previous_status, new_status, action_by_staff_id, remarks) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$log_id, $household_id, $previous_status, 'verified_approved', $user_id, $verification_notes]);
            
            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?, 'household_approved', ?, NOW())");
            $stmt->execute([$user_id, "Approved household #$household_id by $full_name"]);
            
            $pdo->commit();
            $success_message = "Household #$household_id has been approved successfully!";
        } catch(Exception $e) {
            $pdo->rollBack();
            $error_message = "Failed to approve: " . $e->getMessage();
        }
    }
}

// ============================================================
// 2. HANDLE REJECT (Direct Reject)
// ============================================================
if(isset($_POST['reject_household'])) {
    $household_id = intval($_POST['household_id'] ?? 0);
    $rejection_reason = trim($_POST['rejection_reason'] ?? '');
    $rejection_notes = trim($_POST['rejection_notes'] ?? '');
    
    if($household_id > 0 && !empty($rejection_reason)) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT verification_status FROM households WHERE id = ?");
            $stmt->execute([$household_id]);
            $current = $stmt->fetch();
            $previous_status = $current['verification_status'] ?? 'pending_review';
            
            $stmt = $pdo->prepare("UPDATE households SET verification_status = 'rejected_needs_correction', rejected_by = ?, rejected_by_name = ?, rejected_at = NOW(), rejection_reason = ?, rejection_notes = ?, verification_notes = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$user_id, $full_name, $rejection_reason, $rejection_notes, $rejection_notes, $household_id]);
            
            $log_id = 'log_' . uniqid();
            $stmt = $pdo->prepare("INSERT INTO verification_audit_logs (log_id, household_id, previous_status, new_status, action_by_staff_id, remarks) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$log_id, $household_id, $previous_status, 'rejected_needs_correction', $user_id, $rejection_notes]);
            
            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?, 'household_rejected', ?, NOW())");
            $stmt->execute([$user_id, "Rejected household #$household_id - Reason: $rejection_reason"]);
            
            $pdo->commit();
            $success_message = "Household #$household_id has been rejected and flagged for corrections.";
        } catch(Exception $e) {
            $pdo->rollBack();
            $error_message = "Failed to reject: " . $e->getMessage();
        }
    } else {
        $error_message = "Please select a rejection reason.";
    }
}

// ============================================================
// 3. HANDLE PROCESS AND NOTIFY
// ============================================================
if(isset($_POST['process_and_notify'])) {
    $household_id = intval($_POST['household_id'] ?? 0);
    $review_action = $_POST['review_action'] ?? 'APPROVE';
    $send_push = isset($_POST['send_push_notification']) ? true : false;
    $custom_message = trim($_POST['custom_message'] ?? '');
    $internal_remarks = trim($_POST['internal_remarks'] ?? '');
    
    if($household_id > 0) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("SELECT verification_status, user_id FROM households WHERE id = ?");
            $stmt->execute([$household_id]);
            $household = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if(!$household) {
                throw new Exception("Household not found.");
            }
            
            $previous_status = $household['verification_status'] ?? 'pending_review';
            $resident_user_id = $household['user_id'];
            $new_status = ($review_action === 'APPROVE') ? 'verified_approved' : 'rejected_needs_correction';
            
            if($previous_status === 'verified_approved' && $review_action === 'APPROVE') {
                throw new Exception("Household is already verified and approved.");
            }
            
            $stmt = $pdo->prepare("UPDATE households SET verification_status = ?, verified_by = ?, verified_by_name = ?, verified_at = NOW(), verification_notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND verification_status = ?");
            $stmt->execute([$new_status, $user_id, $full_name, $internal_remarks ?: ($review_action === 'APPROVE' ? 'Verified and approved via staff review.' : 'Rejected with correction requirements.'), $household_id, $previous_status]);
            
            if($stmt->rowCount() === 0) {
                throw new Exception("Failed to update household status. It may have been modified by another user.");
            }
            
            $log_id = 'log_' . uniqid();
            $stmt = $pdo->prepare("INSERT INTO verification_audit_logs (log_id, household_id, previous_status, new_status, action_by_staff_id, remarks) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$log_id, $household_id, $previous_status, $new_status, $user_id, $internal_remarks ?: ($review_action === 'APPROVE' ? 'Approved via process and notify.' : 'Rejected via process and notify.')]);
            
            $push_delivered = false;
            
            if($send_push && $resident_user_id) {
                $notif_title = $review_action === 'APPROVE' 
                    ? '🎉 Household Profile Approved!' 
                    : '⚠️ Profile Correction Required';
                
                $notif_body = $custom_message ?: (
                    $review_action === 'APPROVE' 
                        ? 'Your household record has been verified and approved by ' . $full_name . '. You can now access all municipal programs.'
                        : 'Your household record requires corrections. Please check your dashboard for details.'
                );
                
                $notification_id = 'notif_' . uniqid();
                $stmt = $pdo->prepare("INSERT INTO resident_notifications (notification_id, user_id, title, body, timestamp_sent, related_household_id, notification_type) VALUES (?, ?, ?, ?, NOW(), ?, ?)");
                $stmt->execute([$notification_id, $resident_user_id, $notif_title, $notif_body, $household_id, 'VERIFICATION']);
                
                $push_delivered = true;
            }
            
            $action = $review_action === 'APPROVE' ? 'household_verified_with_notify' : 'household_rejected_with_notify';
            $details = $review_action === 'APPROVE' 
                ? "Approved household #$household_id with notification" 
                : "Rejected household #$household_id with notification";
            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$user_id, $action, $details]);
            
            $pdo->commit();
            
            $success_message = "✅ Household #$household_id has been " . strtolower($review_action) . "d successfully!";
            if($push_delivered) {
                $success_message .= " Push notification sent to resident.";
            } else {
                $success_message .= " No push notification sent.";
            }
            
            echo '<script>
                setTimeout(function() {
                    window.location.href = "household.php";
                }, 1500);
            </script>';
            
        } catch(Exception $e) {
            $pdo->rollBack();
            $error_message = "Failed to process: " . $e->getMessage();
        }
    }
}

// ============================================================
// 4. UPDATE POVERTY STATUS FOR A HOUSEHOLD
// ============================================================
if(isset($_POST['recalculate_poverty'])) {
    $household_id = intval($_POST['household_id'] ?? 0);
    if($household_id > 0) {
        try {
            $stmt = $pdo->prepare("SELECT monthly_income, total_members FROM households WHERE id = ?");
            $stmt->execute([$household_id]);
            $household = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if($household) {
                $income = floatval($household['monthly_income'] ?? 0);
                $members = intval($household['total_members'] ?? 1);
                $poverty_status = calculatePovertyStatus($income, $members);
                
                global $has_poverty_status;
                if($has_poverty_status) {
                    $stmt = $pdo->prepare("UPDATE households SET poverty_status = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$poverty_status, $household_id]);
                    $success_message = "Poverty status recalculated: " . str_replace('_', ' ', $poverty_status);
                } else {
                    $success_message = "Poverty status calculated: " . str_replace('_', ' ', $poverty_status) . " (column not available)";
                }
            } else {
                $error_message = "Household not found.";
            }
        } catch(PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
}

// ============================================================
// 5. BULK RECALCULATE POVERTY STATUS
// ============================================================
if(isset($_POST['bulk_recalculate_poverty'])) {
    try {
        $stmt = $pdo->query("SELECT id, monthly_income, total_members FROM households");
        $households = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $updated_count = 0; $poor_count = 0; $middle_class_count = 0; $rich_count = 0;
        
        global $has_poverty_status;
        
        foreach($households as $hh) {
            $income = floatval($hh['monthly_income'] ?? 0);
            $members = intval($hh['total_members'] ?? 1);
            $poverty_status = calculatePovertyStatus($income, $members);
            
            if($has_poverty_status) {
                $stmt = $pdo->prepare("UPDATE households SET poverty_status = ? WHERE id = ?");
                $stmt->execute([$poverty_status, $hh['id']]);
            }
            $updated_count++;
            if($poverty_status === 'POOR') $poor_count++;
            if($poverty_status === 'MIDDLE_CLASS') $middle_class_count++;
            if($poverty_status === 'RICH') $rich_count++;
        }
        $success_message = "✅ Poverty status recalculated for $updated_count households. Poor: $poor_count | Middle-Class: $middle_class_count | Rich: $rich_count";
    } catch(PDOException $e) {
        $error_message = "Database error: " . $e->getMessage();
    }
}

// ============================================================
// 6. DELETE HOUSEHOLD (Move to Recycle Bin)
// ============================================================
if(isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    try {
        $stmt = $pdo->prepare("SELECT * FROM households WHERE id = ?");
        $stmt->execute([$delete_id]);
        $household = $stmt->fetch();
        
        if(!$household) {
            header("Location: household.php?error=1&msg=Household+not+found");
            exit();
        }
        
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("DELETE FROM household_members WHERE household_id = ?");
        $stmt->execute([$delete_id]);
        
        $poverty_status = 'Not Classified';
        if($has_poverty_status && isset($household['poverty_status']) && !empty($household['poverty_status'])) {
            $poverty_status = $household['poverty_status'];
        }
        
        $stmt = $pdo->prepare("INSERT INTO deleted_households (original_id, head_first_name, head_last_name, barangay, address, monthly_income, total_members, is_4ps_beneficiary, gps_latitude, gps_longitude, deleted_by, deleted_by_name, poverty_status, verification_status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $result = $stmt->execute([
            $household['id'], $household['head_first_name'], $household['head_last_name'],
            $household['barangay'], $household['address'], $household['monthly_income'],
            $household['total_members'], $household['is_4ps_beneficiary'],
            $household['gps_latitude'], $household['gps_longitude'],
            $user_id, $full_name, $poverty_status,
            $household['verification_status'] ?? 'pending_review', $household['created_at']
        ]);
        
        if(!$result) throw new Exception("Failed to insert into deleted_households");
        
        $stmt = $pdo->prepare("DELETE FROM households WHERE id = ?");
        $stmt->execute([$delete_id]);
        
        $pdo->commit();
        header("Location: household.php?deleted=1");
        exit();
    } catch(Exception $e) {
        $pdo->rollBack();
        error_log("Delete error for ID $delete_id: " . $e->getMessage());
        header("Location: household.php?error=1&msg=" . urlencode($e->getMessage()));
        exit();
    }
}

// ============================================================
// 7. GET HOUSEHOLD DATA WITH FILTERS
// ============================================================
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$barangay_filter = isset($_GET['barangay']) ? trim($_GET['barangay']) : '';
$verification_filter = isset($_GET['verification']) ? trim($_GET['verification']) : '';
$poverty_filter = isset($_GET['poverty']) ? trim($_GET['poverty']) : '';

$query = "SELECT h.*, u.full_name as resident_name FROM households h LEFT JOIN users u ON h.user_id = u.id WHERE 1=1";
$params = [];

if(!empty($search)) {
    $query .= " AND (h.head_first_name LIKE ? OR h.head_last_name LIKE ?)";
    $params[] = "%$search%"; $params[] = "%$search%";
}
if(!empty($barangay_filter)) {
    $query .= " AND h.barangay = ?";
    $params[] = $barangay_filter;
}
if(!empty($verification_filter)) {
    $query .= " AND h.verification_status = ?";
    $params[] = $verification_filter;
}
if(!empty($poverty_filter) && $has_poverty_status) {
    $query .= " AND h.poverty_status = ?";
    $params[] = $poverty_filter;
}
$query .= " ORDER BY h.created_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$households = $stmt->fetchAll();

// Statistics
$stmt = $pdo->query("SELECT COUNT(*) as total FROM households");
$total_households = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE verification_status = 'pending_review'");
$pending_review = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE verification_status = 'verified_approved'");
$verified_count = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE verification_status = 'rejected_needs_correction'");
$rejected_count = $stmt->fetch()['total'];

$poor_count = 0; $middle_class_count = 0; $rich_count = 0; $unclassified_count = 0;
if($has_poverty_status) {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE poverty_status = 'POOR'");
    $poor_count = $stmt->fetch()['total'] ?? 0;
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE poverty_status = 'MIDDLE_CLASS'");
    $middle_class_count = $stmt->fetch()['total'] ?? 0;
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE poverty_status = 'RICH'");
    $rich_count = $stmt->fetch()['total'] ?? 0;
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE poverty_status IS NULL OR poverty_status = ''");
    $unclassified_count = $stmt->fetch()['total'] ?? 0;
}

$stmt = $pdo->query("SELECT DISTINCT barangay FROM households WHERE barangay IS NOT NULL AND barangay != '' ORDER BY barangay");
$barangays = $stmt->fetchAll();

$stmt = $pdo->query("SELECT SUM(total_members) as total FROM households");
$total_members = $stmt->fetch()['total'] ?? 0;

$deleted = isset($_GET['deleted']);
$error = isset($_GET['error']);
$error_msg = isset($_GET['msg']) ? urldecode($_GET['msg']) : '';
$success_message = isset($success_message) ? $success_message : null;
$error_message = isset($error_message) ? $error_message : null;

$rejection_reasons = [
    'INCORRECT_INCOME_DECLARATION' => 'Incorrect Income Declaration',
    'MISSING_DOCUMENTS' => 'Missing Required Documents',
    'INCOMPLETE_INFORMATION' => 'Incomplete Information',
    'DISCREPANCY_IN_DATA' => 'Discrepancy in Data',
    'FRAUDULENT_INFORMATION' => 'Fraudulent Information',
    'NEEDS_HOME_VISIT' => 'Needs Home Visit Verification',
    'OTHER' => 'Other'
];

function getVerificationBadge($status) {
    switch($status) {
        case 'pending_review': return '<span class="verification-badge badge-pending"><i class="fas fa-clock"></i> Pending Review</span>';
        case 'verified_approved': return '<span class="verification-badge badge-approved"><i class="fas fa-check-circle"></i> Approved</span>';
        case 'rejected_needs_correction': return '<span class="verification-badge badge-rejected"><i class="fas fa-times-circle"></i> Needs Correction</span>';
        default: return '<span class="verification-badge badge-pending"><i class="fas fa-clock"></i> Pending Review</span>';
    }
}

function getIndexStatus($pdo) {
    $status = [];
    $indexes = ['idx_household_verification', 'idx_household_geo_poverty', 'idx_household_user_id', 'idx_financial_aid_status', 'idx_applications_user_id', 'idx_users_role', 'idx_audit_household_id'];
    foreach($indexes as $name) {
        try {
            $stmt = $pdo->prepare("SHOW INDEX FROM households WHERE Key_name = ?");
            $stmt->execute([$name]);
            $status[$name] = $stmt->rowCount() > 0;
        } catch(PDOException $e) { $status[$name] = false; }
    }
    return $status;
}

$index_status = getIndexStatus($pdo);
$index_count = count(array_filter($index_status));
$total_indexes = count($index_status);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Household Records - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F1F5F9; color: #334155; padding-bottom: 75px; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F; --accent: #F5B042;
            --success: #059669; --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9;
            --gray-200: #E2E8F0; --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B;
            --gray-600: #475569; --gray-700: #334155; --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem; --radius-md: 0.75rem; --radius-lg: 1rem; --radius-xl: 1.5rem; --radius-2xl: 2rem;
        }
        .app { display: flex; min-height: 100vh; }
        .sidebar { 
            width: 260px; 
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%); 
            border-right: 1px solid var(--gray-200); 
            position: fixed; top: 0; left: 0; bottom: 0; 
            overflow-y: auto; z-index: 40; 
        }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        /* ============================================================
           UPDATED: Logo container now displays MSWDO logo image
           ============================================================ */
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--gray-400); margin-bottom: 8px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; font-size: 0.85rem; font-weight: 500; transition: all 0.2s ease; margin-bottom: 2px; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25); }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s ease; font-size: 0.8rem; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu { margin-left: 32px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 12px; margin-bottom: 2px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; font-size: 0.8rem; transition: all 0.2s; }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .main-content { flex: 1; margin-left: 260px; padding: 24px 32px 80px 32px; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid var(--gray-200); }
        .page-title h1 { font-size: 1.5rem; font-weight: 800; color: var(--gray-800); margin-bottom: 4px; letter-spacing: -0.02em; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--white); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 600; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }
        .poverty-badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 0.65rem; font-weight: 700; }
        .badge-poor { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        .badge-middle-class { background: #DBEAFE; color: #1E40AF; border: 1px solid #93C5FD; }
        .badge-rich { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .badge-unknown { background: #F3F4F6; color: #6B7280; border: 1px solid #9CA3AF; }
        .poverty-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; }
        .poverty-stat-card { background: white; padding: 16px; border-radius: var(--radius-lg); border: 1px solid var(--gray-200); text-align: center; transition: all 0.2s; box-shadow: var(--shadow-sm); }
        .poverty-stat-card:hover { box-shadow: var(--shadow-md); transform: translateY(-2px); }
        .poverty-stat-card .pov-stat-number { font-size: 1.5rem; font-weight: 800; }
        .poverty-stat-card .pov-stat-label { font-size: 0.65rem; color: var(--gray-500); margin-top: 4px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; }
        .poverty-stat-card.poor .pov-stat-number { color: #D32F2F; }
        .poverty-stat-card.middle-class .pov-stat-number { color: #1E4A8C; }
        .poverty-stat-card.rich .pov-stat-number { color: #F5B042; }
        .poverty-stat-card.unclassified .pov-stat-number { color: #6B7280; }
        .stats-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: var(--white); padding: 20px 16px; border-radius: var(--radius-xl); border: 1px solid var(--gray-200); text-align: center; transition: all 0.3s; box-shadow: var(--shadow-sm); }
        .stat-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); }
        .stat-card i { font-size: 1.8rem; margin-bottom: 8px; }
        .stat-number { font-size: 1.6rem; font-weight: 800; color: var(--gray-800); letter-spacing: -0.03em; }
        .stat-label { font-size: 0.68rem; color: var(--gray-500); font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 4px; }
        .filter-card { background: var(--white); border-radius: var(--radius-xl); padding: 24px; margin-bottom: 24px; border: 1px solid var(--gray-200); box-shadow: var(--shadow-sm); }
        .filter-row { display: flex; gap: 16px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { flex: 1; min-width: 180px; }
        .filter-group label { display: block; font-size: 0.7rem; font-weight: 700; color: var(--gray-600); margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.04em; }
        .filter-group input, .filter-group select { width: 100%; padding: 10px 14px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-family: 'Inter', sans-serif; font-size: 0.85rem; transition: all 0.2s; }
        .filter-group input:focus, .filter-group select:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1); }
        .btn-primary { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border: none; padding: 10px 20px; border-radius: var(--radius-md); font-weight: 700; font-size: 0.8rem; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-secondary { background: var(--gray-100); color: var(--gray-700); border: 1.5px solid var(--gray-200); padding: 10px 20px; border-radius: var(--radius-md); font-weight: 600; font-size: 0.8rem; cursor: pointer; text-decoration: none; display: inline-block; transition: all 0.2s; }
        .btn-secondary:hover { background: var(--gray-200); }
        .btn-success { background: var(--success); color: white; border: none; padding: 6px 12px; border-radius: 20px; font-weight: 600; cursor: pointer; font-size: 0.7rem; }
        .btn-success:hover { background: #047857; }
        .btn-danger { background: var(--secondary); color: white; border: none; padding: 6px 12px; border-radius: 20px; font-weight: 600; cursor: pointer; font-size: 0.7rem; }
        .btn-danger:hover { background: #B71C1C; }
        .notification-toggle { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: var(--gray-50); border-radius: var(--radius-md); border: 1px solid var(--gray-200); margin-bottom: 12px; }
        .notification-toggle .toggle-label { display: flex; align-items: center; gap: 8px; font-size: 0.8rem; font-weight: 500; color: var(--gray-700); }
        .notification-toggle .toggle-label i { color: var(--accent); }
        .notification-toggle .toggle-label .toggle-desc { font-weight: 400; font-size: 0.7rem; color: var(--gray-500); }
        .toggle-switch { position: relative; width: 44px; height: 24px; flex-shrink: 0; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background: var(--gray-300); border-radius: 24px; transition: all 0.3s ease; }
        .toggle-slider:before { content: ''; position: absolute; height: 18px; width: 18px; left: 3px; bottom: 3px; background: white; border-radius: 50%; transition: all 0.3s ease; }
        .toggle-switch input:checked + .toggle-slider { background: #007AFF; }
        .toggle-switch input:checked + .toggle-slider:before { transform: translateX(20px); }
        .btn-process { background: #007AFF; color: white; border: none; padding: 6px 14px; border-radius: 20px; font-weight: 600; cursor: pointer; font-size: 0.7rem; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s; }
        .btn-process:hover { background: #0055B3; }
        .btn-recalculate { background: #7C3AED; color: white; border: none; padding: 6px 12px; border-radius: 20px; font-weight: 600; cursor: pointer; font-size: 0.65rem; display: inline-flex; align-items: center; gap: 4px; transition: all 0.2s; }
        .btn-recalculate:hover { background: #6D28D9; }
        .table-container { background: var(--white); border-radius: var(--radius-xl); border: 1px solid var(--gray-200); overflow-x: auto; box-shadow: var(--shadow-sm); }
        .table { width: 100%; border-collapse: collapse; font-size: 0.8rem; min-width: 1000px; }
        .table th { text-align: left; padding: 14px 16px; background: linear-gradient(180deg, #F8FAFC, #F1F5F9); font-weight: 700; color: var(--gray-600); border-bottom: 2px solid var(--accent); text-transform: uppercase; letter-spacing: 0.05em; font-size: 0.68rem; }
        .table td { padding: 12px 16px; border-bottom: 1px solid var(--gray-100); }
        .table tr:hover td { background: var(--gray-50); }
        .btn-view { background: var(--primary); color: white; padding: 6px 12px; border-radius: 20px; text-decoration: none; font-size: 0.7rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s; }
        .btn-view:hover { background: var(--primary-dark); }
        .btn-delete { background: #FEF2F2; color: var(--secondary); padding: 6px 12px; border-radius: 20px; text-decoration: none; font-size: 0.7rem; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s; border: none; cursor: pointer; margin-left: 8px; }
        .btn-delete:hover { background: var(--secondary); color: white; }
        .action-buttons { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .verification-badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.68rem; font-weight: 700; letter-spacing: 0.03em; }
        .badge-pending { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .badge-approved { background: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7; }
        .badge-rejected { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        .empty-state { text-align: center; padding: 60px 20px; color: var(--gray-500); }
        .empty-state i { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; }
        .alert { padding: 16px 20px; border-radius: var(--radius-lg); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; animation: slideDown 0.3s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .alert-success { background: #ECFDF5; border-left: 4px solid var(--success); color: #065F46; }
        .alert-error { background: #FEF2F2; border-left: 4px solid var(--secondary); color: #991B1B; }
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(12px); display: flex; justify-content: space-around; padding: 8px 16px 12px; border-top: 1px solid var(--gray-200); z-index: 100; box-shadow: 0 -4px 12px rgba(0,0,0,0.04); }
        .bottom-nav .nav-item { display: flex; flex-direction: column; align-items: center; padding: 6px 12px; font-size: 0.68rem; color: var(--gray-600); text-decoration: none; font-weight: 600; }
        .bottom-nav .nav-item i { font-size: 1.1rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .menu-toggle:hover { background: var(--gray-100); }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1100; align-items: center; justify-content: center; }
        .modal-content { background: white; border-radius: var(--radius-xl); max-width: 550px; width: 90%; padding: 24px; max-height: 80vh; overflow-y: auto; box-shadow: var(--shadow-lg); }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 6px; color: var(--gray-700); text-transform: uppercase; letter-spacing: 0.04em; }
        .form-group textarea, .form-group select, .form-group input { width: 100%; padding: 10px 12px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-family: inherit; font-size: 0.85rem; transition: all 0.2s; }
        .form-group textarea:focus, .form-group select:focus, .form-group input:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1); }
        .form-group .helper-text { font-size: 0.7rem; color: var(--gray-500); margin-top: 4px; }
        .btn-submit { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border: none; padding: 10px 20px; border-radius: var(--radius-md); cursor: pointer; font-weight: 700; font-size: 0.85rem; transition: all 0.2s; box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25); }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-cancel { background: var(--gray-200); color: var(--gray-700); border: none; padding: 10px 20px; border-radius: var(--radius-md); cursor: pointer; margin-left: 10px; font-weight: 600; }
        .modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--gray-200); }
        .required { color: var(--secondary); }
        .index-info-card { background: white; border-radius: var(--radius-xl); border: 1px solid var(--gray-200); padding: 16px 20px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; box-shadow: var(--shadow-sm); }
        .index-info-card .index-status { display: flex; align-items: center; gap: 12px; }
        .index-info-card .index-status .index-icon { font-size: 1.2rem; color: var(--primary); }
        .index-info-card .index-status .index-text { font-size: 0.8rem; color: var(--gray-600); }
        .index-info-card .index-status .index-text strong { color: var(--gray-800); }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
            .poverty-stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
            .filter-row { flex-direction: column; }
            .notification-toggle { flex-direction: column; align-items: flex-start; }
            .index-info-card { flex-direction: column; align-items: flex-start; }
        }
        @media (max-width: 480px) { 
            .stats-grid { grid-template-columns: 1fr; }
            .poverty-stats-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="app">
   <aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <!-- ============================================================
                 UPDATED: MSWDO Logo Image replaces Font Awesome icon
                 ============================================================ -->
            <div class="logo-icon">
                <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
            </div>
            <div class="logo-text">
                <h1>MSWDO Cantilan</h1>
                <p>Staff Portal</p>
            </div>
        </div>
    </div>
    <nav class="nav-menu">
        <div class="nav-section">
            <div class="nav-label">Main</div>
            <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i> <span>Dashboard</span>
            </a>
            <a href="mswdstaff_communityservice.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
            </a>
            <a href="household.php" class="nav-item active">
                <i class="fas fa-users"></i> <span>Household Records</span>
            </a>
        </div>
        <div class="nav-section">
            <div class="nav-label">Applications</div>
            <div class="nav-item collapsible" id="programToggle">
                <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                <i class="fas fa-chevron-right chevron" id="programIcon"></i>
            </div>
            <div class="submenu" id="programSubmenu">
                <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                <a href="mswdstaff_aics.php" class="submenu-item"><i class="fas fa-coins"></i> AICS</a>
                <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
            </div>
            <a href="mswdstaff_idapplication.php" class="nav-item">
                <i class="fas fa-id-card"></i> <span>ID Applications</span>
            </a>
            <a href="staff_eligibility_engine.php" class="nav-item">
                <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
            </a>
            <a href="reports.php" class="nav-item">
                <i class="fas fa-chart-bar"></i> <span>Reports</span>
            </a>
        </div>
        <div class="nav-section">
            <div class="nav-label">Account</div>
            <a href="mswdstaff_profile.php" class="nav-item">
                <i class="fas fa-user-circle"></i> <span>Profile</span>
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </div>
    </nav>
</aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Household Records</h1>
                    <p>Manage, verify, and monitor poverty classification</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small><?php echo ucfirst(str_replace('_', ' ', $role)); ?></small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="index-info-card">
            <div class="index-status">
                <span class="index-icon"><i class="fas fa-database"></i></span>
                <span class="index-text">
                    <strong>Database Index Status:</strong> 
                    <?php 
                    if($index_count == $total_indexes) echo '<span style="color: #059669;">✅ Fully Optimized</span>';
                    elseif($index_count > 0) echo '<span style="color: #B45309;">⚠️ Partially Optimized</span>';
                    else echo '<span style="color: #991B1B;">❌ Not Optimized</span>';
                    ?>
                    <span style="color: var(--gray-400); margin-left: 8px; font-weight: 400;">(<?php echo $index_count; ?>/<?php echo $total_indexes; ?> indexes active)</span>
                </span>
            </div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap; font-size: 0.65rem;">
                <?php foreach($index_status as $name => $exists): ?>
                    <span style="display: inline-flex; align-items: center; gap: 4px; padding: 2px 10px; border-radius: 12px; background: <?php echo $exists ? '#D1FAE5' : '#FEE2E2'; ?>; color: <?php echo $exists ? '#065F46' : '#991B1B'; ?>;">
                        <i class="fas <?php echo $exists ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                        <?php 
                        $labels = ['idx_household_verification' => 'Verification','idx_household_geo_poverty' => 'Geo+Poverty','idx_household_user_id' => 'User ID','idx_financial_aid_status' => 'Financial Aid','idx_applications_user_id' => 'App User','idx_users_role' => 'User Role','idx_audit_household_id' => 'Audit'];
                        echo $labels[$name] ?? $name;
                        ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if($deleted): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> Household record has been moved to recycle bin.</div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> An error occurred while deleting the record. 
                <?php if($error_msg): ?><br><small style="color: #991B1B;">Error: <?php echo htmlspecialchars($error_msg); ?></small><?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if(isset($success_message)): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if(isset($error_message)): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?></div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card"><i class="fas fa-home" style="color: var(--primary);"></i><div class="stat-number"><?php echo $total_households; ?></div><div class="stat-label">Total Households</div></div>
            <div class="stat-card"><i class="fas fa-users" style="color: var(--success);"></i><div class="stat-number"><?php echo $total_members; ?></div><div class="stat-label">Total Residents</div></div>
            <div class="stat-card"><i class="fas fa-clock" style="color: #F5B042;"></i><div class="stat-number"><?php echo $pending_review; ?></div><div class="stat-label">Pending Review</div></div>
            <div class="stat-card"><i class="fas fa-check-circle" style="color: var(--success);"></i><div class="stat-number"><?php echo $verified_count; ?></div><div class="stat-label">Verified Approved</div></div>
            <div class="stat-card"><i class="fas fa-times-circle" style="color: var(--secondary);"></i><div class="stat-number"><?php echo $rejected_count; ?></div><div class="stat-label">Needs Correction</div></div>
        </div>

        <?php if($has_poverty_status): ?>
        <div class="poverty-stats-grid">
            <div class="poverty-stat-card poor"><div class="pov-stat-number"><?php echo $poor_count; ?></div><div class="pov-stat-label"><i class="fas fa-exclamation-triangle" style="color: #D32F2F;"></i> Poor</div></div>
            <div class="poverty-stat-card middle-class"><div class="pov-stat-number"><?php echo $middle_class_count; ?></div><div class="pov-stat-label"><i class="fas fa-chart-line" style="color: #1E4A8C;"></i> Middle-Class</div></div>
            <div class="poverty-stat-card rich"><div class="pov-stat-number"><?php echo $rich_count; ?></div><div class="pov-stat-label"><i class="fas fa-crown" style="color: #F5B042;"></i> Rich</div></div>
            <div class="poverty-stat-card unclassified"><div class="pov-stat-number"><?php echo $unclassified_count; ?></div><div class="pov-stat-label"><i class="fas fa-question-circle" style="color: #6B7280;"></i> Unclassified</div></div>
        </div>
        <?php endif; ?>

        <div class="filter-card">
            <form method="GET" action="">
                <div class="filter-row">
                    <div class="filter-group">
                        <label><i class="fas fa-search"></i> Search by Name</label>
                        <input type="text" name="search" placeholder="Search household head..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="filter-group">
                        <label><i class="fas fa-map-marker-alt"></i> Filter by Barangay</label>
                        <select name="barangay">
                            <option value="">All Barangays</option>
                            <?php foreach($barangays as $b): ?>
                                <option value="<?php echo htmlspecialchars($b['barangay']); ?>" <?php echo $barangay_filter == $b['barangay'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($b['barangay']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label><i class="fas fa-check-circle"></i> Verification Status</label>
                        <select name="verification">
                            <option value="">All Status</option>
                            <option value="pending_review" <?php echo $verification_filter == 'pending_review' ? 'selected' : ''; ?>>Pending Review</option>
                            <option value="verified_approved" <?php echo $verification_filter == 'verified_approved' ? 'selected' : ''; ?>>Approved</option>
                            <option value="rejected_needs_correction" <?php echo $verification_filter == 'rejected_needs_correction' ? 'selected' : ''; ?>>Needs Correction</option>
                        </select>
                    </div>
                    <?php if($has_poverty_status): ?>
                    <div class="filter-group">
                        <label><i class="fas fa-tag"></i> Poverty Classification</label>
                        <select name="poverty">
                            <option value="">All Classifications</option>
                            <option value="POOR" <?php echo $poverty_filter == 'POOR' ? 'selected' : ''; ?>>Poor</option>
                            <option value="MIDDLE_CLASS" <?php echo $poverty_filter == 'MIDDLE_CLASS' ? 'selected' : ''; ?>>Middle-Class</option>
                            <option value="RICH" <?php echo $poverty_filter == 'RICH' ? 'selected' : ''; ?>>Rich</option>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="filter-group" style="display: flex; gap: 8px; align-items: flex-end; flex-wrap: wrap;">
                        <button type="submit" class="btn-primary"><i class="fas fa-filter"></i> Apply Filter</button>
                        <a href="household.php" class="btn-secondary"><i class="fas fa-sync-alt"></i> Reset</a>
                        <a href="household.php?verification=verified_approved" class="btn-secondary" style="background: <?php echo ($verification_filter === 'verified_approved') ? '#059669' : '#D1FAE5'; ?>; color: <?php echo ($verification_filter === 'verified_approved') ? 'white' : '#065F46'; ?>; border: 1px solid #059669;">
                            <i class="fas fa-check-circle"></i> Approved
                        </a>
                        <a href="household.php?verification=rejected_needs_correction" class="btn-secondary" style="background: <?php echo ($verification_filter === 'rejected_needs_correction') ? '#D32F2F' : '#FEE2E2'; ?>; color: <?php echo ($verification_filter === 'rejected_needs_correction') ? 'white' : '#991B1B'; ?>; border: 1px solid #D32F2F;">
                            <i class="fas fa-times-circle"></i> Rejected
                        </a>
                        <?php if(!empty($verification_filter) || !empty($poverty_filter) || !empty($barangay_filter) || !empty($search)): ?>
                        <a href="household.php" class="btn-secondary" style="background: #1E4A8C; color: white; border: 1px solid #0A2F6C;">
                            <i class="fas fa-list"></i> Show All Households
                        </a>
                        <?php endif; ?>
                        <?php if($has_poverty_status): ?>
                        <button type="submit" name="bulk_recalculate_poverty" value="1" class="btn-recalculate" onclick="return confirm('Recalculate poverty status for ALL households? This may take a moment.')">
                            <i class="fas fa-calculator"></i> Recalculate All
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-container">
            <?php if(count($households) > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Household Head</th>
                            <th>Barangay</th>
                            <th>Members</th>
                            <th>Monthly Income</th>
                            <th>Poverty Status</th>
                            <th>Verification</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($households as $hh): 
                            $income = floatval($hh['monthly_income'] ?? 0);
                            $members = intval($hh['total_members'] ?? 1);
                            $poverty_status = $hh['poverty_status'] ?? 'Not Classified';
                            $status = $hh['verification_status'] ?? 'pending_review';
                        ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($hh['barangay'] ?? 'N/A'); ?></td>
                                <td><?php echo $members; ?></td>
                                <td>₱ <?php echo number_format($income, 2); ?></td>
                                <td>
                                    <?php 
                                    if($has_poverty_status && !empty($poverty_status)) echo getPovertyBadge($poverty_status); 
                                    else echo '<span class="poverty-badge badge-unknown">Not Classified</span>';
                                    ?>
                                    <?php if($has_poverty_status): ?>
                                    <form method="POST" style="display: inline; margin-left: 4px;">
                                        <input type="hidden" name="household_id" value="<?php echo $hh['id']; ?>">
                                        <button type="submit" name="recalculate_poverty" class="btn-recalculate" style="font-size: 0.55rem; padding: 2px 8px;" title="Recalculate poverty status">
                                            <i class="fas fa-sync-alt"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo getVerificationBadge($status); ?></td>
                                <td><?php echo date('M d, Y', strtotime($hh['created_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="household_view.php?id=<?php echo $hh['id']; ?>" class="btn-view"><i class="fas fa-eye"></i> View</a>
                                        
                                        <?php if($status == 'pending_review'): ?>
                                            <button class="btn-success" onclick="openApproveModal(<?php echo $hh['id']; ?>, '<?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?>')">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                            <button class="btn-danger" onclick="openRejectModal(<?php echo $hh['id']; ?>, '<?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?>')">
                                                <i class="fas fa-times"></i> Reject
                                            </button>
                                        <?php endif; ?>
                                        
                                        <?php if($status == 'pending_review' || $status == 'rejected_needs_correction'): ?>
                                            <button class="btn-process" onclick="openProcessModal(<?php echo $hh['id']; ?>, '<?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?>', 'APPROVE')">
                                                <i class="fas fa-bell"></i> Notify
                                            </button>
                                        <?php endif; ?>
                                        
                                        <button onclick="confirmDelete(<?php echo $hh['id']; ?>, '<?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?>')" class="btn-delete"><i class="fas fa-trash-alt"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <p>No household records found.</p>
                    <p style="font-size: 0.75rem; margin-top: 8px;">Try adjusting your search or filter criteria.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<div class="bottom-nav">
    <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
    <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
    <a href="household.php" class="nav-item active"><i class="fas fa-users"></i><span>Households</span></a>
    <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
    <a href="mswdstaff_idapplication.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Apps</span></a>
    <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
    <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
</div>

<!-- MODAL 1: Approve Household (Direct) -->
<div id="approveModal" class="modal">
    <div class="modal-content">
        <h3><i class="fas fa-check-circle" style="color: var(--success);"></i> Approve Household</h3>
        <p style="font-size: 0.85rem; color: var(--gray-500); margin: 8px 0 16px;">
            You are about to approve <strong id="approveHouseholdName"></strong>
        </p>
        <form method="POST">
            <input type="hidden" name="household_id" id="approveHouseholdId">
            <input type="hidden" name="approve_household" value="1">
            <div class="form-group">
                <label><i class="fas fa-sticky-note"></i> Verification Notes</label>
                <textarea name="verification_notes" rows="3" placeholder="e.g., Documents matched. Home visit conducted."></textarea>
                <div class="helper-text">Add any notes about the verification process</div>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeModal('approveModal')">Cancel</button>
                <button type="submit" class="btn-submit" style="background: var(--success);">Approve Household</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 2: Reject Household (Direct) -->
<div id="rejectModal" class="modal">
    <div class="modal-content">
        <h3><i class="fas fa-times-circle" style="color: var(--secondary);"></i> Reject & Flag for Corrections</h3>
        <p style="font-size: 0.85rem; color: var(--gray-500); margin: 8px 0 16px;">
            You are about to reject <strong id="rejectHouseholdName"></strong>
        </p>
        <form method="POST">
            <input type="hidden" name="household_id" id="rejectHouseholdId">
            <input type="hidden" name="reject_household" value="1">
            <div class="form-group">
                <label><i class="fas fa-tag"></i> Rejection Reason <span class="required">*</span></label>
                <select name="rejection_reason" required>
                    <option value="">Select Reason</option>
                    <?php foreach($rejection_reasons as $key => $label): ?>
                        <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label><i class="fas fa-sticky-note"></i> Notes to Resident</label>
                <textarea name="rejection_notes" rows="3" placeholder="e.g., Please re-upload your proof of income."></textarea>
                <div class="helper-text">These notes will be visible to the resident</div>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeModal('rejectModal')">Cancel</button>
                <button type="submit" class="btn-submit" style="background: var(--secondary);">Reject & Flag</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 3: Process & Notify -->
<div id="processModal" class="modal">
    <div class="modal-content">
        <h3 id="processModalTitle"><i class="fas fa-check-circle" style="color: var(--success);"></i> Approve Household</h3>
        <p style="font-size: 0.85rem; color: var(--gray-500); margin: 8px 0 16px;">
            You are about to <strong id="processActionText">approve</strong> <strong id="processHouseholdName"></strong>
        </p>
        <form method="POST" id="processForm">
            <input type="hidden" name="household_id" id="processHouseholdId">
            <input type="hidden" name="review_action" id="processReviewAction" value="APPROVE">
            <input type="hidden" name="process_and_notify" value="1">
            
            <div class="notification-toggle">
                <div class="toggle-label">
                    <i class="fas fa-bell"></i>
                    <div>
                        Send Live Notification
                        <div class="toggle-desc">Alert resident on their mobile app instantly</div>
                    </div>
                </div>
                <label class="toggle-switch">
                    <input type="checkbox" name="send_push_notification" id="sendPushNotification" checked>
                    <span class="toggle-slider"></span>
                </label>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-edit"></i> Custom Message (Optional)</label>
                <textarea name="custom_message" id="customMessage" rows="2" placeholder="Enter custom notification message for resident..."></textarea>
                <div class="helper-text">Leave blank to use default message</div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-sticky-note"></i> Staff Remarks</label>
                <textarea name="internal_remarks" id="internalRemarks" rows="2" placeholder="Add internal notes for audit trail..."></textarea>
                <div class="helper-text">These remarks are only visible to staff</div>
            </div>
            
            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeModal('processModal')">Cancel</button>
                <button type="submit" class="btn-submit" id="processSubmitBtn" style="background: var(--success);">
                    <i class="fas fa-check-circle"></i> <span id="processBtnText">Approve & Notify</span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if(menuToggle) menuToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
    document.addEventListener('click', (event) => { if(window.innerWidth <= 768 && !sidebar.contains(event.target) && !menuToggle?.contains(event.target)) sidebar.classList.remove('open'); });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    if(programToggle) programToggle.addEventListener('click', () => { programSubmenu.classList.toggle('show'); programIcon.classList.toggle('rotated'); });
    
    function confirmDelete(id, householdName) {
        if(confirm(`Are you sure you want to move "${householdName}" to recycle bin?\n\nThis record can be restored by the administrator.`)) {
            window.location.href = `?delete_id=${id}`;
        }
    }
    
    function closeModal(modalId) { document.getElementById(modalId).style.display = 'none'; }
    
    function openApproveModal(id, name) {
        document.getElementById('approveHouseholdId').value = id;
        document.getElementById('approveHouseholdName').textContent = name;
        document.getElementById('approveModal').style.display = 'flex';
    }
    
    function openRejectModal(id, name) {
        document.getElementById('rejectHouseholdId').value = id;
        document.getElementById('rejectHouseholdName').textContent = name;
        document.getElementById('rejectModal').style.display = 'flex';
    }
    
    function openProcessModal(id, name, action) {
        document.getElementById('processHouseholdId').value = id;
        document.getElementById('processHouseholdName').textContent = name;
        document.getElementById('processReviewAction').value = action;
        
        const isApprove = action === 'APPROVE';
        const title = document.getElementById('processModalTitle');
        const btnText = document.getElementById('processBtnText');
        const submitBtn = document.getElementById('processSubmitBtn');
        const actionText = document.getElementById('processActionText');
        
        if(isApprove) {
            title.innerHTML = '<i class="fas fa-check-circle" style="color: var(--success);"></i> Approve Household';
            btnText.textContent = 'Approve & Notify';
            submitBtn.style.background = 'var(--success)';
            submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Approve & Notify';
            actionText.textContent = 'approve';
        } else {
            title.innerHTML = '<i class="fas fa-times-circle" style="color: var(--secondary);"></i> Reject Household';
            btnText.textContent = 'Reject & Notify';
            submitBtn.style.background = 'var(--secondary)';
            submitBtn.innerHTML = '<i class="fas fa-times-circle"></i> Reject & Notify';
            actionText.textContent = 'reject';
        }
        
        const customMsg = document.getElementById('customMessage');
        if(isApprove) customMsg.placeholder = 'e.g., Your household has been approved! You can now access all municipal programs.';
        else customMsg.placeholder = 'e.g., Please correct the income declaration and re-submit your application.';
        
        document.getElementById('processModal').style.display = 'flex';
    }
    
    window.onclick = function(event) { if(event.target.classList.contains('modal')) event.target.style.display = 'none'; }
    
    document.querySelectorAll('.toggle-switch input').forEach(function(input) {
        input.addEventListener('change', function() {
            const label = this.closest('.toggle-label');
            if(label) {
                const desc = label.querySelector('.toggle-desc');
                if(desc) desc.textContent = this.checked ? 'Alert resident on their mobile app instantly' : 'Resident will not receive a notification';
            }
        });
    });

    console.log('✅ Household Records loaded');
</script>

<?= renderPwaServiceWorker() ?>
</body>
</html>