<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff/admin
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$error = '';
$success = '';
$latitude = '';
$longitude = '';
$address = '';

// Handle saving GPS coordinates
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $latitude = $_POST['latitude'] ?? '';
    $longitude = $_POST['longitude'] ?? '';
    $address = $_POST['address'] ?? '';
    $household_id = $_POST['household_id'] ?? null;
    
    if($latitude && $longitude) {
        try {
            // Save to session or database
            $_SESSION['temp_gps'] = ['lat' => $latitude, 'lng' => $longitude, 'address' => $address];
            
            if($household_id) {
                $stmt = $pdo->prepare("UPDATE households SET gps_latitude = ?, gps_longitude = ? WHERE id = ?");
                $stmt->execute([$latitude, $longitude, $household_id]);
                $success = "GPS coordinates saved to household record!";
            } else {
                $success = "GPS coordinates captured successfully!";
            }
            
            // Redirect back to household form if coming from there
            if(isset($_GET['return'])) {
                header("Location: " . $_GET['return'] . "?lat=" . $latitude . "&lng=" . $longitude);
                exit();
            }
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "Failed to capture GPS coordinates.";
    }
}

// Get saved GPS from session
$saved_gps = $_SESSION['temp_gps'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>GPS Tracker - MSWDO</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        #map {
            height: 400px;
            width: 100%;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
        }
        .gps-coordinates {
            background: var(--gray-100);
            padding: 15px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            text-align: center;
        }
        .coordinates-value {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary);
            font-family: monospace;
        }
        .accuracy-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.75rem;
            margin-left: 10px;
        }
        .accuracy-high { background: #27ae60; color: white; }
        .accuracy-medium { background: #f39c12; color: white; }
        .accuracy-low { background: #e74c3c; color: white; }
        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid var(--gray-300);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .address-result {
            margin-top: 10px;
            padding: 10px;
            background: var(--info-light);
            border-radius: var(--radius-md);
            font-size: 0.85rem;
        }
    </style>
    <!-- Leaflet CSS and JS for map -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head>
<body>
    <div class="page-wrapper">
        <div class="top-bar">
            <a href="javascript:history.back()" class="nav-item" style="flex-direction: row; gap: var(--spacing-xs);">
                ← Back
            </a>
            <div class="logo" style="font-size: 1.25rem;">📍 MSWDO GPS</div>
            <div style="width: 80px;"></div>
        </div>
        
        <div class="container">
            <div class="card">
                <div class="card-header" style="text-align: center;">
                    <i style="font-size: 2.5rem;">📍</i>
                    <h2>GPS Location Tracker</h2>
                    <p class="text-muted">Capture household GPS coordinates for accurate mapping</p>
                </div>
                
                <div class="card-body">
                    <?php if($error): ?>
                        <div class="alert alert-danger">⚠️ <?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if($success): ?>
                        <div class="alert alert-success">✅ <?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <!-- Map Container -->
                    <div id="map"></div>
                    
                    <!-- GPS Status -->
                    <div class="gps-coordinates" id="gpsStatus">
                        <div id="statusText">
                            <span class="loading-spinner"></span> Acquiring GPS signal...
                        </div>
                        <div id="coordinatesDisplay" style="display: none;">
                            <strong>📍 Current Location:</strong><br>
                            <span class="coordinates-value" id="latitude">-</span><br>
                            <span class="coordinates-value" id="longitude">-</span>
                            <span id="accuracyBadge"></span>
                        </div>
                    </div>
                    
                    <!-- Address Result -->
                    <div id="addressResult" class="address-result" style="display: none;">
                        <strong>🏠 Address:</strong><br>
                        <span id="addressText"></span>
                    </div>
                    
                    <form method="POST" action="" id="gpsForm">
                        <input type="hidden" name="latitude" id="latInput">
                        <input type="hidden" name="longitude" id="lngInput">
                        <input type="hidden" name="address" id="addressInput">
                        <input type="hidden" name="household_id" value="<?php echo $_GET['household_id'] ?? ''; ?>">
                        
                        <div class="action-buttons">
                            <button type="button" class="btn btn-primary" id="captureBtn" onclick="getLocation()">
                                📍 Capture Current Location
                            </button>
                            <button type="submit" class="btn btn-success" id="saveBtn" disabled>
                                💾 Save Coordinates
                            </button>
                            <button type="button" class="btn btn-outline" onclick="refreshMap()">
                                🔄 Refresh Map
                            </button>
                        </div>
                    </form>
                    
                    <div class="alert alert-info" style="margin-top: 20px; font-size: 0.8rem;">
                        <i>ℹ️</i> <strong>Instructions:</strong><br>
                        1. Click "Capture Current Location" to get your GPS coordinates.<br>
                        2. Wait for the system to detect your location (accuracy: high = green, medium = yellow, low = red).<br>
                        3. Click "Save Coordinates" to store the location for this household.<br>
                        4. For best accuracy, ensure you are outdoors with clear sky view.
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let map;
        let marker;
        let currentLat = null;
        let currentLng = null;
        let currentAccuracy = null;
        
        // Initialize map
        function initMap(lat = 14.5995, lng = 120.9842) {
            map = L.map('map').setView([lat, lng], 15);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);
            
            marker = L.marker([lat, lng]).addTo(map);
            marker.bindPopup('<b>📍 Current Location</b>').openPopup();
        }
        
        // Get current location
        function getLocation() {
            const statusDiv = document.getElementById('gpsStatus');
            const statusText = document.getElementById('statusText');
            const coordinatesDisplay = document.getElementById('coordinatesDisplay');
            
            statusText.innerHTML = '<span class="loading-spinner"></span> Acquiring GPS signal...';
            coordinatesDisplay.style.display = 'none';
            document.getElementById('addressResult').style.display = 'none';
            
            if("geolocation" in navigator) {
                navigator.geolocation.getCurrentPosition(
                    showPosition, 
                    showError,
                    { enableHighAccuracy: true, timeout: 30000, maximumAge: 0 }
                );
            } else {
                statusText.innerHTML = '❌ Geolocation is not supported by this browser.';
            }
        }
        
        // Show position
        function showPosition(position) {
            currentLat = position.coords.latitude;
            currentLng = position.coords.longitude;
            currentAccuracy = position.coords.accuracy;
            
            // Update display
            document.getElementById('latitude').innerHTML = currentLat.toFixed(6);
            document.getElementById('longitude').innerHTML = currentLng.toFixed(6);
            document.getElementById('latInput').value = currentLat;
            document.getElementById('lngInput').value = currentLng;
            
            // Show accuracy badge
            const accuracyBadge = document.getElementById('accuracyBadge');
            let accuracyClass = '';
            let accuracyText = '';
            
            if(currentAccuracy < 10) {
                accuracyClass = 'accuracy-high';
                accuracyText = 'Excellent (±' + currentAccuracy.toFixed(1) + 'm)';
            } else if(currentAccuracy < 30) {
                accuracyClass = 'accuracy-medium';
                accuracyText = 'Good (±' + currentAccuracy.toFixed(1) + 'm)';
            } else {
                accuracyClass = 'accuracy-low';
                accuracyText = 'Poor (±' + currentAccuracy.toFixed(1) + 'm) - Move to open area';
            }
            
            accuracyBadge.className = 'accuracy-badge ' + accuracyClass;
            accuracyBadge.innerHTML = accuracyText;
            
            // Update UI
            document.getElementById('statusText').innerHTML = '✅ GPS signal acquired!';
            document.getElementById('coordinatesDisplay').style.display = 'block';
            document.getElementById('saveBtn').disabled = false;
            
            // Update map
            if(map) {
                map.setView([currentLat, currentLng], 18);
                marker.setLatLng([currentLat, currentLng]);
                marker.bindPopup('<b>📍 Current Location</b><br>Accuracy: ' + currentAccuracy.toFixed(1) + 'm').openPopup();
            } else {
                initMap(currentLat, currentLng);
            }
            
            // Reverse geocoding to get address
            reverseGeocode(currentLat, currentLng);
        }
        
        // Reverse geocoding (get address from coordinates)
        function reverseGeocode(lat, lng) {
            const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
            
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if(data && data.display_name) {
                        const address = data.display_name;
                        document.getElementById('addressText').innerHTML = address;
                        document.getElementById('addressInput').value = address;
                        document.getElementById('addressResult').style.display = 'block';
                    }
                })
                .catch(error => {
                    console.log('Reverse geocoding error:', error);
                    document.getElementById('addressText').innerHTML = 'Unable to get address automatically';
                });
        }
        
        // Show error
        function showError(error) {
            const statusText = document.getElementById('statusText');
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    statusText.innerHTML = '❌ User denied the request for Geolocation.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    statusText.innerHTML = '❌ Location information is unavailable.';
                    break;
                case error.TIMEOUT:
                    statusText.innerHTML = '❌ The request to get user location timed out.';
                    break;
                case error.UNKNOWN_ERROR:
                    statusText.innerHTML = '❌ An unknown error occurred.';
                    break;
            }
        }
        
        // Refresh map
        function refreshMap() {
            if(currentLat && currentLng) {
                map.setView([currentLat, currentLng], 18);
                marker.setLatLng([currentLat, currentLng]);
            } else {
                getLocation();
            }
        }
        
        // Initialize map on load
        document.addEventListener('DOMContentLoaded', function() {
            initMap();
            
            // Auto-capture if requested
            const autoCapture = <?php echo isset($_GET['auto']) ? 'true' : 'false'; ?>;
            if(autoCapture) {
                setTimeout(getLocation, 500);
            }
        });
    </script>
</body>
</html>