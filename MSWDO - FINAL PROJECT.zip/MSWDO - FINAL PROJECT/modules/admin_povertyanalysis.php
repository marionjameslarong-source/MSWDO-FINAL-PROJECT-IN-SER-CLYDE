<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];

// Get deleted count for recycle bin badge
$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
$deleted_count = $stmt->fetch()['total'];

// First, check what columns exist in households table
$columns = [];
try {
    $col_stmt = $pdo->query("DESCRIBE households");
    while($col = $col_stmt->fetch(PDO::FETCH_ASSOC)) {
        $columns[] = $col['Field'];
    }
} catch(PDOException $e) {
    $columns = [];
}

// ============================================================
// POVERTY STATISTICS - 3-CLASS SYSTEM
// POOR:          ₱5,000  - ₱10,000
// MIDDLE-CLASS:  ₱10,001 - ₱25,000
// RICH:          ₱25,001 and above
// ============================================================
$stmt = $pdo->query("
    SELECT 
        COUNT(*) as total_households,
        SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) as poor,
        SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) as middle_class,
        SUM(CASE WHEN monthly_income > 25000 THEN 1 ELSE 0 END) as rich,
        SUM(CASE WHEN monthly_income < 5000 THEN 1 ELSE 0 END) as not_classified,
        AVG(monthly_income) as avg_income
    FROM households WHERE monthly_income IS NOT NULL
");
$poverty_stats = $stmt->fetch();

// ============================================================
// BARANGAY LEVEL POVERTY - 3-CLASS SYSTEM
// ============================================================
$stmt = $pdo->query("
    SELECT 
        barangay,
        COUNT(*) as total,
        AVG(monthly_income) as avg_income,
        SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) as poor,
        SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) as middle_class,
        SUM(CASE WHEN monthly_income > 25000 THEN 1 ELSE 0 END) as rich
    FROM households 
    WHERE barangay IS NOT NULL AND barangay != '' AND monthly_income IS NOT NULL
    GROUP BY barangay 
    ORDER BY avg_income ASC
");
$barangay_poverty = $stmt->fetchAll();

// Get 4Ps beneficiary statistics (if column exists) - UPDATED RANGES
$fourps_stats = ['total_4ps' => 0, 'poor_4ps' => 0, 'middle_class_4ps' => 0];
if(in_array('is_4ps_beneficiary', $columns)) {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_4ps,
            SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) as poor_4ps,
            SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) as middle_class_4ps
        FROM households 
        WHERE is_4ps_beneficiary = 1 AND monthly_income IS NOT NULL
    ");
    $fourps_stats = $stmt->fetch();
}

// Get monthly trend of poverty submissions
$stmt = $pdo->query("
    SELECT 
        DATE_FORMAT(created_at, '%Y-%m') as month,
        COUNT(*) as total,
        AVG(monthly_income) as avg_income
    FROM households 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH) AND monthly_income IS NOT NULL
    GROUP BY month 
    ORDER BY month ASC
");
$monthly_trend = $stmt->fetchAll();

// Get employment statistics
$employment_stats = ['total' => 0, 'employed' => 0, 'unemployed' => 0, 'self_employed' => 0, 'ofw' => 0];
if(in_array('employment_status', $columns)) {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN employment_status = 'employed' THEN 1 ELSE 0 END) as employed,
            SUM(CASE WHEN employment_status = 'unemployed' THEN 1 ELSE 0 END) as unemployed,
            SUM(CASE WHEN employment_status = 'self_employed' THEN 1 ELSE 0 END) as self_employed,
            SUM(CASE WHEN employment_status = 'ofw' THEN 1 ELSE 0 END) as ofw
        FROM households
    ");
    $employment_stats = $stmt->fetch();
} else {
    if(in_array('occupation', $columns)) {
        $stmt = $pdo->query("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN occupation IS NOT NULL AND occupation != '' THEN 1 ELSE 0 END) as employed,
                SUM(CASE WHEN occupation IS NULL OR occupation = '' THEN 1 ELSE 0 END) as unemployed
            FROM households
        ");
        $emp_data = $stmt->fetch();
        $employment_stats['total'] = $emp_data['total'];
        $employment_stats['employed'] = $emp_data['employed'];
        $employment_stats['unemployed'] = $emp_data['unemployed'];
        $employment_stats['self_employed'] = 0;
        $employment_stats['ofw'] = 0;
    }
}

// Get poverty line threshold (125% of poverty line)
$poverty_line = 12000;
$poverty_threshold = $poverty_line * 1.25;

// Count households below poverty threshold
$stmt = $pdo->prepare("SELECT COUNT(*) as below_threshold FROM households WHERE monthly_income < ? AND monthly_income IS NOT NULL");
$stmt->execute([$poverty_threshold]);
$below_threshold = $stmt->fetch()['below_threshold'];

// ============================================================
// FUNCTION: 3-Class Poverty Classification
// ============================================================
function getPovertyClass($income) {
    if($income >= 5000 && $income <= 10000) return 'POOR';
    elseif($income > 10000 && $income <= 25000) return 'MIDDLE-CLASS';
    elseif($income > 25000) return 'RICH';
    else return 'Not Classified';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Poverty Analysis - MSWDO Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
            background-image: 
                radial-gradient(at 0% 0%, rgba(30, 74, 140, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(245, 176, 66, 0.05) 0px, transparent 50%);
            background-attachment: fixed;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #3B6BB5;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --accent-dark: #D99524;
            --success: #059669;
            --warning: #F59E0B;
            --danger: #DC2626;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }

        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); width: 260px; }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }

        /* Top Bar */
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 { 
            font-size: 1.35rem; 
            font-weight: 800; 
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 600; color: var(--gray-700); }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }

        /* ================================================================
           INTERACTIVE STATS CARDS
           ================================================================ */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: var(--white);
            padding: 22px;
            border-radius: var(--radius-xl);
            text-align: center;
            border: 1px solid var(--gray-200);
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 5px;
            transition: all 0.3s;
        }
        .stat-card.poor::before { background: linear-gradient(90deg, #DC2626, #EF4444); }
        .stat-card.middle::before { background: linear-gradient(90deg, #1E4A8C, #3B82F6); }
        .stat-card.rich::before { background: linear-gradient(90deg, #D99524, #F5B042); }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }
        .stat-card .stat-icon {
            width: 48px;
            height: 48px;
            margin: 0 auto 12px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            transition: transform 0.3s;
        }
        .stat-card:hover .stat-icon { transform: scale(1.15); }
        .stat-card.poor .stat-icon { background: #FEE2E2; color: #DC2626; }
        .stat-card.middle .stat-icon { background: #DBEAFE; color: #1E4A8C; }
        .stat-card.rich .stat-icon { background: #FEF3C7; color: #B45309; }
        .stat-number { 
            font-size: 2rem; 
            font-weight: 800; 
            letter-spacing: -0.03em;
            line-height: 1;
        }
        .stat-card.poor .stat-number { color: #DC2626; }
        .stat-card.middle .stat-number { color: #1E4A8C; }
        .stat-card.rich .stat-number { color: #B45309; }
        .stat-label { 
            font-size: 0.72rem; 
            color: var(--gray-500); 
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-top: 8px;
        }
        .stat-range { 
            font-size: 0.68rem; 
            color: var(--gray-400); 
            margin-top: 4px;
            font-weight: 600;
        }

        /* ================================================================
           TABLEAU-STYLE CHARTS
           ================================================================ */
        .charts-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        .chart-container {
            background: white;
            border-radius: var(--radius-xl);
            padding: 20px;
            border: 1px solid var(--gray-200);
            transition: all 0.3s;
            box-shadow: var(--shadow-sm);
            position: relative;
        }
        .chart-container:hover {
            box-shadow: var(--shadow-lg);
            border-color: var(--primary-light);
        }
        .chart-container h4 { 
            margin-bottom: 16px; 
            color: var(--gray-800); 
            font-size: 0.9rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--gray-100);
        }
        .chart-container h4 i { color: var(--primary); }
        .chart-container .chart-wrapper {
            position: relative;
            height: 280px;
        }

        /* ================================================================
           MODERN TABLES
           ================================================================ */
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 800px;
        }
        .table th {
            text-align: left;
            padding: 14px 16px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            border-bottom: 2px solid var(--accent);
            font-size: 0.7rem;
            color: var(--gray-600);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .table td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .table tbody tr { transition: background 0.15s; }
        .table tbody tr:hover { background: var(--gray-50); }
        .table tbody tr:last-child td { border-bottom: none; }

        .poverty-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .poverty-poor { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        .poverty-middle { background: #DBEAFE; color: #1E40AF; border: 1px solid #93C5FD; }
        .poverty-rich { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }

        /* ================================================================
           KEY INSIGHTS CARDS
           ================================================================ */
        .insights-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-top: 16px;
        }
        .insight-card {
            background: linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%);
            padding: 20px;
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-200);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        .insight-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0;
            width: 4px; height: 100%;
            background: linear-gradient(180deg, var(--primary), var(--primary-light));
        }
        .insight-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-md);
        }
        .insight-card.warning::before { background: linear-gradient(180deg, #DC2626, #EF4444); }
        .insight-card.success::before { background: linear-gradient(180deg, #059669, #10B981); }
        .insight-icon {
            width: 42px;
            height: 42px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            margin-bottom: 12px;
        }
        .insight-icon.blue { background: #DBEAFE; color: var(--primary); }
        .insight-icon.red { background: #FEE2E2; color: #DC2626; }
        .insight-icon.green { background: #D1FAE5; color: #059669; }
        .insight-title { font-weight: 700; font-size: 0.78rem; color: var(--gray-600); text-transform: uppercase; letter-spacing: 0.04em; }
        .insight-value { font-size: 1.6rem; font-weight: 800; color: var(--gray-800); margin-top: 6px; letter-spacing: -0.03em; }
        .insight-desc { font-size: 0.7rem; color: var(--gray-500); margin-top: 4px; font-weight: 500; }

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-decoration: none;
            position: relative;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        .nav-badge {
            position: absolute;
            top: -4px;
            right: -4px;
            background: var(--secondary);
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.6rem;
            font-weight: 700;
        }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        @media (max-width: 992px) {
            .stats-grid { grid-template-columns: repeat(3, 1fr); }
            .charts-row { grid-template-columns: 1fr; }
            .insights-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: 1fr; }
            .insights-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Administrator</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="manage_users.php" class="nav-item"><i class="fas fa-users-cog"></i> User Management</a>
                <a href="admin_household.php" class="nav-item"><i class="fas fa-home"></i> All Households</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="admin_povertyanalysis.php" class="nav-item active"><i class="fas fa-chart-line"></i> Poverty Analysis</a>
                <a href="admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="../admin/recycle_bin.php" class="nav-item"><i class="fas fa-trash-restore"></i> Recycle Bin</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Poverty Analysis</h1>
                    <p>Household income classification and poverty statistics · 3-Class System</p>
                </div>
            </div>
            <a href="admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- ================================================================
        STATS CARDS - 3 CLASSES
        ================================================================ -->
        <div class="stats-grid">
            <div class="stat-card poor">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-number"><?php echo number_format($poverty_stats['poor'] ?? 0); ?></div>
                <div class="stat-label">Poor Households</div>
                <div class="stat-range">₱5,000 – ₱10,000</div>
            </div>
            <div class="stat-card middle">
                <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
                <div class="stat-number"><?php echo number_format($poverty_stats['middle_class'] ?? 0); ?></div>
                <div class="stat-label">Middle-Class</div>
                <div class="stat-range">₱10,001 – ₱25,000</div>
            </div>
            <div class="stat-card rich">
                <div class="stat-icon"><i class="fas fa-crown"></i></div>
                <div class="stat-number"><?php echo number_format($poverty_stats['rich'] ?? 0); ?></div>
                <div class="stat-label">Rich Households</div>
                <div class="stat-range">₱25,001 and above</div>
            </div>
        </div>

        <!-- ================================================================
        CHARTS ROW 1
        ================================================================ -->
        <div class="charts-row">
            <div class="chart-container">
                <h4><i class="fas fa-chart-pie"></i> Poverty Distribution (3-Class)</h4>
                <div class="chart-wrapper">
                    <canvas id="povertyChart"></canvas>
                </div>
            </div>
            <div class="chart-container">
                <h4><i class="fas fa-chart-line"></i> Monthly Average Income Trend</h4>
                <div class="chart-wrapper">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
        </div>

        <!-- ================================================================
        CHARTS ROW 2 - EMPLOYMENT & 4PS
        ================================================================ -->
        <?php if(($employment_stats['employed'] ?? 0) > 0 || ($employment_stats['unemployed'] ?? 0) > 0): ?>
        <div class="charts-row">
            <div class="chart-container">
                <h4><i class="fas fa-briefcase"></i> Employment Status</h4>
                <div class="chart-wrapper">
                    <canvas id="employmentChart"></canvas>
                </div>
            </div>
            <div class="chart-container">
                <h4><i class="fas fa-hand-holding-heart"></i> 4Ps Beneficiary Distribution</h4>
                <div class="chart-wrapper">
                    <canvas id="fourpsChart"></canvas>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- ================================================================
        BARANGAY LEVEL POVERTY TABLE - 3 CLASSES
        ================================================================ -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Barangay</th>
                        <th>Total Households</th>
                        <th>Average Income</th>
                        <th>Poor (₱5k–₱10k)</th>
                        <th>Middle-Class (₱10k–₱25k)</th>
                        <th>Rich (₱25k+)</th>
                        <th>Poverty Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($barangay_poverty) > 0): ?>
                        <?php foreach($barangay_poverty as $b): 
                            $poor_total = $b['poor'] ?? 0;
                            $poverty_rate = $b['total'] > 0 ? round(($poor_total / $b['total']) * 100, 1) : 0;
                            $rate_color = $poverty_rate > 60 ? '#DC2626' : ($poverty_rate > 30 ? '#1E4A8C' : '#B45309');
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($b['barangay']); ?></strong></td>
                            <td><?php echo $b['total']; ?></td>
                            <td>₱ <?php echo number_format($b['avg_income'] ?? 0, 2); ?></td>
                            <td><span class="poverty-badge poverty-poor"><?php echo $poor_total; ?></span></td>
                            <td><span class="poverty-badge poverty-middle"><?php echo $b['middle_class'] ?? 0; ?></span></td>
                            <td><span class="poverty-badge poverty-rich"><?php echo $b['rich'] ?? 0; ?></span></td>
                            <td>
                                <span style="background: <?php echo $rate_color; ?>; color: white; padding: 5px 12px; border-radius: 20px; font-weight: 700; font-size: 0.7rem;">
                                    <?php echo $poverty_rate; ?>%
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" style="text-align:center; padding:40px; color:var(--gray-500);">
                            <i class="fas fa-folder-open" style="font-size:2rem; opacity:0.5; display:block; margin-bottom:8px;"></i>
                            No barangay data available
                        </td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- ================================================================
        KEY INSIGHTS
        ================================================================ -->
        <div class="chart-container">
            <h4><i class="fas fa-lightbulb"></i> Key Poverty Insights</h4>
            <div class="insights-grid">
                <div class="insight-card warning">
                    <div class="insight-icon red"><i class="fas fa-chart-line"></i></div>
                    <div class="insight-title">Poverty Incidence</div>
                    <div class="insight-value">
                        <?php 
                            $total = $poverty_stats['total_households'] ?? 0;
                            $poor = $poverty_stats['poor'] ?? 0;
                            echo $total > 0 ? round(($poor / $total) * 100, 1) : 0; 
                        ?>%
                    </div>
                    <div class="insight-desc">of households are classified as POOR</div>
                </div>
                <div class="insight-card success">
                    <div class="insight-icon green"><i class="fas fa-money-bill-wave"></i></div>
                    <div class="insight-title">Average Household Income</div>
                    <div class="insight-value">₱ <?php echo number_format($poverty_stats['avg_income'] ?? 0, 2); ?></div>
                    <div class="insight-desc">monthly average across all households</div>
                </div>
                <div class="insight-card">
                    <div class="insight-icon blue"><i class="fas fa-exclamation-circle"></i></div>
                    <div class="insight-title">Below Poverty Threshold</div>
                    <div class="insight-value"><?php echo number_format($below_threshold); ?> households</div>
                    <div class="insight-desc">earning below ₱<?php echo number_format($poverty_threshold, 2); ?></div>
                </div>
            </div>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="admin_povertyanalysis.php" class="nav-item active"><i class="fas fa-chart-line"></i><span>Poverty</span></a>
        <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };

        // ============================================================
        // CHART.JS GLOBAL TABLEAU-STYLE DEFAULTS
        // ============================================================
        Chart.defaults.font.family = "'Inter', sans-serif";
        Chart.defaults.font.size = 11;
        Chart.defaults.color = '#475569';
        Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(15, 23, 42, 0.95)';
        Chart.defaults.plugins.tooltip.padding = 12;
        Chart.defaults.plugins.tooltip.cornerRadius = 8;
        Chart.defaults.plugins.tooltip.titleFont = { size: 12, weight: '700' };
        Chart.defaults.plugins.tooltip.bodyFont = { size: 11 };
        Chart.defaults.plugins.legend.labels.boxWidth = 12;
        Chart.defaults.plugins.legend.labels.padding = 14;
        Chart.defaults.plugins.legend.labels.font = { size: 11, weight: '600' };

        // ============================================================
        // POVERTY DISTRIBUTION - 3 CLASSES DOUGHNUT
        // ============================================================
        const povCtx = document.getElementById('povertyChart')?.getContext('2d');
        if(povCtx) {
            const poorVal = <?php echo $poverty_stats['poor'] ?? 0; ?>;
            const middleVal = <?php echo $poverty_stats['middle_class'] ?? 0; ?>;
            const richVal = <?php echo $poverty_stats['rich'] ?? 0; ?>;
            
            new Chart(povCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Poor (₱5k–₱10k)', 'Middle-Class (₱10k–₱25k)', 'Rich (₱25k+)'],
                    datasets: [{
                        data: [poorVal, middleVal, richVal],
                        backgroundColor: [
                            'rgba(220, 38, 38, 0.85)',
                            'rgba(30, 74, 140, 0.85)',
                            'rgba(245, 176, 66, 0.85)'
                        ],
                        borderColor: ['#DC2626', '#1E4A8C', '#F5B042'],
                        borderWidth: 3,
                        hoverOffset: 12
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '62%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { padding: 14, font: { size: 11, weight: '600' } }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const pct = total > 0 ? ((context.parsed / total) * 100).toFixed(1) : 0;
                                    return ` ${context.label}: ${context.parsed} households (${pct}%)`;
                                }
                            }
                        }
                    },
                    animation: {
                        animateRotate: true,
                        animateScale: true,
                        duration: 1200,
                        easing: 'easeOutQuart'
                    }
                }
            });
        }

        // ============================================================
        // TREND CHART - MODERN LINE
        // ============================================================
        const trendCtx = document.getElementById('trendChart')?.getContext('2d');
        if(trendCtx) {
            let months = [], incomes = [];
            <?php foreach($monthly_trend as $m): ?>
                months.push('<?php echo date('M Y', strtotime($m['month'].'-01')); ?>');
                incomes.push(<?php echo round($m['avg_income'] ?? 0); ?>);
            <?php endforeach; ?>
            
            if (months.length === 0) {
                months = ['No Data'];
                incomes = [0];
            }
            
            const gradient = trendCtx.createLinearGradient(0, 0, 0, 280);
            gradient.addColorStop(0, 'rgba(30, 74, 140, 0.3)');
            gradient.addColorStop(1, 'rgba(30, 74, 140, 0.02)');
            
            new Chart(trendCtx, {
                type: 'line',
                data: {
                    labels: months,
                    datasets: [{
                        label: 'Average Income (₱)',
                        data: incomes,
                        borderColor: '#1E4A8C',
                        backgroundColor: gradient,
                        tension: 0.4,
                        fill: true,
                        borderWidth: 3,
                        pointBackgroundColor: '#FFFFFF',
                        pointBorderColor: '#1E4A8C',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 8,
                        pointHoverBackgroundColor: '#1E4A8C',
                        pointHoverBorderColor: '#FFFFFF',
                        pointHoverBorderWidth: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: '#F1F5F9', drawBorder: false },
                            ticks: { 
                                font: { size: 10 },
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                }
                            }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { size: 10 } }
                        }
                    },
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return ` Avg Income: ₱${context.parsed.y.toLocaleString()}`;
                                }
                            }
                        }
                    },
                    animation: {
                        duration: 1400,
                        easing: 'easeOutQuart'
                    }
                }
            });
        }

        // ============================================================
        // EMPLOYMENT CHART - MODERN BAR
        // ============================================================
        <?php if(($employment_stats['employed'] ?? 0) > 0 || ($employment_stats['unemployed'] ?? 0) > 0): ?>
        const empCtx = document.getElementById('employmentChart')?.getContext('2d');
        if(empCtx) {
            new Chart(empCtx, {
                type: 'bar',
                data: {
                    labels: ['Employed', 'Unemployed', 'Self-Employed', 'OFW'],
                    datasets: [{
                        label: 'Number of Households',
                        data: [
                            <?php echo $employment_stats['employed']??0; ?>, 
                            <?php echo $employment_stats['unemployed']??0; ?>, 
                            <?php echo $employment_stats['self_employed']??0; ?>, 
                            <?php echo $employment_stats['ofw']??0; ?>
                        ],
                        backgroundColor: [
                            'rgba(5, 150, 105, 0.85)',
                            'rgba(220, 38, 38, 0.85)',
                            'rgba(30, 74, 140, 0.85)',
                            'rgba(245, 176, 66, 0.85)'
                        ],
                        borderColor: ['#059669', '#DC2626', '#1E4A8C', '#F5B042'],
                        borderWidth: 2,
                        borderRadius: 8,
                        borderSkipped: false,
                        barPercentage: 0.65
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: '#F1F5F9', drawBorder: false },
                            ticks: { precision: 0, font: { size: 11 } }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { size: 11, weight: '600' } }
                        }
                    },
                    plugins: { legend: { display: false } },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        }

        // ============================================================
        // 4PS DISTRIBUTION - DOUGHNUT
        // ============================================================
        const fourpsCtx = document.getElementById('fourpsChart')?.getContext('2d');
        if(fourpsCtx) {
            const fourpsCount = <?php echo $fourps_stats['total_4ps'] ?? 0; ?>;
            const nonFourps = <?php echo ($poverty_stats['total_households'] ?? 0) - ($fourps_stats['total_4ps'] ?? 0); ?>;
            
            new Chart(fourpsCtx, {
                type: 'doughnut',
                data: {
                    labels: ['4Ps Beneficiaries', 'Non-4Ps'],
                    datasets: [{
                        data: [fourpsCount, nonFourps > 0 ? nonFourps : 0],
                        backgroundColor: [
                            'rgba(30, 74, 140, 0.85)',
                            'rgba(203, 213, 225, 0.85)'
                        ],
                        borderColor: ['#1E4A8C', '#CBD5E1'],
                        borderWidth: 3,
                        hoverOffset: 12
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '62%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { padding: 14, font: { size: 11, weight: '600' } }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const pct = total > 0 ? ((context.parsed / total) * 100).toFixed(1) : 0;
                                    return ` ${context.label}: ${context.parsed} households (${pct}%)`;
                                }
                            }
                        }
                    },
                    animation: { duration: 1200, easing: 'easeOutQuart' }
                }
            });
        }
        <?php endif; ?>

        console.log('%c✅ Poverty Analysis loaded', 'color: #059669; font-weight: bold; font-size: 14px;');
        console.log('%c📊 Charts: Tableau-style with animations', 'color: #8B5CF6; font-weight: 600;');
        console.log('%c📈 3-Class System: POOR / MIDDLE-CLASS / RICH', 'color: #1E4A8C; font-weight: 600;');
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>