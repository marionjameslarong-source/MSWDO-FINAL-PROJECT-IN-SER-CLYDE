<?php
session_start();
require_once '../config/database.php';

// Staff only access
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder', 'admin'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];

// Handle status update
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $application_id = $_POST['application_id'];
    $status = $_POST['status'];
    $notes = $_POST['notes'] ?? '';
    
    $stmt = $pdo->prepare("UPDATE welfare_applications SET status = ?, review_notes = ?, reviewed_by = ?, reviewed_at = NOW(), updated_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $notes, $user_id, $application_id]);
    $success_message = "Application has been " . ($status == 'approved' ? "approved" : "rejected");
}

// Get all AICS applications - READ ONLY
$stmt = $pdo->prepare("
    SELECT wa.*, u.full_name, u.username, u.email, u.contact_number 
    FROM welfare_applications wa 
    JOIN users u ON wa.user_id = u.id 
    WHERE wa.program_type = 'aics'
    ORDER BY wa.created_at DESC
");
$stmt->execute();
$applications = $stmt->fetchAll();

// Pre-load reviewer names
$reviewer_ids = array_filter(array_unique(array_column($applications, 'reviewed_by')));
$reviewers = [];
if (!empty($reviewer_ids)) {
    $placeholders = implode(',', array_fill(0, count($reviewer_ids), '?'));
    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE id IN ($placeholders)");
    $stmt->execute(array_values($reviewer_ids));
    foreach ($stmt->fetchAll() as $r) {
        $reviewers[$r['id']] = $r['full_name'];
    }
}

$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

$deleted_count = 0;
if($role === 'admin') {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
        $deleted_count = $stmt->fetch()['total'];
    } catch(PDOException $e) {
        $deleted_count = 0;
    }
}

// Emergency type labels
$emergency_type_labels = [
    'medical' => ['label' => 'Medical', 'color' => 'red', 'icon' => 'fa-heartbeat'],
    'burial' => ['label' => 'Burial', 'color' => 'gray', 'icon' => 'fa-cross'],
    'transportation' => ['label' => 'Transportation', 'color' => 'blue', 'icon' => 'fa-bus'],
    'educational' => ['label' => 'Educational', 'color' => 'green', 'icon' => 'fa-graduation-cap'],
    'food' => ['label' => 'Food Assistance', 'color' => 'orange', 'icon' => 'fa-utensils'],
    'medicine' => ['label' => 'Medicine', 'color' => 'red', 'icon' => 'fa-prescription-bottle-medical'],
    'housing' => ['label' => 'Housing', 'color' => 'blue', 'icon' => 'fa-home'],
    'others' => ['label' => 'Others', 'color' => 'gray', 'icon' => 'fa-ellipsis-h'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>AICS Applications - MSWD Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        /* ============================================================
           UPDATED: MSWDO Logo Image replaces Font Awesome icon
           ============================================================ */
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 2px;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .submenu-item.active i { color: var(--accent); }
        
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 {
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px;
            height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        
        .program-header {
            background: linear-gradient(135deg, #FFF3E0, #FFE0B2);
            padding: 28px;
            border-radius: var(--radius-xl);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 18px;
            box-shadow: 0 12px 24px -8px rgba(230, 81, 0, 0.2);
            border: 1px solid rgba(245, 124, 0, 0.3);
        }
        .program-icon {
            width: 64px;
            height: 64px;
            background: #E65100;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 20px rgba(230, 81, 0, 0.3);
            flex-shrink: 0;
        }
        .program-icon i { font-size: 1.8rem; color: white; }
        .program-title h2 { font-size: 1.5rem; color: #E65100; font-weight: 800; letter-spacing: -0.02em; }
        .program-title p { color: #E65100; font-size: 0.82rem; margin-top: 4px; }
        
        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-box {
            background: white;
            padding: 20px;
            border-radius: var(--radius-xl);
            text-align: center;
            border: 1px solid var(--gray-200);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .stat-box::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), #3B82F6);
        }
        .stat-box:nth-child(1)::before { background: linear-gradient(90deg, #F5B042, #FCD34D); }
        .stat-box:nth-child(2)::before { background: linear-gradient(90deg, #059669, #34D399); }
        .stat-box:nth-child(3)::before { background: linear-gradient(90deg, #DC2626, #F87171); }
        .stat-box:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); border-color: transparent; }
        .stat-number { font-size: 2rem; font-weight: 800; color: var(--gray-800); letter-spacing: -0.03em; }
        .stat-box:nth-child(1) .stat-number { color: #B45309; }
        .stat-box:nth-child(2) .stat-number { color: #059669; }
        .stat-box:nth-child(3) .stat-number { color: #DC2626; }
        .stat-label { font-size: 0.7rem; color: var(--gray-500); font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 6px; }
        
        .filter-bar {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            background: white;
            padding: 6px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .filter-btn {
            padding: 9px 20px;
            border-radius: var(--radius-md);
            background: transparent;
            border: none;
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--gray-600);
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .filter-btn:hover { background: var(--gray-100); color: var(--primary); }
        .filter-btn.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        
        .success-alert {
            background: #D1FAE5;
            color: #065F46;
            padding: 14px 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.85rem;
            font-weight: 500;
            border-left: 4px solid #059669;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
            box-shadow: var(--shadow-sm);
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 900px;
        }
        .table th {
            text-align: left;
            padding: 14px 16px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            color: var(--gray-600);
            border-bottom: 2px solid var(--accent);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 0.68rem;
        }
        .table td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .table tr:hover td { background: var(--gray-50); }
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .status-pending { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .status-approved { background: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7; }
        .status-rejected { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        
        .emergency-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
        }
        .emergency-badge.red { background: #FEE2E2; color: #991B1B; }
        .emergency-badge.blue { background: #DBEAFE; color: #1E40AF; }
        .emergency-badge.green { background: #D1FAE5; color: #065F46; }
        .emergency-badge.orange { background: #FEF3C7; color: #B45309; }
        .emergency-badge.gray { background: #F1F5F9; color: #475569; }
        
        .btn-approve {
            background: #059669;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-approve:hover { background: #047857; transform: translateY(-1px); }
        .btn-reject {
            background: #D32F2F;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            margin-left: 5px;
            transition: all 0.2s;
        }
        .btn-reject:hover { background: #B71C1C; transform: translateY(-1px); }
        .btn-view {
            background: var(--primary);
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-view:hover { background: var(--primary-dark); transform: translateY(-1px); }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            z-index: 1100;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            max-width: 820px;
            width: 100%;
            padding: 24px;
            max-height: 88vh;
            overflow-y: auto;
            box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.2);
        }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 6px; color: var(--gray-700); text-transform: uppercase; letter-spacing: 0.04em; }
        .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: inherit;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        .form-group select:focus, .form-group textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
        }
        .btn-submit {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border: none;
            padding: 12px 22px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 700;
            font-size: 0.85rem;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-cancel {
            background: var(--gray-200);
            color: var(--gray-700);
            border: none;
            padding: 12px 22px;
            border-radius: var(--radius-md);
            cursor: pointer;
            margin-left: 10px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        .btn-cancel:hover { background: var(--gray-300); }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        .empty-state i { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; display: block; }
        
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-decoration: none;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        
        /* Detail sections */
        .detail-section {
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--gray-200);
        }
        .detail-section:last-child { border-bottom: none; margin-bottom: 0; }
        .detail-section h4 {
            font-size: 0.85rem;
            color: var(--primary);
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 8px;
            border-bottom: 1px dashed var(--gray-200);
            font-weight: 700;
        }
        .detail-section h4 i { color: var(--secondary); }
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
        }
        .detail-item { padding: 6px 0; }
        .detail-label {
            font-weight: 700;
            color: var(--gray-500);
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .detail-value {
            font-size: 0.8rem;
            margin-top: 2px;
            color: var(--gray-800);
            word-break: break-word;
        }
        .doc-link {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
            text-decoration: none;
            margin: 2px 4px 2px 0;
            transition: all 0.2s;
        }
        .doc-link:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(30, 74, 140, 0.3); }
        .id-photo, .signature-photo {
            max-width: 200px;
            max-height: 160px;
            border-radius: 8px;
            border: 2px solid var(--gray-200);
            margin-top: 6px;
            object-fit: cover;
        }
        .case-summary {
            background: linear-gradient(135deg, #FFF7ED, #FFEDD5);
            padding: 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            border: 1px solid #FED7AA;
            border-left: 4px solid #E65100;
        }
        .case-summary .case-no {
            font-size: 1.2rem;
            font-weight: 800;
            color: #C2410C;
            font-family: monospace;
            margin-bottom: 4px;
            letter-spacing: 0.02em;
        }
        .case-summary .ref-code {
            font-size: 0.8rem;
            color: var(--gray-600);
            font-family: monospace;
        }
        .case-summary .submitted-at {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin-top: 8px;
        }
        .case-summary .emergency-type-header {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #E65100;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .amount-highlight {
            background: #FEF3C7;
            color: #92400E;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 700;
            display: inline-block;
            border-left: 4px solid #F59E0B;
        }
        @media (max-width: 480px) { .detail-grid { grid-template-columns: 1fr; } }
        
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); }
            .top-bar { flex-wrap: wrap; gap: 12px; }
            .page-title h1 { font-size: 1.1rem; }
            .page-title p { display: none; }
        }
        @media (max-width: 480px) { .stats-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

   <!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <!-- ============================================================
                 UPDATED: MSWDO Logo Image replaces Font Awesome icon
                 ============================================================ -->
            <div class="logo-icon">
                <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
            </div>
            <div class="logo-text">
                <h1>MSWDO Cantilan</h1>
                <p>Staff Portal</p>
            </div>
        </div>
    </div>
    <nav class="nav-menu">
        <div class="nav-section">
            <div class="nav-label">Main</div>
            <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item">
                <i class="fas fa-chart-line"></i> <span>Dashboard</span>
            </a>
            <a href="mswdstaff_communityservice.php" class="nav-item">
                <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
            </a>
            <a href="household.php" class="nav-item">
                <i class="fas fa-users"></i> <span>Household Records</span>
            </a>
        </div>
        <div class="nav-section">
            <div class="nav-label">Applications</div>
            <div class="nav-item collapsible" id="programToggle">
                <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                <i class="fas fa-chevron-right chevron" id="programIcon"></i>
            </div>
            <div class="submenu" id="programSubmenu">
                <a href="mswdstaff_soloparent.php" class="submenu-item"><i class="fas fa-female"></i> Solo Parent</a>
                <a href="mswdstaff_seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i> Senior Citizen</a>
                <a href="mswdstaff_pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i> PWD</a>
                <a href="mswdstaff_aics.php" class="submenu-item active"><i class="fas fa-coins"></i> AICS</a>
                <a href="mswdstaff_vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i> VAWC</a>
            </div>
            <a href="mswdstaff_idapplication.php" class="nav-item">
                <i class="fas fa-id-card"></i> <span>ID Applications</span>
            </a>
            <a href="staff_eligibility_engine.php" class="nav-item">
                <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
            </a>
            <a href="reports.php" class="nav-item">
                <i class="fas fa-chart-bar"></i> <span>Reports</span>
            </a>
        </div>
        <div class="nav-section">
            <div class="nav-label">Account</div>
            <a href="mswdstaff_profile.php" class="nav-item">
                <i class="fas fa-user-circle"></i> <span>Profile</span>
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
            </a>
        </div>
    </nav>
</aside>

    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>AICS Program Applications</h1>
                <p>View and manage AICS (Assistance to Individuals in Crisis Situation) applications</p>
            </div>
            <a href="mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <?php if(isset($success_message)): ?>
        <div class="success-alert"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div>
        <?php endif; ?>

        <div class="program-header">
            <div class="program-icon"><i class="fas fa-coins"></i></div>
            <div class="program-title">
                <h2>AICS Program</h2>
                <p>Assistance to Individuals in Crisis Situation</p>
            </div>
        </div>

        <?php
        $pending_count = count(array_filter($applications, fn($a) => $a['status'] == 'pending'));
        $approved_count = count(array_filter($applications, fn($a) => $a['status'] == 'approved'));
        $rejected_count = count(array_filter($applications, fn($a) => $a['status'] == 'rejected'));
        ?>
        <div class="stats-row">
            <div class="stat-box"><div class="stat-number"><?php echo $pending_count; ?></div><div class="stat-label">Pending Review</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $approved_count; ?></div><div class="stat-label">Approved</div></div>
            <div class="stat-box"><div class="stat-number"><?php echo $rejected_count; ?></div><div class="stat-label">Rejected</div></div>
        </div>

        <div class="filter-bar">
            <a href="?status=all" class="filter-btn <?php echo $status_filter == 'all' ? 'active' : ''; ?>">
                <i class="fas fa-list"></i> All
            </a>
            <a href="?status=pending" class="filter-btn <?php echo $status_filter == 'pending' ? 'active' : ''; ?>">
                <i class="fas fa-clock"></i> Pending
            </a>
            <a href="?status=approved" class="filter-btn <?php echo $status_filter == 'approved' ? 'active' : ''; ?>">
                <i class="fas fa-check-circle"></i> Approved
            </a>
            <a href="?status=rejected" class="filter-btn <?php echo $status_filter == 'rejected' ? 'active' : ''; ?>">
                <i class="fas fa-times-circle"></i> Rejected
            </a>
        </div>

        <div class="table-container">
            <table class="table">
                <thead>
                    <tr><th>ID</th><th>Case No.</th><th>Applicant</th><th>Emergency Type</th><th>Amount Requested</th><th>Date Applied</th><th>Status</th><th>Reviewed By</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php 
                    $filtered = array_filter($applications, fn($app) => $status_filter == 'all' || $app['status'] == $status_filter);
                    if(count($filtered) == 0): ?>
                    <tr>
                        <td colspan="9" class="empty-state">
                            <i class="fas fa-folder-open"></i>
                            <p>No AICS applications found</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach($filtered as $app): 
                        $app_data = json_decode($app['application_data'], true);
                        $display_case_no = $app_data['case_no'] ?? 'N/A';
                        $emergency_type = $app_data['emergency_type'] ?? '';
                        $et_info = $emergency_type_labels[$emergency_type] ?? ['label' => 'N/A', 'color' => 'gray', 'icon' => 'fa-question'];
                        $amount_requested = $app_data['amount_requested'] ?? null;
                    ?>
                    <tr>
                        <td><strong>#<?php echo $app['id']; ?></strong></td>
                        <td><small style="font-family: monospace; color: var(--primary); font-weight: 700;"><?php echo htmlspecialchars($display_case_no); ?></small></td>
                        <td><strong><?php echo htmlspecialchars($app['full_name']); ?></strong><br><small style="color: var(--gray-400);"><?php echo htmlspecialchars($app['username']); ?></small></td>
                        <td>
                            <?php if($emergency_type): ?>
                                <span class="emergency-badge <?php echo $et_info['color']; ?>">
                                    <i class="fas <?php echo $et_info['icon']; ?>"></i> <?php echo $et_info['label']; ?>
                                </span>
                            <?php else: ?>
                                <span style="color: #94A3B8;">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($amount_requested): ?>
                                <strong style="color: #B45309;">₱<?php echo number_format((float)$amount_requested, 2); ?></strong>
                            <?php else: ?>
                                <span style="color: #94A3B8;">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                        <td><span class="status-badge status-<?php echo $app['status']; ?>"><?php echo ucfirst($app['status']); ?></span></td>
                        <td><?php echo htmlspecialchars($reviewers[$app['reviewed_by']] ?? '-'); ?></td>
                        <td>
                            <button class="btn-view" onclick='viewDetails(<?php echo $app['id']; ?>, <?php echo json_encode($app_data, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                                <i class="fas fa-eye"></i> View
                            </button>
                            <?php if($app['status'] == 'pending'): ?>
                                <button class="btn-approve" onclick="openActionModal(<?php echo $app['id']; ?>, 'approve')">
                                    <i class="fas fa-check"></i> Approve
                                </button>
                                <button class="btn-reject" onclick="openActionModal(<?php echo $app['id']; ?>, 'reject')">
                                    <i class="fas fa-times"></i> Reject
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/mswdstaff_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="mswdstaff_idapplication.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Apps</span></a>
        <a href="mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <!-- Modal for View Details -->
    <div id="viewModal" class="modal">
        <div class="modal-content">
            <h3 style="margin-bottom: 16px; color: var(--primary); font-weight: 800;"><i class="fas fa-file-alt"></i> Application Details</h3>
            <div id="modalContent"></div>
            <div style="margin-top: 20px; text-align: right;">
                <button type="button" class="btn-cancel" onclick="closeModal('viewModal')">Close</button>
            </div>
        </div>
    </div>

    <!-- Modal for Approve/Reject Action -->
    <div id="actionModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <h3 id="actionTitle" style="margin-bottom: 16px; color: var(--primary); font-weight: 800;">Update Application Status</h3>
            <form method="POST">
                <input type="hidden" name="application_id" id="actionAppId">
                <input type="hidden" name="update_status" value="1">
                <input type="hidden" name="status" id="actionStatus">
                <div class="form-group">
                    <label>Review Notes</label>
                    <textarea name="notes" id="actionNotes" rows="3" placeholder="Add your review notes here..."></textarea>
                </div>
                <button type="submit" class="btn-submit" id="actionSubmitBtn">Confirm</button>
                <button type="button" class="btn-cancel" onclick="closeModal('actionModal')">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) {
            menuToggle.addEventListener('click', () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); });
        }
        if(overlay) {
            overlay.addEventListener('click', () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); });
        }

        // Collapsible Program Menu
        const programToggle = document.getElementById('programToggle');
        const programSubmenu = document.getElementById('programSubmenu');
        const programIcon = document.getElementById('programIcon');
        if(programToggle) {
            programSubmenu.classList.add('show');
            programIcon.classList.add('rotated');
            programToggle.addEventListener('click', () => { 
                programSubmenu.classList.toggle('show'); 
                programIcon.classList.toggle('rotated'); 
            });
        }

        // Emergency type metadata
        const emergencyMeta = {
            'medical': { label: 'Medical Assistance', color: 'red', icon: 'fa-heartbeat' },
            'burial': { label: 'Burial Assistance', color: 'gray', icon: 'fa-cross' },
            'transportation': { label: 'Transportation Assistance', color: 'blue', icon: 'fa-bus' },
            'educational': { label: 'Educational Assistance', color: 'green', icon: 'fa-graduation-cap' },
            'food': { label: 'Food Assistance', color: 'orange', icon: 'fa-utensils' },
            'medicine': { label: 'Medicine Assistance', color: 'red', icon: 'fa-prescription-bottle-medical' },
            'housing': { label: 'Housing Assistance', color: 'blue', icon: 'fa-home' },
            'others': { label: 'Others', color: 'gray', icon: 'fa-ellipsis-h' }
        };

        // ============================================================
        // VIEW DETAILS
        // ============================================================
        function viewDetails(id, d) {
            let html = '';
            
            try {
                if (typeof d === 'string') d = JSON.parse(d);
                const et = emergencyMeta[d.emergency_type] || { label: 'N/A', color: 'gray', icon: 'fa-question' };

                // ==================== CASE SUMMARY ====================
                html += '<div class="case-summary">';
                if (d.emergency_type) {
                    html += '<div class="emergency-type-header"><i class="fas ' + et.icon + '"></i> ' + et.label + '</div>';
                }
                html += '<div class="case-no"><i class="fas fa-hashtag" style="font-size: 0.9rem;"></i> ' + escapeHtml(d.case_no || 'N/A') + '</div>';
                if (d.reference_code) {
                    html += '<div class="ref-code"><i class="fas fa-key"></i> Reference Code: ' + escapeHtml(d.reference_code) + '</div>';
                }
                html += '<div class="submitted-at"><i class="fas fa-clock"></i> Submitted: ' + escapeHtml(d.submission_date || 'N/A') + '</div>';
                if (d.amount_requested) {
                    html += '<div style="margin-top: 12px;"><span class="amount-highlight">₱ ' + Number(d.amount_requested).toLocaleString() + '</span></div>';
                }
                html += '</div>';

                // ==================== STEP 1 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-info-circle"></i> Step 1: Submission Info</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Case No.</div><div class="detail-value">' + escapeHtml(d.case_no || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Reference Code</div><div class="detail-value"><code>' + escapeHtml(d.reference_code || 'N/A') + '</code></div></div>';
                html += '<div class="detail-item"><div class="detail-label">Submission Date</div><div class="detail-value">' + escapeHtml(d.submission_date || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Verification Code</div><div class="detail-value"><code>' + escapeHtml(d.verification_code || 'N/A') + '</code></div></div>';
                html += '</div></div>';

                // ==================== STEP 2 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-id-card"></i> Step 2: Client Profile</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">First Name</div><div class="detail-value">' + escapeHtml(d.first_name || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Middle Name</div><div class="detail-value">' + escapeHtml(d.middle_name || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Last Name</div><div class="detail-value">' + escapeHtml(d.last_name || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Birthdate</div><div class="detail-value">' + escapeHtml(d.birthdate || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Age</div><div class="detail-value">' + escapeHtml(d.age || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Sex</div><div class="detail-value">' + escapeHtml(d.sex || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Civil Status</div><div class="detail-value">' + escapeHtml(d.civil_status || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Barangay</div><div class="detail-value">' + escapeHtml(d.barangay || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Municipality</div><div class="detail-value">' + escapeHtml(d.municipality || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Province</div><div class="detail-value">' + escapeHtml(d.province || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Contact No.</div><div class="detail-value">' + escapeHtml(d.contact_no || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Occupation</div><div class="detail-value">' + escapeHtml(d.occupation || 'N/A') + '</div></div>';
                html += '</div></div>';

                // ==================== STEP 3 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-chart-line"></i> Step 3: Socio-Economic Assessment</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Housing Ownership</div><div class="detail-value">' + escapeHtml(d.housing_ownership || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Housing Materials</div><div class="detail-value">' + escapeHtml(d.housing_materials || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Water Source</div><div class="detail-value">' + escapeHtml(d.water_source || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Toilet Type</div><div class="detail-value">' + escapeHtml(d.toilet_type || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Employment Status</div><div class="detail-value">' + escapeHtml(d.employment_status || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Has Insurance</div><div class="detail-value">' + (d.has_insurance == 1 ? 'Yes' : 'No') + '</div></div>';
                html += '</div></div>';

                // ==================== STEP 4 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-coins"></i> Step 4: AICS Program Details</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Emergency Type</div><div class="detail-value"><span class="emergency-badge ' + et.color + '"><i class="fas ' + et.icon + '"></i> ' + et.label + '</span></div></div>';
                html += '<div class="detail-item"><div class="detail-label">Relationship to Beneficiary</div><div class="detail-value">' + escapeHtml(d.relationship_to_beneficiary || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Amount Requested</div><div class="detail-value"><strong style="color: #B45309;">₱' + (d.amount_requested ? Number(d.amount_requested).toLocaleString() : '0') + '</strong></div></div>';
                html += '<div class="detail-item"><div class="detail-label">Cause of Crisis</div><div class="detail-value">' + escapeHtml(d.cause_of_crisis || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Household Disposable Cash</div><div class="detail-value">₱' + escapeHtml(d.household_disposable_cash || '0') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Incident Date</div><div class="detail-value">' + escapeHtml(d.incident_date || 'N/A') + '</div></div>';
                html += '<div class="detail-item" style="grid-column: 1 / -1;"><div class="detail-label">Incident Location</div><div class="detail-value">' + escapeHtml(d.incident_location || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Beneficiary Name</div><div class="detail-value">' + escapeHtml(d.beneficiary_name || 'N/A') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Beneficiary Age</div><div class="detail-value">' + escapeHtml(d.beneficiary_age || 'N/A') + '</div></div>';
                html += '</div>';

                html += '<div class="detail-item" style="margin-top:12px;">';
                html += '<div class="detail-label">Crisis Description</div>';
                html += '<div class="detail-value">' + escapeHtml(d.crisis_description || 'N/A') + '</div>';
                html += '</div>';

                // Conditional fields based on emergency type
                if (d.emergency_type === 'medical' && (d.medical_diagnosis || d.hospital_name || d.medical_bill_amount)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#FEF2F2; border-radius:8px; border-left:3px solid #DC2626;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#991B1B; margin-bottom:8px;"><i class="fas fa-heartbeat"></i> MEDICAL ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-grid">';
                    if (d.medical_diagnosis) html += '<div class="detail-item"><div class="detail-label">Medical Diagnosis</div><div class="detail-value">' + escapeHtml(d.medical_diagnosis) + '</div></div>';
                    if (d.hospital_name) html += '<div class="detail-item"><div class="detail-label">Hospital Name</div><div class="detail-value">' + escapeHtml(d.hospital_name) + '</div></div>';
                    if (d.medical_bill_amount) html += '<div class="detail-item"><div class="detail-label">Medical Bill Amount</div><div class="detail-value">₱' + Number(d.medical_bill_amount).toLocaleString() + '</div></div>';
                    html += '</div></div>';
                }

                if (d.emergency_type === 'burial' && (d.deceased_name || d.cause_of_death || d.funeral_home)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#F1F5F9; border-radius:8px; border-left:3px solid #475569;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#334155; margin-bottom:8px;"><i class="fas fa-cross"></i> BURIAL ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-grid">';
                    if (d.deceased_name) html += '<div class="detail-item"><div class="detail-label">Name of Deceased</div><div class="detail-value">' + escapeHtml(d.deceased_name) + '</div></div>';
                    if (d.cause_of_death) html += '<div class="detail-item"><div class="detail-label">Cause of Death</div><div class="detail-value">' + escapeHtml(d.cause_of_death) + '</div></div>';
                    if (d.funeral_home) html += '<div class="detail-item" style="grid-column: 1 / -1;"><div class="detail-label">Funeral Home</div><div class="detail-value">' + escapeHtml(d.funeral_home) + '</div></div>';
                    html += '</div></div>';
                }

                if (d.emergency_type === 'educational' && (d.school_name || d.school_level || d.school_bill_amount)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#ECFDF5; border-radius:8px; border-left:3px solid #059669;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#065F46; margin-bottom:8px;"><i class="fas fa-graduation-cap"></i> EDUCATIONAL ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-grid">';
                    if (d.school_name) html += '<div class="detail-item"><div class="detail-label">School Name</div><div class="detail-value">' + escapeHtml(d.school_name) + '</div></div>';
                    if (d.school_level) html += '<div class="detail-item"><div class="detail-label">School Level</div><div class="detail-value">' + escapeHtml(d.school_level) + '</div></div>';
                    if (d.school_bill_amount) html += '<div class="detail-item"><div class="detail-label">School Bill Amount</div><div class="detail-value">₱' + Number(d.school_bill_amount).toLocaleString() + '</div></div>';
                    html += '</div></div>';
                }

                if (d.emergency_type === 'transportation' && (d.transportation_details || d.transportation_destination)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#DBEAFE; border-radius:8px; border-left:3px solid #1E40AF;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#1E3A8A; margin-bottom:8px;"><i class="fas fa-bus"></i> TRANSPORTATION ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-grid">';
                    if (d.transportation_details) html += '<div class="detail-item"><div class="detail-label">Purpose of Travel</div><div class="detail-value">' + escapeHtml(d.transportation_details) + '</div></div>';
                    if (d.transportation_destination) html += '<div class="detail-item"><div class="detail-label">Destination</div><div class="detail-value">' + escapeHtml(d.transportation_destination) + '</div></div>';
                    html += '</div></div>';
                }

                if (d.emergency_type === 'food' && (d.food_details || d.food_persons_count)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#FEF3C7; border-radius:8px; border-left:3px solid #D97706;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#92400E; margin-bottom:8px;"><i class="fas fa-utensils"></i> FOOD ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-grid">';
                    if (d.food_details) html += '<div class="detail-item"><div class="detail-label">Food Details</div><div class="detail-value">' + escapeHtml(d.food_details) + '</div></div>';
                    if (d.food_persons_count) html += '<div class="detail-item"><div class="detail-label">Number of Persons</div><div class="detail-value">' + escapeHtml(d.food_persons_count) + '</div></div>';
                    html += '</div></div>';
                }

                if (d.emergency_type === 'medicine' && (d.medicine_details || d.medicine_prescription)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#FEF2F2; border-radius:8px; border-left:3px solid #DC2626;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#991B1B; margin-bottom:8px;"><i class="fas fa-prescription-bottle-medical"></i> MEDICINE ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-grid">';
                    if (d.medicine_details) html += '<div class="detail-item"><div class="detail-label">Medicine Details</div><div class="detail-value">' + escapeHtml(d.medicine_details) + '</div></div>';
                    if (d.medicine_prescription) html += '<div class="detail-item"><div class="detail-label">With Prescription</div><div class="detail-value">' + escapeHtml(d.medicine_prescription) + '</div></div>';
                    html += '</div></div>';
                }

                if (d.emergency_type === 'housing' && (d.housing_details || d.housing_damage_type || d.housing_repair_amount)) {
                    html += '<div style="margin-top:12px; padding:12px; background:#DBEAFE; border-radius:8px; border-left:3px solid #1E40AF;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#1E3A8A; margin-bottom:8px;"><i class="fas fa-home"></i> HOUSING ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-grid">';
                    if (d.housing_details) html += '<div class="detail-item" style="grid-column: 1 / -1;"><div class="detail-label">Housing Details</div><div class="detail-value">' + escapeHtml(d.housing_details) + '</div></div>';
                    if (d.housing_damage_type) html += '<div class="detail-item"><div class="detail-label">Type of Damage/Assistance</div><div class="detail-value">' + escapeHtml(d.housing_damage_type) + '</div></div>';
                    if (d.housing_repair_amount) html += '<div class="detail-item"><div class="detail-label">Estimated Repair Amount</div><div class="detail-value">₱' + Number(d.housing_repair_amount).toLocaleString() + '</div></div>';
                    html += '</div></div>';
                }

                if (d.emergency_type === 'others' && d.others_details) {
                    html += '<div style="margin-top:12px; padding:12px; background:#F1F5F9; border-radius:8px; border-left:3px solid #475569;">';
                    html += '<div style="font-size:0.7rem; font-weight:700; color:#334155; margin-bottom:8px;"><i class="fas fa-ellipsis-h"></i> OTHER ASSISTANCE DETAILS</div>';
                    html += '<div class="detail-value">' + escapeHtml(d.others_details) + '</div>';
                    html += '</div>';
                }

                html += '<div class="detail-item" style="margin-top:12px;">';
                html += '<div class="detail-label">Problem Presented</div>';
                html += '<div class="detail-value">' + escapeHtml(d.problem_presented || 'N/A') + '</div>';
                html += '</div>';

                let rehabDisplay = 'N/A';
                if (Array.isArray(d.rehabilitation_goals) && d.rehabilitation_goals.length > 0) {
                    rehabDisplay = '<div style="display:flex; flex-wrap:wrap; gap:6px; margin-top:4px;">';
                    d.rehabilitation_goals.forEach(function(g) {
                        rehabDisplay += '<span style="display:inline-block; background:#F1F5F9; color:#475569; padding:3px 10px; border-radius:12px; font-size:0.7rem; font-weight:600;">' + escapeHtml(g) + '</span>';
                    });
                    rehabDisplay += '</div>';
                }
                html += '<div class="detail-item" style="margin-top:8px;">';
                html += '<div class="detail-label">Rehabilitation Goals</div>';
                html += '<div class="detail-value">' + rehabDisplay + '</div>';
                html += '</div>';

                // Documents
                html += '<div class="detail-item" style="margin-top:12px;">';
                html += '<div class="detail-label">Barangay Certificate of Indigency</div>';
                html += '<div class="detail-value">';
                if (d.barangay_certificate) {
                    html += '<a href="../' + escapeHtml(d.barangay_certificate) + '" target="_blank" class="doc-link"><i class="fas fa-file-certificate"></i> View Document</a>';
                } else {
                    html += '<span style="color:#94A3B8;">No file uploaded</span>';
                }
                html += '</div></div>';

                html += '<div class="detail-item" style="margin-top:8px;">';
                let dynamicDocLabel = 'Supporting Document';
                if (d.dynamic_document_type === 'medical') dynamicDocLabel = 'Clinical Abstract';
                else if (d.dynamic_document_type === 'burial') dynamicDocLabel = 'Death Certificate';
                else if (d.dynamic_document_type === 'educational') dynamicDocLabel = 'School Billing';
                else if (d.dynamic_document_type === 'transportation') dynamicDocLabel = 'Proof of Travel';
                else if (d.dynamic_document_type === 'food') dynamicDocLabel = 'Proof of Need';
                else if (d.dynamic_document_type === 'medicine') dynamicDocLabel = 'Medical Prescription';
                else if (d.dynamic_document_type === 'housing') dynamicDocLabel = 'Proof of Housing Damage';
                html += '<div class="detail-label">' + dynamicDocLabel + '</div>';
                html += '<div class="detail-value">';
                if (d.dynamic_document) {
                    html += '<a href="../' + escapeHtml(d.dynamic_document) + '" target="_blank" class="doc-link"><i class="fas fa-file-alt"></i> View Document</a>';
                } else {
                    html += '<span style="color:#94A3B8;">No file uploaded</span>';
                }
                html += '</div></div>';
                html += '</div>';

                // ==================== STEP 5 ====================
                html += '<div class="detail-section">';
                html += '<h4><i class="fas fa-shield-alt"></i> Step 5: Digital Verification</h4>';
                html += '<div class="detail-grid">';
                html += '<div class="detail-item"><div class="detail-label">Client Consent</div><div class="detail-value">' + (d.client_consent == 1 ? '<span style="color:#059669;">✓ Given</span>' : '<span style="color:#D32F2F;">✗ Not given</span>') + '</div></div>';
                html += '<div class="detail-item"><div class="detail-label">Caseworker</div><div class="detail-value">' + escapeHtml(d.caseworker_name || 'N/A') + ' (ID #' + escapeHtml(d.caseworker_id || 'N/A') + ')</div></div>';
                if (d.photo_timestamp) {
                    html += '<div class="detail-item"><div class="detail-label">Captured At</div><div class="detail-value">' + escapeHtml(d.photo_timestamp) + '</div></div>';
                }
                html += '</div>';

                if (d.identity_photo) {
                    html += '<div class="detail-item" style="margin-top:12px;">';
                    html += '<div class="detail-label">Identity Photo</div>';
                    html += '<div class="detail-value"><img src="../' + escapeHtml(d.identity_photo) + '" class="id-photo" alt="Identity"></div>';
                    html += '</div>';
                }

                if (d.client_signature && d.client_signature.length > 100) {
                    html += '<div class="detail-item" style="margin-top:12px;">';
                    html += '<div class="detail-label">Client Signature</div>';
                    html += '<div class="detail-value"><img src="' + d.client_signature + '" class="signature-photo" alt="Signature"></div>';
                    html += '</div>';
                }
                html += '</div>';

            } catch(e) {
                html = '<p style="text-align:center;color:var(--gray-500);padding:20px;">Error parsing application data: ' + e.message + '</p>';
                console.error('View details error:', e);
            }
            
            document.getElementById('modalContent').innerHTML = html;
            document.getElementById('viewModal').style.display = 'flex';
        }

        function escapeHtml(text) {
            if (text === null || text === undefined) return '';
            return String(text)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function openActionModal(id, action) {
            document.getElementById('actionAppId').value = id;
            document.getElementById('actionStatus').value = action;
            const title = action == 'approve' ? '✅ Approve Application' : '❌ Reject Application';
            const btnText = action == 'approve' ? 'Approve' : 'Reject';
            const btnColor = action == 'approve' ? '#059669' : '#D32F2F';
            document.getElementById('actionTitle').innerHTML = title;
            const btn = document.getElementById('actionSubmitBtn');
            btn.innerHTML = btnText;
            btn.style.background = btnColor;
            document.getElementById('actionModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        window.onclick = (e) => { 
            if(e.target.classList.contains('modal')) closeModal(e.target.id); 
        }
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>