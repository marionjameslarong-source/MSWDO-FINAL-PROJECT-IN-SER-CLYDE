<?php
session_start();
require_once '../config/database.php';

// Admin only access
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];

// Get deleted count for recycle bin badge
$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
$deleted_count = $stmt->fetch()['total'];

// Date range filter
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-01');
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');

// Report type
$report_type = isset($_GET['type']) ? $_GET['type'] : 'overview';

// Get all barangays from households table
$barangays = [];
try {
    $stmt = $pdo->query("
        SELECT DISTINCT barangay 
        FROM households 
        WHERE barangay IS NOT NULL 
        AND barangay != '' 
        AND barangay != 'NULL'
        ORDER BY barangay ASC
    ");
    $barangays = $stmt->fetchAll();
} catch(PDOException $e) {
    $barangays = [];
}

$barangay_filter = isset($_GET['barangay']) ? $_GET['barangay'] : '';

// ============================================================
// 1. POVERTY MATRIX - 3 CLASSES (UPDATED RANGES)
// ============================================================
$poverty_matrix = [];
try {
    $poverty_query = "
        SELECT 
            barangay,
            SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) AS total_poor,
            SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) AS total_middle_class,
            SUM(CASE WHEN monthly_income > 25000 THEN 1 ELSE 0 END) AS total_rich,
            COUNT(*) AS grand_total_households
        FROM households
        WHERE created_at BETWEEN ? AND ?
        AND monthly_income IS NOT NULL
    ";
    if($barangay_filter) {
        $poverty_query .= " AND barangay = ?";
    }
    $poverty_query .= " GROUP BY barangay ORDER BY grand_total_households DESC";
    
    $stmt = $pdo->prepare($poverty_query);
    $params = [$date_from, $date_to . ' 23:59:59'];
    if($barangay_filter) {
        $params[] = $barangay_filter;
    }
    $stmt->execute($params);
    $poverty_matrix = $stmt->fetchAll();
} catch(PDOException $e) {
    $poverty_matrix = [];
}

// ============================================================
// 2. STAFF PERFORMANCE
// ============================================================
$staff_performance = [];
try {
    $staff_query = "
        SELECT 
            u.id as staff_id,
            u.full_name AS staff_full_name,
            u.email,
            u.role AS staff_role,
            u.status AS staff_status
        FROM users u
        WHERE u.role IN ('staff', 'social_worker', 'encoder', 'admin')
        ORDER BY u.full_name ASC
    ";
    $stmt = $pdo->query($staff_query);
    $all_staff = $stmt->fetchAll();
    
    $staff_ids = array_column($all_staff, 'staff_id');
    $staff_metrics = [];
    if(!empty($staff_ids)) {
        $placeholders = implode(',', array_fill(0, count($staff_ids), '?'));
        
        $stmt = $pdo->query("SHOW TABLES LIKE 'verification_audit_logs'");
        if($stmt->rowCount() > 0) {
            $perf_query = "
                SELECT 
                    val.action_by_staff_id as staff_id,
                    COUNT(CASE WHEN val.new_status IN ('VERIFIED_APPROVED', 'verified_approved', 'approved') THEN 1 END) AS total_approvals,
                    COUNT(CASE WHEN val.new_status IN ('REJECTED_NEEDS_CORRECTION', 'rejected_needs_correction', 'REJECTED', 'rejected') THEN 1 END) AS total_rejections,
                    COUNT(*) AS total_actions_processed
                FROM verification_audit_logs val
                WHERE val.action_by_staff_id IN ($placeholders)
                AND val.created_at >= ?
                GROUP BY val.action_by_staff_id
            ";
            $stmt = $pdo->prepare($perf_query);
            $params = array_merge($staff_ids, [$date_from]);
            $stmt->execute($params);
            $results = $stmt->fetchAll();
            foreach($results as $r) {
                $staff_metrics[$r['staff_id']] = [
                    'total_approvals' => $r['total_approvals'],
                    'total_rejections' => $r['total_rejections'],
                    'total_actions_processed' => $r['total_actions_processed']
                ];
            }
        }
        
        foreach($all_staff as $staff) {
            $staff_id = $staff['staff_id'];
            $staff_performance[] = [
                'staff_id' => $staff_id,
                'staff_full_name' => $staff['staff_full_name'],
                'staff_email' => $staff['email'],
                'staff_role' => $staff['staff_role'],
                'staff_status' => $staff['staff_status'],
                'total_approvals' => $staff_metrics[$staff_id]['total_approvals'] ?? 0,
                'total_rejections' => $staff_metrics[$staff_id]['total_rejections'] ?? 0,
                'total_actions_processed' => $staff_metrics[$staff_id]['total_actions_processed'] ?? 0
            ];
        }
    }
} catch(PDOException $e) {
    $staff_performance = [];
}

// ============================================================
// 3. FINANCIAL BURN-RATE ANALYSIS - Reads from budget_settings
// ============================================================
$initial_allocation = 5000000.00;
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'budget_settings'");
    if($stmt->rowCount() > 0) {
        $stmt = $pdo->query("SELECT setting_value FROM budget_settings WHERE setting_key = 'initial_allocation' LIMIT 1");
        $result = $stmt->fetch();
        if($result) $initial_allocation = floatval($result['setting_value']);
    }
} catch(PDOException $e) {}

$financial_metrics = [];
try {
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(actual_amount_paid), 0) as total_disbursed,
               COUNT(*) as total_transactions
        FROM welfare_applications 
        WHERE status = 'disbursed' 
        AND created_at BETWEEN ? AND ?
    ");
    $stmt->execute([$date_from, $date_to . ' 23:59:59']);
    $disbursed_data = $stmt->fetch();
    
    $total_disbursed = $disbursed_data['total_disbursed'] ?? 0;
    $total_transactions = $disbursed_data['total_transactions'] ?? 0;
    
    $current_remaining = max(0, $initial_allocation - $total_disbursed);
    
    $date1 = new DateTime($date_from);
    $date2 = new DateTime($date_to);
    $days_diff = $date1->diff($date2)->days + 1;
    
    $avg_daily_disbursement = ($days_diff > 0 && $total_disbursed > 0) ? ($total_disbursed / $days_diff) : 0;
    $estimated_days_until_depletion = ($avg_daily_disbursement > 0) ? floor($current_remaining / $avg_daily_disbursement) : 0;
    
    $financial_metrics = [
        'fund_name' => 'MUNICIPAL_CRISIS_BUDGET_2026',
        'initial_allocation' => $initial_allocation,
        'current_remaining_balance' => $current_remaining,
        'total_disbursed_to_date' => $total_disbursed,
        'total_transactions' => $total_transactions,
        'average_daily_disbursement' => $avg_daily_disbursement,
        'estimated_days_until_depletion' => $estimated_days_until_depletion
    ];
} catch(PDOException $e) {
    $financial_metrics = [
        'fund_name' => 'MUNICIPAL_CRISIS_BUDGET_2026',
        'initial_allocation' => $initial_allocation,
        'current_remaining_balance' => $initial_allocation,
        'total_disbursed_to_date' => 0,
        'total_transactions' => 0,
        'average_daily_disbursement' => 0,
        'estimated_days_until_depletion' => 0
    ];
}

// ============================================================
// DATA COLLECTION
// ============================================================

$stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
$total_users = $stmt->fetch()['total'];
$stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'resident'");
$total_residents = $stmt->fetch()['total'];
$stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role != 'resident'");
$total_staff = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM households");
$total_households = $stmt->fetch()['total'];
$stmt = $pdo->query("SELECT SUM(total_members) as total FROM households");
$total_members = $stmt->fetch()['total'] ?? 0;
$stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE is_4ps_beneficiary = 1");
$total_4ps = $stmt->fetch()['total'];

$total_applications = 0;
$pending_apps = 0;
$approved_apps = 0;
$rejected_apps = 0;
$apps_by_program = [];

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications");
    $total_applications = $stmt->fetch()['total'];
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications WHERE status = 'pending'");
    $pending_apps = $stmt->fetch()['total'];
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications WHERE status = 'approved'");
    $approved_apps = $stmt->fetch()['total'];
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications WHERE status = 'rejected'");
    $rejected_apps = $stmt->fetch()['total'];
    
    $stmt = $pdo->prepare("
        SELECT program_type, COUNT(*) as count 
        FROM welfare_applications 
        WHERE created_at BETWEEN ? AND ?
        GROUP BY program_type
    ");
    $stmt->execute([$date_from, $date_to . ' 23:59:59']);
    $apps_by_program = $stmt->fetchAll();
} catch(PDOException $e) {}

$program_names = [
    'solo_parent' => 'Solo Parent',
    'senior_citizen' => 'Senior Citizen',
    'pwd' => 'PWD',
    'aics' => 'AICS',
    'vawc' => 'VAWC',
    'financial_assistance' => 'Financial Assistance',
    'id_application' => 'ID Application',
    '4ps' => '4Ps'
];

$stmt = $pdo->prepare("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
    FROM households 
    WHERE created_at BETWEEN ? AND ?
    GROUP BY month 
    ORDER BY month ASC
");
$stmt->execute([$date_from, $date_to . ' 23:59:59']);
$household_growth = $stmt->fetchAll();

$application_trend = [];
try {
    $stmt = $pdo->prepare("
        SELECT DATE_FORMAT(created_at, '%Y-%m') as month, 
               SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
               SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
               SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
               COUNT(*) as total
        FROM welfare_applications 
        WHERE created_at BETWEEN ? AND ?
        GROUP BY month 
        ORDER BY month ASC
    ");
    $stmt->execute([$date_from, $date_to . ' 23:59:59']);
    $application_trend = $stmt->fetchAll();
} catch(PDOException $e) {}

// Barangay query - UPDATED 3-class ranges
$barangay_query = "
    SELECT 
        barangay,
        COUNT(*) as households,
        SUM(total_members) as total_members,
        SUM(CASE WHEN is_4ps_beneficiary = 1 THEN 1 ELSE 0 END) as total_4ps,
        ROUND(AVG(monthly_income), 2) as avg_income,
        SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) as poor_count,
        SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) as middle_class_count,
        SUM(CASE WHEN monthly_income > 25000 THEN 1 ELSE 0 END) as rich_count
    FROM households 
    WHERE created_at BETWEEN ? AND ?
    AND monthly_income IS NOT NULL
";
$params = [$date_from, $date_to . ' 23:59:59'];
if($barangay_filter) {
    $barangay_query .= " AND barangay = ?";
    $params[] = $barangay_filter;
}
$barangay_query .= " GROUP BY barangay ORDER BY households DESC";
$stmt = $pdo->prepare($barangay_query);
$stmt->execute($params);
$barangay_data = $stmt->fetchAll();

// Poverty stats - UPDATED 3-class ranges
$poverty_stats = ['poor' => 0, 'middle_class' => 0, 'rich' => 0, 'total' => 0];
try {
    $stmt = $pdo->prepare("
        SELECT 
            SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) as poor,
            SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) as middle_class,
            SUM(CASE WHEN monthly_income > 25000 THEN 1 ELSE 0 END) as rich,
            COUNT(*) as total
        FROM households 
        WHERE created_at BETWEEN ? AND ?
        AND monthly_income IS NOT NULL
    ");
    $stmt->execute([$date_from, $date_to . ' 23:59:59']);
    $poverty_stats = $stmt->fetch();
} catch(PDOException $e) {
    $poverty_stats = ['poor' => 0, 'middle_class' => 0, 'rich' => 0, 'total' => 0];
}

$stmt = $pdo->prepare("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, 
           SUM(CASE WHEN role = 'resident' THEN 1 ELSE 0 END) as residents,
           SUM(CASE WHEN role != 'resident' THEN 1 ELSE 0 END) as staff,
           COUNT(*) as total
    FROM users 
    WHERE created_at BETWEEN ? AND ?
    GROUP BY month 
    ORDER BY month ASC
");
$stmt->execute([$date_from, $date_to . ' 23:59:59']);
$user_growth = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM households ORDER BY created_at DESC LIMIT 5");
$stmt->execute();
$recent_households = $stmt->fetchAll();

$recent_applications = [];
try {
    $stmt = $pdo->prepare("
        SELECT wa.*, u.full_name as applicant_name 
        FROM welfare_applications wa 
        JOIN users u ON wa.user_id = u.id 
        ORDER BY wa.created_at DESC LIMIT 5
    ");
    $stmt->execute();
    $recent_applications = $stmt->fetchAll();
} catch(PDOException $e) {}

// Export to CSV
if(isset($_GET['export']) && $_GET['export'] == 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="admin_report_' . $report_type . '_' . date('Y-m-d') . '.csv"');
    $output = fopen('php://output', 'w');
    
    switch($report_type) {
        case 'poverty_matrix':
            fputcsv($output, ['Barangay', 'Poor (₱5k-₱10k)', 'Middle-Class (₱10k-₱25k)', 'Rich (₱25k+)', 'Total Households']);
            foreach($poverty_matrix as $row) {
                fputcsv($output, [$row['barangay'], $row['total_poor'] ?? 0, $row['total_middle_class'] ?? 0, $row['total_rich'] ?? 0, $row['grand_total_households'] ?? 0]);
            }
            break;
        case 'staff_performance':
            fputcsv($output, ['Staff Name', 'Role', 'Status', 'Approvals', 'Rejections', 'Total Actions']);
            foreach($staff_performance as $row) {
                fputcsv($output, [$row['staff_full_name'] ?? 'Unknown', $row['staff_role'] ?? 'N/A', $row['staff_status'] ?? 'N/A', $row['total_approvals'] ?? 0, $row['total_rejections'] ?? 0, $row['total_actions_processed'] ?? 0]);
            }
            break;
        case 'financial':
            fputcsv($output, ['Metric', 'Value']);
            fputcsv($output, ['Fund Name', $financial_metrics['fund_name']]);
            fputcsv($output, ['Initial Allocation', $financial_metrics['initial_allocation']]);
            fputcsv($output, ['Total Disbursed', $financial_metrics['total_disbursed_to_date']]);
            fputcsv($output, ['Remaining Balance', $financial_metrics['current_remaining_balance']]);
            break;
        case 'barangay':
            fputcsv($output, ['Barangay', 'Households', 'Total Members', '4Ps', 'Avg Income', 'Poor', 'Middle-Class', 'Rich']);
            foreach($barangay_data as $row) {
                fputcsv($output, [$row['barangay'], $row['households'], $row['total_members'], $row['total_4ps'], $row['avg_income'], $row['poor_count'] ?? 0, $row['middle_class_count'] ?? 0, $row['rich_count'] ?? 0]);
            }
            break;
        case 'poverty':
            fputcsv($output, ['Category', 'Households']);
            fputcsv($output, ['Poor (₱5k-₱10k)', $poverty_stats['poor'] ?? 0]);
            fputcsv($output, ['Middle-Class (₱10k-₱25k)', $poverty_stats['middle_class'] ?? 0]);
            fputcsv($output, ['Rich (₱25k+)', $poverty_stats['rich'] ?? 0]);
            break;
        case 'applications':
            fputcsv($output, ['Program', 'Count']);
            foreach($apps_by_program as $row) {
                fputcsv($output, [$program_names[$row['program_type']] ?? ucfirst($row['program_type']), $row['count']]);
            }
            break;
        default:
            fputcsv($output, ['Metric', 'Value']);
            fputcsv($output, ['Total Users', $total_users]);
            fputcsv($output, ['Residents', $total_residents]);
            fputcsv($output, ['Staff', $total_staff]);
            fputcsv($output, ['Households', $total_households]);
            fputcsv($output, ['Total Members', $total_members]);
            fputcsv($output, ['4Ps Beneficiaries', $total_4ps]);
            fputcsv($output, ['Applications', $total_applications]);
    }
    fclose($output);
    exit();
}

// Helper: build URL preserving filters
function buildReportUrl($type) {
    global $date_from, $date_to, $barangay_filter;
    $url = "?type=$type&date_from=$date_from&date_to=$date_to";
    if($barangay_filter && in_array($type, ['barangay', 'poverty_matrix'])) {
        $url .= "&barangay=" . urlencode($barangay_filter);
    }
    return $url;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Admin Reports - MSWDO Analytics</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
            background-image: 
                radial-gradient(at 0% 0%, rgba(30, 74, 140, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(245, 176, 66, 0.05) 0px, transparent 50%);
            background-attachment: fixed;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #3B6BB5;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --accent-dark: #D99524;
            --success: #059669;
            --warning: #F59E0B;
            --danger: #DC2626;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0; left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed; inset: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999; display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.08em;
            color: var(--gray-400); margin-bottom: 8px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 12px; border-radius: var(--radius-md);
            color: var(--gray-600); text-decoration: none;
            font-size: 0.85rem; font-weight: 500;
            transition: all 0.2s ease; margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }

        .main-content { width: 100%; min-height: 100vh; padding: 16px; }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); width: 260px; }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }

        /* Top Bar */
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none; border: none; font-size: 1.3rem;
            cursor: pointer; padding: 8px; color: var(--gray-600);
            border-radius: var(--radius-md);
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 {
            font-size: 1.35rem; font-weight: 800;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex; align-items: center; gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px; text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 600; color: var(--gray-700); }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }

        /* Report Type Selector - Segmented */
        .report-type-buttons {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
            margin-bottom: 20px;
            background: white;
            padding: 6px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .type-btn {
            padding: 9px 16px;
            background: transparent;
            border: none;
            border-radius: var(--radius-md);
            text-decoration: none;
            color: var(--gray-600);
            font-size: 0.78rem;
            font-weight: 600;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }
        .type-btn:hover { background: var(--gray-100); color: var(--primary); }
        .type-btn.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .type-btn.active i { color: var(--accent); }

        /* Filter Bar */
        .report-header {
            background: white;
            border-radius: var(--radius-xl);
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .filter-bar {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        .filter-group {
            flex: 1;
            min-width: 150px;
        }
        .filter-group label {
            font-size: 0.7rem;
            font-weight: 700;
            margin-bottom: 6px;
            display: block;
            color: var(--gray-600);
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .filter-group input, .filter-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.82rem;
            font-family: inherit;
            transition: all 0.2s;
            background: white;
        }
        .filter-group input:focus, .filter-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white; border: none;
            padding: 10px 22px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 700;
            font-size: 0.8rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-secondary {
            background: white;
            color: var(--gray-700);
            border: 1.5px solid var(--gray-200);
            padding: 10px 22px;
            border-radius: var(--radius-md);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-weight: 600;
            font-size: 0.8rem;
            transition: all 0.2s;
        }
        .btn-secondary:hover { background: var(--gray-50); border-color: var(--primary); color: var(--primary); }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: var(--radius-xl);
            text-align: center;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            opacity: 0;
            transition: opacity 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }
        .stat-card:hover::before { opacity: 1; }
        .stat-card i { font-size: 1.6rem; margin-bottom: 10px; display: inline-block; }
        .stat-number { font-size: 1.8rem; font-weight: 800; color: var(--primary); letter-spacing: -0.03em; }
        .stat-label { font-size: 0.7rem; color: var(--gray-500); font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 6px; }
        .stat-card.danger .stat-number { color: #DC2626; }
        .stat-card.success .stat-number { color: #059669; }
        .stat-card.warning .stat-number { color: #B45309; }
        .stat-card.info .stat-number { color: #1E4A8C; }

        /* Chart containers - Tableau-style */
        .chart-container {
            background: white;
            border-radius: var(--radius-xl);
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.3s;
        }
        .chart-container:hover { box-shadow: var(--shadow-lg); border-color: var(--primary-light); }
        .chart-container h4 {
            margin-bottom: 16px;
            font-size: 0.92rem;
            color: var(--gray-800);
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--gray-100);
        }
        .chart-container h4 i { color: var(--primary); }
        .chart-wrapper { position: relative; height: 300px; }

        /* Table */
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
            box-shadow: var(--shadow-sm);
            margin-bottom: 24px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 600px;
        }
        .table th {
            padding: 14px 16px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            border-bottom: 2px solid var(--accent);
            text-align: left;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .table td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .table tbody tr { transition: background 0.15s; }
        .table tbody tr:hover { background: var(--gray-50); }
        .table tbody tr:last-child td { border-bottom: none; }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .status-badge.pending { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .status-badge.approved { background: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7; }
        .status-badge.rejected { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        .status-badge.poor { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        .status-badge.middle { background: #DBEAFE; color: #1E40AF; border: 1px solid #93C5FD; }
        .status-badge.rich { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: var(--gray-500);
        }
        .empty-state i { font-size: 3rem; opacity: 0.3; margin-bottom: 12px; display: block; }

        /* Burn-rate card */
        .burn-rate-card {
            background: linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%);
            border-radius: var(--radius-xl);
            padding: 24px;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-md);
            position: relative;
            overflow: hidden;
        }
        .burn-rate-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent), var(--secondary));
        }
        .burn-rate-card .br-title {
            font-size: 0.78rem;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .burn-rate-card .br-title i { color: var(--primary); }
        .burn-rate-card .br-value {
            font-size: 2rem;
            font-weight: 800;
            margin-top: 6px;
            letter-spacing: -0.03em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .burn-rate-card .br-value.danger { background: linear-gradient(135deg, #DC2626, #EF4444); -webkit-background-clip: text; background-clip: text; }
        .burn-rate-card .br-value.success { background: linear-gradient(135deg, #047857, #10B981); -webkit-background-clip: text; background-clip: text; }
        .burn-rate-card .br-value.warning { background: linear-gradient(135deg, #D99524, #F5B042); -webkit-background-clip: text; background-clip: text; }
        .burn-rate-card .br-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 16px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px dashed var(--gray-200);
        }
        .burn-rate-card .br-grid > div {
            background: white;
            padding: 12px 14px;
            border-radius: var(--radius-md);
            border: 1px solid var(--gray-200);
        }
        .burn-rate-card .br-grid .br-label { font-size: 0.62rem; color: var(--gray-500); text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; }
        .burn-rate-card .br-grid .br-num { font-size: 1rem; font-weight: 800; margin-top: 4px; color: var(--gray-800); }

        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 24px;
        }
        @media (max-width: 768px) { .grid-2 { grid-template-columns: 1fr; } }

        .staff-role-badge {
            display: inline-block;
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.62rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .staff-role-badge.admin { background: #DBEAFE; color: #1E40AF; border: 1px solid #93C5FD; }
        .staff-role-badge.staff { background: #D1FAE5; color: #065F46; border: 1px solid #6EE7B7; }
        .staff-role-badge.socialworker { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }
        .staff-role-badge.encoder { background: #EDE9FE; color: #5B21B6; border: 1px solid #C4B5FD; }

        .status-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 6px;
        }
        .status-dot.active { background: #059669; box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.2); }
        .status-dot.inactive { background: #DC2626; box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.2); }

        /* Bottom Nav */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex; justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex; flex-direction: column; align-items: center;
            font-size: 0.68rem; color: var(--gray-600); text-decoration: none;
            position: relative; font-weight: 600; padding: 6px 8px;
            border-radius: var(--radius-md); transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        .nav-badge {
            position: absolute; top: -4px; right: -4px;
            background: var(--secondary); color: white;
            border-radius: 50%; padding: 2px 6px;
            font-size: 0.6rem; font-weight: 700;
        }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        @media (max-width: 768px) {
            .stats-cards { grid-template-columns: repeat(2, 1fr); }
            .filter-bar { flex-direction: column; }
            .burn-rate-card .br-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 480px) {
            .stats-cards { grid-template-columns: 1fr; }
            .burn-rate-card .br-grid { grid-template-columns: 1fr; }
            .type-btn { font-size: 0.72rem; padding: 7px 12px; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Administrator</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="manage_users.php" class="nav-item"><i class="fas fa-users-cog"></i> User Management</a>
                <a href="admin_household.php" class="nav-item"><i class="fas fa-home"></i> All Households</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i> Poverty Analysis</a>
                <a href="admin_reports.php" class="nav-item active"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="../admin/recycle_bin.php" class="nav-item"><i class="fas fa-trash-restore"></i> Recycle Bin</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>System Reports</h1>
                    <p>Comprehensive analytics and data export · 3-Class System</p>
                </div>
            </div>
            <a href="admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Report Type Selector -->
        <div class="report-type-buttons">
            <a href="<?php echo buildReportUrl('overview'); ?>" class="type-btn <?php echo $report_type == 'overview' ? 'active' : ''; ?>"><i class="fas fa-chart-simple"></i> Overview</a>
            <a href="<?php echo buildReportUrl('barangay'); ?>" class="type-btn <?php echo $report_type == 'barangay' ? 'active' : ''; ?>"><i class="fas fa-map-marker-alt"></i> Barangay</a>
            <a href="<?php echo buildReportUrl('poverty'); ?>" class="type-btn <?php echo $report_type == 'poverty' ? 'active' : ''; ?>"><i class="fas fa-chart-line"></i> Poverty</a>
            <a href="<?php echo buildReportUrl('poverty_matrix'); ?>" class="type-btn <?php echo $report_type == 'poverty_matrix' ? 'active' : ''; ?>"><i class="fas fa-table"></i> Poverty Matrix</a>
            <a href="<?php echo buildReportUrl('staff_performance'); ?>" class="type-btn <?php echo $report_type == 'staff_performance' ? 'active' : ''; ?>"><i class="fas fa-users"></i> Staff</a>
            <a href="<?php echo buildReportUrl('financial'); ?>" class="type-btn <?php echo $report_type == 'financial' ? 'active' : ''; ?>"><i class="fas fa-coins"></i> Financial</a>
            <a href="<?php echo buildReportUrl('applications'); ?>" class="type-btn <?php echo $report_type == 'applications' ? 'active' : ''; ?>"><i class="fas fa-file-alt"></i> Applications</a>
            <a href="<?php echo buildReportUrl('users'); ?>" class="type-btn <?php echo $report_type == 'users' ? 'active' : ''; ?>"><i class="fas fa-users"></i> User Growth</a>
        </div>

        <!-- Filter Bar -->
        <div class="report-header">
            <form method="GET" class="filter-bar">
                <input type="hidden" name="type" value="<?php echo $report_type; ?>">
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" value="<?php echo $date_from; ?>">
                </div>
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" value="<?php echo $date_to; ?>">
                </div>
                <?php if($report_type == 'barangay' || $report_type == 'poverty_matrix'): ?>
                <div class="filter-group">
                    <label>Barangay</label>
                    <select name="barangay">
                        <option value="">All Barangays</option>
                        <?php foreach($barangays as $b): ?>
                            <option value="<?php echo htmlspecialchars($b['barangay']); ?>" <?php echo $barangay_filter == $b['barangay'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($b['barangay']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="filter-group" style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <button type="submit" class="btn-primary"><i class="fas fa-filter"></i> Apply Filter</button>
                    <a href="?type=<?php echo $report_type; ?>&export=csv&date_from=<?php echo $date_from; ?>&date_to=<?php echo $date_to; ?>&barangay=<?php echo urlencode($barangay_filter); ?>" class="btn-secondary"><i class="fas fa-download"></i> Export CSV</a>
                </div>
            </form>
        </div>

        <!-- ==================================================
        REPORT: OVERVIEW
        ================================================== -->
        <?php if($report_type == 'overview'): ?>
        <div class="stats-cards">
            <div class="stat-card">
                <i class="fas fa-users" style="color: var(--primary);"></i>
                <div class="stat-number"><?php echo $total_users; ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-home" style="color: #2E7D32;"></i>
                <div class="stat-number"><?php echo $total_households; ?></div>
                <div class="stat-label">Households</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-file-alt" style="color: var(--accent);"></i>
                <div class="stat-number"><?php echo $total_applications; ?></div>
                <div class="stat-label">Applications</div>
            </div>
            <div class="stat-card success">
                <i class="fas fa-check-circle" style="color: var(--success);"></i>
                <div class="stat-number"><?php echo $approved_apps; ?></div>
                <div class="stat-label">Approved</div>
            </div>
        </div>

        <?php if(!empty($household_growth)): ?>
        <div class="chart-container">
            <h4><i class="fas fa-chart-line"></i> Household Registration Trend</h4>
            <div class="chart-wrapper">
                <canvas id="householdTrendChart"></canvas>
            </div>
        </div>
        <?php endif; ?>

        <?php if(!empty($application_trend)): ?>
        <div class="chart-container">
            <h4><i class="fas fa-chart-line"></i> Application Trend</h4>
            <div class="chart-wrapper">
                <canvas id="appTrendChart"></canvas>
            </div>
        </div>
        <?php endif; ?>

        <?php if(!empty($apps_by_program)): ?>
        <div class="chart-container">
            <h4><i class="fas fa-chart-pie"></i> Applications by Program</h4>
            <div class="chart-wrapper">
                <canvas id="programPieChart"></canvas>
            </div>
        </div>
        <?php endif; ?>

        <div class="grid-2">
            <div>
                <h4 style="margin-bottom:12px; font-size:0.95rem; color:var(--gray-800);">
                    <i class="fas fa-home" style="color:var(--primary);"></i> Recent Households
                </h4>
                <div class="table-container">
                    <table class="table">
                        <thead><tr><th>Head</th><th>Barangay</th><th>Date</th></tr></thead>
                        <tbody>
                            <?php if(!empty($recent_households)): foreach($recent_households as $h): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars(($h['head_first_name'] ?? '') . ' ' . ($h['head_last_name'] ?? '')); ?></strong></td>
                                <td><?php echo htmlspecialchars($h['barangay'] ?? 'N/A'); ?></td>
                                <td><?php echo date('M d, Y', strtotime($h['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="3" class="empty-state">No recent households</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div>
                <h4 style="margin-bottom:12px; font-size:0.95rem; color:var(--gray-800);">
                    <i class="fas fa-file-alt" style="color:var(--primary);"></i> Recent Applications
                </h4>
                <div class="table-container">
                    <table class="table">
                        <thead><tr><th>Applicant</th><th>Program</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php if(!empty($recent_applications)): foreach($recent_applications as $a): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($a['applicant_name'] ?? 'N/A'); ?></td>
                                <td><?php echo $program_names[$a['program_type']] ?? ucfirst($a['program_type'] ?? 'N/A'); ?></td>
                                <td><span class="status-badge <?php echo $a['status'] ?? 'pending'; ?>"><?php echo ucfirst($a['status'] ?? 'Pending'); ?></span></td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="3" class="empty-state">No recent applications</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script>
        // ============================================================
        // OVERVIEW CHARTS - TABLEAU STYLE
        // ============================================================
        // Household Trend
        (function() {
            const ctx = document.getElementById('householdTrendChart')?.getContext('2d');
            if(!ctx) return;
            const gradient = ctx.createLinearGradient(0, 0, 0, 300);
            gradient.addColorStop(0, 'rgba(30, 74, 140, 0.3)');
            gradient.addColorStop(1, 'rgba(30, 74, 140, 0.02)');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_column($household_growth, 'month')); ?>,
                    datasets: [{
                        label: 'New Households',
                        data: <?php echo json_encode(array_column($household_growth, 'count')); ?>,
                        borderColor: '#1E4A8C',
                        backgroundColor: gradient,
                        tension: 0.4,
                        fill: true,
                        borderWidth: 3,
                        pointBackgroundColor: '#FFFFFF',
                        pointBorderColor: '#1E4A8C',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 8
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 11 } } }
                    },
                    plugins: { legend: { display: false } },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        })();

        // Application Trend
        (function() {
            const ctx = document.getElementById('appTrendChart')?.getContext('2d');
            if(!ctx) return;
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(array_column($application_trend, 'month')); ?>,
                    datasets: [
                        { label: 'Pending', data: <?php echo json_encode(array_column($application_trend, 'pending')); ?>, borderColor: '#F5B042', backgroundColor: 'rgba(245,176,66,0.1)', tension: 0.4, borderWidth: 3, fill: false, pointRadius: 4, pointHoverRadius: 7 },
                        { label: 'Approved', data: <?php echo json_encode(array_column($application_trend, 'approved')); ?>, borderColor: '#059669', backgroundColor: 'rgba(5,150,105,0.1)', tension: 0.4, borderWidth: 3, fill: false, pointRadius: 4, pointHoverRadius: 7 },
                        { label: 'Rejected', data: <?php echo json_encode(array_column($application_trend, 'rejected')); ?>, borderColor: '#DC2626', backgroundColor: 'rgba(220,38,38,0.1)', tension: 0.4, borderWidth: 3, fill: false, pointRadius: 4, pointHoverRadius: 7 }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 11 } } }
                    },
                    plugins: { legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } } },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        })();

        // Program Pie
        (function() {
            const ctx = document.getElementById('programPieChart')?.getContext('2d');
            if(!ctx) return;
            const labels = <?php echo json_encode(array_map(function($p) use ($program_names) { return $program_names[$p['program_type']] ?? ucfirst($p['program_type']); }, $apps_by_program)); ?>;
            const counts = <?php echo json_encode(array_column($apps_by_program, 'count')); ?>;
            if (labels.length === 0) { labels.push('No Data'); counts.push(1); }
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: counts,
                        backgroundColor: ['#F5B042', '#10B981', '#1E4A8C', '#DC2626', '#8B5CF6', '#F97316', '#06B6D4', '#EC4899'],
                        borderWidth: 3,
                        borderColor: '#FFFFFF',
                        hoverOffset: 12
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    cutout: '62%',
                    plugins: {
                        legend: { position: 'bottom', labels: { padding: 12, font: { size: 11, weight: '600' } } },
                        tooltip: { callbacks: { label: function(c) { const t = c.dataset.data.reduce((a,b)=>a+b,0); return ` ${c.label}: ${c.parsed} (${t>0?((c.parsed/t)*100).toFixed(1):0}%)`; } } }
                    },
                    animation: { animateRotate: true, animateScale: true, duration: 1200, easing: 'easeOutQuart' }
                }
            });
        })();
        </script>

        <!-- ==================================================
        REPORT: POVERTY MATRIX
        ================================================== -->
        <?php elseif($report_type == 'poverty_matrix'): ?>
        <div class="stats-cards">
            <div class="stat-card">
                <i class="fas fa-map-marker-alt" style="color: var(--primary);"></i>
                <div class="stat-number"><?php echo count($poverty_matrix); ?></div>
                <div class="stat-label">Barangays</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-home" style="color: #2E7D32;"></i>
                <div class="stat-number"><?php echo array_sum(array_column($poverty_matrix, 'grand_total_households')); ?></div>
                <div class="stat-label">Total Households</div>
            </div>
            <div class="stat-card danger">
                <i class="fas fa-exclamation-triangle" style="color: #DC2626;"></i>
                <div class="stat-number"><?php echo array_sum(array_column($poverty_matrix, 'total_poor')); ?></div>
                <div class="stat-label">Poor (₱5k-₱10k)</div>
            </div>
            <div class="stat-card info">
                <i class="fas fa-chart-line" style="color: #1E4A8C;"></i>
                <div class="stat-number"><?php echo array_sum(array_column($poverty_matrix, 'total_middle_class')); ?></div>
                <div class="stat-label">Middle-Class</div>
            </div>
        </div>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Barangay</th>
                        <th>Poor<br><small style="font-weight:400; color:var(--gray-400);">₱5k – ₱10k</small></th>
                        <th>Middle-Class<br><small style="font-weight:400; color:var(--gray-400);">₱10k – ₱25k</small></th>
                        <th>Rich<br><small style="font-weight:400; color:var(--gray-400);">₱25k+</small></th>
                        <th>Total</th>
                        <th>Poverty Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($poverty_matrix)): foreach($poverty_matrix as $row): 
                        $total = $row['grand_total_households'] ?? 1;
                        $poor = $row['total_poor'] ?? 0;
                        $poverty_rate = ($total > 0) ? round(($poor / $total) * 100, 1) : 0;
                        $rate_color = $poverty_rate > 60 ? '#DC2626' : ($poverty_rate > 30 ? '#1E4A8C' : '#B45309');
                    ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($row['barangay']); ?></strong></td>
                        <td><span class="status-badge poor"><?php echo $poor; ?></span></td>
                        <td><span class="status-badge middle"><?php echo $row['total_middle_class'] ?? 0; ?></span></td>
                        <td><span class="status-badge rich"><?php echo $row['total_rich'] ?? 0; ?></span></td>
                        <td><strong><?php echo $total; ?></strong></td>
                        <td><span style="font-weight:800; color:<?php echo $rate_color; ?>;"><?php echo $poverty_rate; ?>%</span></td>
                    </tr>
                    <?php endforeach; else: ?>
                    <tr><td colspan="6" class="empty-state"><i class="fas fa-folder-open"></i> No data available for this period</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="chart-container">
            <h4><i class="fas fa-chart-bar"></i> Poverty Distribution by Barangay (3-Class)</h4>
            <div class="chart-wrapper" style="height:350px;">
                <canvas id="povertyMatrixChart"></canvas>
            </div>
        </div>
        <script>
        (function() {
            const ctx = document.getElementById('povertyMatrixChart')?.getContext('2d');
            if(!ctx) return;
            const labels = <?php echo json_encode(array_column($poverty_matrix, 'barangay')); ?>;
            const poorData = <?php echo json_encode(array_column($poverty_matrix, 'total_poor')); ?>;
            const middleData = <?php echo json_encode(array_column($poverty_matrix, 'total_middle_class')); ?>;
            const richData = <?php echo json_encode(array_column($poverty_matrix, 'total_rich')); ?>;
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels.length > 0 ? labels : ['No Data'],
                    datasets: [
                        { label: 'Poor', data: poorData.length > 0 ? poorData : [0], backgroundColor: 'rgba(220, 38, 38, 0.85)', borderColor: '#DC2626', borderWidth: 2, borderRadius: 6, borderSkipped: false },
                        { label: 'Middle-Class', data: middleData.length > 0 ? middleData : [0], backgroundColor: 'rgba(30, 74, 140, 0.85)', borderColor: '#1E4A8C', borderWidth: 2, borderRadius: 6, borderSkipped: false },
                        { label: 'Rich', data: richData.length > 0 ? richData : [0], backgroundColor: 'rgba(245, 176, 66, 0.85)', borderColor: '#F5B042', borderWidth: 2, borderRadius: 6, borderSkipped: false }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    scales: {
                        x: { stacked: true, grid: { display: false }, ticks: { font: { size: 10 } } },
                        y: { stacked: true, beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } }
                    },
                    plugins: { legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } } },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        })();
        </script>

        <!-- ==================================================
        REPORT: STAFF PERFORMANCE
        ================================================== -->
        <?php elseif($report_type == 'staff_performance'): ?>
        <div class="stats-cards">
            <div class="stat-card">
                <i class="fas fa-users" style="color: var(--primary);"></i>
                <div class="stat-number"><?php echo count($staff_performance); ?></div>
                <div class="stat-label">Total Staff</div>
            </div>
            <div class="stat-card success">
                <i class="fas fa-check-circle" style="color: #059669;"></i>
                <div class="stat-number"><?php echo array_sum(array_column($staff_performance, 'total_approvals')); ?></div>
                <div class="stat-label">Total Approvals</div>
            </div>
            <div class="stat-card danger">
                <i class="fas fa-times-circle" style="color: #DC2626;"></i>
                <div class="stat-number"><?php echo array_sum(array_column($staff_performance, 'total_rejections')); ?></div>
                <div class="stat-label">Total Rejections</div>
            </div>
            <div class="stat-card info">
                <i class="fas fa-clipboard-check" style="color: #1E4A8C;"></i>
                <div class="stat-number"><?php echo array_sum(array_column($staff_performance, 'total_actions_processed')); ?></div>
                <div class="stat-label">Total Actions</div>
            </div>
        </div>
        <?php if(!empty($staff_performance)): ?>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Staff Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Approvals</th>
                        <th>Rejections</th>
                        <th>Total Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($staff_performance as $row): 
                        $role_class = str_replace('_', '', $row['staff_role'] ?? 'staff');
                    ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($row['staff_full_name'] ?? 'Unknown'); ?></strong></td>
                        <td><span class="staff-role-badge <?php echo $role_class; ?>"><?php echo ucfirst(str_replace('_', ' ', $row['staff_role'] ?? 'Staff')); ?></span></td>
                        <td><span class="status-dot <?php echo ($row['staff_status'] ?? 'active') == 'active' ? 'active' : 'inactive'; ?>"></span><?php echo ucfirst($row['staff_status'] ?? 'Active'); ?></td>
                        <td><span class="status-badge approved"><?php echo $row['total_approvals'] ?? 0; ?></span></td>
                        <td><span class="status-badge rejected"><?php echo $row['total_rejections'] ?? 0; ?></span></td>
                        <td><strong><?php echo $row['total_actions_processed'] ?? 0; ?></strong></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="empty-state"><i class="fas fa-users"></i><p>No staff members found.</p></div>
        <?php endif; ?>

        <!-- ==================================================
        REPORT: FINANCIAL
        ================================================== -->
        <?php elseif($report_type == 'financial'): ?>
        <div class="burn-rate-card">
            <div class="br-title"><i class="fas fa-coins"></i> <?php echo $financial_metrics['fund_name']; ?></div>
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:20px; margin-top:14px;">
                <div>
                    <div style="font-size:0.75rem; color:var(--gray-500); font-weight:600;">Remaining Budget</div>
                    <div class="br-value <?php echo $financial_metrics['current_remaining_balance'] > 1000000 ? 'success' : ($financial_metrics['current_remaining_balance'] > 500000 ? 'warning' : 'danger'); ?>">
                        ₱ <?php echo number_format($financial_metrics['current_remaining_balance'], 2); ?>
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:0.75rem; color:var(--gray-500); font-weight:600;">Est. Days Until Depletion</div>
                    <div class="br-value <?php echo $financial_metrics['estimated_days_until_depletion'] > 30 ? 'success' : ($financial_metrics['estimated_days_until_depletion'] > 15 ? 'warning' : 'danger'); ?>">
                        <?php echo $financial_metrics['estimated_days_until_depletion']; ?> days
                    </div>
                </div>
            </div>
            <div class="br-grid">
                <div>
                    <div class="br-label">Initial Allocation</div>
                    <div class="br-num">₱ <?php echo number_format($financial_metrics['initial_allocation'], 2); ?></div>
                </div>
                <div>
                    <div class="br-label">Total Disbursed</div>
                    <div class="br-num" style="color:#B45309;">₱ <?php echo number_format($financial_metrics['total_disbursed_to_date'], 2); ?></div>
                </div>
                <div>
                    <div class="br-label">Avg Daily Disbursement</div>
                    <div class="br-num">₱ <?php echo number_format($financial_metrics['average_daily_disbursement'], 2); ?></div>
                </div>
                <div>
                    <div class="br-label">Total Transactions</div>
                    <div class="br-num"><?php echo $financial_metrics['total_transactions']; ?></div>
                </div>
            </div>
        </div>
        <div class="chart-container">
            <h4><i class="fas fa-chart-pie"></i> Budget Utilization</h4>
            <div class="chart-wrapper">
                <canvas id="budgetChart"></canvas>
            </div>
        </div>
        <script>
        (function() {
            const ctx = document.getElementById('budgetChart')?.getContext('2d');
            if(!ctx) return;
            const remaining = <?php echo floatval($financial_metrics['current_remaining_balance']); ?>;
            const disbursed = <?php echo floatval($financial_metrics['total_disbursed_to_date']); ?>;
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Remaining Budget', 'Disbursed'],
                    datasets: [{
                        data: [remaining, disbursed],
                        backgroundColor: ['rgba(5, 150, 105, 0.85)', 'rgba(30, 74, 140, 0.85)'],
                        borderColor: ['#059669', '#1E4A8C'],
                        borderWidth: 3,
                        hoverOffset: 12
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false, cutout: '62%',
                    plugins: {
                        legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } },
                        tooltip: { callbacks: { label: function(c) { const t = c.dataset.data.reduce((a,b)=>a+b,0); return ` ${c.label}: ₱${Number(c.parsed).toLocaleString()} (${t>0?((c.parsed/t)*100).toFixed(1):0}%)`; } } }
                    },
                    animation: { animateRotate: true, animateScale: true, duration: 1200, easing: 'easeOutQuart' }
                }
            });
        })();
        </script>

        <!-- ==================================================
        REPORT: BARANGAY
        ================================================== -->
        <?php elseif($report_type == 'barangay'): ?>
        <div class="stats-cards">
            <div class="stat-card"><i class="fas fa-map-marker-alt" style="color: var(--primary);"></i><div class="stat-number"><?php echo count($barangay_data); ?></div><div class="stat-label">Barangays</div></div>
            <div class="stat-card"><i class="fas fa-home" style="color: #2E7D32;"></i><div class="stat-number"><?php echo array_sum(array_column($barangay_data, 'households')); ?></div><div class="stat-label">Total Households</div></div>
            <div class="stat-card"><i class="fas fa-users" style="color: var(--accent);"></i><div class="stat-number"><?php echo array_sum(array_column($barangay_data, 'total_members')); ?></div><div class="stat-label">Total Residents</div></div>
            <div class="stat-card success"><i class="fas fa-hand-holding-usd" style="color: #059669;"></i><div class="stat-number"><?php echo array_sum(array_column($barangay_data, 'total_4ps')); ?></div><div class="stat-label">4Ps Beneficiaries</div></div>
        </div>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Barangay</th>
                        <th>Households</th>
                        <th>Members</th>
                        <th>4Ps</th>
                        <th>Avg Income</th>
                        <th>Poor</th>
                        <th>Middle-Class</th>
                        <th>Rich</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($barangay_data)): foreach($barangay_data as $b): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($b['barangay']); ?></strong></td>
                        <td><?php echo $b['households']; ?></td>
                        <td><?php echo $b['total_members']; ?></td>
                        <td><?php echo $b['total_4ps']; ?></td>
                        <td>₱ <?php echo number_format($b['avg_income'] ?? 0, 2); ?></td>
                        <td><span class="status-badge poor"><?php echo $b['poor_count'] ?? 0; ?></span></td>
                        <td><span class="status-badge middle"><?php echo $b['middle_class_count'] ?? 0; ?></span></td>
                        <td><span class="status-badge rich"><?php echo $b['rich_count'] ?? 0; ?></span></td>
                    </tr>
                    <?php endforeach; else: ?>
                    <tr><td colspan="8" class="empty-state"><i class="fas fa-folder-open"></i> No barangay data available</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- ==================================================
        REPORT: POVERTY
        ================================================== -->
        <?php elseif($report_type == 'poverty'): ?>
        <div class="stats-cards">
            <div class="stat-card danger"><i class="fas fa-exclamation-triangle" style="color: #DC2626;"></i><div class="stat-number"><?php echo $poverty_stats['poor'] ?? 0; ?></div><div class="stat-label">Poor (₱5k–₱10k)</div></div>
            <div class="stat-card info"><i class="fas fa-chart-line" style="color: #1E4A8C;"></i><div class="stat-number" style="color:#1E4A8C;"><?php echo $poverty_stats['middle_class'] ?? 0; ?></div><div class="stat-label">Middle-Class (₱10k–₱25k)</div></div>
            <div class="stat-card warning"><i class="fas fa-crown" style="color: #B45309;"></i><div class="stat-number" style="color:#B45309;"><?php echo $poverty_stats['rich'] ?? 0; ?></div><div class="stat-label">Rich (₱25k+)</div></div>
            <div class="stat-card"><i class="fas fa-home" style="color: var(--primary);"></i><div class="stat-number"><?php echo $poverty_stats['total'] ?? 0; ?></div><div class="stat-label">Total Households</div></div>
        </div>
        <div class="chart-container">
            <h4><i class="fas fa-chart-bar"></i> Poverty Distribution (3-Class)</h4>
            <div class="chart-wrapper" style="height:350px;">
                <canvas id="povertyChart"></canvas>
            </div>
        </div>
        <script>
        (function() {
            const ctx = document.getElementById('povertyChart')?.getContext('2d');
            if(!ctx) return;
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Poor (₱5k-₱10k)', 'Middle-Class (₱10k-₱25k)', 'Rich (₱25k+)'],
                    datasets: [{
                        label: 'Households',
                        data: [<?php echo $poverty_stats['poor'] ?? 0; ?>, <?php echo $poverty_stats['middle_class'] ?? 0; ?>, <?php echo $poverty_stats['rich'] ?? 0; ?>],
                        backgroundColor: ['rgba(220, 38, 38, 0.85)', 'rgba(30, 74, 140, 0.85)', 'rgba(245, 176, 66, 0.85)'],
                        borderColor: ['#DC2626', '#1E4A8C', '#F5B042'],
                        borderWidth: 2,
                        borderRadius: 8,
                        borderSkipped: false,
                        barPercentage: 0.6
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 11, weight: '600' } } }
                    },
                    plugins: { legend: { display: false } },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        })();
        </script>

        <!-- ==================================================
        REPORT: APPLICATIONS
        ================================================== -->
        <?php elseif($report_type == 'applications'): ?>
        <div class="stats-cards">
            <div class="stat-card"><i class="fas fa-file-alt" style="color: var(--primary);"></i><div class="stat-number"><?php echo array_sum(array_column($apps_by_program, 'count')); ?></div><div class="stat-label">Total Applications</div></div>
            <?php foreach($apps_by_program as $prog): ?>
            <div class="stat-card"><i class="fas fa-folder" style="color: var(--accent);"></i><div class="stat-number"><?php echo $prog['count']; ?></div><div class="stat-label"><?php echo $program_names[$prog['program_type']] ?? ucfirst($prog['program_type']); ?></div></div>
            <?php endforeach; ?>
        </div>
        <div class="table-container">
            <table class="table">
                <thead><tr><th>Program</th><th>Number of Applications</th></tr></thead>
                <tbody>
                    <?php if(!empty($apps_by_program)): foreach($apps_by_program as $prog): ?>
                    <tr>
                        <td><strong><?php echo $program_names[$prog['program_type']] ?? ucfirst($prog['program_type']); ?></strong></td>
                        <td><span class="status-badge approved"><?php echo $prog['count']; ?></span></td>
                    </tr>
                    <?php endforeach; else: ?>
                    <tr><td colspan="2" class="empty-state">No applications found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="chart-container">
            <h4><i class="fas fa-chart-pie"></i> Applications by Program</h4>
            <div class="chart-wrapper">
                <canvas id="appsPieChart"></canvas>
            </div>
        </div>
        <script>
        (function() {
            const ctx = document.getElementById('appsPieChart')?.getContext('2d');
            if(!ctx) return;
            const labels = <?php echo json_encode(array_map(function($p) use ($program_names) { return $program_names[$p['program_type']] ?? ucfirst($p['program_type']); }, $apps_by_program)); ?>;
            const counts = <?php echo json_encode(array_column($apps_by_program, 'count')); ?>;
            if (labels.length === 0) { labels.push('No Data'); counts.push(1); }
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: counts,
                        backgroundColor: ['#F5B042', '#10B981', '#1E4A8C', '#DC2626', '#8B5CF6', '#F97316', '#06B6D4', '#EC4899'],
                        borderWidth: 3,
                        borderColor: '#FFFFFF',
                        hoverOffset: 12
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false, cutout: '62%',
                    plugins: {
                        legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } },
                        tooltip: { callbacks: { label: function(c) { const t = c.dataset.data.reduce((a,b)=>a+b,0); return ` ${c.label}: ${c.parsed} (${t>0?((c.parsed/t)*100).toFixed(1):0}%)`; } } }
                    },
                    animation: { animateRotate: true, animateScale: true, duration: 1200, easing: 'easeOutQuart' }
                }
            });
        })();
        </script>

        <!-- ==================================================
        REPORT: USER GROWTH
        ================================================== -->
        <?php elseif($report_type == 'users'): ?>
        <div class="stats-cards">
            <div class="stat-card"><i class="fas fa-users" style="color: var(--primary);"></i><div class="stat-number"><?php echo $total_users; ?></div><div class="stat-label">Total Users</div></div>
            <div class="stat-card"><i class="fas fa-user" style="color: #2E7D32;"></i><div class="stat-number"><?php echo $total_residents; ?></div><div class="stat-label">Residents</div></div>
            <div class="stat-card"><i class="fas fa-user-tie" style="color: var(--accent);"></i><div class="stat-number"><?php echo $total_staff; ?></div><div class="stat-label">Staff</div></div>
            <div class="stat-card info"><i class="fas fa-calendar" style="color: #1E4A8C;"></i><div class="stat-number"><?php echo count($user_growth); ?></div><div class="stat-label">Months Active</div></div>
        </div>
        <div class="chart-container">
            <h4><i class="fas fa-chart-line"></i> User Registration Growth</h4>
            <div class="chart-wrapper" style="height:350px;">
                <canvas id="userGrowthChart"></canvas>
            </div>
        </div>
        <script>
        (function() {
            const ctx = document.getElementById('userGrowthChart')?.getContext('2d');
            if(!ctx) return;
            const labels = <?php echo json_encode(array_column($user_growth, 'month')); ?>;
            if (labels.length === 0) return;
            const grad1 = ctx.createLinearGradient(0, 0, 0, 300);
            grad1.addColorStop(0, 'rgba(30, 74, 140, 0.3)');
            grad1.addColorStop(1, 'rgba(30, 74, 140, 0.02)');
            const grad2 = ctx.createLinearGradient(0, 0, 0, 300);
            grad2.addColorStop(0, 'rgba(245, 176, 66, 0.3)');
            grad2.addColorStop(1, 'rgba(245, 176, 66, 0.02)');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        { label: 'Residents', data: <?php echo json_encode(array_column($user_growth, 'residents')); ?>, borderColor: '#1E4A8C', backgroundColor: grad1, tension: 0.4, fill: true, borderWidth: 3, pointRadius: 4, pointHoverRadius: 7 },
                        { label: 'Staff', data: <?php echo json_encode(array_column($user_growth, 'staff')); ?>, borderColor: '#F5B042', backgroundColor: grad2, tension: 0.4, fill: true, borderWidth: 3, pointRadius: 4, pointHoverRadius: 7 }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 11 } } }
                    },
                    plugins: { legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } } },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        })();
        </script>
        <?php endif; ?>

        <div style="text-align:center; padding:20px 0; margin-top:20px; font-size:0.7rem; color:var(--gray-400); border-top:1px solid var(--gray-200);">
            <i class="fas fa-database"></i> MSWDO Analytics v2.0 &bull; <?php echo date('F d, Y'); ?> &bull; 3-Class System
        </div>
    </main>

    <!-- Bottom Navigation -->
    <nav class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Dashboard</span></a>
        <a href="manage_users.php" class="nav-item"><i class="fas fa-users-cog"></i><span>Users</span></a>
        <a href="admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="admin_reports.php" class="nav-item active"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </nav>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };

        // Chart.js global Tableau-style defaults
        Chart.defaults.font.family = "'Inter', sans-serif";
        Chart.defaults.font.size = 11;
        Chart.defaults.color = '#475569';
        Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(15, 23, 42, 0.95)';
        Chart.defaults.plugins.tooltip.padding = 12;
        Chart.defaults.plugins.tooltip.cornerRadius = 8;
        Chart.defaults.plugins.tooltip.titleFont = { size: 12, weight: '700' };
        Chart.defaults.plugins.tooltip.bodyFont = { size: 11 };
        Chart.defaults.plugins.legend.labels.boxWidth = 12;
        Chart.defaults.plugins.legend.labels.padding = 14;

        console.log('%c✅ Admin Reports loaded', 'color: #059669; font-weight: bold; font-size: 14px;');
        console.log('%c📊 Report Type: <?php echo $report_type; ?>', 'color: #1E4A8C; font-weight: 600;');
        console.log('%c📈 3-Class System applied', 'color: #F5B042; font-weight: 600;');
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>