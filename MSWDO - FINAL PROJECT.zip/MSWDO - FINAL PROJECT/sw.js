// ============================================================
// MSWDO Cantilan — Service Worker (v3)
// Caches ONLY static assets. NEVER caches PHP pages.
// ============================================================

const CACHE_NAME = 'mswdo-v3';  // bumped to force fresh install

// Only these get pre-cached (static files — same for every user)
const CORE_ASSETS = [
    '/mswdo/assets/img/mswdo_logo.jpg',
    '/mswdo/pwa/manifest.json',
    '/mswdo/pwa/logo.png'
];

// ============================================================
// INSTALL — pre-cache core assets, skip missing ones silently
// ============================================================
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return Promise.all(
                CORE_ASSETS.map((url) =>
                    cache.add(url).catch(() => {
                        // Skip missing files silently
                    })
                )
            );
        }).then(() => self.skipWaiting())
    );
});

// ============================================================
// ACTIVATE — remove old cache versions automatically
// ============================================================
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) =>
            Promise.all(
                keys
                    .filter((key) => key !== CACHE_NAME)
                    .map((key) => caches.delete(key))
            )
        ).then(() => self.clients.claim())
    );
});

// ============================================================
// FETCH — cache-first ONLY for static assets.
// PHP pages, API calls, dashboards, modules → always network.
// ============================================================
self.addEventListener('fetch', (event) => {
    const req = event.request;

    // Only handle GET
    if (req.method !== 'GET') return;

    // Only handle same-origin
    if (!req.url.startsWith(self.location.origin)) return;

    const url = new URL(req.url);

    // ============================================================
    // 🚫 NEVER cache dynamic content. Let the browser handle it.
    // ============================================================
    const isDynamic =
        url.pathname.endsWith('.php') ||
        url.pathname.startsWith('/mswdo/api/') ||
        url.pathname.startsWith('/mswdo/dashboards/') ||
        url.pathname.startsWith('/mswdo/modules/') ||
        url.pathname.startsWith('/mswdo/admin/') ||
        url.searchParams.has('view') ||
        url.searchParams.has('id') ||
        url.searchParams.has('edit') ||
        url.searchParams.has('continue');

    if (isDynamic) {
        // Let the browser fetch directly — no service worker involvement.
        return;
    }

    // ============================================================
    // ✅ Static assets: cache-first, then network, then self-populate
    // ============================================================
    event.respondWith(
        caches.match(req).then((cached) => {
            if (cached) return cached;

            return fetch(req)
                .then((response) => {
                    // Only cache successful STATIC asset responses
                    if (
                        response &&
                        response.status === 200 &&
                        response.type === 'basic' &&
                        !response.redirected &&
                        req.url.match(/\.(png|jpg|jpeg|gif|css|js|svg|ico|woff2?|ttf|eot)$/i)
                    ) {
                        const copy = response.clone();
                        caches.open(CACHE_NAME).then((cache) => {
                            cache.put(req, copy).catch(() => {});
                        });
                    }
                    return response;
                })
                .catch(() => {
                    // Offline + not cached → friendly message
                    return new Response(
                        '<html><body style="font-family:sans-serif;padding:40px;text-align:center;">' +
                        '<h2>You are offline</h2>' +
                        '<p>This page has not been cached yet. Please reconnect and try again.</p>' +
                        '</body></html>',
                        { status: 503, headers: { 'Content-Type': 'text/html' } }
                    );
                });
        })
    );
});