<?php
session_start();
require_once 'config/database.php';

// If already logged in, redirect to appropriate dashboard
if(isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    switch($_SESSION['role']) {
        case 'resident':
            header("Location: dashboards/resident_dashboard.php");
            break;
        case 'staff':
        case 'social_worker':
        case 'encoder':
            header("Location: dashboards/mswdstaff_dashboard.php");
            break;
        case 'admin':
            header("Location: dashboards/admin_dashboard.php");
            break;
        default:
            header("Location: dashboards/resident_dashboard.php");
    }
    exit();
}

$error = '';
$success = '';
$form_data = [];

// Get all roles for dropdown - ONLY RESIDENT AND MSWD STAFF
$roles = ['resident', 'staff'];
$statuses = ['active', 'inactive'];

// Get list of existing users who can create accounts (admin only can create others)
$created_by = null;
if(isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
    $created_by = $_SESSION['user_id'];
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate inputs
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? 'resident';
    $contact_number = trim($_POST['contact_number'] ?? '');
    $position = trim($_POST['position'] ?? '');
    $office_id = trim($_POST['office_id'] ?? '');
    $status = $_POST['status'] ?? 'active';
    
    // Store form data for repopulation
    $form_data = [
        'username' => $username,
        'full_name' => $full_name,
        'email' => $email,
        'role' => $role,
        'contact_number' => $contact_number,
        'position' => $position,
        'office_id' => $office_id
    ];
    
    // Validation
    $errors = [];
    
    // Username validation
    if(empty($username)) {
        $errors[] = "Username is required.";
    } elseif(strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters.";
    } elseif(strlen($username) > 50) {
        $errors[] = "Username must be less than 50 characters.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = "Username can only contain letters, numbers, and underscore.";
    } else {
        // Check if username already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if($stmt->fetch()) {
            $errors[] = "Username already exists. Please choose another.";
        }
    }
    
    // SIMPLIFIED PASSWORD VALIDATION - Only check if not empty and minimum length
    if(empty($password)) {
        $errors[] = "Password is required.";
    } elseif(strlen($password) < 4) {
        $errors[] = "Password must be at least 4 characters.";
    }
    
    // Confirm password
    if($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }
    
    // Full name validation
    if(empty($full_name)) {
        $errors[] = "Full name is required.";
    } elseif(strlen($full_name) < 2) {
        $errors[] = "Please enter a valid full name.";
    }
    
    // Email validation (optional)
    if(!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    
    // Role validation - ONLY 'resident' and 'staff'
    if(!in_array($role, $roles)) {
        $errors[] = "Invalid role selected.";
    }
    
    // If no errors, create the user
    if(empty($errors)) {
        try {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new user
            $stmt = $pdo->prepare("
                INSERT INTO users (username, password, full_name, email, role, contact_number, position, office_id, status, created_by, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $username,
                $hashed_password,
                $full_name,
                $email,
                $role,
                $contact_number,
                $position,
                $office_id,
                $status,
                $created_by
            ]);
            
            $user_id = $pdo->lastInsertId();
            
            // Auto-login after registration with role-based redirection
            if(!isset($_SESSION['user_id'])) {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['full_name'] = $full_name;
                $_SESSION['role'] = $role;
                $_SESSION['username'] = $username;
                
                // Redirect based on role - UPDATED PATHS
                switch($role) {
                    case 'resident':
                        header("Location: dashboards/resident_dashboard.php");
                        break;
                    case 'staff':
                        header("Location: dashboards/mswdstaff_dashboard.php");
                        break;
                    default:
                        header("Location: dashboards/resident_dashboard.php");
                }
                exit();
            } else {
                $success = "User account created successfully!";
                // Clear form data
                $form_data = [];
            }
            
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    $error = implode("<br>", $errors);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Register - MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0A2F6C 0%, #1E4A8C 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 20px;
            position: relative;
        }
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: radial-gradient(circle at 10% 20%, rgba(245,176,66,0.08) 2%, transparent 2.5%),
                              radial-gradient(circle at 85% 70%, rgba(211,47,47,0.05) 1.8%, transparent 2%);
            background-size: 48px 48px, 64px 64px;
            pointer-events: none;
        }
        .page-wrapper {
            width: 100%;
            max-width: 580px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
            animation: fadeSlideUp 0.45s ease-out;
        }
        @keyframes fadeSlideUp {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .card {
            background: #FFFFFF;
            border-radius: 36px;
            box-shadow: 0 25px 45px -12px rgba(0,0,0,0.25), 0 4px 12px rgba(0,0,0,0.05);
            overflow: hidden;
            transition: transform 0.2s ease, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 32px 55px -14px rgba(0,0,0,0.3);
        }
        .card-header {
            padding: 1.8rem 2rem 1rem 2rem;
            text-align: center;
            background: white;
            border-bottom: 1px solid #F0F2F5;
        }
        .logo-icon {
            font-size: 3rem;
            display: inline-block;
            background: linear-gradient(135deg, #F5B042 25%, #D32F2F 45%, #1E4A8C 75%);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            margin-bottom: 12px;
        }
        .card-header h2 {
            font-size: 1.8rem;
            font-weight: 700;
            letter-spacing: -0.3px;
            background: linear-gradient(120deg, #0A2F6C, #1E4A8C);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
        }
        .text-muted {
            font-size: 0.85rem;
            color: #5B6E8C;
            margin-top: 6px;
        }
        .color-stripes {
            display: flex;
            justify-content: center;
            gap: 12px;
            margin: 18px 0 8px;
        }
        .stripe {
            width: 48px;
            height: 4px;
            border-radius: 4px;
        }
        .stripe-blue { background-color: #1E4A8C; }
        .stripe-red { background-color: #D32F2F; }
        .stripe-yellow { background-color: #F5B042; }
        .card-body {
            padding: 1.8rem 2rem 2rem;
        }
        .alert {
            padding: 14px 18px;
            border-radius: 24px;
            margin-bottom: 1.6rem;
            font-size: 0.85rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-danger {
            background: #FEF2F0;
            border-left: 5px solid #D32F2F;
            color: #B91C1C;
        }
        .alert-success {
            background: #E8F5E9;
            border-left: 5px solid #2E7D32;
            color: #1E5A2E;
        }
        .alert-info {
            background: #EFF6FF;
            border-left: 5px solid #1E4A8C;
            color: #1E3A6F;
            font-size: 0.75rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 0.85rem;
            color: #1E2F4E;
            margin-bottom: 8px;
        }
        .form-label i {
            color: #F5B042;
            width: 20px;
        }
        .form-control {
            width: 100%;
            padding: 12px 16px;
            font-size: 0.95rem;
            font-family: 'Inter', sans-serif;
            border: 1.5px solid #E2E8F0;
            border-radius: 28px;
            transition: all 0.2s;
            background-color: #FEFEFE;
            outline: none;
        }
        .form-control:focus {
            border-color: #F5B042;
            box-shadow: 0 0 0 3px rgba(245, 176, 66, 0.2);
        }
        .form-control.success {
            border-color: #2E7D32;
        }
        .form-control.error {
            border-color: #D32F2F;
        }
        .form-text {
            font-size: 0.7rem;
            color: #6C86A3;
            margin-top: 5px;
            padding-left: 12px;
        }
        .text-danger { color: #D32F2F; }
        .text-success { color: #2E7D32; }
        .role-selector {
            display: flex;
            gap: 16px;
            margin-top: 8px;
            flex-wrap: wrap;
        }
        .role-option {
            flex: 1;
            background: white;
            text-align: center;
            padding: 16px 12px;
            border: 2px solid #E2E8F0;
            border-radius: 28px;
            cursor: pointer;
            transition: all 0.2s;
            min-width: 140px;
        }
        .role-option i {
            font-size: 2rem;
            display: block;
            margin-bottom: 8px;
            color: #1E4A8C;
        }
        .role-option span {
            font-weight: 700;
            font-size: 1rem;
            color: #1E2F4E;
            display: block;
        }
        .role-option small {
            font-size: 0.7rem;
            color: #6C86A3;
            display: block;
            margin-top: 4px;
        }
        .role-option.selected {
            border-color: #F5B042;
            background: #FFF9EF;
            box-shadow: 0 4px 12px rgba(245,176,66,0.2);
        }
        .role-option.selected i {
            color: #D32F2F;
        }
        .staff-fields {
            display: block;
            transition: all 0.2s;
        }
        .staff-fields.hidden {
            display: none;
        }
        .password-strength {
            height: 5px;
            background: #E2E8F0;
            border-radius: 6px;
            margin-top: 12px;
            overflow: hidden;
        }
        .strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s;
        }
        .strength-weak { background: #D32F2F; width: 33%; }
        .strength-medium { background: #F5B042; width: 66%; }
        .strength-strong { background: #2E7D32; width: 100%; }
        .btn-primary {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            background: #1E4A8C;
            border: none;
            padding: 14px 20px;
            border-radius: 48px;
            font-weight: 700;
            font-size: 1rem;
            color: white;
            cursor: pointer;
            transition: all 0.25s;
            margin-top: 12px;
        }
        .btn-primary:hover {
            background: #0A2F6C;
            transform: scale(1.01);
            box-shadow: 0 8px 20px rgba(30,74,140,0.3);
        }
        .btn-primary:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        .btn-primary i { font-size: 1rem; }
        .back-link {
            text-align: center;
            margin-top: 24px;
        }
        .back-link a {
            color: #1E4A8C;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.85rem;
        }
        .back-link a i { margin-right: 6px; }
        .back-link a:hover {
            text-decoration: underline;
            color: #D32F2F;
        }
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 0.8s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .sync-status {
            font-size: 0.7rem;
            color: #6C86A3;
            margin-top: 16px;
            text-align: center;
        }
        .offline-badge {
            display: inline-block;
            background: #FEF3C7;
            color: #B45309;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.6rem;
            font-weight: 600;
            margin-left: 6px;
        }
        @media (max-width: 500px) {
            .card-body { padding: 1.5rem; }
            .card-header { padding: 1.5rem 1.5rem 0.8rem; }
            .role-option { padding: 12px 8px; min-width: 120px; }
            .role-option i { font-size: 1.5rem; }
            .role-option span { font-size: 0.85rem; }
        }
    </style>
</head>
<body>
<div class="page-wrapper">
    <div class="card">
        <div class="card-header">
            <div class="logo-icon">
                <i class="fas fa-hands-helping"></i>
            </div>
            <h2>Create Account</h2>
            <p class="text-muted">Join MSWDO – Social welfare at your service</p>
            <div class="color-stripes">
                <div class="stripe stripe-blue"></div>
                <div class="stripe stripe-red"></div>
                <div class="stripe stripe-yellow"></div>
            </div>
        </div>

        <div class="card-body">
            <?php if(!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            <?php if(!empty($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <div id="statusBanner" style="margin-bottom: 12px; display: none;">
                <div id="statusMessage" style="padding: 8px 14px; border-radius: 20px; font-size: 0.7rem; display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-wifi" id="statusIcon"></i>
                    <span id="statusText">Checking connection...</span>
                </div>
            </div>

            <form method="POST" action="" id="registerForm">
                <!-- username field -->
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-user"></i> Username <span class="text-danger">*</span></label>
                    <input type="text" name="username" id="username" class="form-control" value="<?php echo htmlspecialchars($form_data['username'] ?? ''); ?>" required minlength="3" maxlength="50" pattern="[a-zA-Z0-9_]+" title="Letters, numbers, underscore only">
                    <div class="form-text" id="usernameFeedback">3–50 characters, only letters, numbers, and underscore.</div>
                </div>

                <!-- full name -->
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-id-card"></i> Full Name <span class="text-danger">*</span></label>
                    <input type="text" name="full_name" id="full_name" class="form-control" value="<?php echo htmlspecialchars($form_data['full_name'] ?? ''); ?>" required>
                </div>

                <!-- email -->
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>" placeholder="name@example.com">
                </div>

                <!-- password + strength -->
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-lock"></i> Password <span class="text-danger">*</span></label>
                    <input type="password" name="password" id="password" class="form-control" required>
                    <div class="password-strength">
                        <div class="strength-bar" id="strengthBar"></div>
                    </div>
                    <div class="form-text" id="passwordReqMsg">Password must be at least 4 characters</div>
                </div>

                <!-- confirm password -->
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-check-circle"></i> Confirm Password <span class="text-danger">*</span></label>
                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                    <div class="form-text" id="matchMessage"></div>
                </div>

                <!-- role selector - ONLY RESIDENT AND MSWD STAFF -->
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-briefcase"></i> Account Type <span class="text-danger">*</span></label>
                    <div class="role-selector" id="roleSelector">
                        <div class="role-option <?php echo ($form_data['role'] ?? 'resident') == 'resident' ? 'selected' : ''; ?>" data-role="resident">
                            <i class="fas fa-home"></i>
                            <span>Resident</span>
                            <small>Apply for assistance & services</small>
                        </div>
                        <div class="role-option <?php echo ($form_data['role'] ?? '') == 'staff' ? 'selected' : ''; ?>" data-role="staff">
                            <i class="fas fa-user-tie"></i>
                            <span>MSWD Staff</span>
                            <small>Municipal Social Welfare Staff</small>
                        </div>
                    </div>
                    <input type="hidden" name="role" id="roleInput" value="<?php echo htmlspecialchars($form_data['role'] ?? 'resident'); ?>">
                </div>

                <!-- Staff-specific fields -->
                <div id="staffFields" class="staff-fields <?php echo ($form_data['role'] ?? 'resident') == 'resident' ? 'hidden' : ''; ?>">
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-phone-alt"></i> Contact Number</label>
                        <input type="tel" name="contact_number" id="contact_number" class="form-control" value="<?php echo htmlspecialchars($form_data['contact_number'] ?? ''); ?>" placeholder="0912 345 6789">
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-briefcase"></i> Position / Job Title</label>
                        <input type="text" name="position" id="position" class="form-control" value="<?php echo htmlspecialchars($form_data['position'] ?? ''); ?>" placeholder="e.g., Social Welfare Officer">
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-id-badge"></i> Office ID / Employee ID</label>
                        <input type="text" name="office_id" id="office_id" class="form-control" value="<?php echo htmlspecialchars($form_data['office_id'] ?? ''); ?>" placeholder="Optional">
                    </div>
                </div>

                <input type="hidden" name="status" value="active">

                <div class="alert alert-info" style="margin-top: 8px;">
                    <i class="fas fa-shield-alt"></i>
                    <span>By registering, you agree to MSWDO data privacy protocols and community guidelines.</span>
                </div>

                <button type="submit" class="btn-primary" id="registerBtn">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>

                <div class="back-link">
                    <a href="index.php"><i class="fas fa-arrow-left"></i> Already have an account? Sign in</a>
                </div>

                <div class="sync-status">
                    <i class="fas fa-database"></i> <span id="syncText">Checking offline status...</span>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========================================================== -->
<!-- JAVASCRIPT: OFFLINE SQLite / IndexedDB ENGINE              -->
<!-- ========================================================== -->
<script>
(function() {
    'use strict';

    // ============================================================
    // 1. DATABASE INITIALIZATION (IndexedDB)
    // ============================================================
    const DB_NAME = 'MSWDO_OfflineDB';
    const DB_VERSION = 2;
    let db = null;

    function initDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            
            request.onupgradeneeded = function(event) {
                const db = event.target.result;
                
                if (!db.objectStoreNames.contains('users')) {
                    const userStore = db.createObjectStore('users', { keyPath: 'id' });
                    userStore.createIndex('username', 'username', { unique: true });
                    userStore.createIndex('role', 'role', { unique: false });
                }
                
                if (!db.objectStoreNames.contains('households')) {
                    const householdStore = db.createObjectStore('households', { keyPath: 'id' });
                    householdStore.createIndex('barangay', 'barangay', { unique: false });
                    householdStore.createIndex('user_id', 'user_id', { unique: false });
                }
                
                if (!db.objectStoreNames.contains('sync_queue')) {
                    const syncStore = db.createObjectStore('sync_queue', { keyPath: 'id', autoIncrement: true });
                    syncStore.createIndex('status', 'status', { unique: false });
                    syncStore.createIndex('created_at', 'created_at', { unique: false });
                }
                
                if (!db.objectStoreNames.contains('applications')) {
                    const appStore = db.createObjectStore('applications', { keyPath: 'id', autoIncrement: true });
                    appStore.createIndex('user_id', 'user_id', { unique: false });
                    appStore.createIndex('status', 'status', { unique: false });
                }
            };
            
            request.onsuccess = function(event) {
                db = event.target.result;
                console.log('✅ Offline Database initialized');
                resolve();
            };
            
            request.onerror = function(event) {
                console.error('Database error:', event.target.error);
                reject(event.target.error);
            };
        });
    }

    // ============================================================
    // 2. DATABASE OPERATIONS
    // ============================================================
    function dbAdd(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.add(data);
            request.onsuccess = function() { resolve(request.result); };
            request.onerror = function() { reject(request.error); };
        });
    }

    function dbGetByIndex(storeName, indexName, value) {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const index = store.index(indexName);
            const request = index.get(value);
            request.onsuccess = function() { resolve(request.result); };
            request.onerror = function() { reject(request.error); };
        });
    }

    function dbGetAll(storeName) {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.getAll();
            request.onsuccess = function() { resolve(request.result); };
            request.onerror = function() { reject(request.error); };
        });
    }

    function dbUpdate(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.put(data);
            request.onsuccess = function() { resolve(request.result); };
            request.onerror = function() { reject(request.error); };
        });
    }

    function hashPassword(password) {
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return 'hashed_' + Math.abs(hash);
    }

    function verifyPassword(plain, hashed) {
        return hashPassword(plain) === hashed;
    }

    // ============================================================
    // 3. OFFLINE REGISTRATION
    // ============================================================
    async function offlineRegister(formData) {
        try {
            // Check if username exists
            const existing = await dbGetByIndex('users', 'username', formData.username);
            if (existing) {
                return { success: false, error: 'Username already exists' };
            }
            
            // Create user
            const newUser = {
                id: Date.now(),
                username: formData.username,
                password: hashPassword(formData.password),
                full_name: formData.full_name,
                email: formData.email || '',
                role: formData.role || 'resident',
                contact_number: formData.contact_number || '',
                position: formData.position || '',
                office_id: formData.office_id || '',
                status: 'active',
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString()
            };
            
            await dbAdd('users', newUser);
            
            // Also sync to server if online
            if (navigator.onLine) {
                // The form will submit to server for online sync
                // We use the server to ensure data is synced
            }
            
            return {
                success: true,
                user: {
                    id: newUser.id,
                    username: newUser.username,
                    full_name: newUser.full_name,
                    role: newUser.role
                }
            };
            
        } catch (error) {
            console.error('Offline registration error:', error);
            return { success: false, error: 'Registration failed offline' };
        }
    }

    // ============================================================
    // 4. UI FUNCTIONS
    // ============================================================
    function getSyncStatus() {
        const statusEl = document.getElementById('syncText');
        const banner = document.getElementById('statusBanner');
        const message = document.getElementById('statusMessage');
        const icon = document.getElementById('statusIcon');
        const text = document.getElementById('statusText');
        
        if (navigator.onLine) {
            statusEl.textContent = '🟢 Online - Data synced to server';
            banner.style.display = 'block';
            message.style.background = '#D1FAE5';
            icon.className = 'fas fa-wifi';
            icon.style.color = '#059669';
            text.textContent = '✅ Connected to server';
        } else {
            statusEl.textContent = '🟡 Offline Mode - Saving locally';
            banner.style.display = 'block';
            message.style.background = '#FEF3C7';
            icon.className = 'fas fa-wifi-slash';
            icon.style.color = '#B45309';
            text.textContent = '📶 Offline Mode - Data will sync when online';
        }
    }

    // ============================================================
    // 5. FORM HANDLING
    // ============================================================
    let isSubmitting = false;

    async function handleRegister(e) {
        e.preventDefault();
        
        if (isSubmitting) return;
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        const fullName = document.getElementById('full_name').value.trim();
        const email = document.getElementById('email').value.trim();
        const role = document.getElementById('roleInput').value;
        const contactNumber = document.getElementById('contact_number')?.value.trim() || '';
        const position = document.getElementById('position')?.value.trim() || '';
        const officeId = document.getElementById('office_id')?.value.trim() || '';
        
        // Validation
        if (!username || username.length < 3) {
            alert('Username must be at least 3 characters');
            return;
        }
        
        if (!password || password.length < 4) {
            alert('Password must be at least 4 characters');
            return;
        }
        
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }
        
        if (!fullName) {
            alert('Full name is required');
            return;
        }
        
        const btn = document.getElementById('registerBtn');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<span class="spinner"></span> Creating account...';
        btn.disabled = true;
        isSubmitting = true;
        
        try {
            const formData = {
                username,
                password,
                full_name: fullName,
                email,
                role,
                contact_number: contactNumber,
                position,
                office_id: officeId
            };
            
            // Try offline registration first
            const offlineResult = await offlineRegister(formData);
            
            if (offlineResult.success) {
                // Also submit to server for online sync
                if (navigator.onLine) {
                    // The form will submit normally to server
                    document.getElementById('registerForm').submit();
                    return;
                } else {
                    // Offline only - show success
                    alert('✅ Account created offline! It will sync when you go online.');
                    window.location.href = 'index.php';
                    return;
                }
            } else {
                // If offline fails, try online
                if (navigator.onLine) {
                    document.getElementById('registerForm').submit();
                    return;
                } else {
                    alert('❌ ' + offlineResult.error);
                }
            }
            
        } catch (error) {
            alert('Registration error: ' + error.message);
        } finally {
            btn.innerHTML = originalText;
            btn.disabled = false;
            isSubmitting = false;
        }
    }

    // ============================================================
    // 6. ROLE SELECTOR
    // ============================================================
    function initRoleSelector() {
        const options = document.querySelectorAll('.role-option');
        const roleInput = document.getElementById('roleInput');
        const staffFields = document.getElementById('staffFields');
        
        options.forEach(opt => {
            opt.addEventListener('click', function() {
                options.forEach(o => o.classList.remove('selected'));
                this.classList.add('selected');
                const role = this.dataset.role;
                roleInput.value = role;
                
                if (role === 'resident') {
                    staffFields.classList.add('hidden');
                } else if (role === 'staff') {
                    staffFields.classList.remove('hidden');
                }
            });
        });
    }

    // ============================================================
    // 7. PASSWORD STRENGTH & MATCH
    // ============================================================
    function initPasswordChecks() {
        const passwordInput = document.getElementById('password');
        const confirmInput = document.getElementById('confirm_password');
        const strengthBar = document.getElementById('strengthBar');
        const passwordReqMsg = document.getElementById('passwordReqMsg');
        const matchMessage = document.getElementById('matchMessage');
        
        function evaluateStrength() {
            const pwd = passwordInput.value;
            if (pwd.length >= 4) {
                passwordReqMsg.innerHTML = '✓ Password meets minimum requirement (4+ characters)';
                passwordReqMsg.style.color = '#2E7D32';
                if (pwd.length >= 8) {
                    strengthBar.className = 'strength-bar strength-strong';
                } else if (pwd.length >= 6) {
                    strengthBar.className = 'strength-bar strength-medium';
                } else {
                    strengthBar.className = 'strength-bar strength-weak';
                }
            } else {
                passwordReqMsg.innerHTML = '⚠️ Password must be at least 4 characters';
                passwordReqMsg.style.color = '#D32F2F';
                strengthBar.className = 'strength-bar';
                strengthBar.style.width = '0%';
            }
            checkMatch();
        }
        
        function checkMatch() {
            const pwd = passwordInput.value;
            const confirm = confirmInput.value;
            if (confirm.length === 0) {
                matchMessage.innerHTML = '';
                return;
            }
            if (pwd === confirm) {
                matchMessage.innerHTML = '✓ Passwords match';
                matchMessage.style.color = '#2E7D32';
            } else {
                matchMessage.innerHTML = '✗ Passwords do not match';
                matchMessage.style.color = '#D32F2F';
            }
        }
        
        passwordInput.addEventListener('input', evaluateStrength);
        confirmInput.addEventListener('input', checkMatch);
    }

    // ============================================================
    // 8. USERNAME AVAILABILITY CHECK
    // ============================================================
    function initUsernameCheck() {
        const usernameField = document.getElementById('username');
        let timer = null;
        
        usernameField.addEventListener('input', function() {
            clearTimeout(timer);
            const val = this.value.trim();
            if (val.length >= 3) {
                timer = setTimeout(async () => {
                    try {
                        // Check offline first
                        const existing = await dbGetByIndex('users', 'username', val);
                        const feedback = document.getElementById('usernameFeedback');
                        if (existing) {
                            feedback.innerHTML = '❌ Username already taken';
                            feedback.style.color = '#D32F2F';
                            this.classList.add('error');
                            this.classList.remove('success');
                        } else {
                            feedback.innerHTML = '✓ Username available';
                            feedback.style.color = '#2E7D32';
                            this.classList.add('success');
                            this.classList.remove('error');
                        }
                    } catch (e) {
                        // Ignore errors
                    }
                }, 500);
            } else {
                const feedback = document.getElementById('usernameFeedback');
                feedback.innerHTML = '3–50 characters, only letters, numbers, and underscore.';
                feedback.style.color = '#6C86A3';
                this.classList.remove('success', 'error');
            }
        });
    }

    // ============================================================
    // 9. INITIALIZATION
    // ============================================================
    async function init() {
        try {
            await initDatabase();
            
            // Setup form
            document.getElementById('registerForm').addEventListener('submit', handleRegister);
            
            // Setup role selector
            initRoleSelector();
            
            // Setup password checks
            initPasswordChecks();
            
            // Setup username check
            initUsernameCheck();
            
            // Network status
            window.addEventListener('online', getSyncStatus);
            window.addEventListener('offline', getSyncStatus);
            
            // Show sync status
            getSyncStatus();
            
            console.log('✅ MSWDO Registration with Offline SQLite/IndexedDB ready');
            
        } catch (error) {
            console.error('Initialization error:', error);
        }
    }

    // Start when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
</script>
</body>
</html>