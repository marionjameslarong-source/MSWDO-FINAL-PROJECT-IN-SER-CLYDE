<?php
// ============================================================
// logout.php — NUCLEAR OPTION: kill everything session-related
// ============================================================

// Start the session so we can access it
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Clear all session variables
$_SESSION = array();

// 2. Delete the session cookie (with every possible path/domain variant)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    
    // Clear for the current path
    setcookie(
        session_name(),
        '',
        time() - 86400,     // 1 day in the past
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
    
    // Also clear for the /mswdo/ path explicitly
    setcookie(
        session_name(),
        '',
        time() - 86400,
        '/mswdo/',
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
    
    // And for the root path
    setcookie(
        session_name(),
        '',
        time() - 86400,
        '/',
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// 3. Destroy the session server-side
session_destroy();

// 4. Start a FRESH session so the login page has a clean slate
session_start();
session_regenerate_id(true);

// 5. Redirect to login
header("Location: index.php");
exit();
?>