// File: src/routes/householdRoutes.js
// Server Backend - The Safe Tracking Logic

const express = require('express');
const router = express.Router();
const { db } = require('../config/database');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

/**
 * POST /api/v1/households/:household_id/poverty-override
 * 
 * Manual poverty status override with automatic audit trail logging.
 * This is a secure database transaction that ensures both the update
 * and the audit log happen atomically.
 * 
 * Request Body:
 *   - staff_id (string): The ID of the staff member performing the override
 *   - new_status (string): The new poverty status (SUBSISTENCE_POOR, POOR, NON_POOR)
 *   - justification_reason (string): The reason for the override
 * 
 * Response:
 *   - status: 'SUCCESS' or 'ERROR'
 *   - message: Description of the result
 *   - data: { household_id, previous_status, new_status, log_id }
 */
router.patch('/:household_id/poverty-override', 
  authenticateToken, 
  authorizeRole(['staff', 'social_worker', 'admin']),
  async (req, res) => {
    const { household_id } = req.params;
    const { staff_id, new_status, justification_reason } = req.body;
    
    // Input validation
    if (!household_id || !staff_id || !new_status || !justification_reason) {
      return res.status(400).json({
        status: 'ERROR',
        message: 'Missing required fields: household_id, staff_id, new_status, justification_reason'
      });
    }
    
    // Validate new_status value
    const validStatuses = ['SUBSISTENCE_POOR', 'POOR', 'NON_POOR'];
    if (!validStatuses.includes(new_status)) {
      return res.status(400).json({
        status: 'ERROR',
        message: `Invalid new_status. Must be one of: ${validStatuses.join(', ')}`
      });
    }
    
    // Validate justification length
    if (justification_reason.length < 10) {
      return res.status(400).json({
        status: 'ERROR',
        message: 'Justification reason must be at least 10 characters'
      });
    }
    
    try {
      // Begin database transaction
      await db.query('BEGIN');
      
      // 1. Fetch current poverty status first to keep a perfect history trail
      const currentData = await db.query(
        "SELECT poverty_status FROM household_records WHERE household_id = $1",
        [household_id]
      );
      
      if (currentData.rows.length === 0) {
        await db.query('ROLLBACK');
        return res.status(404).json({
          status: 'ERROR',
          message: 'Household not found'
        });
      }
      
      const oldStatus = currentData.rows[0].poverty_status;
      
      // Check if the new status is different from the current one
      if (oldStatus === new_status) {
        await db.query('ROLLBACK');
        return res.status(400).json({
          status: 'ERROR',
          message: 'New poverty status must be different from the current status'
        });
      }
      
      // 2. Perform the master status update override
      await db.query(
        "UPDATE household_records SET poverty_status = $1, updated_at = CURRENT_TIMESTAMP WHERE household_id = $2",
        [new_status, household_id]
      );
      
      // 3. Generate a unique log ID
      const logId = 'ovr_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      
      // 4. Write the permanent tracking log into the audit table
      await db.query(
        `INSERT INTO administrative_override_logs 
         (override_log_id, household_id, action_by_staff_id, previous_poverty_status, 
          new_poverty_status, justification_reason_text, timestamp_logged)
         VALUES ($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP)`,
        [logId, household_id, staff_id, oldStatus, new_status, justification_reason]
      );
      
      // 5. Also log to the general activity logs
      await db.query(
        `INSERT INTO activity_logs (user_id, action, details, created_at)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
        [
          staff_id,
          'poverty_override',
          `Manual poverty override for household #${household_id}: ${oldStatus} → ${new_status}`
        ]
      );
      
      // Commit the transaction - both updates happen atomically
      await db.query('COMMIT');
      
      // Return success response
      return res.status(200).json({
        status: 'SUCCESS',
        message: 'Override logged successfully.',
        data: {
          household_id: household_id,
          previous_status: oldStatus,
          new_status: new_status,
          log_id: logId,
          timestamp: new Date().toISOString()
        }
      });
      
    } catch (error) {
      // Rollback the transaction on any error
      await db.query('ROLLBACK');
      console.error('Poverty override error:', error);
      
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to process override: ' + error.message
      });
    }
  }
);

/**
 * GET /api/v1/households/:household_id/override-logs
 * 
 * Retrieve the override history for a specific household
 */
router.get('/:household_id/override-logs',
  authenticateToken,
  async (req, res) => {
    const { household_id } = req.params;
    
    try {
      const logs = await db.query(
        `SELECT 
           aol.override_log_id,
           aol.household_id,
           aol.previous_poverty_status,
           aol.new_poverty_status,
           aol.justification_reason_text,
           aol.timestamp_logged,
           u.full_name as staff_name
         FROM administrative_override_logs aol
         LEFT JOIN users u ON aol.action_by_staff_id = u.id
         WHERE aol.household_id = $1
         ORDER BY aol.timestamp_logged DESC
         LIMIT 50`,
        [household_id]
      );
      
      return res.status(200).json({
        status: 'SUCCESS',
        data: logs.rows
      });
      
    } catch (error) {
      console.error('Error fetching override logs:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to fetch override logs'
      });
    }
  }
);

/**
 * GET /api/v1/staff/households
 * 
 * Fetch all households with their current poverty status
 */
router.get('/staff/households',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'admin']),
  async (req, res) => {
    try {
      const households = await db.query(
        `SELECT 
           id,
           head_first_name,
           head_last_name,
           barangay,
           poverty_status,
           verification_status,
           created_at
         FROM household_records
         ORDER BY head_last_name ASC
         LIMIT 100`
      );
      
      return res.status(200).json({
        status: 'SUCCESS',
        data: households.rows
      });
      
    } catch (error) {
      console.error('Error fetching households:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to fetch households'
      });
    }
  }
);

/**
 * GET /api/v1/staff/households/:household_id
 * 
 * Fetch a single household by ID
 */
router.get('/staff/households/:household_id',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'admin']),
  async (req, res) => {
    const { household_id } = req.params;
    
    try {
      const household = await db.query(
        `SELECT 
           h.*,
           u.full_name as resident_name,
           u.email,
           u.contact_number
         FROM household_records h
         LEFT JOIN users u ON h.user_id = u.id
         WHERE h.id = $1`,
        [household_id]
      );
      
      if (household.rows.length === 0) {
        return res.status(404).json({
          status: 'ERROR',
          message: 'Household not found'
        });
      }
      
      return res.status(200).json({
        status: 'SUCCESS',
        data: household.rows[0]
      });
      
    } catch (error) {
      console.error('Error fetching household:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to fetch household'
      });
    }
  }
);

module.exports = router;