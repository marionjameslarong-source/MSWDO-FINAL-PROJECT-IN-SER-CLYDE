// File: src/screens/staff/HouseholdRecordsScreen.js
// Mobile view layout inside dashboard's MAIN → HOUSEHOLD RECORDS menu tab

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  SafeAreaView,
  Modal
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function HouseholdRecordsScreen({ navigation, route }) {
  // State for the selected household
  const [selectedHousehold, setSelectedHousehold] = useState(null);
  const [households, setHouseholds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  // State for poverty override form
  const [showOverrideModal, setShowOverrideModal] = useState(false);
  const [newPovertyStatus, setNewPovertyStatus] = useState('');
  const [justificationReason, setJustificationReason] = useState('');
  const [selectedHouseholdForOverride, setSelectedHouseholdForOverride] = useState(null);
  
  // State for viewing override logs
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [overrideLogs, setOverrideLogs] = useState([]);

  // Load households on component mount
  useEffect(() => {
    fetchHouseholds();
  }, []);

  // Fetch households from the server
  const fetchHouseholds = async () => {
    setLoading(true);
    try {
      // Simulate API call - in production, this would call your backend
      // const response = await fetch('https://gov.local/api/v1/staff/households');
      // const data = await response.json();
      
      // Mock data for demonstration
      const mockData = [
        { id: 'hh_98234-x9a2', head_first_name: 'Juan', head_last_name: 'Dela Cruz', poverty_status: 'POOR', barangay: 'Zone 4' },
        { id: 'hh_11024-k2p1', head_first_name: 'Maria', head_last_name: 'Santos', poverty_status: 'SUBSISTENCE_POOR', barangay: 'Zone 2' },
        { id: 'hh_88412-m3n5', head_first_name: 'Pedro', head_last_name: 'Reyes', poverty_status: 'NON_POOR', barangay: 'Zone 1' },
        { id: 'hh_55210-p7q2', head_first_name: 'Ana', head_last_name: 'Garcia', poverty_status: 'POOR', barangay: 'Zone 3' },
      ];
      
      setTimeout(() => {
        setHouseholds(mockData);
        setLoading(false);
      }, 500);
      
    } catch (error) {
      console.error('Error fetching households:', error);
      Alert.alert('Error', 'Failed to load households. Please try again.');
      setLoading(false);
    }
  };

  // Handle poverty status override submission
  const handlePovertyOverride = async () => {
    if (!selectedHouseholdForOverride) {
      Alert.alert('Error', 'Please select a household.');
      return;
    }
    
    if (!newPovertyStatus) {
      Alert.alert('Error', 'Please select a new poverty status.');
      return;
    }
    
    if (!justificationReason.trim() || justificationReason.length < 10) {
      Alert.alert('Error', 'Please provide a detailed justification (minimum 10 characters).');
      return;
    }
    
    // Check if the new status is different from current
    if (selectedHouseholdForOverride.poverty_status === newPovertyStatus) {
      Alert.alert('No Change', 'The selected household already has this poverty status.');
      return;
    }
    
    setSubmitting(true);
    
    try {
      // API call to the backend poverty-override endpoint
      const response = await fetch(
        `https://gov.local/api/v1/households/${selectedHouseholdForOverride.id}/poverty-override`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${secureStaffToken}`, // Use actual token
          },
          body: JSON.stringify({
            staff_id: currentLoggedInStaffId,
            new_status: newPovertyStatus,
            justification_reason: justificationReason.trim()
          })
        }
      );
      
      const result = await response.json();
      
      if (response.ok && result.status === 'SUCCESS') {
        Alert.alert(
          'Success',
          `Poverty status override successful!\n\n${selectedHouseholdForOverride.head_first_name} ${selectedHouseholdForOverride.head_last_name}\n${selectedHouseholdForOverride.poverty_status} → ${newPovertyStatus}`,
          [
            { 
              text: 'OK', 
              onPress: () => {
                setShowOverrideModal(false);
                setNewPovertyStatus('');
                setJustificationReason('');
                setSelectedHouseholdForOverride(null);
                // Refresh the household list
                fetchHouseholds();
              }
            }
          ]
        );
      } else {
        Alert.alert('Error', result.message || 'Failed to override poverty status. Please try again.');
      }
    } catch (error) {
      console.error('Error overriding poverty status:', error);
      Alert.alert(
        'Error',
        'Network error. Please check your connection and try again.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  // Fetch override logs for a specific household
  const fetchOverrideLogs = async (householdId) => {
    try {
      // Simulate API call
      const mockLogs = [
        {
          override_log_id: 'ovr_1a2b3c4d',
          household_id: householdId,
          previous_poverty_status: 'POOR',
          new_poverty_status: 'SUBSISTENCE_POOR',
          justification_reason_text: 'Updated after home visit - family lost primary income source.',
          staff_name: 'Elena Santos',
          timestamp_logged: '2026-07-01 10:30:00'
        },
        {
          override_log_id: 'ovr_5e6f7g8h',
          household_id: householdId,
          previous_poverty_status: 'NON_POOR',
          new_poverty_status: 'POOR',
          justification_reason_text: 'Medical expenses exceeded income threshold.',
          staff_name: 'Maria Reyes',
          timestamp_logged: '2026-06-28 14:15:00'
        }
      ];
      
      setOverrideLogs(mockLogs);
      setShowLogsModal(true);
      
    } catch (error) {
      console.error('Error fetching override logs:', error);
      Alert.alert('Error', 'Failed to load override logs.');
    }
  };

  // Render each household card
  const renderHouseholdCard = (household) => {
    const statusColors = {
      'SUBSISTENCE_POOR': '#D32F2F',
      'POOR': '#B45309',
      'NON_POOR': '#059669'
    };
    
    const statusLabels = {
      'SUBSISTENCE_POOR': 'Subsistence Poor',
      'POOR': 'Poor',
      'NON_POOR': 'Non-Poor'
    };
    
    return (
      <View key={household.id} style={styles.householdCard}>
        <View style={styles.cardHeader}>
          <View>
            <Text style={styles.householdName}>
              {household.head_first_name} {household.head_last_name}
            </Text>
            <Text style={styles.householdId}>ID: {household.id}</Text>
            <Text style={styles.householdBarangay}>
              <Ionicons name="location-outline" size={12} color="#64748B" />
              {' '}{household.barangay}
            </Text>
          </View>
          <View style={[
            styles.statusBadge,
            { backgroundColor: statusColors[household.poverty_status] || '#64748B' }
          ]}>
            <Text style={styles.statusBadgeText}>
              {statusLabels[household.poverty_status] || household.poverty_status}
            </Text>
          </View>
        </View>
        
        <View style={styles.cardActions}>
          <TouchableOpacity
            style={[styles.actionButton, styles.viewButton]}
            onPress={() => navigation.navigate('HouseholdDetails', { householdId: household.id })}
          >
            <Ionicons name="eye-outline" size={16} color="#1E4A8C" />
            <Text style={styles.actionButtonText}>View</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.overrideButton]}
            onPress={() => {
              setSelectedHouseholdForOverride(household);
              setNewPovertyStatus('');
              setJustificationReason('');
              setShowOverrideModal(true);
            }}
          >
            <Ionicons name="create-outline" size={16} color="#D32F2F" />
            <Text style={[styles.actionButtonText, { color: '#D32F2F' }]}>Override</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.logsButton]}
            onPress={() => fetchOverrideLogs(household.id)}
          >
            <Ionicons name="time-outline" size={16} color="#1E4A8C" />
            <Text style={[styles.actionButtonText, { color: '#1E4A8C' }]}>Logs</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // Loading state
  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color="#1E4A8C" />
          <Text style={styles.loadingText}>Loading households...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Household Records</Text>
        <TouchableOpacity onPress={fetchHouseholds}>
          <Ionicons name="refresh-outline" size={24} color="#1E4A8C" />
        </TouchableOpacity>
      </View>
      
      {/* Subtitle */}
      <View style={styles.subHeader}>
        <Text style={styles.subHeaderText}>
          {households.length} households found
        </Text>
        <TouchableOpacity style={styles.filterButton}>
          <Ionicons name="filter-outline" size={20} color="#64748B" />
          <Text style={styles.filterButtonText}>Filter</Text>
        </TouchableOpacity>
      </View>

      {/* Household List */}
      <ScrollView 
        style={styles.householdList}
        contentContainerStyle={styles.householdListContent}
        showsVerticalScrollIndicator={false}
      >
        {households.map(renderHouseholdCard)}
      </ScrollView>

      {/* ============================================================ */}
      {/* POVERTY OVERRIDE MODAL                                       */}
      {/* ============================================================ */}
      <Modal
        visible={showOverrideModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => {
          if (!submitting) {
            setShowOverrideModal(false);
            setSelectedHouseholdForOverride(null);
          }
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                <Ionicons name="warning-outline" size={20} color="#D32F2F" />
                {' '}Manual Poverty Override
              </Text>
              <TouchableOpacity 
                onPress={() => {
                  if (!submitting) {
                    setShowOverrideModal(false);
                    setSelectedHouseholdForOverride(null);
                  }
                }}
                disabled={submitting}
              >
                <Ionicons name="close-outline" size={24} color="#64748B" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalBody}>
              {/* Warning notice */}
              <View style={styles.warningNotice}>
                <Ionicons name="alert-circle" size={20} color="#D32F2F" />
                <Text style={styles.warningText}>
                  Changing poverty status affects financial aid eligibility. 
                  All changes are logged for anti-fraud monitoring.
                </Text>
              </View>
              
              {/* Household info */}
              {selectedHouseholdForOverride && (
                <View style={styles.householdInfo}>
                  <Text style={styles.infoLabel}>Household</Text>
                  <Text style={styles.infoValue}>
                    {selectedHouseholdForOverride.head_first_name} {selectedHouseholdForOverride.head_last_name}
                  </Text>
                  <Text style={styles.infoSub}>
                    ID: {selectedHouseholdForOverride.id}
                  </Text>
                  <Text style={styles.infoSub}>
                    Current Status: <Text style={styles.currentStatus}>
                      {selectedHouseholdForOverride.poverty_status}
                    </Text>
                  </Text>
                </View>
              )}
              
              {/* New Status Selection */}
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>New Poverty Status *</Text>
                <View style={styles.statusOptions}>
                  {['SUBSISTENCE_POOR', 'POOR', 'NON_POOR'].map((status) => (
                    <TouchableOpacity
                      key={status}
                      style={[
                        styles.statusOption,
                        newPovertyStatus === status && styles.statusOptionSelected
                      ]}
                      onPress={() => setNewPovertyStatus(status)}
                      disabled={submitting}
                    >
                      <Text style={[
                        styles.statusOptionText,
                        newPovertyStatus === status && styles.statusOptionTextSelected
                      ]}>
                        {status.replace('_', ' ')}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
              
              {/* Justification Reason */}
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Justification Reason *</Text>
                <TextInput
                  style={styles.textArea}
                  multiline
                  numberOfLines={4}
                  placeholder="Explain why this override is necessary..."
                  value={justificationReason}
                  onChangeText={setJustificationReason}
                  editable={!submitting}
                  textAlignVertical="top"
                />
                <Text style={styles.charCount}>
                  {justificationReason.length} characters minimum 10
                </Text>
              </View>
            </View>
            
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  if (!submitting) {
                    setShowOverrideModal(false);
                    setSelectedHouseholdForOverride(null);
                  }
                }}
                disabled={submitting}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.modalButton,
                  styles.submitButton,
                  (submitting || !newPovertyStatus || !justificationReason.trim() || justificationReason.length < 10) && 
                  styles.submitButtonDisabled
                ]}
                onPress={handlePovertyOverride}
                disabled={
                  submitting || 
                  !newPovertyStatus || 
                  !justificationReason.trim() || 
                  justificationReason.length < 10
                }
              >
                {submitting ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <Text style={styles.submitButtonText}>Save Override</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ============================================================ */}
      {/* OVERRIDE LOGS MODAL                                          */}
      {/* ============================================================ */}
      <Modal
        visible={showLogsModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowLogsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '80%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                <Ionicons name="time-outline" size={20} color="#1E4A8C" />
                {' '}Override History
              </Text>
              <TouchableOpacity onPress={() => setShowLogsModal(false)}>
                <Ionicons name="close-outline" size="24" color="#64748B" />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.logsContainer}>
              {overrideLogs.length > 0 ? (
                overrideLogs.map((log, index) => (
                  <View key={index} style={styles.logEntry}>
                    <View style={styles.logHeader}>
                      <Text style={styles.logStaff}>{log.staff_name}</Text>
                      <Text style={styles.logDate}>
                        {new Date(log.timestamp_logged).toLocaleString()}
                      </Text>
                    </View>
                    <View style={styles.logStatusChange}>
                      <Text style={styles.logOldStatus}>
                        {log.previous_poverty_status}
                      </Text>
                      <Ionicons name="arrow-forward" size={14} color="#94A3B8" />
                      <Text style={styles.logNewStatus}>
                        {log.new_poverty_status}
                      </Text>
                    </View>
                    <Text style={styles.logJustification}>
                      "{log.justification_reason_text}"
                    </Text>
                  </View>
                ))
              ) : (
                <View style={styles.emptyLogs}>
                  <Ionicons name="clipboard-outline" size={48} color="#CBD5E1" />
                  <Text style={styles.emptyLogsText}>No override logs found</Text>
                </View>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    color: '#64748B',
    fontSize: 14,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1E293B',
  },
  subHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
  },
  subHeaderText: {
    fontSize: 13,
    color: '#64748B',
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  filterButtonText: {
    fontSize: 13,
    color: '#64748B',
  },
  householdList: {
    flex: 1,
  },
  householdListContent: {
    padding: 16,
    paddingBottom: 24,
  },
  householdCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  householdName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
  },
  householdId: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 2,
  },
  householdBarangay: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  statusBadgeText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  cardActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
    borderWidth: 1,
    flex: 1,
  },
  viewButton: {
    borderColor: '#1E4A8C',
    backgroundColor: '#F0F4FF',
  },
  overrideButton: {
    borderColor: '#D32F2F',
    backgroundColor: '#FFF5F5',
  },
  logsButton: {
    borderColor: '#1E4A8C',
    backgroundColor: '#F0F4FF',
  },
  actionButtonText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#1E4A8C',
    marginLeft: 4,
  },
  
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    width: '100%',
    maxWidth: 440,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
  },
  modalBody: {
    padding: 16,
  },
  warningNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    backgroundColor: '#FFF5F5',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FEE2E2',
    marginBottom: 16,
  },
  warningText: {
    flex: 1,
    fontSize: 12,
    color: '#991B1B',
    lineHeight: 18,
  },
  householdInfo: {
    backgroundColor: '#F8FAFC',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  infoLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#64748B',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  infoValue: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1E293B',
    marginTop: 2,
  },
  infoSub: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 2,
  },
  currentStatus: {
    fontWeight: '600',
    color: '#1E293B',
  },
  formGroup: {
    marginBottom: 16,
  },
  formLabel: {
    fontSize: 13,
    fontWeight: '500',
    color: '#1E293B',
    marginBottom: 8,
  },
  statusOptions: {
    flexDirection: 'row',
    gap: 8,
  },
  statusOption: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    alignItems: 'center',
  },
  statusOptionSelected: {
    borderColor: '#D32F2F',
    backgroundColor: '#FFF5F5',
  },
  statusOptionText: {
    fontSize: 12,
    color: '#64748B',
  },
  statusOptionTextSelected: {
    color: '#D32F2F',
    fontWeight: '600',
  },
  textArea: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  charCount: {
    fontSize: 11,
    color: '#94A3B8',
    marginTop: 4,
    textAlign: 'right',
  },
  modalFooter: {
    flexDirection: 'row',
    gap: 12,
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  cancelButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#475569',
  },
  submitButton: {
    backgroundColor: '#D32F2F',
  },
  submitButtonDisabled: {
    opacity: 0.5,
  },
  submitButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  
  // Logs Modal
  logsContainer: {
    padding: 16,
  },
  logEntry: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  logHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logStaff: {
    fontSize: 13,
    fontWeight: '500',
    color: '#1E293B',
  },
  logDate: {
    fontSize: 11,
    color: '#94A3B8',
  },
  logStatusChange: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
  },
  logOldStatus: {
    fontSize: 12,
    color: '#B45309',
    fontWeight: '500',
  },
  logNewStatus: {
    fontSize: 12,
    color: '#D32F2F',
    fontWeight: '600',
  },
  logJustification: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 4,
    fontStyle: 'italic',
  },
  emptyLogs: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyLogsText: {
    fontSize: 14,
    color: '#94A3B8',
    marginTop: 8,
  },
});