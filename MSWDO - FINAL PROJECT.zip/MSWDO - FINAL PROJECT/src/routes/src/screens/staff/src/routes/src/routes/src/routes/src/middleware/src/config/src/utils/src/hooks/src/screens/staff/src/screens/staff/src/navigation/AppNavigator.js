import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

// Import screens with cache
import HouseholdRecordsScreen from '../screens/staff/HouseholdRecordsScreen';
import FinancialAssistanceScreen from '../screens/staff/FinancialAssistanceScreen';
import DashboardScreen from '../screens/staff/DashboardScreen';
import ProfileScreen from '../screens/staff/ProfileScreen';

// Import utility
import { setAuthToken } from '../utils/localStorageCache';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// ============================================================
// STAFF TAB NAVIGATOR
// ============================================================
function StaffTabNavigator() {
    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;
                    if (route.name === 'Dashboard') {
                        iconName = focused ? 'home' : 'home-outline';
                    } else if (route.name === 'Households') {
                        iconName = focused ? 'people' : 'people-outline';
                    } else if (route.name === 'Financial') {
                        iconName = focused ? 'cash' : 'cash-outline';
                    } else if (route.name === 'Profile') {
                        iconName = focused ? 'person' : 'person-outline';
                    }
                    return <Ionicons name={iconName} size={size} color={color} />;
                },
                tabBarActiveTintColor: '#1E4A8C',
                tabBarInactiveTintColor: '#94A3B8',
                headerShown: false,
            })}
        >
            <Tab.Screen name="Dashboard" component={DashboardScreen} />
            <Tab.Screen 
                name="Households" 
                component={HouseholdRecordsScreen}
                options={{ tabBarLabel: 'Households' }}
            />
            <Tab.Screen 
                name="Financial" 
                component={FinancialAssistanceScreen}
                options={{ tabBarLabel: 'Financial' }}
            />
            <Tab.Screen name="Profile" component={ProfileScreen} />
        </Tab.Navigator>
    );
}

// ============================================================
// MAIN APP NAVIGATOR
// ============================================================
export default function AppNavigator() {
    // Set auth token when app starts
    React.useEffect(() => {
        // Retrieve token from secure storage
        const getToken = async () => {
            try {
                const token = await AsyncStorage.getItem('auth_token');
                if (token) {
                    setAuthToken(token);
                }
            } catch (error) {
                console.warn('Failed to load auth token:', error);
            }
        };
        getToken();
    }, []);

    return (
        <NavigationContainer>
            <Stack.Navigator screenOptions={{ headerShown: false }}>
                <Stack.Screen name="MainTabs" component={StaffTabNavigator} />
                {/* Other screens */}
            </Stack.Navigator>
        </NavigationContainer>
    );
}