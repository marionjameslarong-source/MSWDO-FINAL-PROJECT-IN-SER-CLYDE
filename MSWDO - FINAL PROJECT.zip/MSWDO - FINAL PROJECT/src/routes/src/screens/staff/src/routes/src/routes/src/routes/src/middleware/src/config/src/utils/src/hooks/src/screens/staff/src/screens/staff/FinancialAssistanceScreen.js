/**
 * Financial Assistance Screen with Local Cache Engine
 * 
 * This screen implements:
 * - Instant loading from cache
 * - Pull-to-refresh functionality
 * - Status filtering
 * - Cache status display
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    SafeAreaView,
    TouchableOpacity,
    RefreshControl,
    ActivityIndicator,
    Alert,
    Dimensions,
} from 'react-native';
import { useFinancialAssistance } from '../../hooks/useCachedData';

const { width } = Dimensions.get('window');

// ============================================================
// STATS CARD COMPONENT
// ============================================================
const StatsCard = ({ icon, value, label, color, bgColor }) => (
    <View style={[styles.statsCard, { backgroundColor: bgColor || '#FFFFFF' }]}>
        <Text style={styles.statsIcon}>{icon}</Text>
        <Text style={[styles.statsValue, { color: color || '#1E293B' }]}>{value}</Text>
        <Text style={styles.statsLabel}>{label}</Text>
    </View>
);

// ============================================================
// APPLICATION CARD COMPONENT
// ============================================================
const ApplicationCard = ({ application, onPress }) => {
    const getStatusColor = (status) => {
        switch(status) {
            case 'disbursed': return '#059669';
            case 'approved': return '#059669';
            case 'pending': return '#F5B042';
            case 'rejected': return '#D32F2F';
            default: return '#94A3B8';
        }
    };

    const getStatusLabel = (status) => {
        switch(status) {
            case 'disbursed': return '💰 Disbursed';
            case 'approved': return '✅ Approved';
            case 'pending': return '⏳ Pending';
            case 'rejected': return '❌ Rejected';
            default: return status || 'Unknown';
        }
    };

    return (
        <TouchableOpacity style={styles.appCard} onPress={() => onPress(application)}>
            <View style={styles.appHeader}>
                <Text style={styles.appName}>{application.applicant_name || 'Unknown'}</Text>
                <View style={[styles.appStatusBadge, { backgroundColor: getStatusColor(application.status) }]}>
                    <Text style={styles.appStatusText}>{getStatusLabel(application.status)}</Text>
                </View>
            </View>
            <View style={styles.appBody}>
                <View style={styles.appRow}>
                    <Text style={styles.appLabel}>📍 Barangay</Text>
                    <Text style={styles.appValue}>{application.barangay || 'N/A'}</Text>
                </View>
                <View style={styles.appRow}>
                    <Text style={styles.appLabel}>💰 Amount</Text>
                    <Text style={[styles.appValue, styles.amountText]}>
                        ₱ {Number(application.actual_amount_paid || 0).toLocaleString()}
                    </Text>
                </View>
                <View style={styles.appRow}>
                    <Text style={styles.appLabel}>📅 Date</Text>
                    <Text style={styles.appValue}>
                        {new Date(application.created_at).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                        })}
                    </Text>
                </View>
            </View>
        </TouchableOpacity>
    );
};

// ============================================================
// FILTER BUTTONS
// ============================================================
const FilterButtons = ({ selectedFilter, onFilterChange }) => {
    const filters = [
        { key: 'all', label: 'All' },
        { key: 'pending', label: 'Pending' },
        { key: 'approved', label: 'Approved' },
        { key: 'disbursed', label: 'Disbursed' },
        { key: 'rejected', label: 'Rejected' },
    ];

    return (
        <View style={styles.filterContainer}>
            {filters.map((filter) => (
                <TouchableOpacity
                    key={filter.key}
                    style={[
                        styles.filterButton,
                        selectedFilter === filter.key && styles.filterButtonActive,
                    ]}
                    onPress={() => onFilterChange(filter.key)}
                >
                    <Text
                        style={[
                            styles.filterText,
                            selectedFilter === filter.key && styles.filterTextActive,
                        ]}
                    >
                        {filter.label}
                    </Text>
                </TouchableOpacity>
            ))}
        </View>
    );
};

// ============================================================
// MAIN SCREEN COMPONENT
// ============================================================
export default function FinancialAssistanceScreen({ navigation }) {
    const {
        applications,
        summary,
        loading,
        refreshing,
        error,
        cacheStatus,
        refresh,
        getByStatus,
    } = useFinancialAssistance();

    const [selectedFilter, setSelectedFilter] = useState('all');
    const [filteredApps, setFilteredApps] = useState([]);
    const [showCacheInfo, setShowCacheInfo] = useState(false);

    // Update filtered list when filter or applications change
    useEffect(() => {
        if (selectedFilter === 'all') {
            setFilteredApps(applications);
        } else {
            const filtered = applications.filter(app => app.status === selectedFilter);
            setFilteredApps(filtered);
        }
    }, [selectedFilter, applications]);

    // Handle filter change
    const handleFilterChange = (filter) => {
        setSelectedFilter(filter);
    };

    // Handle application press
    const handleApplicationPress = (app) => {
        navigation.navigate('ApplicationDetails', { 
            applicationId: app.id,
            application: app 
        });
    };

    // Handle force refresh
    const handleForceRefresh = async () => {
        Alert.alert(
            'Refresh Cache',
            'This will clear the local cache and fetch fresh data from the server. Continue?',
            [
                { text: 'Cancel', style: 'cancel' },
                { 
                    text: 'Refresh', 
                    onPress: async () => {
                        await refresh();
                        Alert.alert('✅ Success', 'Cache refreshed successfully!');
                    }
                }
            ]
        );
    };

    // Render cache status bar
    const renderCacheStatus = () => {
        const statusColor = cacheStatus.isFresh ? '#059669' : (cacheStatus.age !== null ? '#F5B042' : '#D32F2F');
        const statusLabel = cacheStatus.isFresh ? 'Fresh' : (cacheStatus.age !== null ? 'Stale' : 'Miss');
        
        return (
            <TouchableOpacity 
                style={[styles.cacheBar, { borderLeftColor: statusColor }]}
                onPress={() => setShowCacheInfo(!showCacheInfo)}
            >
                <View style={styles.cacheBarLeft}>
                    <View style={[styles.cacheDot, { backgroundColor: statusColor }]} />
                    <Text style={styles.cacheBarText}>
                        Cache: <Text style={styles.cacheBarBold}>{statusLabel}</Text>
                        {cacheStatus.age !== null && (
                            <Text style={styles.cacheBarAge}> | {cacheStatus.age} min ago</Text>
                        )}
                    </Text>
                </View>
                <View style={styles.cacheBarRight}>
                    <Text style={styles.cacheBarCount}>{applications.length} apps</Text>
                    <TouchableOpacity onPress={handleForceRefresh} style={styles.refreshButton}>
                        <Text style={styles.refreshButtonText}>🔄</Text>
                    </TouchableOpacity>
                </View>
            </TouchableOpacity>
        );
    };

    // Render stats
    const renderStats = () => (
        <View style={styles.statsGrid}>
            <StatsCard 
                icon="📊" 
                value={summary.total || 0} 
                label="Total" 
                color="#1E4A8C" 
            />
            <StatsCard 
                icon="⏳" 
                value={summary.pending || 0} 
                label="Pending" 
                color="#F5B042" 
                bgColor="#FFF9EF" 
            />
            <StatsCard 
                icon="✅" 
                value={summary.approved || 0} 
                label="Approved" 
                color="#059669" 
                bgColor="#ECFDF5" 
            />
            <StatsCard 
                icon="💰" 
                value={`₱ ${(summary.total_disbursed || 0).toLocaleString()}`} 
                label="Disbursed" 
                color="#1E4A8C" 
                bgColor="#EFF6FF" 
            />
        </View>
    );

    // Render loading state
    if (loading && applications.length === 0) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color="#1E4A8C" />
                    <Text style={styles.loadingText}>Loading financial assistance...</Text>
                    <Text style={styles.loadingSubText}>Checking local cache...</Text>
                </View>
            </SafeAreaView>
        );
    }

    // Render error state
    if (error && applications.length === 0) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.errorContainer}>
                    <Text style={styles.errorEmoji}>⚠️</Text>
                    <Text style={styles.errorTitle}>Failed to Load</Text>
                    <Text style={styles.errorText}>{error}</Text>
                    <TouchableOpacity style={styles.retryButton} onPress={refresh}>
                        <Text style={styles.retryButtonText}>Retry</Text>
                    </TouchableOpacity>
                </View>
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            {renderCacheStatus()}
            {renderStats()}
            <FilterButtons 
                selectedFilter={selectedFilter} 
                onFilterChange={handleFilterChange} 
            />
            
            <FlatList
                data={filteredApps}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                    <ApplicationCard 
                        application={item} 
                        onPress={handleApplicationPress} 
                    />
                )}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={refresh}
                        colors={['#1E4A8C']}
                        tintColor="#1E4A8C"
                    />
                }
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <Text style={styles.emptyEmoji}>📭</Text>
                        <Text style={styles.emptyTitle}>No Applications</Text>
                        <Text style={styles.emptyText}>
                            {selectedFilter === 'all' 
                                ? 'No financial assistance applications found.' 
                                : `No ${selectedFilter} applications found.`}
                        </Text>
                    </View>
                }
                ListFooterComponent={
                    <View style={styles.footer}>
                        <Text style={styles.footerText}>
                            {filteredApps.length} of {applications.length} applications
                        </Text>
                        <TouchableOpacity 
                            style={styles.footerRefreshButton}
                            onPress={handleForceRefresh}
                        >
                            <Text style={styles.footerRefreshText}>🔄 Sync Now</Text>
                        </TouchableOpacity>
                    </View>
                }
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
            />
        </SafeAreaView>
    );
}

// ============================================================
// STYLES
// ============================================================
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F8FAFC',
    },
    // Cache Status Bar
    cacheBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        paddingHorizontal: 16,
        paddingVertical: 10,
        marginHorizontal: 16,
        marginTop: 12,
        marginBottom: 8,
        borderRadius: 10,
        borderLeftWidth: 4,
        borderColor: '#E2E8F0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 2,
    },
    cacheBarLeft: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    cacheDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginRight: 8,
    },
    cacheBarText: {
        fontSize: 11,
        color: '#64748B',
    },
    cacheBarBold: {
        fontWeight: '600',
        color: '#1E293B',
    },
    cacheBarAge: {
        color: '#94A3B8',
    },
    cacheBarRight: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    cacheBarCount: {
        fontSize: 11,
        color: '#94A3B8',
        fontWeight: '500',
    },
    refreshButton: {
        padding: 4,
    },
    refreshButtonText: {
        fontSize: 16,
    },
    // Stats
    statsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingHorizontal: 16,
        paddingVertical: 8,
        gap: 8,
    },
    statsCard: {
        flex: 1,
        minWidth: (width - 48) / 2 - 4,
        backgroundColor: '#FFFFFF',
        borderRadius: 10,
        padding: 12,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#E2E8F0',
    },
    statsIcon: {
        fontSize: 20,
        marginBottom: 2,
    },
    statsValue: {
        fontSize: 18,
        fontWeight: '700',
        color: '#1E293B',
    },
    statsLabel: {
        fontSize: 10,
        color: '#94A3B8',
        marginTop: 1,
    },
    // Filter
    filterContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingHorizontal: 16,
        paddingVertical: 8,
        gap: 6,
    },
    filterButton: {
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 16,
        backgroundColor: '#F1F5F9',
        borderWidth: 1,
        borderColor: '#E2E8F0',
    },
    filterButtonActive: {
        backgroundColor: '#1E4A8C',
        borderColor: '#1E4A8C',
    },
    filterText: {
        fontSize: 11,
        fontWeight: '500',
        color: '#64748B',
    },
    filterTextActive: {
        color: '#FFFFFF',
    },
    // Application Cards
    listContent: {
        paddingHorizontal: 16,
        paddingBottom: 16,
    },
    appCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        padding: 16,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: '#E2E8F0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 2,
    },
    appHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 8,
    },
    appName: {
        fontSize: 15,
        fontWeight: '600',
        color: '#1E293B',
        flex: 1,
    },
    appStatusBadge: {
        paddingHorizontal: 8,
        paddingVertical: 3,
        borderRadius: 12,
        marginLeft: 8,
    },
    appStatusText: {
        fontSize: 9,
        fontWeight: '600',
        color: '#FFFFFF',
    },
    appBody: {
        gap: 3,
    },
    appRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    appLabel: {
        fontSize: 11,
        color: '#94A3B8',
    },
    appValue: {
        fontSize: 11,
        fontWeight: '500',
        color: '#334155',
    },
    amountText: {
        color: '#1E4A8C',
        fontWeight: '600',
    },
    // Loading
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    loadingText: {
        marginTop: 12,
        fontSize: 16,
        fontWeight: '600',
        color: '#1E293B',
    },
    loadingSubText: {
        marginTop: 4,
        fontSize: 12,
        color: '#94A3B8',
    },
    // Error
    errorContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 40,
    },
    errorEmoji: {
        fontSize: 48,
        marginBottom: 12,
    },
    errorTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#1E293B',
        marginBottom: 4,
    },
    errorText: {
        fontSize: 14,
        color: '#64748B',
        textAlign: 'center',
        marginBottom: 16,
    },
    retryButton: {
        backgroundColor: '#1E4A8C',
        paddingHorizontal: 24,
        paddingVertical: 10,
        borderRadius: 8,
    },
    retryButtonText: {
        color: '#FFFFFF',
        fontWeight: '600',
    },
    // Empty
    emptyContainer: {
        paddingVertical: 40,
        alignItems: 'center',
    },
    emptyEmoji: {
        fontSize: 40,
        marginBottom: 8,
    },
    emptyTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#1E293B',
        marginBottom: 4,
    },
    emptyText: {
        fontSize: 13,
        color: '#94A3B8',
        textAlign: 'center',
    },
    // Footer
    footer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 12,
        paddingHorizontal: 4,
        borderTopWidth: 1,
        borderTopColor: '#E2E8F0',
        marginTop: 4,
    },
    footerText: {
        fontSize: 12,
        color: '#94A3B8',
    },
    footerRefreshButton: {
        backgroundColor: '#F1F5F9',
        paddingHorizontal: 16,
        paddingVertical: 6,
        borderRadius: 16,
    },
    footerRefreshText: {
        fontSize: 12,
        fontWeight: '500',
        color: '#1E4A8C',
    },
});