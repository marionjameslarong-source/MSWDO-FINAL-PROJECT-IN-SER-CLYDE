/**
 * Household Records Screen with Local Cache Engine
 * 
 * This screen implements:
 * - Instant loading from cache
 * - Pull-to-refresh functionality
 * - Search filtering
 * - Cache status display
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
    View,
    Text,
    StyleSheet,
    FlatList,
    SafeAreaView,
    TouchableOpacity,
    RefreshControl,
    TextInput,
    Alert,
    ActivityIndicator,
    Dimensions,
} from 'react-native';
import { useHouseholds } from '../../hooks/useCachedData';
import { LocalCacheEngine } from '../../utils/localStorageCache';

const { width } = Dimensions.get('window');

// ============================================================
// HOUSEHOLD CARD COMPONENT
// ============================================================
const HouseholdCard = ({ household, onPress }) => {
    const getStatusColor = (status) => {
        switch(status) {
            case 'verified_approved': return '#059669';
            case 'pending_review': return '#F5B042';
            case 'rejected': return '#D32F2F';
            default: return '#94A3B8';
        }
    };

    const getStatusLabel = (status) => {
        switch(status) {
            case 'verified_approved': return 'Verified';
            case 'pending_review': return 'Pending';
            case 'rejected': return 'Rejected';
            default: return 'Unknown';
        }
    };

    return (
        <TouchableOpacity style={styles.card} onPress={() => onPress(household)}>
            <View style={styles.cardHeader}>
                <Text style={styles.cardTitle}>
                    {household.head_first_name} {household.head_last_name || ''}
                </Text>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(household.verification_status) }]}>
                    <Text style={styles.statusText}>{getStatusLabel(household.verification_status)}</Text>
                </View>
            </View>
            <View style={styles.cardBody}>
                <View style={styles.cardRow}>
                    <Text style={styles.cardLabel}>📍 Barangay</Text>
                    <Text style={styles.cardValue}>{household.barangay || 'N/A'}</Text>
                </View>
                <View style={styles.cardRow}>
                    <Text style={styles.cardLabel}>👨‍👩‍👧‍👦 Members</Text>
                    <Text style={styles.cardValue}>{household.total_members || 0}</Text>
                </View>
                <View style={styles.cardRow}>
                    <Text style={styles.cardLabel}>💰 Income</Text>
                    <Text style={styles.cardValue}>₱ {Number(household.monthly_income || 0).toLocaleString()}</Text>
                </View>
                <View style={styles.cardRow}>
                    <Text style={styles.cardLabel}>📱 Contact</Text>
                    <Text style={styles.cardValue}>{household.contact_number || 'N/A'}</Text>
                </View>
            </View>
        </TouchableOpacity>
    );
};

// ============================================================
// MAIN SCREEN COMPONENT
// ============================================================
export default function HouseholdRecordsScreen({ navigation }) {
    const {
        households,
        loading,
        refreshing,
        error,
        cacheStatus,
        refresh,
        searchHouseholds,
        total,
    } = useHouseholds();

    const [searchTerm, setSearchTerm] = useState('');
    const [filteredHouseholds, setFilteredHouseholds] = useState([]);
    const [showCacheInfo, setShowCacheInfo] = useState(false);

    // Update filtered list when search term changes
    useEffect(() => {
        if (searchTerm.trim() === '') {
            setFilteredHouseholds(households);
        } else {
            const filtered = households.filter(h => 
                (h.head_first_name && h.head_first_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
                (h.head_last_name && h.head_last_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
                (h.barangay && h.barangay.toLowerCase().includes(searchTerm.toLowerCase()))
            );
            setFilteredHouseholds(filtered);
        }
    }, [searchTerm, households]);

    // Handle search submit
    const handleSearch = () => {
        if (searchTerm.trim() !== '') {
            searchHouseholds(searchTerm);
        }
    };

    // Handle household press
    const handleHouseholdPress = (household) => {
        navigation.navigate('HouseholdDetails', { 
            householdId: household.id,
            household: household 
        });
    };

    // Handle force refresh
    const handleForceRefresh = async () => {
        Alert.alert(
            'Refresh Cache',
            'This will clear the local cache and fetch fresh data from the server. Continue?',
            [
                { text: 'Cancel', style: 'cancel' },
                { 
                    text: 'Refresh', 
                    onPress: async () => {
                        await refresh();
                        Alert.alert('✅ Success', 'Cache refreshed successfully!');
                    }
                }
            ]
        );
    };

    // Render cache status bar
    const renderCacheStatus = () => {
        const statusColor = cacheStatus.isFresh ? '#059669' : (cacheStatus.age !== null ? '#F5B042' : '#D32F2F');
        const statusLabel = cacheStatus.isFresh ? 'Fresh' : (cacheStatus.age !== null ? 'Stale' : 'Miss');
        
        return (
            <TouchableOpacity 
                style={[styles.cacheBar, { borderLeftColor: statusColor }]}
                onPress={() => setShowCacheInfo(!showCacheInfo)}
            >
                <View style={styles.cacheBarLeft}>
                    <View style={[styles.cacheDot, { backgroundColor: statusColor }]} />
                    <Text style={styles.cacheBarText}>
                        Cache: <Text style={styles.cacheBarBold}>{statusLabel}</Text>
                        {cacheStatus.age !== null && (
                            <Text style={styles.cacheBarAge}> | {cacheStatus.age} min ago</Text>
                        )}
                    </Text>
                </View>
                <View style={styles.cacheBarRight}>
                    <Text style={styles.cacheBarCount}>{total} households</Text>
                    <TouchableOpacity onPress={handleForceRefresh} style={styles.refreshButton}>
                        <Text style={styles.refreshButtonText}>🔄</Text>
                    </TouchableOpacity>
                </View>
            </TouchableOpacity>
        );
    };

    // Render search bar
    const renderSearchBar = () => (
        <View style={styles.searchContainer}>
            <View style={styles.searchInputWrapper}>
                <Text style={styles.searchIcon}>🔍</Text>
                <TextInput
                    style={styles.searchInput}
                    placeholder="Search by name or barangay..."
                    value={searchTerm}
                    onChangeText={setSearchTerm}
                    onSubmitEditing={handleSearch}
                    returnKeyType="search"
                />
                {searchTerm.length > 0 && (
                    <TouchableOpacity onPress={() => setSearchTerm('')} style={styles.clearButton}>
                        <Text style={styles.clearButtonText}>✕</Text>
                    </TouchableOpacity>
                )}
            </View>
        </View>
    );

    // Render loading state
    if (loading && households.length === 0) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color="#1E4A8C" />
                    <Text style={styles.loadingText}>Loading households...</Text>
                    <Text style={styles.loadingSubText}>Checking local cache...</Text>
                </View>
            </SafeAreaView>
        );
    }

    // Render error state
    if (error && households.length === 0) {
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.errorContainer}>
                    <Text style={styles.errorEmoji}>⚠️</Text>
                    <Text style={styles.errorTitle}>Failed to Load</Text>
                    <Text style={styles.errorText}>{error}</Text>
                    <TouchableOpacity style={styles.retryButton} onPress={refresh}>
                        <Text style={styles.retryButtonText}>Retry</Text>
                    </TouchableOpacity>
                </View>
            </SafeAreaView>
        );
    }

    // Render empty state
    if (!loading && households.length === 0) {
        return (
            <SafeAreaView style={styles.container}>
                {renderCacheStatus()}
                {renderSearchBar()}
                <View style={styles.emptyContainer}>
                    <Text style={styles.emptyEmoji}>📭</Text>
                    <Text style={styles.emptyTitle}>No Households Found</Text>
                    <Text style={styles.emptyText}>No household records available in cache.</Text>
                    <TouchableOpacity style={styles.refreshButtonLarge} onPress={handleForceRefresh}>
                        <Text style={styles.refreshButtonLargeText}>🔄 Refresh Cache</Text>
                    </TouchableOpacity>
                </View>
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            {renderCacheStatus()}
            {renderSearchBar()}
            
            <FlatList
                data={filteredHouseholds}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                    <HouseholdCard household={item} onPress={handleHouseholdPress} />
                )}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={refresh}
                        colors={['#1E4A8C']}
                        tintColor="#1E4A8C"
                    />
                }
                ListFooterComponent={
                    <View style={styles.footer}>
                        <Text style={styles.footerText}>
                            {filteredHouseholds.length} of {total} households
                        </Text>
                        <TouchableOpacity 
                            style={styles.footerRefreshButton}
                            onPress={handleForceRefresh}
                        >
                            <Text style={styles.footerRefreshText}>🔄 Sync Now</Text>
                        </TouchableOpacity>
                    </View>
                }
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
            />
        </SafeAreaView>
    );
}

// ============================================================
// STYLES
// ============================================================
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F8FAFC',
    },
    // Cache Status Bar
    cacheBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        paddingHorizontal: 16,
        paddingVertical: 10,
        marginHorizontal: 16,
        marginTop: 12,
        marginBottom: 8,
        borderRadius: 10,
        borderLeftWidth: 4,
        borderColor: '#E2E8F0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 2,
    },
    cacheBarLeft: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    cacheDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginRight: 8,
    },
    cacheBarText: {
        fontSize: 11,
        color: '#64748B',
    },
    cacheBarBold: {
        fontWeight: '600',
        color: '#1E293B',
    },
    cacheBarAge: {
        color: '#94A3B8',
    },
    cacheBarRight: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    cacheBarCount: {
        fontSize: 11,
        color: '#94A3B8',
        fontWeight: '500',
    },
    refreshButton: {
        padding: 4,
    },
    refreshButtonText: {
        fontSize: 16,
    },
    // Search Bar
    searchContainer: {
        paddingHorizontal: 16,
        paddingVertical: 8,
    },
    searchInputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#E2E8F0',
        paddingHorizontal: 12,
    },
    searchIcon: {
        fontSize: 14,
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        paddingVertical: 10,
        fontSize: 14,
        color: '#1E293B',
    },
    clearButton: {
        padding: 4,
    },
    clearButtonText: {
        fontSize: 12,
        color: '#94A3B8',
    },
    // Cards
    listContent: {
        paddingBottom: 16,
        paddingHorizontal: 16,
    },
    card: {
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: '#E2E8F0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 2,
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 8,
    },
    cardTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#1E293B',
        flex: 1,
    },
    statusBadge: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
        marginLeft: 8,
    },
    statusText: {
        fontSize: 10,
        fontWeight: '600',
        color: '#FFFFFF',
    },
    cardBody: {
        gap: 4,
    },
    cardRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    cardLabel: {
        fontSize: 12,
        color: '#94A3B8',
    },
    cardValue: {
        fontSize: 12,
        fontWeight: '500',
        color: '#334155',
    },
    // Loading
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    loadingText: {
        marginTop: 12,
        fontSize: 16,
        fontWeight: '600',
        color: '#1E293B',
    },
    loadingSubText: {
        marginTop: 4,
        fontSize: 12,
        color: '#94A3B8',
    },
    // Error
    errorContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 40,
    },
    errorEmoji: {
        fontSize: 48,
        marginBottom: 12,
    },
    errorTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#1E293B',
        marginBottom: 4,
    },
    errorText: {
        fontSize: 14,
        color: '#64748B',
        textAlign: 'center',
        marginBottom: 16,
    },
    retryButton: {
        backgroundColor: '#1E4A8C',
        paddingHorizontal: 24,
        paddingVertical: 10,
        borderRadius: 8,
    },
    retryButtonText: {
        color: '#FFFFFF',
        fontWeight: '600',
    },
    // Empty
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 40,
    },
    emptyEmoji: {
        fontSize: 48,
        marginBottom: 12,
    },
    emptyTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#1E293B',
        marginBottom: 4,
    },
    emptyText: {
        fontSize: 14,
        color: '#64748B',
        textAlign: 'center',
        marginBottom: 16,
    },
    refreshButtonLarge: {
        backgroundColor: '#1E4A8C',
        paddingHorizontal: 24,
        paddingVertical: 10,
        borderRadius: 8,
    },
    refreshButtonLargeText: {
        color: '#FFFFFF',
        fontWeight: '600',
    },
    // Footer
    footer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 12,
        paddingHorizontal: 4,
        borderTopWidth: 1,
        borderTopColor: '#E2E8F0',
        marginTop: 4,
    },
    footerText: {
        fontSize: 12,
        color: '#94A3B8',
    },
    footerRefreshButton: {
        backgroundColor: '#F1F5F9',
        paddingHorizontal: 16,
        paddingVertical: 6,
        borderRadius: 16,
    },
    footerRefreshText: {
        fontSize: 12,
        fontWeight: '500',
        color: '#1E4A8C',
    },
});