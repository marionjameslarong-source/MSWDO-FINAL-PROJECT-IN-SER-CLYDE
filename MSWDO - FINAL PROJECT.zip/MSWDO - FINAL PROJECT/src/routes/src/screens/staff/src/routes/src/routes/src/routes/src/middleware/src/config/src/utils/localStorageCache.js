/**
 * Local Storage Cache Engine
 * Optimized for low-bandwidth field operations
 * 
 * This engine implements the caching strategy:
 * - Check if cache exists & is fresh (< 6 hours)
 * - If fresh, load instantly from cache
 * - If expired or empty, fetch from live server and update cache
 * - Fallback to stale cache on network failure
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

// ============================================================
// CACHE CONFIGURATION
// ============================================================
const CACHE_EXPIRATION_LIMIT = 6 * 60 * 60 * 1000; // 6 hours in milliseconds

// Cache keys for different datasets
const CACHE_KEYS = {
    HOUSEHOLDS: 'CACHE_HOUSEHOLD_REGISTRY',
    FINANCIAL_ASSISTANCE: 'CACHE_FINANCIAL_ASSISTANCE',
    APPLICATIONS: 'CACHE_WELFARE_APPLICATIONS',
    STAFF_PROFILE: 'CACHE_STAFF_PROFILE',
    TIMESTAMP: 'CACHE_TIMESTAMP',
    TIMESTAMP_FINANCIAL: 'CACHE_TIMESTAMP_FINANCIAL',
    TIMESTAMP_APPLICATIONS: 'CACHE_TIMESTAMP_APPLICATIONS',
    TIMESTAMP_STAFF: 'CACHE_TIMESTAMP_STAFF',
};

// API endpoints
const API_BASE_URL = 'https://gov.local/api/v1';
const API_ENDPOINTS = {
    HOUSEHOLDS: `${API_BASE_URL}/households`,
    FINANCIAL_ASSISTANCE: `${API_BASE_URL}/financial-assistance`,
    APPLICATIONS: `${API_BASE_URL}/welfare-applications`,
    STAFF_PROFILE: `${API_BASE_URL}/staff/profile`,
};

// ============================================================
// AUTH TOKEN MANAGEMENT
// ============================================================
let authToken = null;

export const setAuthToken = (token) => {
    authToken = token;
};

export const getAuthToken = () => {
    return authToken;
};

// ============================================================
// CACHE ENGINE - CORE FUNCTIONS
// ============================================================

export const LocalCacheEngine = {

    /**
     * Check if cache is fresh
     */
    isCacheFresh: async (cacheKey) => {
        try {
            const timestampKey = cacheKey.replace('CACHE_', 'CACHE_TIMESTAMP_');
            const cacheTimestamp = await AsyncStorage.getItem(timestampKey);
            
            if (!cacheTimestamp) return false;
            
            const age = Date.now() - parseInt(cacheTimestamp, 10);
            return age < CACHE_EXPIRATION_LIMIT;
        } catch (error) {
            console.warn('Cache freshness check failed:', error);
            return false;
        }
    },

    /**
     * Get cached data if fresh, otherwise fetch from server
     */
    getCachedData: async (cacheKey, apiEndpoint, forceRefresh = false) => {
        try {
            // If force refresh, skip cache and fetch from server
            if (forceRefresh) {
                console.log('🔄 Force refresh: Fetching fresh data from server...');
                return await LocalCacheEngine.fetchAndCacheData(cacheKey, apiEndpoint);
            }

            // Check if cache is fresh
            const isFresh = await LocalCacheEngine.isCacheFresh(cacheKey);
            
            if (isFresh) {
                // 🚀 CACHE HIT: Loading thousands of rows instantly from local storage
                const cachedData = await AsyncStorage.getItem(cacheKey);
                if (cachedData) {
                    console.log(`🚀 Cache Hit: Loading ${cacheKey} instantly from local storage.`);
                    return JSON.parse(cachedData);
                }
            }

            // 🌐 CACHE MISS/EXPIRED: Syncing fresh metrics from live government database
            console.log(`🌐 Cache Miss/Expired: Syncing fresh ${cacheKey} from live database.`);
            return await LocalCacheEngine.fetchAndCacheData(cacheKey, apiEndpoint);

        } catch (error) {
            console.warn(`❌ Cache error for ${cacheKey}:`, error.message);
            
            // Try to return stale cache as fallback
            try {
                const staleData = await AsyncStorage.getItem(cacheKey);
                if (staleData) {
                    console.log(`⚠️ Falling back to stale ${cacheKey} data to prevent app crash.`);
                    return JSON.parse(staleData);
                }
            } catch (staleError) {
                console.error('Failed to load stale cache:', staleError);
            }
            
            // Return empty data structure
            return LocalCacheEngine.getEmptyDataStructure(cacheKey);
        }
    },

    /**
     * Fetch data from server and cache it
     */
    fetchAndCacheData: async (cacheKey, apiEndpoint) => {
        try {
            const headers = {
                'Content-Type': 'application/json',
            };
            
            if (authToken) {
                headers['Authorization'] = `Bearer ${authToken}`;
            }

            const response = await fetch(apiEndpoint, { headers });
            
            if (!response.ok) {
                throw new Error(`API Error: ${response.status} ${response.statusText}`);
            }

            const freshData = await response.json();
            
            // Save data to cache
            await AsyncStorage.setItem(cacheKey, JSON.stringify(freshData));
            
            // Save timestamp
            const timestampKey = cacheKey.replace('CACHE_', 'CACHE_TIMESTAMP_');
            await AsyncStorage.setItem(timestampKey, Date.now().toString());
            
            console.log(`✅ Cache updated: ${cacheKey} with ${Array.isArray(freshData) ? freshData.length : Object.keys(freshData).length} items`);
            
            return freshData;
            
        } catch (error) {
            console.error(`❌ Failed to fetch and cache ${cacheKey}:`, error);
            throw error;
        }
    },

    /**
     * Force refresh all cached data
     */
    forceRefreshAll: async () => {
        console.log('🔄 Force refreshing all cached data...');
        
        const results = {
            households: null,
            financialAssistance: null,
            applications: null,
            staffProfile: null,
        };
        
        try {
            results.households = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.HOUSEHOLDS,
                API_ENDPOINTS.HOUSEHOLDS,
                true
            );
        } catch (e) { console.warn('Households refresh failed:', e); }
        
        try {
            results.financialAssistance = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.FINANCIAL_ASSISTANCE,
                API_ENDPOINTS.FINANCIAL_ASSISTANCE,
                true
            );
        } catch (e) { console.warn('Financial Assistance refresh failed:', e); }
        
        try {
            results.applications = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.APPLICATIONS,
                API_ENDPOINTS.APPLICATIONS,
                true
            );
        } catch (e) { console.warn('Applications refresh failed:', e); }
        
        try {
            results.staffProfile = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.STAFF_PROFILE,
                API_ENDPOINTS.STAFF_PROFILE,
                true
            );
        } catch (e) { console.warn('Staff Profile refresh failed:', e); }
        
        console.log('✅ All caches refreshed');
        return results;
    },

    /**
     * Clear a specific cache
     */
    clearCache: async (cacheKey) => {
        try {
            const timestampKey = cacheKey.replace('CACHE_', 'CACHE_TIMESTAMP_');
            await AsyncStorage.removeItem(cacheKey);
            await AsyncStorage.removeItem(timestampKey);
            console.log(`🗑️ Cache cleared: ${cacheKey}`);
            return true;
        } catch (error) {
            console.error(`Failed to clear cache ${cacheKey}:`, error);
            return false;
        }
    },

    /**
     * Clear all caches
     */
    clearAllCaches: async () => {
        console.log('🗑️ Clearing all caches...');
        
        const keys = Object.values(CACHE_KEYS);
        let successCount = 0;
        
        for (const key of keys) {
            const result = await LocalCacheEngine.clearCache(key);
            if (result) successCount++;
        }
        
        console.log(`✅ Cleared ${successCount}/${keys.length} caches`);
        return successCount;
    },

    /**
     * Get cache status information
     */
    getCacheStatus: async () => {
        const status = {
            households: { exists: false, fresh: false, age: null },
            financialAssistance: { exists: false, fresh: false, age: null },
            applications: { exists: false, fresh: false, age: null },
            staffProfile: { exists: false, fresh: false, age: null },
        };
        
        const cacheKeys = [
            CACHE_KEYS.HOUSEHOLDS,
            CACHE_KEYS.FINANCIAL_ASSISTANCE,
            CACHE_KEYS.APPLICATIONS,
            CACHE_KEYS.STAFF_PROFILE,
        ];
        
        for (const key of cacheKeys) {
            const name = key.replace('CACHE_', '').toLowerCase();
            const exists = await AsyncStorage.getItem(key);
            status[name].exists = !!exists;
            
            if (exists) {
                const timestampKey = key.replace('CACHE_', 'CACHE_TIMESTAMP_');
                const timestamp = await AsyncStorage.getItem(timestampKey);
                if (timestamp) {
                    const age = Date.now() - parseInt(timestamp, 10);
                    status[name].fresh = age < CACHE_EXPIRATION_LIMIT;
                    status[name].age = Math.round(age / 60000); // in minutes
                }
            }
        }
        
        return status;
    },

    /**
     * Get empty data structure for cache key
     */
    getEmptyDataStructure: (cacheKey) => {
        switch(cacheKey) {
            case CACHE_KEYS.HOUSEHOLDS:
                return { households: [], total: 0, cached_at: null };
            case CACHE_KEYS.FINANCIAL_ASSISTANCE:
                return { applications: [], summary: { total: 0, pending: 0, approved: 0, rejected: 0, total_disbursed: 0 } };
            case CACHE_KEYS.APPLICATIONS:
                return { applications: [], by_program: {} };
            case CACHE_KEYS.STAFF_PROFILE:
                return { staff: null, permissions: [] };
            default:
                return [];
        }
    },
};

// ============================================================
// SPECIALIZED CACHE FUNCTIONS FOR HOUSEHOLDS
// ============================================================

export const HouseholdCache = {
    
    /**
     * Get cached households or fetch from server
     */
    getHouseholds: async (forceRefresh = false) => {
        return await LocalCacheEngine.getCachedData(
            CACHE_KEYS.HOUSEHOLDS,
            API_ENDPOINTS.HOUSEHOLDS,
            forceRefresh
        );
    },

    /**
     * Get a single household by ID
     */
    getHouseholdById: async (householdId) => {
        try {
            // First try to get from cache
            const data = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.HOUSEHOLDS,
                API_ENDPOINTS.HOUSEHOLDS
            );
            
            if (data && data.households) {
                const found = data.households.find(h => h.id === householdId);
                if (found) return found;
            }
            
            // If not in cache, fetch directly from server
            const response = await fetch(`${API_ENDPOINTS.HOUSEHOLDS}/${householdId}`, {
                headers: { 'Authorization': `Bearer ${authToken}` }
            });
            
            if (!response.ok) throw new Error('Household not found');
            return await response.json();
            
        } catch (error) {
            console.error('Failed to get household:', error);
            return null;
        }
    },

    /**
     * Search households by name or barangay
     */
    searchHouseholds: async (searchTerm) => {
        try {
            const data = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.HOUSEHOLDS,
                API_ENDPOINTS.HOUSEHOLDS
            );
            
            if (data && data.households) {
                const term = searchTerm.toLowerCase().trim();
                return data.households.filter(h => 
                    (h.head_first_name && h.head_first_name.toLowerCase().includes(term)) ||
                    (h.head_last_name && h.head_last_name.toLowerCase().includes(term)) ||
                    (h.barangay && h.barangay.toLowerCase().includes(term))
                );
            }
            
            return [];
        } catch (error) {
            console.error('Search failed:', error);
            return [];
        }
    },
};

// ============================================================
// SPECIALIZED CACHE FUNCTIONS FOR FINANCIAL ASSISTANCE
// ============================================================

export const FinancialCache = {
    
    /**
     * Get cached financial assistance or fetch from server
     */
    getFinancialAssistance: async (forceRefresh = false) => {
        return await LocalCacheEngine.getCachedData(
            CACHE_KEYS.FINANCIAL_ASSISTANCE,
            API_ENDPOINTS.FINANCIAL_ASSISTANCE,
            forceRefresh
        );
    },

    /**
     * Get financial assistance summary
     */
    getFinancialSummary: async () => {
        try {
            const data = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.FINANCIAL_ASSISTANCE,
                API_ENDPOINTS.FINANCIAL_ASSISTANCE
            );
            
            if (data && data.summary) {
                return data.summary;
            }
            
            // Fetch summary directly if not in cache
            const response = await fetch(`${API_ENDPOINTS.FINANCIAL_ASSISTANCE}/summary`, {
                headers: { 'Authorization': `Bearer ${authToken}` }
            });
            
            if (!response.ok) throw new Error('Failed to fetch summary');
            return await response.json();
            
        } catch (error) {
            console.error('Failed to get financial summary:', error);
            return { total: 0, pending: 0, approved: 0, rejected: 0, total_disbursed: 0 };
        }
    },

    /**
     * Get applications by status
     */
    getApplicationsByStatus: async (status) => {
        try {
            const data = await LocalCacheEngine.getCachedData(
                CACHE_KEYS.FINANCIAL_ASSISTANCE,
                API_ENDPOINTS.FINANCIAL_ASSISTANCE
            );
            
            if (data && data.applications) {
                return data.applications.filter(app => app.status === status);
            }
            
            return [];
        } catch (error) {
            console.error('Failed to filter applications:', error);
            return [];
        }
    },
};

// ============================================================
// EXPORT ALL CACHE UTILITIES
// ============================================================

export default {
    LocalCacheEngine,
    HouseholdCache,
    FinancialCache,
    CACHE_KEYS,
    API_ENDPOINTS,
    setAuthToken,
    getAuthToken,
};