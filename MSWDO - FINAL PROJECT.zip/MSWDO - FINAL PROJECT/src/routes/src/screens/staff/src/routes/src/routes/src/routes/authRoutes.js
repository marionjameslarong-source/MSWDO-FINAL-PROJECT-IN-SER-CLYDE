// File: src/routes/authRoutes.js
// Authentication Routes - Login, Logout, Session Management

const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { db } = require('../config/database');

// JWT Secret - Should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || 'mswdo_secret_key_2026';

/**
 * POST /api/v1/auth/login
 * Authenticate user and return JWT token
 */
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({
            status: 'ERROR',
            message: 'Username and password are required'
        });
    }
    
    try {
        // Find user by username
        const userResult = await db.query(
            'SELECT id, username, full_name, email, role, password FROM users WHERE username = $1',
            [username]
        );
        
        if (userResult.rows.length === 0) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'Invalid username or password'
            });
        }
        
        const user = userResult.rows[0];
        
        // Verify password
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'Invalid username or password'
            });
        }
        
        // Generate JWT token
        const token = jwt.sign(
            {
                id: user.id,
                username: user.username,
                role: user.role,
                full_name: user.full_name
            },
            JWT_SECRET,
            { expiresIn: '24h' }
        );
        
        // Log login activity
        await db.query(
            'INSERT INTO activity_logs (user_id, action, details, created_at) VALUES ($1, $2, $3, NOW())',
            [user.id, 'user_login', `User ${username} logged in`]
        );
        
        // Return user data without password
        delete user.password;
        
        return res.status(200).json({
            status: 'SUCCESS',
            message: 'Login successful',
            data: {
                token: token,
                user: user
            }
        });
        
    } catch (error) {
        console.error('Login error:', error);
        return res.status(500).json({
            status: 'ERROR',
            message: 'Login failed: ' + error.message
        });
    }
});

/**
 * POST /api/v1/auth/logout
 * Logout user - Invalidate token (client-side)
 */
router.post('/logout', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Log logout activity
        await db.query(
            'INSERT INTO activity_logs (user_id, action, details, created_at) VALUES ($1, $2, $3, NOW())',
            [decoded.id, 'user_logout', `User ${decoded.username} logged out`]
        );
        
        return res.status(200).json({
            status: 'SUCCESS',
            message: 'Logout successful'
        });
        
    } catch (error) {
        // Token might be invalid, but we still want to logout
        return res.status(200).json({
            status: 'SUCCESS',
            message: 'Logout successful'
        });
    }
});

/**
 * POST /api/v1/auth/refresh
 * Refresh JWT token
 */
router.post('/refresh', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        
        if (!token) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'No token provided'
            });
        }
        
        // Verify current token
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Generate new token
        const newToken = jwt.sign(
            {
                id: decoded.id,
                username: decoded.username,
                role: decoded.role,
                full_name: decoded.full_name
            },
            JWT_SECRET,
            { expiresIn: '24h' }
        );
        
        return res.status(200).json({
            status: 'SUCCESS',
            message: 'Token refreshed',
            data: {
                token: newToken
            }
        });
        
    } catch (error) {
        return res.status(401).json({
            status: 'ERROR',
            message: 'Invalid or expired token'
        });
    }
});

/**
 * GET /api/v1/auth/verify
 * Verify if token is valid
 */
router.get('/verify', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        
        if (!token) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'No token provided'
            });
        }
        
        const decoded = jwt.verify(token, JWT_SECRET);
        
        return res.status(200).json({
            status: 'SUCCESS',
            message: 'Token is valid',
            data: {
                user: {
                    id: decoded.id,
                    username: decoded.username,
                    role: decoded.role,
                    full_name: decoded.full_name
                }
            }
        });
        
    } catch (error) {
        return res.status(401).json({
            status: 'ERROR',
            message: 'Invalid or expired token'
        });
    }
});

module.exports = router;