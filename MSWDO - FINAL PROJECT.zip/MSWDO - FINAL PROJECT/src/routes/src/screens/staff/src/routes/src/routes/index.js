// File: src/routes/index.js
// Main Router - Centralizes all API routes for the MSWDO Portal Backend

const express = require('express');
const router = express.Router();

// Import route modules
const householdRoutes = require('./householdRoutes');
const idApplicationRoutes = require('./idApplicationRoutes');
const financialAssistanceRoutes = require('./financialAssistanceRoutes');
const staffProfileRoutes = require('./staffProfileRoutes');
const residentProfileRoutes = require('./residentProfileRoutes');
const welfareProgramsRoutes = require('./welfareProgramsRoutes');
const reportsRoutes = require('./reportsRoutes');
const authRoutes = require('./authRoutes');

// ============================================================
// AUTHENTICATION ROUTES
// ============================================================
// Login, Logout, Session management
router.use('/api/v1/auth', authRoutes);

// ============================================================
// STAFF ROUTES
// ============================================================

// 1. Staff Profile Management
// GET /api/v1/staff/profile - Get staff profile
// POST /api/v1/staff/profile/device-register - Register mobile device
// PATCH /api/v1/staff/profile/status - Update operational status
// POST /api/v1/staff/profile/session-refresh - Refresh mobile session
router.use('/api/v1/staff', staffProfileRoutes);

// 2. Household Records Management
// GET /api/v1/staff/households - Get all households
// GET /api/v1/staff/households/:id - Get single household
// PATCH /api/v1/staff/households/:id/poverty-override - Override poverty status
// POST /api/v1/staff/households/:id/process-and-notify - Process and notify resident
router.use('/api/v1/staff', householdRoutes);

// 3. ID Application Management
// GET /api/v1/staff/id-applications - Get all ID applications
// GET /api/v1/staff/id-applications/:id - Get single ID application
// POST /api/v1/staff/id-applications/:id/approve - Approve ID application
// PUT /api/v1/staff/id-applications/:id/issue - Issue ID card
// PATCH /api/v1/staff/id-applications/:id/reject - Reject ID application
// GET /api/v1/staff/id-applications/:id/validate-attachments - Validate attachments
// POST /api/v1/staff/id-applications/bulk-approve - Bulk approve
// GET /api/v1/staff/id-applications/stats - Get statistics
router.use('/api/v1/staff', idApplicationRoutes);

// 4. Financial Assistance Management
// GET /api/v1/staff/financial-assistance - Get all financial assistance applications
// POST /api/v1/staff/financial-assistance/:id/assess - Assess application
// POST /api/v1/staff/financial-assistance/:id/disburse - Disburse funds
// PATCH /api/v1/staff/financial-assistance/:id/reject - Reject application
router.use('/api/v1/staff/financial-assistance', financialAssistanceRoutes);

// 5. Welfare Programs Management
// GET /api/v1/staff/programs/:program_code/applicants - Get program applicants
// PATCH /api/v1/staff/programs/:program_code/applications/:id - Update application
// POST /api/v1/staff/programs/AICS/disburse - AICS disbursement
router.use('/api/v1/staff/programs', welfareProgramsRoutes);

// 6. Reports
// GET /api/v1/staff/reports/summary - Get summary report
// GET /api/v1/staff/reports/households - Get household report
// GET /api/v1/staff/reports/applications - Get applications report
router.use('/api/v1/staff/reports', reportsRoutes);

// ============================================================
// RESIDENT ROUTES
// ============================================================

// 1. Resident Profile
// GET /api/v1/residents/profile/status - Check profile status
// GET /api/v1/residents/profile - Get resident profile
// POST /api/v1/residents/profile/attachments - Upload attachments
// PATCH /api/v1/residents/profile/contact - Update contact info
// POST /api/v1/residents/profile/push-token - Register push token
router.use('/api/v1/residents', residentProfileRoutes);

// 2. Resident Notifications
// GET /api/v1/residents/notifications - Get notification inbox
// PATCH /api/v1/residents/notifications/:id/read - Mark notification as read
router.use('/api/v1/residents', residentProfileRoutes);

// ============================================================
// SYSTEM ROUTES
// ============================================================

// Health Check - For monitoring and load balancers
router.get('/api/v1/health', (req, res) => {
    res.status(200).json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        version: '2.4.1',
        uptime: process.uptime()
    });
});

// API Information - For documentation and discovery
router.get('/api/v1/info', (req, res) => {
    res.status(200).json({
        name: 'MSWDO Portal API',
        version: '2.4.1',
        description: 'Municipal Social Welfare and Development Office API',
        endpoints: {
            staff: {
                profile: '/api/v1/staff/profile',
                households: '/api/v1/staff/households',
                id_applications: '/api/v1/staff/id-applications',
                financial_assistance: '/api/v1/staff/financial-assistance',
                programs: '/api/v1/staff/programs',
                reports: '/api/v1/staff/reports'
            },
            resident: {
                profile: '/api/v1/residents/profile',
                notifications: '/api/v1/residents/notifications'
            },
            auth: '/api/v1/auth',
            health: '/api/v1/health'
        }
    });
});

// ============================================================
// 404 Handler - Catch all unmatched routes
// ============================================================
router.use('*', (req, res) => {
    res.status(404).json({
        status: 'ERROR',
        message: `Route not found: ${req.method} ${req.originalUrl}`,
        timestamp: new Date().toISOString()
    });
});

module.exports = router;