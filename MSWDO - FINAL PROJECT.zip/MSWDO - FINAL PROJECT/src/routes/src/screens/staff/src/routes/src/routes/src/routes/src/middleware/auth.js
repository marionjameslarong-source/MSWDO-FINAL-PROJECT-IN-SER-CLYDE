// File: src/middleware/auth.js
// Authentication Middleware - JWT Verification and Role Authorization

const jwt = require('jsonwebtoken');
const { db } = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET || 'mswdo_secret_key_2026';

/**
 * Authenticate Token Middleware
 * Verifies JWT token and attaches user data to request
 */
const authenticateToken = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'Authentication required. Please provide a valid token.'
            });
        }
        
        const token = authHeader.split(' ')[1];
        
        // Verify token
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Check if user still exists in database
        const userResult = await db.query(
            'SELECT id, username, full_name, role FROM users WHERE id = $1 AND status = $2',
            [decoded.id, 'active']
        );
        
        if (userResult.rows.length === 0) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'User account not found or inactive'
            });
        }
        
        // Attach user to request
        req.user = userResult.rows[0];
        req.user.id = parseInt(req.user.id);
        
        next();
        
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                status: 'ERROR',
                message: 'Invalid token'
            });
        }
        
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                status: 'ERROR',
                message: 'Token expired. Please login again.'
            });
        }
        
        console.error('Authentication error:', error);
        return res.status(500).json({
            status: 'ERROR',
            message: 'Authentication failed'
        });
    }
};

/**
 * Authorize Role Middleware
 * Checks if user has the required role(s)
 */
const authorizeRole = (allowedRoles) => {
    return async (req, res, next) => {
        try {
            if (!req.user) {
                return res.status(401).json({
                    status: 'ERROR',
                    message: 'Authentication required'
                });
            }
            
            const userRole = req.user.role;
            
            if (!allowedRoles.includes(userRole)) {
                // Log unauthorized attempt
                await db.query(
                    'INSERT INTO activity_logs (user_id, action, details, created_at) VALUES ($1, $2, $3, NOW())',
                    [req.user.id, 'unauthorized_access', `User ${req.user.username} attempted to access ${req.originalUrl}`]
                );
                
                return res.status(403).json({
                    status: 'ERROR',
                    message: 'Access denied. You do not have the required permissions.',
                    required_roles: allowedRoles,
                    user_role: userRole
                });
            }
            
            next();
            
        } catch (error) {
            console.error('Authorization error:', error);
            return res.status(500).json({
                status: 'ERROR',
                message: 'Authorization failed'
            });
        }
    };
};

/**
 * Check if user has VAWC officer clearance
 */
const requireVawcClearance = async (req, res, next) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'Authentication required'
            });
        }
        
        const userRole = req.user.role;
        const allowedVawcRoles = ['admin', 'vawc_officer', 'social_worker'];
        
        if (!allowedVawcRoles.includes(userRole)) {
            // Log VAWC access attempt
            await db.query(
                'INSERT INTO activity_logs (user_id, action, details, created_at) VALUES ($1, $2, $3, NOW())',
                [req.user.id, 'vawc_access_denied', `User ${req.user.username} attempted to access VAWC module`]
            );
            
            return res.status(403).json({
                status: 'ERROR',
                message: 'Access denied. VAWC module requires special clearance.'
            });
        }
        
        next();
        
    } catch (error) {
        console.error('VAWC clearance error:', error);
        return res.status(500).json({
            status: 'ERROR',
            message: 'Authorization failed'
        });
    }
};

/**
 * Check if user has admin privileges
 */
const requireAdmin = async (req, res, next) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                status: 'ERROR',
                message: 'Authentication required'
            });
        }
        
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                status: 'ERROR',
                message: 'Access denied. Admin privileges required.'
            });
        }
        
        next();
        
    } catch (error) {
        console.error('Admin check error:', error);
        return res.status(500).json({
            status: 'ERROR',
            message: 'Authorization failed'
        });
    }
};

module.exports = {
    authenticateToken,
    authorizeRole,
    requireVawcClearance,
    requireAdmin
};