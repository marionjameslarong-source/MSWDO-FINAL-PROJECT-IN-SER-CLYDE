// File: src/routes/idApplicationRoutes.js
// Backend API Routes for ID Application Processing with File Validation

const express = require('express');
const router = express.Router();
const axios = require('axios');
const { db } = require('../config/database');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

/**
 * ============================================================
 * 1. GET ID APPLICATIONS QUEUE
 * ============================================================
 * Fetches all ID applications with optional status filtering
 * 
 * GET /api/v1/staff/id-applications
 * Query Params: status (optional) - e.g., PENDING, PENDING_PRINT, APPROVED, ISSUED, REJECTED
 */
router.get('/id-applications', 
  authenticateToken, 
  authorizeRole(['staff', 'social_worker', 'encoder', 'admin']),
  async (req, res) => {
    try {
      const { status } = req.query;
      let query = `
        SELECT 
          ia.*, 
          u.full_name as applicant_name, 
          u.username, 
          u.email, 
          u.contact_number 
        FROM id_applications ia
        LEFT JOIN users u ON ia.user_id = u.id
        WHERE 1=1
      `;
      const params = [];
      
      if (status && status !== 'all') {
        query += ` AND ia.status = $1`;
        params.push(status);
      }
      
      query += ` ORDER BY ia.created_at DESC`;
      
      const result = await db.query(query, params);
      
      return res.status(200).json({
        status: 'SUCCESS',
        data: result.rows,
        count: result.rows.length
      });
      
    } catch (error) {
      console.error('Error fetching ID applications:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to fetch ID applications'
      });
    }
  }
);

/**
 * ============================================================
 * 2. GET SINGLE ID APPLICATION (with file validation check)
 * ============================================================
 * Fetches a single ID application with file validation status
 * 
 * GET /api/v1/staff/id-applications/:id_application_id
 */
router.get('/id-applications/:id_application_id',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'encoder', 'admin']),
  async (req, res) => {
    try {
      const { id_application_id } = req.params;
      
      const result = await db.query(
        `
        SELECT 
          ia.*, 
          u.full_name as applicant_name, 
          u.username, 
          u.email, 
          u.contact_number 
        FROM id_applications ia
        LEFT JOIN users u ON ia.user_id = u.id
        WHERE ia.id = $1
        `,
        [id_application_id]
      );
      
      if (result.rows.length === 0) {
        return res.status(404).json({
          status: 'ERROR',
          message: 'ID application not found'
        });
      }
      
      const application = result.rows[0];
      
      // Check file validation status
      let fileValidation = {
        photo_valid: false,
        signature_valid: false,
        photo_url: application.photo_url,
        signature_url: application.signature_url
      };
      
      // Validate photo URL
      if (application.photo_url) {
        try {
          const fileCheck = await axios.head(application.photo_url, { timeout: 5000 });
          fileValidation.photo_valid = (fileCheck.status === 200 && parseInt(fileCheck.headers['content-length'] || 0) > 0);
        } catch (error) {
          fileValidation.photo_valid = false;
        }
      }
      
      // Validate signature URL
      if (application.signature_url) {
        try {
          const fileCheck = await axios.head(application.signature_url, { timeout: 5000 });
          fileValidation.signature_valid = (fileCheck.status === 200 && parseInt(fileCheck.headers['content-length'] || 0) > 0);
        } catch (error) {
          fileValidation.signature_valid = false;
        }
      }
      
      return res.status(200).json({
        status: 'SUCCESS',
        data: {
          ...application,
          file_validation: fileValidation
        }
      });
      
    } catch (error) {
      console.error('Error fetching ID application:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to fetch ID application'
      });
    }
  }
);

/**
 * ============================================================
 * 3. APPROVE ID APPLICATION (Move to PENDING_PRINT)
 * ============================================================
 * Validates files before moving to printing queue
 * 
 * POST /api/v1/staff/id-applications/:id_application_id/approve
 */
router.post('/id-applications/:id_application_id/approve',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'encoder', 'admin']),
  async (req, res) => {
    const { id_application_id } = req.params;
    const { quality_check_passed, system_remarks } = req.body;
    
    try {
      // Step 1: Fetch application data
      const appResult = await db.query(
        'SELECT photo_url, signature_url, status FROM id_applications WHERE id = $1',
        [id_application_id]
      );
      
      if (appResult.rows.length === 0) {
        return res.status(404).json({
          status: 'ERROR',
          message: 'ID application not found'
        });
      }
      
      const application = appResult.rows[0];
      
      // Step 2: Check if already approved
      if (application.status === 'approved' || application.status === 'issued') {
        return res.status(422).json({
          status: 'ERROR',
          message: 'This application has already been processed'
        });
      }
      
      // Step 3: CRUCIAL VALIDATION - Check for photo URL
      if (!application.photo_url) {
        return res.status(422).json({
          status: 'ERROR',
          error: 'MISSING_ATTACHMENT',
          message: 'Failsafe Block: This application does not contain an ID photo link. Approval denied.'
        });
      }
      
      // Step 4: Live Network Check - Verify photo file is accessible
      try {
        const fileCheck = await axios.head(application.photo_url, { timeout: 5000 });
        
        // Check if the server responds with an error or returns an empty file (0 bytes)
        if (fileCheck.status !== 200 || parseInt(fileCheck.headers['content-length'] || 0) === 0) {
          throw new Error('CORRUPTED_FILE');
        }
      } catch (networkError) {
        // Block if the link returns a 404, 500 error, or broken image data
        return res.status(422).json({
          status: 'ERROR',
          error: 'CORRUPTED_ATTACHMENT_LINK',
          message: 'Failsafe Block: The resident\'s uploaded photo file link is broken, missing from cloud storage, or corrupted. Please reject the application so the resident can re-upload.'
        });
      }
      
      // Step 5: Validate signature if it exists
      if (application.signature_url) {
        try {
          const sigCheck = await axios.head(application.signature_url, { timeout: 5000 });
          if (sigCheck.status !== 200 || parseInt(sigCheck.headers['content-length'] || 0) === 0) {
            // Log warning but don't block approval
            console.warn(`Signature file for application ${id_application_id} may be corrupted`);
          }
        } catch (sigError) {
          // Log warning but don't block approval
          console.warn(`Signature file for application ${id_application_id} is not accessible`);
        }
      }
      
      // Step 6: Generate tracking number
      const trackingNumber = 'ID-' + new Date().getFullYear() + '-' + String(Math.floor(10000 + Math.random() * 90000)).padStart(5, '0');
      
      // Step 7: Update application status
      await db.query(
        `UPDATE id_applications 
         SET status = 'pending_print', 
             review_notes = $1, 
             reviewed_by = $2, 
             reviewed_at = NOW(), 
             updated_at = NOW(),
             tracking_number = $3,
             quality_check_passed = $4
         WHERE id = $5`,
        [system_remarks || 'Photo and signature verified clear. Moving to production queue.', req.user.id, trackingNumber, quality_check_passed || 1, id_application_id]
      );
      
      // Step 8: Log activity
      await db.query(
        `INSERT INTO activity_logs (user_id, action, details, created_at)
         VALUES ($1, 'id_application_approved', $2, NOW())`,
        [req.user.id, `ID Application #${id_application_id} approved with tracking #${trackingNumber}`]
      );
      
      return res.status(200).json({
        status: 'SUCCESS',
        message: 'ID Application approved and moved to printing queue.',
        data: {
          application_id: id_application_id,
          tracking_number: trackingNumber,
          status: 'pending_print'
        }
      });
      
    } catch (error) {
      console.error('Error approving ID application:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to approve ID application: ' + error.message
      });
    }
  }
);

/**
 * ============================================================
 * 4. ISSUE ID CARD (Activate with Serial Number)
 * ============================================================
 * Validates files before issuing the ID card
 * 
 * PUT /api/v1/staff/id-applications/:id_application_id/issue
 */
router.put('/id-applications/:id_application_id/issue',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'encoder', 'admin']),
  async (req, res) => {
    const { id_application_id } = req.params;
    const { physical_card_serial_number, issuance_method } = req.body;
    
    // Validate required fields
    if (!physical_card_serial_number) {
      return res.status(400).json({
        status: 'ERROR',
        message: 'Physical card serial number is required'
      });
    }
    
    try {
      // Step 1: Fetch the profile image attachment URL from the database
      const appResult = await db.query(
        'SELECT photo_url, signature_url, status, tracking_number FROM id_applications WHERE id = $1',
        [id_application_id]
      );
      
      if (appResult.rows.length === 0) {
        return res.status(404).json({
          status: 'ERROR',
          message: 'ID application not found'
        });
      }
      
      const application = appResult.rows[0];
      
      // Step 2: Check if already issued
      if (application.status === 'issued') {
        return res.status(422).json({
          status: 'ERROR',
          message: 'This ID card has already been issued'
        });
      }
      
      // Step 3: Check if application is in the correct state
      if (application.status !== 'pending_print' && application.status !== 'approved') {
        return res.status(422).json({
          status: 'ERROR',
          message: 'Application must be in pending_print or approved status to issue ID'
        });
      }
      
      // Step 4: CRUCIAL VALIDATION RULE - Block if the string link is empty
      if (!application.photo_url) {
        return res.status(422).json({
          status: 'ERROR',
          error: 'MISSING_ATTACHMENT',
          message: 'Failsafe Block: This application does not contain an ID photo link. Activation denied.'
        });
      }
      
      // Step 5: Live Network Check to verify if the file link is broken or corrupted
      try {
        const fileCheck = await axios.head(application.photo_url, { timeout: 5000 });
        
        // Check if the server responds with an error or returns an empty file (0 bytes)
        if (fileCheck.status !== 200 || parseInt(fileCheck.headers['content-length'] || 0) === 0) {
          throw new Error('CORRUPTED_FILE');
        }
      } catch (networkError) {
        // Block if the link returns a 404, 500 error, or broken image data
        return res.status(422).json({
          status: 'ERROR',
          error: 'CORRUPTED_ATTACHMENT_LINK',
          message: 'Failsafe Block: The resident\'s uploaded photo file link is broken, missing from cloud storage, or corrupted. Please reject the application so the resident can re-upload.'
        });
      }
      
      // Step 6: Check if serial number is already used
      const serialCheck = await db.query(
        'SELECT id FROM id_applications WHERE physical_card_serial = $1 AND id != $2',
        [physical_card_serial_number, id_application_id]
      );
      
      if (serialCheck.rows.length > 0) {
        return res.status(422).json({
          status: 'ERROR',
          message: 'This physical card serial number is already assigned to another ID card'
        });
      }
      
      // Step 7: Proceed with database update only if all safety checks pass
      await db.query(
        `UPDATE id_applications 
         SET status = 'issued', 
             physical_card_serial = $1, 
             issuance_method = $2, 
             date_issued = NOW(),
             issued_by = $3,
             updated_at = NOW()
         WHERE id = $4`,
        [physical_card_serial_number, issuance_method || 'WALK_IN_PICKUP', req.user.id, id_application_id]
      );
      
      // Step 8: Log activity
      await db.query(
        `INSERT INTO activity_logs (user_id, action, details, created_at)
         VALUES ($1, 'id_card_issued', $2, NOW())`,
        [req.user.id, `ID Card #${id_application_id} issued with serial #${physical_card_serial_number}`]
      );
      
      return res.status(200).json({
        status: 'SUCCESS',
        message: 'ID Card activated and issued cleanly.',
        data: {
          application_id: id_application_id,
          physical_card_serial: physical_card_serial_number,
          issuance_method: issuance_method || 'WALK_IN_PICKUP',
          status: 'issued',
          date_issued: new Date().toISOString()
        }
      });
      
    } catch (error) {
      console.error('Error issuing ID card:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to issue ID card: ' + error.message
      });
    }
  }
);

/**
 * ============================================================
 * 5. REJECT ID APPLICATION
 * ============================================================
 * Rejects an ID application with reason and instructions
 * 
 * PATCH /api/v1/staff/id-applications/:id_application_id/reject
 */
router.patch('/id-applications/:id_application_id/reject',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'encoder', 'admin']),
  async (req, res) => {
    const { id_application_id } = req.params;
    const { rejection_reason, instruction_to_resident } = req.body;
    
    if (!rejection_reason) {
      return res.status(400).json({
        status: 'ERROR',
        message: 'Rejection reason is required'
      });
    }
    
    try {
      // Step 1: Check if application exists
      const appResult = await db.query(
        'SELECT status FROM id_applications WHERE id = $1',
        [id_application_id]
      );
      
      if (appResult.rows.length === 0) {
        return res.status(404).json({
          status: 'ERROR',
          message: 'ID application not found'
        });
      }
      
      // Step 2: Update application status to rejected
      await db.query(
        `UPDATE id_applications 
         SET status = 'rejected', 
             review_notes = CONCAT('Rejection Code: ', $1, ' - Instruction: ', $2),
             rejection_reason = $1,
             instruction_to_resident = $2,
             reviewed_by = $3,
             reviewed_at = NOW(),
             updated_at = NOW()
         WHERE id = $4`,
        [rejection_reason, instruction_to_resident || 'Please review the requirements and re-submit your application.', req.user.id, id_application_id]
      );
      
      // Step 3: Log activity
      await db.query(
        `INSERT INTO activity_logs (user_id, action, details, created_at)
         VALUES ($1, 'id_application_rejected', $2, NOW())`,
        [req.user.id, `ID Application #${id_application_id} rejected. Reason: ${rejection_reason}`]
      );
      
      return res.status(200).json({
        status: 'SUCCESS',
        message: 'ID Application rejected successfully.',
        data: {
          application_id: id_application_id,
          status: 'rejected',
          rejection_reason: rejection_reason
        }
      });
      
    } catch (error) {
      console.error('Error rejecting ID application:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to reject ID application: ' + error.message
      });
    }
  }
);

/**
 * ============================================================
 * 6. VALIDATE ATTACHMENTS (Pre-Approval Check)
 * ============================================================
 * Checks if file attachments are valid without changing status
 * 
 * GET /api/v1/staff/id-applications/:id_application_id/validate-attachments
 */
router.get('/id-applications/:id_application_id/validate-attachments',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'encoder', 'admin']),
  async (req, res) => {
    const { id_application_id } = req.params;
    
    try {
      const appResult = await db.query(
        'SELECT photo_url, signature_url FROM id_applications WHERE id = $1',
        [id_application_id]
      );
      
      if (appResult.rows.length === 0) {
        return res.status(404).json({
          status: 'ERROR',
          message: 'ID application not found'
        });
      }
      
      const application = appResult.rows[0];
      const validationResult = {
        photo: {
          url: application.photo_url,
          valid: false,
          status: 'MISSING'
        },
        signature: {
          url: application.signature_url,
          valid: false,
          status: 'MISSING'
        }
      };
      
      // Validate photo
      if (application.photo_url) {
        try {
          const fileCheck = await axios.head(application.photo_url, { timeout: 5000 });
          const isValid = (fileCheck.status === 200 && parseInt(fileCheck.headers['content-length'] || 0) > 0);
          validationResult.photo.valid = isValid;
          validationResult.photo.status = isValid ? 'VALID' : 'CORRUPTED';
          validationResult.photo.file_size = parseInt(fileCheck.headers['content-length'] || 0);
          validationResult.photo.content_type = fileCheck.headers['content-type'] || 'unknown';
        } catch (error) {
          validationResult.photo.valid = false;
          validationResult.photo.status = 'BROKEN_LINK';
        }
      }
      
      // Validate signature
      if (application.signature_url) {
        try {
          const fileCheck = await axios.head(application.signature_url, { timeout: 5000 });
          const isValid = (fileCheck.status === 200 && parseInt(fileCheck.headers['content-length'] || 0) > 0);
          validationResult.signature.valid = isValid;
          validationResult.signature.status = isValid ? 'VALID' : 'CORRUPTED';
          validationResult.signature.file_size = parseInt(fileCheck.headers['content-length'] || 0);
          validationResult.signature.content_type = fileCheck.headers['content-type'] || 'unknown';
        } catch (error) {
          validationResult.signature.valid = false;
          validationResult.signature.status = 'BROKEN_LINK';
        }
      }
      
      // Determine overall validation status
      validationResult.overall_valid = validationResult.photo.valid;
      validationResult.overall_status = validationResult.photo.valid ? 'PASSED' : 'FAILED';
      
      return res.status(200).json({
        status: 'SUCCESS',
        data: validationResult
      });
      
    } catch (error) {
      console.error('Error validating attachments:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to validate attachments: ' + error.message
      });
    }
  }
);

/**
 * ============================================================
 * 7. BULK APPROVE ID APPLICATIONS
 * ============================================================
 * Approves multiple ID applications at once
 * 
 * POST /api/v1/staff/id-applications/bulk-approve
 */
router.post('/id-applications/bulk-approve',
  authenticateToken,
  authorizeRole(['admin']),
  async (req, res) => {
    const { application_ids, system_remarks } = req.body;
    
    if (!application_ids || !Array.isArray(application_ids) || application_ids.length === 0) {
      return res.status(400).json({
        status: 'ERROR',
        message: 'At least one application ID is required'
      });
    }
    
    const results = [];
    const errors = [];
    
    for (const id of application_ids) {
      try {
        // Check if application exists and has valid photo
        const appResult = await db.query(
          'SELECT photo_url, status FROM id_applications WHERE id = $1',
          [id]
        );
        
        if (appResult.rows.length === 0) {
          errors.push({ id, error: 'Application not found' });
          continue;
        }
        
        const app = appResult.rows[0];
        
        if (app.status === 'issued' || app.status === 'approved') {
          errors.push({ id, error: 'Application already processed' });
          continue;
        }
        
        if (!app.photo_url) {
          errors.push({ id, error: 'Missing photo attachment' });
          continue;
        }
        
        // Validate photo URL
        try {
          const fileCheck = await axios.head(app.photo_url, { timeout: 5000 });
          if (fileCheck.status !== 200 || parseInt(fileCheck.headers['content-length'] || 0) === 0) {
            errors.push({ id, error: 'Corrupted photo file' });
            continue;
          }
        } catch (error) {
          errors.push({ id, error: 'Broken photo link' });
          continue;
        }
        
        // Generate tracking number
        const trackingNumber = 'ID-' + new Date().getFullYear() + '-' + String(Math.floor(10000 + Math.random() * 90000)).padStart(5, '0');
        
        // Update application
        await db.query(
          `UPDATE id_applications 
           SET status = 'pending_print', 
               review_notes = $1, 
               reviewed_by = $2, 
               reviewed_at = NOW(), 
               updated_at = NOW(),
               tracking_number = $3,
               quality_check_passed = 1
           WHERE id = $4`,
          [system_remarks || 'Bulk approved. Photo verified clear.', req.user.id, trackingNumber, id]
        );
        
        results.push({ id, tracking_number: trackingNumber });
        
      } catch (error) {
        errors.push({ id, error: error.message });
      }
    }
    
    return res.status(200).json({
      status: 'SUCCESS',
      message: `Bulk approval completed. ${results.length} approved, ${errors.length} failed.`,
      data: {
        approved: results,
        failed: errors
      }
    });
  }
);

/**
 * ============================================================
 * 8. GET ID APPLICATION STATISTICS
 * ============================================================
 * Returns statistics for ID applications
 * 
 * GET /api/v1/staff/id-applications/stats
 */
router.get('/id-applications/stats',
  authenticateToken,
  authorizeRole(['staff', 'social_worker', 'encoder', 'admin']),
  async (req, res) => {
    try {
      const stats = await db.query(`
        SELECT 
          COUNT(*) FILTER (WHERE status = 'pending') as pending_count,
          COUNT(*) FILTER (WHERE status = 'pending_print') as pending_print_count,
          COUNT(*) FILTER (WHERE status = 'approved') as approved_count,
          COUNT(*) FILTER (WHERE status = 'issued') as issued_count,
          COUNT(*) FILTER (WHERE status = 'rejected') as rejected_count,
          COUNT(*) as total_count
        FROM id_applications
      `);
      
      // Get monthly trend
      const monthlyTrend = await db.query(`
        SELECT 
          DATE_TRUNC('month', created_at) as month,
          COUNT(*) as count
        FROM id_applications
        WHERE created_at >= NOW() - INTERVAL '6 months'
        GROUP BY DATE_TRUNC('month', created_at)
        ORDER BY month ASC
      `);
      
      return res.status(200).json({
        status: 'SUCCESS',
        data: {
          summary: stats.rows[0],
          monthly_trend: monthlyTrend.rows
        }
      });
      
    } catch (error) {
      console.error('Error fetching ID application stats:', error);
      return res.status(500).json({
        status: 'ERROR',
        message: 'Failed to fetch statistics'
      });
    }
  }
);

module.exports = router;