/**
 * useCachedData - React Hook for using cached data in components
 * 
 * This hook provides a simple way to load cached data with:
 * - Automatic cache checking
 * - Loading states
 * - Error handling
 * - Pull-to-refresh support
 */

import { useState, useEffect, useCallback } from 'react';
import { LocalCacheEngine, HouseholdCache, FinancialCache } from '../utils/localStorageCache';

/**
 * Generic hook for caching any data
 */
export const useCachedData = (cacheKey, apiEndpoint, dependencies = []) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState(null);
    const [cacheStatus, setCacheStatus] = useState({ isFresh: false, age: null });

    const loadData = useCallback(async (forceRefresh = false) => {
        try {
            if (forceRefresh) {
                setRefreshing(true);
            } else {
                setLoading(true);
            }
            
            setError(null);
            
            const freshData = await LocalCacheEngine.getCachedData(
                cacheKey,
                apiEndpoint,
                forceRefresh
            );
            
            setData(freshData);
            
            // Check cache status
            const isFresh = await LocalCacheEngine.isCacheFresh(cacheKey);
            const timestampKey = cacheKey.replace('CACHE_', 'CACHE_TIMESTAMP_');
            const timestamp = await AsyncStorage.getItem(timestampKey);
            const age = timestamp ? Math.round((Date.now() - parseInt(timestamp, 10)) / 60000) : null;
            
            setCacheStatus({ isFresh, age });
            
        } catch (err) {
            setError(err.message || 'Failed to load data');
            console.error('useCachedData error:', err);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, [cacheKey, apiEndpoint]);

    // Load data on mount and when dependencies change
    useEffect(() => {
        loadData(false);
    }, [...dependencies]);

    // Force refresh function (for pull-to-refresh)
    const refresh = useCallback(() => {
        return loadData(true);
    }, [loadData]);

    // Clear cache function
    const clearCache = useCallback(async () => {
        await LocalCacheEngine.clearCache(cacheKey);
        await loadData(false);
    }, [cacheKey, loadData]);

    return {
        data,
        loading,
        refreshing,
        error,
        cacheStatus,
        refresh,
        clearCache,
        isCacheFresh: cacheStatus.isFresh,
    };
};

/**
 * Hook for households data
 */
export const useHouseholds = () => {
    const [households, setHouseholds] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState(null);
    const [cacheStatus, setCacheStatus] = useState({ isFresh: false, age: null });

    const loadHouseholds = useCallback(async (forceRefresh = false) => {
        try {
            if (forceRefresh) {
                setRefreshing(true);
            } else {
                setLoading(true);
            }
            
            setError(null);
            
            const data = await HouseholdCache.getHouseholds(forceRefresh);
            setHouseholds(data.households || []);
            
            // Check cache status
            const isFresh = await LocalCacheEngine.isCacheFresh('CACHE_HOUSEHOLD_REGISTRY');
            const timestamp = await AsyncStorage.getItem('CACHE_TIMESTAMP_HOUSEHOLD_REGISTRY');
            const age = timestamp ? Math.round((Date.now() - parseInt(timestamp, 10)) / 60000) : null;
            
            setCacheStatus({ isFresh, age });
            
        } catch (err) {
            setError(err.message || 'Failed to load households');
            console.error('useHouseholds error:', err);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    // Load on mount
    useEffect(() => {
        loadHouseholds(false);
    }, []);

    const refresh = useCallback(() => loadHouseholds(true), [loadHouseholds]);

    const searchHouseholds = useCallback(async (term) => {
        if (!term || term.trim() === '') {
            // Reload full list
            await loadHouseholds(false);
            return;
        }
        
        const results = await HouseholdCache.searchHouseholds(term);
        setHouseholds(results);
    }, [loadHouseholds]);

    const getHouseholdById = useCallback(async (id) => {
        return await HouseholdCache.getHouseholdById(id);
    }, []);

    return {
        households,
        loading,
        refreshing,
        error,
        cacheStatus,
        refresh,
        searchHouseholds,
        getHouseholdById,
        total: households.length,
    };
};

/**
 * Hook for financial assistance data
 */
export const useFinancialAssistance = () => {
    const [applications, setApplications] = useState([]);
    const [summary, setSummary] = useState({ total: 0, pending: 0, approved: 0, rejected: 0, total_disbursed: 0 });
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState(null);
    const [cacheStatus, setCacheStatus] = useState({ isFresh: false, age: null });

    const loadFinancialData = useCallback(async (forceRefresh = false) => {
        try {
            if (forceRefresh) {
                setRefreshing(true);
            } else {
                setLoading(true);
            }
            
            setError(null);
            
            const data = await FinancialCache.getFinancialAssistance(forceRefresh);
            setApplications(data.applications || []);
            setSummary(data.summary || { total: 0, pending: 0, approved: 0, rejected: 0, total_disbursed: 0 });
            
            // Check cache status
            const isFresh = await LocalCacheEngine.isCacheFresh('CACHE_FINANCIAL_ASSISTANCE');
            const timestamp = await AsyncStorage.getItem('CACHE_TIMESTAMP_FINANCIAL_ASSISTANCE');
            const age = timestamp ? Math.round((Date.now() - parseInt(timestamp, 10)) / 60000) : null;
            
            setCacheStatus({ isFresh, age });
            
        } catch (err) {
            setError(err.message || 'Failed to load financial assistance');
            console.error('useFinancialAssistance error:', err);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    // Load on mount
    useEffect(() => {
        loadFinancialData(false);
    }, []);

    const refresh = useCallback(() => loadFinancialData(true), [loadFinancialData]);

    const getByStatus = useCallback(async (status) => {
        return await FinancialCache.getApplicationsByStatus(status);
    }, []);

    const getSummary = useCallback(async () => {
        return await FinancialCache.getFinancialSummary();
    }, []);

    return {
        applications,
        summary,
        loading,
        refreshing,
        error,
        cacheStatus,
        refresh,
        getByStatus,
        getSummary,
        total: applications.length,
    };
};

export default {
    useCachedData,
    useHouseholds,
    useFinancialAssistance,
};