<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];

// ============================================================
// STAFF "VIEW AS RESIDENT" MODE
// Staff can view a resident's notifications by passing ?view_as_user=ID
// ============================================================
$allowed_staff_roles = ['staff', 'social_worker', 'encoder'];
$viewing_as_staff = false;
$viewed_user_name = null;
$original_user_id = $user_id;

if(in_array($role, $allowed_staff_roles) && isset($_GET['view_as_user']) && is_numeric($_GET['view_as_user'])) {
    $target_user_id = intval($_GET['view_as_user']);
    try {
        $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE id = ?");
        $stmt->execute([$target_user_id]);
        $target_user = $stmt->fetch();
        if($target_user) {
            $viewing_as_staff = true;
            $user_id = $target_user_id;
            $viewed_user_name = $target_user['full_name'];
        }
    } catch(PDOException $e) {}
}

// Get sidebar household ID (uses the viewed user's household if staff-view)
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Mark as read
if(isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    try {
        $stmt = $pdo->prepare("UPDATE resident_notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->execute([intval($_GET['mark_read']), $user_id]);
    } catch(PDOException $e) {}
    if($viewing_as_staff) {
        header("Location: notifications.php?view_as_user=" . $user_id);
    } else {
        header("Location: notifications.php");
    }
    exit();
}

// Mark all as read
if(isset($_POST['mark_all_read'])) {
    try {
        $stmt = $pdo->prepare("UPDATE resident_notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $success_message = "All notifications marked as read.";
    } catch(PDOException $e) {
        $error_message = "Failed to mark as read.";
    }
}

// Filter
$type_filter = isset($_GET['type']) ? trim($_GET['type']) : 'all';

// Fetch notifications
$notifications = [];
try {
    $query = "SELECT * FROM resident_notifications WHERE user_id = ?";
    $params = [$user_id];

    if($type_filter !== 'all') {
        $query .= " AND notification_type = ?";
        $params[] = $type_filter;
    }

    $query .= " ORDER BY timestamp_sent DESC LIMIT 100";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $notifications = $stmt->fetchAll();
} catch(PDOException $e) {
    $notifications = [];
}

// Stats
$unread_count = 0;
$total_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_count = $stmt->fetch()['c'] ?? 0;

    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {}

// Helpers
function getTypeMeta($type) {
    switch($type) {
        case 'VERIFICATION':
        case 'HOUSEHOLD':
            return ['icon' => 'fa-home', 'color' => '#1E4A8C', 'label' => 'Household'];
        case 'SOLO_PARENT':
            return ['icon' => 'fa-female', 'color' => '#D946A0', 'label' => 'Solo Parent'];
        case 'SENIOR_CITIZEN':
            return ['icon' => 'fa-user-graduate', 'color' => '#7C3AED', 'label' => 'Senior Citizen'];
        case 'PWD':
            return ['icon' => 'fa-wheelchair', 'color' => '#0891B2', 'label' => 'PWD'];
        case 'AICS':
            return ['icon' => 'fa-coins', 'color' => '#F59E0B', 'label' => 'AICS'];
        case 'VAWC':
            return ['icon' => 'fa-shield-alt', 'color' => '#DC2626', 'label' => 'VAWC'];
        case 'ID_APPLICATION':
            return ['icon' => 'fa-id-card', 'color' => '#059669', 'label' => 'ID Application'];
        case 'SURVEY':
            return ['icon' => 'fa-chart-line', 'color' => '#4F46E5', 'label' => 'Community Survey'];
        default:
            return ['icon' => 'fa-bell', 'color' => '#64748B', 'label' => 'General'];
    }
}

function timeAgo($timestamp) {
    if(!$timestamp) return '';
    $diff = time() - strtotime($timestamp);
    if($diff < 60) return 'Just now';
    if($diff < 3600) return floor($diff / 60) . 'm ago';
    if($diff < 86400) return floor($diff / 3600) . 'h ago';
    if($diff < 604800) return floor($diff / 86400) . 'd ago';
    return date('M d, Y', strtotime($timestamp));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Notifications - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <?= renderPwaMetaTags() ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; padding-bottom: 75px; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F; --accent: #F5B042;
            --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9; --gray-200: #E2E8F0;
            --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B; --gray-600: #475569;
            --gray-700: #334155; --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem; --radius-lg: 1rem; --radius-xl: 1.5rem; --radius-2xl: 2rem;
        }
        .app { display: flex; min-height: 100vh; }

        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0; left: 0; bottom: 0;
            overflow-y: auto;
            z-index: 40;
            transition: transform 0.3s ease;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.7rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 0.5px; color: var(--gray-400);
            margin-bottom: 12px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 16px; margin-bottom: 4px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
            position: relative;
        }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge {
            margin-left: auto;
            background: var(--secondary);
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 20px;
        }
        .submenu {
            margin-left: 36px; overflow: hidden;
            max-height: 0; transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 300px; }
        .submenu-item {
            display: flex; align-items: center; gap: 12px;
            padding: 8px 16px; margin-bottom: 2px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            transition: all 0.2s ease;
        }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .submenu-item.active i { color: white; }

        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 32px; padding-bottom: 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu {
            display: flex; align-items: center; gap: 16px;
            background: var(--gray-50);
            padding: 8px 16px 8px 20px;
            border-radius: 40px;
            border: 1px solid var(--gray-200);
        }
        .user-avatar {
            width: 36px; height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: var(--white);
            padding: 18px 20px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            display: flex; align-items: center; gap: 14px;
            transition: all 0.2s;
        }
        .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
        .stat-icon {
            width: 46px; height: 46px; border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem;
        }
        .stat-icon.blue { background: #EFF6FF; color: #1E4A8C; }
        .stat-icon.red { background: #FEE2E2; color: #D32F2F; }
        .stat-icon.green { background: #D1FAE5; color: #059669; }
        .stat-info .stat-number { font-size: 1.4rem; font-weight: 700; color: var(--gray-800); }
        .stat-info .stat-label { font-size: 0.7rem; color: var(--gray-500); }

        .filter-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            background: var(--white);
            padding: 12px;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
        }
        .filter-tab {
            padding: 8px 14px;
            border-radius: 40px;
            font-size: 0.75rem;
            font-weight: 600;
            text-decoration: none;
            color: var(--gray-600);
            background: var(--gray-100);
            border: 1px solid transparent;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .filter-tab:hover { background: var(--gray-200); }
        .filter-tab.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary-dark);
        }

        .toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .toolbar h3 {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--gray-700);
        }
        .btn-mark-all {
            background: var(--white);
            color: var(--primary);
            border: 1px solid var(--gray-200);
            padding: 8px 16px;
            border-radius: 40px;
            font-size: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }
        .btn-mark-all:hover { background: var(--gray-50); }

        .notif-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .notif-item {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 18px 20px;
            display: flex;
            align-items: flex-start;
            gap: 16px;
            transition: all 0.2s;
            position: relative;
        }
        .notif-item:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .notif-item.unread {
            background: #FFFBF0;
            border-color: #FCD34D;
            border-left: 4px solid var(--accent);
        }
        .notif-icon {
            width: 44px; height: 44px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem;
            flex-shrink: 0;
            color: white;
        }
        .notif-body { flex: 1; min-width: 0; }
        .notif-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .notif-type-tag {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .notif-text {
            font-size: 0.82rem;
            color: var(--gray-600);
            line-height: 1.5;
            margin-bottom: 8px;
        }
        .notif-meta {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.7rem;
            color: var(--gray-400);
        }
        .notif-actions {
            display: flex;
            flex-direction: column;
            gap: 6px;
            flex-shrink: 0;
        }
        .btn-notif-action {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.2s;
            border: none;
            cursor: pointer;
            white-space: nowrap;
        }
        .btn-view-notif { background: var(--primary); color: white; }
        .btn-view-notif:hover { background: var(--primary-dark); }
        .btn-mark-read { background: var(--gray-100); color: var(--gray-600); }
        .btn-mark-read:hover { background: var(--gray-200); }

        .empty-state {
            text-align: center;
            padding: 80px 20px;
            background: var(--white);
            border-radius: var(--radius-2xl);
            border: 1px solid var(--gray-200);
            color: var(--gray-500);
        }
        .empty-state i {
            font-size: 3.5rem;
            margin-bottom: 16px;
            color: var(--gray-300);
        }
        .empty-state h3 {
            font-size: 1.1rem;
            color: var(--gray-700);
            margin-bottom: 6px;
        }
        .empty-state p { font-size: 0.85rem; }

        .alert {
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.85rem;
        }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-error { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }
        .alert-staff {
            background: #FFF9EF;
            border-left: 3px solid #F5B042;
            color: #7B5E2A;
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .alert-staff a {
            margin-left: auto;
            color: #7B5E2A;
            text-decoration: underline;
            font-weight: 600;
        }

        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: var(--white);
            display: flex; justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex; flex-direction: column; align-items: center;
            font-size: 0.7rem; color: var(--gray-600); text-decoration: none;
            position: relative;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        .bottom-nav .nav-item .nav-badge {
            position: absolute;
            top: -4px; right: 6px;
            background: var(--secondary);
            color: white;
            font-size: 0.55rem;
            font-weight: 700;
            padding: 1px 5px;
            border-radius: 20px;
        }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        .menu-toggle {
            display: none; background: none; border: none;
            font-size: 1.3rem; color: var(--gray-700);
            cursor: pointer; padding: 8px; border-radius: var(--radius-md);
        }
        .menu-toggle:hover { background: var(--gray-100); }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .stats-row { grid-template-columns: 1fr; }
            .notif-item { flex-direction: column; }
            .notif-actions { flex-direction: row; width: 100%; }
        }
    </style>
</head>
<body>
<div class="app">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Municipal Social Welfare</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="dashboards/resident_dashboard.php" class="nav-item">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item">
                    <i class="fas fa-users"></i>
                    <span>Household Profile</span>
                </a>
                <a href="modules/my_applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i>
                    <span>My Applications</span>
                </a>
                <a href="notifications.php" class="nav-item active">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                    <?php if($unread_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i>
                    <span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="modules/survey_form.php" class="nav-item">
                    <i class="fas fa-chart-line"></i>
                    <span>Community Survey</span>
                </a>
                <a href="id_application.php" class="nav-item">
                    <i class="fas fa-id-card"></i>
                    <span>ID Application</span>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile_settings.php" class="nav-item">
                    <i class="fas fa-user-circle"></i>
                    <span>Profile Settings</span>
                </a>
                <a href="logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Notifications<?php echo $viewing_as_staff ? ' — ' . htmlspecialchars($viewed_user_name ?? 'Resident') : ''; ?></h1>
                    <p><?php echo $viewing_as_staff ? 'Viewing as resident (Staff Mode)' : 'Stay updated on your applications and household status'; ?></p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small><?php echo ucfirst($role); ?></small>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <?php if($viewing_as_staff): ?>
            <div class="alert alert-staff">
                <i class="fas fa-user-shield"></i>
                <strong>Staff View Mode:</strong> You are viewing notifications for <strong><?php echo htmlspecialchars($viewed_user_name ?? 'Resident'); ?></strong>.
                <a href="household.php">← Return to Households</a>
            </div>
        <?php endif; ?>

        <?php if(isset($success_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        <?php if(isset($error_message)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <!-- STATS -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-bell"></i></div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo $total_count; ?></div>
                    <div class="stat-label">Total Notifications</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon red"><i class="fas fa-envelope"></i></div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo $unread_count; ?></div>
                    <div class="stat-label">Unread</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-check-double"></i></div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo max(0, $total_count - $unread_count); ?></div>
                    <div class="stat-label">Read</div>
                </div>
            </div>
        </div>

        <!-- FILTER TABS -->
        <div class="filter-tabs">
            <a href="notifications.php<?php echo $viewing_as_staff ? '?view_as_user=' . $user_id : ''; ?>" class="filter-tab <?php echo $type_filter === 'all' ? 'active' : ''; ?>">
                <i class="fas fa-list"></i> All
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=VERIFICATION" class="filter-tab <?php echo $type_filter === 'VERIFICATION' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Household
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=SOLO_PARENT" class="filter-tab <?php echo $type_filter === 'SOLO_PARENT' ? 'active' : ''; ?>">
                <i class="fas fa-female"></i> Solo Parent
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=SENIOR_CITIZEN" class="filter-tab <?php echo $type_filter === 'SENIOR_CITIZEN' ? 'active' : ''; ?>">
                <i class="fas fa-user-graduate"></i> Senior Citizen
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=PWD" class="filter-tab <?php echo $type_filter === 'PWD' ? 'active' : ''; ?>">
                <i class="fas fa-wheelchair"></i> PWD
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=AICS" class="filter-tab <?php echo $type_filter === 'AICS' ? 'active' : ''; ?>">
                <i class="fas fa-coins"></i> AICS
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=VAWC" class="filter-tab <?php echo $type_filter === 'VAWC' ? 'active' : ''; ?>">
                <i class="fas fa-shield-alt"></i> VAWC
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=ID_APPLICATION" class="filter-tab <?php echo $type_filter === 'ID_APPLICATION' ? 'active' : ''; ?>">
                <i class="fas fa-id-card"></i> ID Application
            </a>
            <a href="notifications.php?<?php echo $viewing_as_staff ? 'view_as_user=' . $user_id . '&' : ''; ?>type=SURVEY" class="filter-tab <?php echo $type_filter === 'SURVEY' ? 'active' : ''; ?>">
                <i class="fas fa-chart-line"></i> Survey
            </a>
        </div>

        <!-- TOOLBAR -->
        <div class="toolbar">
            <h3>
                <?php 
                if($type_filter === 'all') echo 'All Notifications';
                else {
                    $meta = getTypeMeta($type_filter);
                    echo $meta['label'] . ' Notifications';
                }
                ?>
                <span style="color: var(--gray-400); font-weight: 400;">(<?php echo count($notifications); ?>)</span>
            </h3>
            <?php if($unread_count > 0): ?>
            <form method="POST" style="display: inline;">
                <button type="submit" name="mark_all_read" class="btn-mark-all">
                    <i class="fas fa-check-double"></i> Mark All as Read
                </button>
            </form>
            <?php endif; ?>
        </div>

        <!-- NOTIFICATION LIST -->
        <?php if(count($notifications) > 0): ?>
            <div class="notif-list">
                <?php foreach($notifications as $notif): 
                    $meta = getTypeMeta($notif['notification_type'] ?? 'GENERAL');
                    $is_unread = empty($notif['is_read']);
                ?>
                    <div class="notif-item <?php echo $is_unread ? 'unread' : ''; ?>">
                        <div class="notif-icon" style="background: <?php echo $meta['color']; ?>;">
                            <i class="fas <?php echo $meta['icon']; ?>"></i>
                        </div>
                        <div class="notif-body">
                            <div class="notif-title">
                                <?php echo htmlspecialchars($notif['title'] ?? 'Notification'); ?>
                                <span class="notif-type-tag" style="background: <?php echo $meta['color']; ?>20; color: <?php echo $meta['color']; ?>;">
                                    <?php echo $meta['label']; ?>
                                </span>
                                <?php if($is_unread): ?>
                                    <span style="display: inline-block; width: 8px; height: 8px; background: var(--secondary); border-radius: 50%;"></span>
                                <?php endif; ?>
                            </div>
                            <div class="notif-text">
                                <?php echo nl2br(htmlspecialchars($notif['body'] ?? '')); ?>
                            </div>
                            <div class="notif-meta">
                                <span><i class="far fa-clock"></i> <?php echo timeAgo($notif['timestamp_sent'] ?? null); ?></span>
                                <?php if(!empty($notif['related_household_id'])): ?>
                                    <span><i class="fas fa-home"></i> Household #<?php echo $notif['related_household_id']; ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="notif-actions">
                            <?php if(!empty($notif['related_household_id']) && ($notif['notification_type'] === 'VERIFICATION' || $notif['notification_type'] === 'HOUSEHOLD')): ?>
                                <a href="modules/household_data.php?view=<?php echo $notif['related_household_id']; ?>" class="btn-notif-action btn-view-notif">
                                    <i class="fas fa-eye"></i> View
                                </a>
                            <?php endif; ?>
                            <?php if($is_unread): ?>
                                <a href="notifications.php?mark_read=<?php echo $notif['id']; ?><?php echo $viewing_as_staff ? '&view_as_user=' . $user_id : ''; ?>" class="btn-notif-action btn-mark-read">
                                    <i class="fas fa-check"></i> Mark Read
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <h3>No Notifications Yet</h3>
                <p>When your household or applications get updated, notifications will appear here.</p>
            </div>
        <?php endif; ?>
    </main>

    <!-- BOTTOM NAV -->
    <div class="bottom-nav">
        <a href="dashboards/resident_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item"><i class="fas fa-users"></i><span>Household</span></a>
        <a href="modules/my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i><span>Apps</span></a>
        <a href="notifications.php<?php echo $viewing_as_staff ? '?view_as_user=' . $user_id : ''; ?>" class="nav-item active">
            <i class="fas fa-bell"></i><span>Alerts</span>
            <?php if($unread_count > 0): ?>
                <span class="nav-badge"><?php echo $unread_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if(menuToggle) menuToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
    document.addEventListener('click', (event) => {
        if(window.innerWidth <= 768 && !sidebar.contains(event.target) && !menuToggle?.contains(event.target)) {
            sidebar.classList.remove('open');
        }
    });

    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    if(programToggle) programToggle.addEventListener('click', () => {
        programSubmenu.classList.toggle('show');
        programIcon.classList.toggle('rotated');
    });
</script>
<?= renderPwaServiceWorker() ?>
</body>
</html>