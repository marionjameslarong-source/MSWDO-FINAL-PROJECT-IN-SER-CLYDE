<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];
$error = '';
$success = '';

// Get sidebar household ID for dynamic navigation
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

$stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
$stmt->execute([$user_id]);
$household = $stmt->fetch();

// Get user contact info
$user_data = [];
try {
    $stmt = $pdo->prepare("SELECT email, contact_number FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $user_data = ['email' => '', 'contact_number' => ''];
}

// Check for existing pending application
$existing_app = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'financial_assistance' AND status IN ('pending', 'approved')");
    $stmt->execute([$user_id]);
    $existing_app = $stmt->fetch();
} catch(PDOException $e) {
    $existing_app = null;
}

// Check yearly AICS limit (max 3 per household per fiscal year)
$current_year = date('Y');
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM welfare_applications WHERE household_id = ? AND program_type = 'financial_assistance' AND YEAR(created_at) = ? AND status = 'approved'");
$stmt->execute([$household['id'] ?? 0, $current_year]);
$aics_count = $stmt->fetch()['count'] ?? 0;
$max_aics_per_year = 3;
$aics_limit_reached = $aics_count >= $max_aics_per_year;

// Generate Case Tracking Number
$case_prefix = 'CRISIS-AICS-' . date('Y') . '-';
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM welfare_applications WHERE program_type = 'financial_assistance' AND YEAR(created_at) = ?");
$stmt->execute([date('Y')]);
$case_count = $stmt->fetch()['count'] + 1;
$case_tracking_no = $case_prefix . str_pad($case_count, 4, '0', STR_PAD_LEFT);

// Generate dynamic voucher code
$voucher_code = 'VCH-' . strtoupper(bin2hex(random_bytes(4)));

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply'])) {
    if(!$household) {
        $error = "Please complete your household data first.";
    } elseif($existing_app) {
        $error = "You already have a pending financial assistance application.";
    } elseif($aics_limit_reached) {
        $error = "Your household has reached the maximum number of AICS assistance requests for this fiscal year (max 3).";
    } else {
        // Handle document uploads (receipts/bills)
        $receipt_path = null;
        if(isset($_FILES['supporting_document']) && $_FILES['supporting_document']['error'] == 0) {
            $upload_dir = 'uploads/financial_assistance/';
            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $receipt_path = $upload_dir . time() . '_' . $user_id . '_' . basename($_FILES['supporting_document']['name']);
            move_uploaded_file($_FILES['supporting_document']['tmp_name'], $receipt_path);
        }
        
        // Get GPS location
        $gps_latitude = $_POST['gps_latitude'] ?? null;
        $gps_longitude = $_POST['gps_longitude'] ?? null;
        
        $application_data = [
            // Case Tracking Information
            'case_tracking_no' => $case_tracking_no,
            'voucher_code' => $voucher_code,
            'gps_latitude' => $gps_latitude,
            'gps_longitude' => $gps_longitude,
            
            // Personal Information
            'first_name' => $_POST['first_name'] ?? '',
            'last_name' => $_POST['last_name'] ?? '',
            'contact_number' => $_POST['contact_number'] ?? '',
            'barangay' => $_POST['barangay'] ?? '',
            
            // Assistance Category
            'assistance_category' => $_POST['assistance_category'] ?? '',
            'assistance_subcategory' => $_POST['assistance_subcategory'] ?? '',
            'amount_requested' => $_POST['amount_requested'] ?? null,
            
            // Fund Source
            'fund_source' => $_POST['fund_source'] ?? '',
            
            // Crisis Details
            'crisis_description' => $_POST['crisis_description'] ?? '',
            'incident_date' => $_POST['incident_date'] ?? '',
            'has_previous_assistance' => isset($_POST['has_previous_assistance']) ? 1 : 0,
            'previous_assistance_details' => $_POST['previous_assistance_details'] ?? '',
            
            // Supporting Documents
            'supporting_document' => $receipt_path,
            'document_type' => $_POST['document_type'] ?? '',
            'document_reference_no' => $_POST['document_reference_no'] ?? '',
            
            // Bank/Payment Details
            'bank_name' => $_POST['bank_name'] ?? '',
            'account_name' => $_POST['account_name'] ?? '',
            'account_number' => $_POST['account_number'] ?? '',
            'preferred_disbursement' => $_POST['preferred_disbursement'] ?? '',
            
            // Declaration
            'declaration_agreed' => isset($_POST['declaration_agreed']) ? 1 : 0,
            'submitted_at' => date('Y-m-d H:i:s')
        ];
        
        try {
            $stmt = $pdo->prepare("INSERT INTO welfare_applications (user_id, household_id, program_type, status, application_data, created_at) VALUES (?, ?, 'financial_assistance', 'pending', ?, NOW())");
            $stmt->execute([$user_id, $household['id'], json_encode($application_data)]);
            $success = "Your financial assistance application (Case No: $case_tracking_no) has been submitted successfully! A social worker will evaluate your application.";
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

// Get household barangay and address
$household_barangay = '';
if($household) {
    $household_barangay = $household['barangay'] ?? '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Financial Assistance - MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F5F7FB;
            color: #1E2F4E;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --radius-2xl: 2rem;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            overflow-y: auto;
            z-index: 40;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-icon i { font-size: 1.3rem; color: var(--accent); }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--gray-400);
            margin-bottom: 12px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            margin-bottom: 4px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            transition: all 0.2s ease;
        }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 36px;
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 300px; }
        .submenu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 16px;
            margin-bottom: 2px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
        }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 32px 40px 80px 40px;
        }
        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 16px;
            background: var(--gray-50);
            padding: 8px 16px 8px 20px;
            border-radius: 40px;
            border: 1px solid var(--gray-200);
        }
        .user-avatar {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        /* Form Card & Steps */
        .form-card {
            background: var(--white);
            border-radius: var(--radius-2xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .form-header {
            padding: 28px 32px;
            background: var(--gray-50);
            border-bottom: 1px solid var(--gray-200);
            text-align: center;
        }
        .form-header i { font-size: 3rem; color: var(--accent); margin-bottom: 12px; }
        .form-header h2 { font-size: 1.3rem; font-weight: 700; color: var(--primary); margin-bottom: 6px; }
        .form-header p { font-size: 0.8rem; color: var(--gray-500); }
        .form-body { padding: 32px; }

        /* Step Progress */
        .step-progress {
            display: flex;
            justify-content: space-between;
            margin-bottom: 32px;
            padding: 0 20px;
            position: relative;
        }
        .step-progress::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 10%;
            right: 10%;
            height: 2px;
            background: var(--gray-200);
            z-index: 1;
        }
        .step {
            text-align: center;
            position: relative;
            z-index: 2;
            flex: 1;
        }
        .step-circle {
            width: 40px;
            height: 40px;
            background: var(--gray-200);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 8px;
            font-weight: 700;
            color: var(--gray-600);
            transition: all 0.3s;
        }
        .step.active .step-circle {
            background: var(--secondary);
            color: white;
        }
        .step.completed .step-circle {
            background: var(--success);
            color: white;
        }
        .step-label {
            font-size: 0.65rem;
            color: var(--gray-500);
        }
        .step.active .step-label {
            color: var(--secondary);
            font-weight: 600;
        }
        
        /* Form Sections */
        .form-section {
            display: none;
            animation: fadeIn 0.3s ease;
        }
        .form-section.active-section {
            display: block;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
        }
        .section-icon {
            width: 40px;
            height: 40px;
            background: var(--gray-100);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .section-icon i { font-size: 1.2rem; color: var(--accent); }
        .section-title h3 { font-size: 1.1rem; font-weight: 600; color: var(--gray-800); }
        .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 16px; }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-600);
            margin-bottom: 6px;
        }
        .form-group label i { margin-right: 6px; color: var(--accent); font-size: 0.7rem; }
        .required { color: var(--secondary); }
        input, select, textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s ease;
            background: var(--white);
        }
        input:focus, select:focus, textarea:focus {
            border-color: var(--accent);
            outline: none;
            box-shadow: 0 0 0 3px rgba(245,176,66,0.15);
        }
        textarea { resize: vertical; min-height: 80px; }
        
        /* Camera/Upload Button */
        .camera-btn {
            background: var(--gray-100);
            border: 1.5px dashed var(--gray-300);
            padding: 12px;
            border-radius: var(--radius-md);
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .camera-btn:hover { border-color: var(--accent); background: var(--gray-50); }
        .camera-btn i { font-size: 1.5rem; color: var(--accent); margin-bottom: 5px; display: block; }
        .camera-btn span { font-size: 0.7rem; color: var(--gray-500); }
        .file-name { font-size: 0.7rem; color: var(--gray-500); margin-top: 5px; text-align: center; }
        
        /* Checkbox Group */
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            margin-top: 8px;
        }
        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 6px;
            font-weight: normal;
            cursor: pointer;
            margin-bottom: 0;
        }
        .checkbox-group input {
            width: 18px;
            height: 18px;
        }
        
        .info-note {
            background: #FFF9EF;
            padding: 10px 14px;
            border-radius: var(--radius-md);
            font-size: 0.7rem;
            color: #7B5E2A;
            margin-top: 8px;
        }
        .alert-warning {
            background: #FEF3C7;
            border-left: 4px solid var(--accent);
            color: #92400E;
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
        }
        
        /* Navigation Buttons */
        .nav-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 32px;
            gap: 16px;
        }
        .btn-prev, .btn-next, .btn-submit {
            padding: 12px 24px;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-prev {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }
        .btn-prev:hover { background: var(--gray-200); }
        .btn-next, .btn-submit {
            background: var(--primary);
            color: white;
        }
        .btn-next:hover, .btn-submit:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }
        .alert {
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }
        .alert-info { background: #FFF9EF; border-left: 3px solid var(--accent); color: #7B5E2A; }
        .info-text { font-size: 0.7rem; color: var(--gray-500); margin-top: 4px; }
        .case-badge {
            background: var(--primary);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            display: inline-block;
            margin-bottom: 16px;
        }
        hr { margin: 20px 0; border: 0; height: 1px; background: var(--gray-200); }
        .menu-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 1.3rem;
            color: var(--gray-700);
            cursor: pointer;
            padding: 8px;
            border-radius: var(--radius-md);
        }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .form-body { padding: 20px; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .step-label { font-size: 0.5rem; }
            .step-circle { width: 30px; height: 30px; font-size: 0.8rem; }
        }
    </style>
</head>
<body>
<div class="app">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-hand-holding-heart"></i></div>
                <div class="logo-text"><h1>MSWDO Portal</h1><p>Municipal Social Welfare</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="dashboards/resident_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Dashboard</span></a>
                <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item"><i class="fas fa-users"></i><span>Household Profile</span></a>
                <a href="modules/my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i><span>My Applications</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i><span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="modules/survey_form.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Community Survey</span></a>
                <a href="financial_assistance.php" class="nav-item active"><i class="fas fa-hand-holding-usd"></i><span>Financial Assistance</span></a>
                <a href="id_application.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Application</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile_settings.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile Settings</span></a>
                <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Financial Assistance (AICS)</h1>
                    <p>Assistance to Individuals in Crisis Situation</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info"><span><?php echo htmlspecialchars($full_name); ?></span><small><?php echo ucfirst($role); ?></small></div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <i class="fas fa-hand-holding-usd"></i>
                <h2>Financial Assistance Request</h2>
                <p>5-Step Mobile Form Wizard | AICS Crisis Assistance</p>
            </div>

            <div class="form-body">
                <?php if($success): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> <strong>Case Tracking Number:</strong> <?php echo $case_tracking_no; ?><br>
                        <strong>Voucher Code:</strong> <?php echo $voucher_code; ?><br>
                        You can check your application status in "My Applications" page.
                    </div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($existing_app && !$success): ?>
                    <div class="alert alert-info"><i class="fas fa-clock"></i> You already have a pending financial assistance application.</div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($aics_limit_reached): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> <strong>AICS Limit Reached</strong><br>
                        Your household has already received the maximum of <?php echo $max_aics_per_year; ?> AICS assistance requests for fiscal year <?php echo $current_year; ?>.
                    </div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php else: ?>
                
                <!-- Step Progress Indicator -->
                <div class="step-progress">
                    <div class="step active" id="step1Indicator"><div class="step-circle">1</div><div class="step-label">System Metadata</div></div>
                    <div class="step" id="step2Indicator"><div class="step-circle">2</div><div class="step-label">Personal Info</div></div>
                    <div class="step" id="step3Indicator"><div class="step-circle">3</div><div class="step-label">Assistance Details</div></div>
                    <div class="step" id="step4Indicator"><div class="step-circle">4</div><div class="step-label">Supporting Docs</div></div>
                    <div class="step" id="step5Indicator"><div class="step-circle">5</div><div class="step-label">Verification</div></div>
                </div>

                <form method="POST" enctype="multipart/form-data" id="financialForm">
                    <input type="hidden" name="apply" value="1">
                    <input type="hidden" name="gps_latitude" id="gps_latitude">
                    <input type="hidden" name="gps_longitude" id="gps_longitude">

                    <!-- ==================== STEP 1: SYSTEM METADATA ==================== -->
                    <div class="form-section active-section" id="step1">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-microchip"></i></div>
                            <h3>Step 1: System-Generated Metadata</h3>
                        </div>
                        <div class="case-badge"><i class="fas fa-qrcode"></i> Case Tracking No: <?php echo $case_tracking_no; ?></div>
                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-calendar"></i> Submission Date & Time</label>
                                <input type="text" value="<?php echo date('Y-m-d H:i:s'); ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-map-marker-alt"></i> GPS Location</label>
                                <input type="text" id="gps_status" value="Detecting location..." disabled>
                                <div class="info-text"><i class="fas fa-sync-alt"></i> Automatically captured from device</div>
                            </div>
                        </div>
                        <div class="info-note">
                            <i class="fas fa-info-circle"></i> <strong>AICS Yearly Limit:</strong> Your household has used <?php echo $aics_count; ?> of <?php echo $max_aics_per_year; ?> assistance requests for FY <?php echo $current_year; ?>.
                        </div>
                    </div>

                    <!-- ==================== STEP 2: PERSONAL INFORMATION ==================== -->
                    <div class="form-section" id="step2">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-id-card"></i></div>
                            <h3>Step 2: Personal Information</h3>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="first_name" value="<?php echo htmlspecialchars(explode(' ', $full_name)[0] ?? ''); ?>" required></div>
                            <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="last_name" value="<?php echo htmlspecialchars(explode(' ', $full_name)[count(explode(' ', $full_name))-1] ?? ''); ?>" required></div>
                        </div>
                        <div class="form-group"><label>Contact Number <span class="required">*</span></label><input type="text" name="contact_number" value="<?php echo htmlspecialchars($user_data['contact_number'] ?? ''); ?>" required></div>
                        <div class="form-group"><label>Barangay <span class="required">*</span></label><input type="text" name="barangay" value="<?php echo htmlspecialchars($household_barangay); ?>" required></div>
                    </div>

                    <!-- ==================== STEP 3: ASSISTANCE DETAILS ==================== -->
                    <div class="form-section" id="step3">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-chart-line"></i></div>
                            <h3>Step 3: Assistance Details</h3>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Assistance Category <span class="required">*</span></label>
                            <select name="assistance_category" id="assistanceCategory" required>
                                <option value="">Select Category</option>
                                <option value="medical">Medical Assistance</option>
                                <option value="burial">Burial Assistance</option>
                                <option value="transport">Transportation Assistance</option>
                                <option value="educational">Educational Assistance</option>
                                <option value="food">Food Assistance</option>
                                <option value="shelter">Emergency Shelter</option>
                            </select>
                        </div>
                        
                        <div class="form-group" id="subcategoryGroup" style="display: none;">
                            <label><i class="fas fa-tag"></i> Sub-category</label>
                            <input type="text" name="assistance_subcategory" id="assistanceSubcategory" placeholder="e.g., Hospital bills, Funeral services, School fees">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-money-bill-wave"></i> Amount Requested (₱) <span class="required">*</span></label>
                                <input type="number" name="amount_requested" step="100" placeholder="0.00" required>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-building"></i> Fund Source</label>
                                <select name="fund_source">
                                    <option value="">Select</option>
                                    <option value="municipal">Municipal Budget</option>
                                    <option value="dswd_regional">DSWD Regional Fund</option>
                                    <option value="calamity">Calamity Fund</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-exclamation-triangle"></i> Crisis Description <span class="required">*</span></label>
                            <textarea name="crisis_description" rows="3" placeholder="Please describe in detail the crisis situation you are facing..." required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-calendar-day"></i> Date of Incident</label>
                            <input type="date" name="incident_date">
                        </div>
                        
                        <div class="checkbox-group">
                            <label><input type="checkbox" name="has_previous_assistance" id="prevAssistanceCheck"> Have you received assistance from other agencies for this crisis?</label>
                        </div>
                        <div class="form-group" id="prevAssistanceDetails" style="display: none;">
                            <label>Previous Assistance Details</label>
                            <textarea name="previous_assistance_details" rows="2" placeholder="Provide details of assistance received from other agencies..."></textarea>
                        </div>
                    </div>

                    <!-- ==================== STEP 4: SUPPORTING DOCUMENTS ==================== -->
                    <div class="form-section" id="step4">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-camera"></i></div>
                            <h3>Step 4: Supporting Documents</h3>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-file-invoice"></i> Document Type</label>
                            <select name="document_type" id="docType">
                                <option value="">Select Document Type</option>
                                <option value="hospital_bill">Hospital/Medical Bill</option>
                                <option value="funeral_contract">Funeral Contract</option>
                                <option value="school_billing">School Billing</option>
                                <option value="police_report">Police/Barangay Report</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-hashtag"></i> Document Reference Number</label>
                            <input type="text" name="document_reference_no" placeholder="Bill/Report number if available">
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-receipt"></i> Upload Supporting Document (Receipt/Bill)</label>
                            <div class="camera-btn" onclick="document.getElementById('supporting_doc').click()">
                                <i class="fas fa-camera"></i>
                                <span>Capture or Upload Receipt/Bill</span>
                            </div>
                            <input type="file" id="supporting_doc" name="supporting_document" accept="image/*,application/pdf" style="display:none" onchange="updateFileName(this, 'docFileName')">
                            <div id="docFileName" class="file-name">No file chosen</div>
                            <div class="info-text">Upload hospital bills, funeral contracts, or school billing summaries</div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-university"></i> Preferred Disbursement Method</label>
                            <select name="preferred_disbursement">
                                <option value="">Select</option>
                                <option value="cash_pickup">Cash Pickup at MSWDO Office</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="guarantee_letter">Guarantee Letter to Hospital/School</option>
                            </select>
                        </div>
                        
                        <div id="bankDetails" style="display: none;">
                            <div class="form-group"><label><i class="fas fa-university"></i> Bank Name</label><input type="text" name="bank_name" placeholder="e.g., Landbank, DBP"></div>
                            <div class="form-group"><label><i class="fas fa-user"></i> Account Name</label><input type="text" name="account_name"></div>
                            <div class="form-group"><label><i class="fas fa-credit-card"></i> Account Number</label><input type="text" name="account_number"></div>
                        </div>
                    </div>

                    <!-- ==================== STEP 5: VERIFICATION & SUBMIT ==================== -->
                    <div class="form-section" id="step5">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-shield-alt"></i></div>
                            <h3>Step 5: Verification & Submit</h3>
                        </div>
                        
                        <div class="checkbox-group">
                            <label><input type="checkbox" name="declaration_agreed" required> I certify that the information provided is true and correct. I understand that any false statement may result in the denial of my application or legal action.</label>
                        </div>
                        
                        <div class="info-note">
                            <i class="fas fa-info-circle"></i> <strong>Disbursement Status Flow:</strong><br>
                            Assessment Ongoing → Guarantee Letter Issued → Cash Released → Case Closed
                        </div>
                        
                        <div class="info-note">
                            <i class="fas fa-clock"></i> <strong>Processing Time:</strong> Standard applications are processed within 5-7 business days. Emergency cases are prioritized.
                        </div>
                    </div>

                    <!-- Navigation Buttons -->
                    <div class="nav-buttons">
                        <button type="button" class="btn-prev" id="prevBtn" onclick="changeStep(-1)" style="display:none;"><i class="fas fa-chevron-left"></i> Previous</button>
                        <button type="button" class="btn-next" id="nextBtn" onclick="changeStep(1)">Next <i class="fas fa-chevron-right"></i></button>
                        <button type="submit" class="btn-submit" id="submitBtn" style="display:none;"><i class="fas fa-paper-plane"></i> SUBMIT APPLICATION</button>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
    let currentStep = 1;
    const totalSteps = 5;
    
    // GPS Location
    function getLocation() {
        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                document.getElementById('gps_latitude').value = position.coords.latitude;
                document.getElementById('gps_longitude').value = position.coords.longitude;
                document.getElementById('gps_status').value = `Lat: ${position.coords.latitude.toFixed(6)}, Lng: ${position.coords.longitude.toFixed(6)}`;
            });
        }
    }
    getLocation();
    
    // Assistance category change handler
    const assistanceCat = document.getElementById('assistanceCategory');
    const subcategoryGroup = document.getElementById('subcategoryGroup');
    const subcategoryInput = document.getElementById('assistanceSubcategory');
    
    if(assistanceCat) {
        assistanceCat.addEventListener('change', function() {
            const category = this.value;
            if(category === 'medical') {
                subcategoryGroup.style.display = 'block';
                subcategoryInput.placeholder = 'e.g., Hospital bills, Laboratory fees, Medicines';
            } else if(category === 'burial') {
                subcategoryGroup.style.display = 'block';
                subcategoryInput.placeholder = 'e.g., Funeral services, Cremation, Cemetery plot';
            } else if(category === 'educational') {
                subcategoryGroup.style.display = 'block';
                subcategoryInput.placeholder = 'e.g., Tuition fees, School supplies, Uniforms';
            } else if(category === 'transport') {
                subcategoryGroup.style.display = 'block';
                subcategoryInput.placeholder = 'e.g., Fare for medical treatment, Repatriation';
            } else {
                subcategoryGroup.style.display = 'none';
            }
        });
    }
    
    // Previous assistance toggle
    const prevCheck = document.getElementById('prevAssistanceCheck');
    const prevDetails = document.getElementById('prevAssistanceDetails');
    if(prevCheck) {
        prevCheck.addEventListener('change', function() {
            prevDetails.style.display = this.checked ? 'block' : 'none';
        });
    }
    
    // Bank details toggle based on disbursement method
    const disbursementSelect = document.querySelector('select[name="preferred_disbursement"]');
    const bankDetails = document.getElementById('bankDetails');
    if(disbursementSelect) {
        disbursementSelect.addEventListener('change', function() {
            bankDetails.style.display = this.value === 'bank_transfer' ? 'block' : 'none';
        });
    }
    
    function updateFileName(input, labelId) {
        const label = document.getElementById(labelId);
        if(input.files && input.files[0]) {
            label.textContent = input.files[0].name;
        } else {
            label.textContent = 'No file chosen';
        }
    }
    
    // Step navigation
    function changeStep(direction) {
        const sections = document.querySelectorAll('.form-section');
        const steps = document.querySelectorAll('.step');
        
        sections[currentStep - 1].classList.remove('active-section');
        steps[currentStep - 1].classList.remove('active');
        steps[currentStep - 1].classList.add('completed');
        
        currentStep += direction;
        
        sections[currentStep - 1].classList.add('active-section');
        steps[currentStep - 1].classList.add('active');
        
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');
        
        if(currentStep === 1) prevBtn.style.display = 'none';
        else prevBtn.style.display = 'inline-flex';
        
        if(currentStep === totalSteps) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-flex';
        } else {
            nextBtn.style.display = 'inline-flex';
            submitBtn.style.display = 'none';
        }
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    // Mobile menu toggle
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if(menuToggle) {
        menuToggle.addEventListener('click', function() { sidebar.classList.toggle('open'); });
    }
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
    
    // Collapsible Program Menu
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
</script>
</body>
</html>