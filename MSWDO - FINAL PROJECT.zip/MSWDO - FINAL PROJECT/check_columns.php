<?php
session_start();
require_once 'config/database.php';

echo "<h2>Households Table Columns</h2>";
$stmt = $pdo->query("DESCRIBE households");
$columns = $stmt->fetchAll();
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>Column Name</th><th>Type</th><th>Null</th></tr>";
foreach($columns as $col) {
    echo "<tr>";
    echo "<td>" . $col['Field'] . "</td>";
    echo "<td>" . $col['Type'] . "</td>";
    echo "<td>" . $col['Null'] . "</td>";
    echo "</tr>";
}
echo "</table>";
?>