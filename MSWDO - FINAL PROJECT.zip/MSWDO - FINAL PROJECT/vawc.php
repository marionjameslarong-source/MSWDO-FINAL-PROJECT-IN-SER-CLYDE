<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];
$error = '';
$success = '';
$pin_verified = isset($_SESSION['vawc_pin_verified']) && $_SESSION['vawc_pin_verified'] === true;

// Create system_settings table if not exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(100) NOT NULL UNIQUE,
        setting_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    $stmt = $pdo->prepare("INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES ('vawc_security_pin', '2024')");
    $stmt->execute();
} catch(PDOException $e) {}

// Handle PIN verification
if(isset($_POST['verify_pin'])) {
    $entered_pin = $_POST['security_pin'] ?? '';
    $stmt = $pdo->query("SELECT setting_value FROM system_settings WHERE setting_key = 'vawc_security_pin'");
    $pin_setting = $stmt->fetch();
    $secure_pin = $pin_setting ? $pin_setting['setting_value'] : '2024';
    if($entered_pin === $secure_pin) {
        $_SESSION['vawc_pin_verified'] = true;
        $pin_verified = true;
    } else {
        $pin_error = "Invalid security PIN. Please contact the VAWC desk for assistance.";
    }
}

// Get sidebar household ID
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get unread notification count
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

$stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
$stmt->execute([$user_id]);
$household = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'vawc' AND status IN ('pending', 'approved')");
$stmt->execute([$user_id]);
$existing_app = $stmt->fetch();

$case_no = 'VAWC-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
$ref_code = strtoupper(substr(md5(uniqid($user_id, true)), 0, 8));

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply']) && $pin_verified) {
    if(!$household) {
        $error = "Please complete your household data first.";
    } elseif($existing_app) {
        $error = "You already have a pending or approved application.";
    } else {
        $children_data = [];
        if(isset($_POST['child_name']) && is_array($_POST['child_name'])) {
            for($i = 0; $i < count($_POST['child_name']); $i++) {
                if(!empty($_POST['child_name'][$i])) {
                    $children_data[] = [
                        'name' => $_POST['child_name'][$i] ?? '',
                        'age' => $_POST['child_age'][$i] ?? '',
                        'sex' => $_POST['child_sex'][$i] ?? '',
                        'relation' => $_POST['child_relation'][$i] ?? ''
                    ];
                }
            }
        }

        $identity_photo_path = null;
        if(isset($_FILES['identity_photo']) && $_FILES['identity_photo']['error'] == 0) {
            $upload_dir = 'uploads/vawc/encrypted/';
            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $identity_photo_path = $upload_dir . time() . '_' . $user_id . '_encrypted.dat';
            move_uploaded_file($_FILES['identity_photo']['tmp_name'], $identity_photo_path);
        }

        $client_signature = $_POST['client_signature'] ?? null;
        $verification_code = bin2hex(random_bytes(16));
        $caseworker_signature = hash('sha256', $_SESSION['user_id'] . time() . uniqid());
        
        $risk_level = $_POST['risk_level'] ?? 'Moderate';
        $life_threatened = $_POST['life_threatened'] ?? 'no';
        $red_alert = ($life_threatened === 'yes' || $risk_level === 'Immediate Danger') ? 1 : 0;
        
        $application_data = [
            'case_no' => $case_no, 'reference_code' => $ref_code,
            'submission_date' => date('Y-m-d H:i:s'),
            'verification_code' => $verification_code, 'red_alert' => $red_alert,
            'first_name' => $_POST['first_name'] ?? '', 'middle_name' => $_POST['middle_name'] ?? '',
            'last_name' => $_POST['last_name'] ?? '', 'suffix' => $_POST['suffix'] ?? '',
            'birthdate' => $_POST['birthdate'] ?? '', 'age' => $_POST['age'] ?? '',
            'birthplace' => $_POST['birthplace'] ?? '', 'sex' => $_POST['sex'] ?? '',
            'civil_status' => $_POST['civil_status'] ?? '', 'religion' => $_POST['religion'] ?? '',
            'street_address' => $_POST['street_address'] ?? '', 'barangay' => $_POST['barangay'] ?? '',
            'municipality' => $_POST['municipality'] ?? '', 'province' => $_POST['province'] ?? '',
            'contact_no' => $_POST['contact_no'] ?? '', 'email' => $_POST['email'] ?? '',
            'occupation' => $_POST['occupation'] ?? '', 'monthly_income' => $_POST['monthly_income'] ?? '',
            'has_children' => $_POST['has_children'] ?? '', 'children_details' => $children_data,
            'children_affected' => $_POST['children_affected'] ?? '',
            'perpetrator_relation' => $_POST['perpetrator_relation'] ?? '',
            'abuse_types' => isset($_POST['abuse_types']) ? $_POST['abuse_types'] : [],
            'incident_frequency' => $_POST['incident_frequency'] ?? '',
            'in_immediate_danger' => isset($_POST['in_immediate_danger']) ? 1 : 0,
            'children_as_witnesses' => isset($_POST['children_as_witnesses']) ? 1 : 0,
            'current_safe_location' => $_POST['current_safe_location'] ?? '',
            'incident_date' => $_POST['incident_date'] ?? '', 'incident_time' => $_POST['incident_time'] ?? '',
            'incident_location' => $_POST['incident_location'] ?? '',
            'incident_description' => $_POST['incident_description'] ?? '',
            'perpetrator_name' => $_POST['perpetrator_name'] ?? '', 'perpetrator_age' => $_POST['perpetrator_age'] ?? '',
            'perpetrator_address' => $_POST['perpetrator_address'] ?? '',
            'perpetrator_has_weapon' => $_POST['perpetrator_has_weapon'] ?? '',
            'physical_injuries' => $_POST['physical_injuries'] ?? '',
            'has_protection_order' => $_POST['has_protection_order'] ?? '',
            'protection_order_type' => $_POST['protection_order_type'] ?? '',
            'has_blotter' => $_POST['has_blotter'] ?? '',
            'risk_level' => $risk_level, 'life_threatened' => $life_threatened,
            'needs_emergency_shelter' => isset($_POST['needs_emergency_shelter']) ? 1 : 0,
            'needs_medical_care' => isset($_POST['needs_medical_care']) ? 1 : 0,
            'needs_psychological_support' => isset($_POST['needs_psychological_support']) ? 1 : 0,
            'action_taken_referral' => isset($_POST['action_taken_referral']) ? $_POST['action_taken_referral'] : [],
            'problem_presented' => $_POST['problem_presented'] ?? '',
            'rehabilitation_goals' => isset($_POST['rehabilitation_goals']) ? $_POST['rehabilitation_goals'] : [],
            'identity_photo' => $identity_photo_path, 'client_signature' => $client_signature,
            'caseworker_signature' => $caseworker_signature, 'caseworker_name' => $full_name,
            'caseworker_id' => $user_id, 'client_consent' => isset($_POST['client_consent']) ? 1 : 0,
            'submitted_at' => date('Y-m-d H:i:s')
        ];
        
        try {
            $stmt = $pdo->prepare("INSERT INTO welfare_applications (user_id, household_id, program_type, status, application_data, created_at) VALUES (?, ?, 'vawc', 'pending', ?, NOW())");
            $stmt->execute([$user_id, $household['id'], json_encode($application_data)]);
            unset($_SESSION['vawc_pin_verified']);
            $success = "Your VAWC application (Case No: $case_no) has been submitted confidentially. A social worker will contact you within 24 hours.";
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>VAWC Program - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <?= renderPwaMetaTags() ?>
   
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F; --accent: #F5B042;
            --success: #059669; --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9;
            --gray-200: #E2E8F0; --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B;
            --gray-600: #475569; --gray-700: #334155; --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem; --radius-md: 0.75rem; --radius-lg: 1rem; --radius-xl: 1.5rem; --radius-2xl: 2rem;
        }
        .app { display: flex; min-height: 100vh; }
        .sidebar { width: 280px; background: var(--white); border-right: 1px solid var(--gray-200); position: fixed; top: 0; left: 0; bottom: 0; overflow-y: auto; z-index: 40; }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; color: var(--gray-400); margin-bottom: 12px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; margin-bottom: 4px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; transition: all 0.2s ease; position: relative; cursor: pointer; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge { margin-left: auto; background: var(--secondary); color: white; font-size: 0.65rem; font-weight: 700; padding: 2px 8px; border-radius: 20px; line-height: 1.4; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 16px; margin-bottom: 2px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; font-size: 0.8rem; }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid var(--gray-200); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--gray-50); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }
        .pin-lock { max-width: 400px; margin: 50px auto; background: var(--white); border-radius: var(--radius-2xl); padding: 32px; text-align: center; border: 1px solid var(--gray-200); box-shadow: var(--shadow-md); }
        .pin-lock i { font-size: 3rem; color: var(--secondary); margin-bottom: 16px; }
        .pin-lock h3 { margin-bottom: 8px; color: var(--gray-800); }
        .pin-lock p { font-size: 0.8rem; color: var(--gray-500); margin-bottom: 20px; }
        .pin-input { font-size: 1.5rem; letter-spacing: 8px; text-align: center; }
        .form-card { background: var(--white); border-radius: var(--radius-2xl); border: 1px solid var(--gray-200); overflow: hidden; box-shadow: var(--shadow-sm); }
        .form-header { padding: 28px 32px; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); text-align: center; }
        .form-header i { font-size: 3rem; color: var(--secondary); margin-bottom: 12px; }
        .form-header h2 { font-size: 1.3rem; font-weight: 700; color: var(--secondary); margin-bottom: 6px; }
        .form-header p { font-size: 0.8rem; color: var(--gray-500); }
        .form-body { padding: 32px; }
        .step-progress { display: flex; justify-content: space-between; margin-bottom: 32px; padding: 0 20px; position: relative; }
        .step-progress::before { content: ''; position: absolute; top: 20px; left: 10%; right: 10%; height: 2px; background: var(--gray-200); z-index: 1; }
        .step { text-align: center; position: relative; z-index: 2; flex: 1; }
        .step-circle { width: 40px; height: 40px; background: var(--gray-200); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 8px; font-weight: 700; color: var(--gray-600); transition: all 0.3s; }
        .step.active .step-circle { background: var(--secondary); color: white; }
        .step.completed .step-circle { background: var(--success); color: white; }
        .step-label { font-size: 0.65rem; color: var(--gray-500); }
        .step.active .step-label { color: var(--secondary); font-weight: 600; }
        .form-section { display: none; }
        .form-section.active-section { display: block; }
        .section-title { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
        .section-icon { width: 40px; height: 40px; background: var(--gray-100); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; }
        .section-icon i { font-size: 1.2rem; color: var(--secondary); }
        .section-title h3 { font-size: 1.1rem; font-weight: 600; color: var(--gray-800); }
        .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 16px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 600; color: var(--gray-600); margin-bottom: 6px; }
        .form-group label i { margin-right: 6px; color: var(--secondary); font-size: 0.7rem; }
        .required { color: var(--secondary); }
        input, select, textarea { width: 100%; padding: 12px 14px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-family: 'Inter', sans-serif; font-size: 0.85rem; transition: all 0.2s ease; background: var(--white); }
        input:focus, select:focus, textarea:focus { border-color: var(--secondary); outline: none; box-shadow: 0 0 0 3px rgba(211,47,47,0.15); }
        textarea { resize: vertical; min-height: 80px; }
        .checkbox-group { display: flex; flex-wrap: wrap; gap: 16px; margin-top: 8px; }
        .checkbox-group label { display: flex; align-items: center; gap: 6px; font-weight: normal; cursor: pointer; margin-bottom: 0; }
        .checkbox-group input { width: 18px; height: 18px; }
        .toggle-container { display: flex; align-items: center; gap: 16px; padding: 12px 16px; background: var(--gray-50); border-radius: var(--radius-md); border: 1px solid var(--gray-200); flex-wrap: wrap; }
        .toggle-switch { position: relative; display: inline-block; width: 52px; height: 28px; flex-shrink: 0; cursor: pointer; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; cursor: pointer; }
        .toggle-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: 0.4s; border-radius: 34px; }
        .toggle-slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 4px; bottom: 4px; background-color: white; transition: 0.4s; border-radius: 50%; box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .toggle-switch input:checked + .toggle-slider { background-color: var(--secondary); }
        .toggle-switch input:checked + .toggle-slider:before { transform: translateX(24px); }
        .toggle-label { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); cursor: pointer; user-select: none; }
        .toggle-status { font-size: 0.7rem; font-weight: 600; padding: 2px 14px; border-radius: 12px; background: var(--gray-200); color: var(--gray-600); transition: all 0.3s; user-select: none; }
        .toggle-status.active { background: #FEE2E2; color: #991B1B; }
        .toggle-status.inactive { background: #D1FAE5; color: #065F46; }
        .camera-btn { background: var(--gray-100); border: 2px dashed var(--gray-300); padding: 16px; border-radius: var(--radius-md); text-align: center; cursor: pointer; transition: all 0.2s; touch-action: manipulation; }
        .camera-btn:hover, .camera-btn:active { border-color: var(--primary); background: var(--gray-50); transform: scale(1.02); }
        .camera-btn i { font-size: 2rem; color: var(--primary); margin-bottom: 8px; display: block; }
        .camera-btn span { font-size: 0.8rem; color: var(--gray-500); display: block; }
        .camera-btn .sub-text { font-size: 0.65rem; color: var(--gray-400); margin-top: 4px; }
        .file-name { font-size: 0.7rem; color: var(--gray-500); margin-top: 8px; text-align: center; padding: 6px; background: var(--gray-50); border-radius: var(--radius-sm); }
        .photo-preview { width: 100px; height: 100px; object-fit: cover; border-radius: var(--radius-md); margin-top: 10px; border: 2px solid var(--gray-200); }
        .photo-preview-container { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px; }
        .upload-section { background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin-bottom: 16px; border: 1px solid var(--gray-200); }
        .upload-section .upload-label { font-size: 0.8rem; font-weight: 600; color: var(--gray-700); margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .signature-container { position: relative; border: 2px solid var(--gray-200); border-radius: var(--radius-lg); background: var(--white); touch-action: none; cursor: crosshair; overflow: hidden; }
        .signature-container canvas { width: 100%; height: 180px; display: block; touch-action: none; }
        .signature-toolbar { display: flex; align-items: center; justify-content: space-between; padding: 10px 16px; background: var(--gray-50); border-top: 1px solid var(--gray-200); flex-wrap: wrap; gap: 8px; }
        .signature-toolbar .pen-indicator { display: flex; align-items: center; gap: 8px; font-size: 0.75rem; color: var(--gray-600); }
        .signature-toolbar .pen-indicator .pen-dot { width: 12px; height: 12px; border-radius: 50%; background: #1E4A8C; display: inline-block; }
        .btn-clear, .btn-undo { background: var(--gray-200); color: var(--gray-700); border: none; padding: 6px 16px; border-radius: var(--radius-md); cursor: pointer; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s; }
        .btn-clear:hover, .btn-undo:hover { background: var(--gray-300); }
        .signature-status { font-size: 0.7rem; color: var(--gray-500); margin-top: 6px; text-align: center; }
        .signature-status.signed { color: var(--success); }
        .verification-info { background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin: 16px 0; border-left: 4px solid var(--secondary); }
        .verification-info p { font-size: 0.75rem; margin: 5px 0; color: var(--gray-600); }
        .confidential-badge { background: #FEF2F0; text-align: center; padding: 14px; border-radius: var(--radius-lg); margin-bottom: 24px; color: #B91C1C; font-weight: 500; display: flex; align-items: center; justify-content: center; gap: 10px; border: 1px solid #FEE2E2; flex-wrap: wrap; }
        .risk-alert { background: #FEF2F0; border-left: 4px solid var(--secondary); padding: 16px; border-radius: var(--radius-lg); margin-bottom: 20px; }
        .child-entry { background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin-bottom: 16px; border: 1px solid var(--gray-200); }
        .child-entry h4 { font-size: 0.85rem; font-weight: 600; color: var(--primary); margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
        .btn-add { background: var(--secondary); color: white; border: none; padding: 8px 16px; border-radius: 40px; cursor: pointer; font-weight: 600; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 6px; }
        .btn-remove { background: #FEF2F0; color: var(--secondary); border: 1px solid var(--secondary); padding: 5px 12px; border-radius: 20px; cursor: pointer; font-size: 0.7rem; }
        .nav-buttons { display: flex; justify-content: space-between; margin-top: 32px; gap: 16px; }
        .btn-prev, .btn-next, .btn-submit { padding: 12px 24px; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: all 0.2s; border: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-prev { background: var(--gray-100); color: var(--gray-700); border: 1px solid var(--gray-200); }
        .btn-prev:hover { background: var(--gray-200); }
        .btn-next, .btn-submit { background: var(--secondary); color: white; }
        .btn-next:hover, .btn-submit:hover { background: #B71C1C; transform: translateY(-1px); }
        .alert { padding: 16px 20px; border-radius: var(--radius-lg); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }
        .alert-info { background: #FFF9EF; border-left: 3px solid var(--accent); color: #7B5E2A; }
        .info-text { font-size: 0.7rem; color: var(--gray-500); margin-top: 4px; }
        .case-badge { background: var(--secondary); color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; display: inline-block; margin-bottom: 16px; }
        hr { margin: 20px 0; border: 0; height: 1px; background: var(--gray-200); }
        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .qr-preview { text-align: center; padding: 15px; background: var(--gray-50); border-radius: var(--radius-lg); margin-top: 15px; }
        .welcome-card { background: linear-gradient(135deg, #7F1D1D 0%, #991B1B 100%); border-radius: var(--radius-xl); padding: 32px; color: white; margin-bottom: 24px; text-align: center; }
        .welcome-card .welcome-icon { width: 80px; height: 80px; background: rgba(255,255,255,0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; border: 3px solid rgba(255,255,255,0.3); }
        .welcome-card .welcome-icon i { font-size: 2.5rem; color: #FEF3C7; }
        .welcome-card h2 { font-size: 1.6rem; margin-bottom: 8px; font-weight: 700; }
        .welcome-card p { opacity: 0.9; font-size: 0.9rem; line-height: 1.6; }
        .welcome-card .case-info { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.15); padding: 8px 20px; border-radius: 40px; margin-top: 16px; font-family: monospace; font-size: 1rem; font-weight: 600; letter-spacing: 1px; }
        .welcome-card .case-info i { color: #FEF3C7; }
        .info-card { background: white; border-radius: var(--radius-lg); padding: 20px; margin-bottom: 16px; border: 1px solid var(--gray-200); display: flex; gap: 16px; align-items: flex-start; }
        .info-card .info-icon { width: 44px; height: 44px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .info-card .info-icon.blue { background: #EFF6FF; color: #1E4A8C; }
        .info-card .info-icon.green { background: #ECFDF5; color: #059669; }
        .info-card .info-icon.orange { background: #FFF7ED; color: #EA580C; }
        .info-card .info-icon.red { background: #FEF2F2; color: #D32F2F; }
        .info-card .info-icon i { font-size: 1.3rem; }
        .info-card .info-body h4 { font-size: 0.95rem; font-weight: 700; color: var(--gray-800); margin-bottom: 4px; }
        .info-card .info-body p { font-size: 0.8rem; color: var(--gray-600); line-height: 1.5; }
        .checklist { list-style: none; margin-top: 12px; }
        .checklist li { display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; font-size: 0.85rem; color: var(--gray-700); border-bottom: 1px solid var(--gray-100); }
        .checklist li:last-child { border-bottom: none; }
        .checklist li i { color: #F5B042; margin-top: 3px; flex-shrink: 0; }
        .consent-box { background: #F8FAFC; border: 2px dashed var(--gray-300); border-radius: var(--radius-lg); padding: 20px; margin-top: 20px; }
        .consent-box label { display: flex; align-items: flex-start; gap: 12px; cursor: pointer; font-size: 0.85rem; color: var(--gray-700); line-height: 1.6; }
        .consent-box input[type="checkbox"] { width: 20px; height: 20px; margin-top: 2px; flex-shrink: 0; }
        .emergency-hotline { background: #FEF2F0; border: 2px solid #FCA5A5; border-radius: var(--radius-lg); padding: 16px; margin-bottom: 16px; }
        .emergency-hotline h4 { color: #991B1B; font-size: 0.95rem; margin-bottom: 10px; display: flex; align-items: center; gap: 8px; }
        .emergency-hotline ul { list-style: none; font-size: 0.85rem; color: #7F1D1D; }
        .emergency-hotline ul li { padding: 4px 0; display: flex; align-items: center; gap: 8px; }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .form-body { padding: 20px; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .step-label { font-size: 0.5rem; }
            .step-circle { width: 30px; height: 30px; font-size: 0.8rem; }
        }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Municipal Social Welfare</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="dashboards/resident_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Dashboard</span></a>
                <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item"><i class="fas fa-users"></i><span>Household Profile</span></a>
                <a href="modules/my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i><span>My Applications</span></a>
                <a href="notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i><span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i><span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="vawc.php" class="submenu-item active"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="modules/survey_form.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Community Survey</span></a>
                <a href="id_application.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Application</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile_settings.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile Settings</span></a>
                <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>VAWC Assistance Program</h1>
                    <p>Violence Against Women and Children · Republic Act No. 9262</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info"><span><?php echo htmlspecialchars($full_name); ?></span><small><?php echo ucfirst($role); ?></small></div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <?php if(!$pin_verified): ?>
        <div class="pin-lock">
            <i class="fas fa-shield-alt"></i>
            <h3>Secure Access Required</h3>
            <p>This section contains confidential information. Please enter the VAWC security PIN to continue.</p>
            <?php if(isset($pin_error)): ?>
                <div class="alert alert-danger" style="margin-bottom: 20px;"><?php echo $pin_error; ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group"><input type="password" name="security_pin" class="pin-input" placeholder="****" maxlength="4" pattern="[0-9]{4}" required></div>
                <button type="submit" name="verify_pin" class="btn-submit" style="margin-top: 20px;">Verify Access</button>
            </form>
            <div class="info-text" style="margin-top: 20px;"><i class="fas fa-lock"></i> For assistance, please contact the MSWDO VAWC Desk.</div>
        </div>
        <?php else: ?>
        
        <div class="form-card">
            <div class="form-header">
                <i class="fas fa-shield-alt"></i>
                <h2>VAWC Application Form</h2>
                <p>5-Step Mobile Form Wizard | Confidential & Encrypted</p>
            </div>

            <div class="form-body">
                <div class="confidential-badge">
                    <i class="fas fa-lock"></i> This application is 100% CONFIDENTIAL. Your information is protected by law.
                    <i class="fas fa-heart" style="color: var(--secondary);"></i> You are not alone. Help is available.
                </div>

                <?php if($success): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <div class="alert alert-info">
                        <i class="fas fa-phone-alt"></i> <strong>Need immediate help?</strong><br>
                        MSWDO VAWC Hotline: 0912-680-1669<br>
                        PNP WCPD: 0939-902-3995<br>
                        Emergency: 911
                    </div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($existing_app && !$success): ?>
                    <div class="alert alert-info"><i class="fas fa-clock"></i> You already have a pending or approved application for this program.</div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php else: ?>
                
                <div class="step-progress">
                    <div class="step active" id="step1Indicator"><div class="step-circle">1</div><div class="step-label">Getting Started</div></div>
                    <div class="step" id="step2Indicator"><div class="step-circle">2</div><div class="step-label">Client Profile</div></div>
                    <div class="step" id="step3Indicator"><div class="step-circle">3</div><div class="step-label">VAWC Details</div></div>
                    <div class="step" id="step4Indicator"><div class="step-circle">4</div><div class="step-label">Risk Assessment</div></div>
                    <div class="step" id="step5Indicator"><div class="step-circle">5</div><div class="step-label">Verification</div></div>
                </div>

                <form method="POST" enctype="multipart/form-data" id="vawcForm">
                    <input type="hidden" name="apply" value="1">
                    <input type="hidden" name="client_signature" id="client_signature" value="">

                    <div class="form-section active-section" id="step1">
                        <div class="welcome-card">
                            <div class="welcome-icon"><i class="fas fa-shield-alt"></i></div>
                            <h2>VAWC Assistance Program</h2>
                            <p>Your safety is our priority. This form is <strong>100% confidential</strong> and your information is protected by law.</p>
                            <div class="case-info"><i class="fas fa-hashtag"></i> <?php echo $case_no; ?></div>
                        </div>
                        <div class="emergency-hotline">
                            <h4><i class="fas fa-phone-alt"></i> If You Are In Immediate Danger</h4>
                            <ul>
                                <li><i class="fas fa-phone"></i> <strong>Emergency:</strong> 911</li>
                                <li><i class="fas fa-phone"></i> <strong>MSWDO VAWC Hotline:</strong> 0912-680-1669</li>
                                <li><i class="fas fa-phone"></i> <strong>PNP WCPD:</strong> 0939-902-3995</li>
                            </ul>
                        </div>
                        <div class="info-card">
                            <div class="info-icon red"><i class="fas fa-heart"></i></div>
                            <div class="info-body">
                                <h4>You Are Not Alone</h4>
                                <p>If you are in immediate danger, please call the hotlines above. This form can be submitted at any time and a social worker will respond within 24 hours.</p>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon blue"><i class="fas fa-info-circle"></i></div>
                            <div class="info-body">
                                <h4>About This Program</h4>
                                <p>The VAWC Program under Republic Act No. 9262 provides protection, support, and assistance to women and children who are victims of violence and abuse.</p>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon orange"><i class="fas fa-clipboard-list"></i></div>
                            <div class="info-body">
                                <h4>What You'll Need to Prepare</h4>
                                <ul class="checklist">
                                    <li><i class="fas fa-check-circle"></i> Incident details (date, time, location, description)</li>
                                    <li><i class="fas fa-check-circle"></i> Information about the perpetrator</li>
                                    <li><i class="fas fa-check-circle"></i> Blotter/Police report number (if available)</li>
                                    <li><i class="fas fa-check-circle"></i> 1x1 photo (encrypted, not saved to gallery)</li>
                                </ul>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon green"><i class="fas fa-lock"></i></div>
                            <div class="info-body">
                                <h4>Confidentiality Guarantee</h4>
                                <p>Your identity and all information you provide will be treated with the strictest confidentiality. Your data is protected under RA 9262 and RA 10173.</p>
                            </div>
                        </div>
                        <div class="consent-box">
                            <label>
                                <input type="checkbox" id="step1_consent" required>
                                <span>I have read and understood the information above. I confirm that I am a resident of this municipality and I am seeking assistance for a VAWC-related incident.</span>
                            </label>
                        </div>
                    </div>

                    <div class="form-section" id="step2">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-id-card"></i></div><h3>Step 2: Client Profile</h3></div>
                        <div class="form-row">
                            <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="first_name" required></div>
                            <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name"></div>
                            <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="last_name" required></div>
                            <div class="form-group"><label>Suffix</label><input type="text" name="suffix" placeholder="Jr., Sr., III"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthdate</label><input type="date" name="birthdate" id="birthdate" onchange="calculateAge()"></div>
                            <div class="form-group"><label>Age</label><input type="number" name="age" id="age" readonly></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthplace</label><input type="text" name="birthplace"></div>
                            <div class="form-group"><label>Sex</label><select name="sex"><option value="">Select</option><option>Female</option><option>Male</option></select></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Civil Status</label><select name="civil_status"><option value="">Select</option><option>Single</option><option>Married</option><option>Separated</option><option>Widowed</option><option>Live-in</option></select></div>
                            <div class="form-group"><label>Religion</label><input type="text" name="religion"></div>
                        </div>
                        <div class="form-group"><label>Street Address</label><input type="text" name="street_address"></div>
                        <div class="form-row">
                            <div class="form-group"><label>Barangay</label><input type="text" name="barangay"></div>
                            <div class="form-group"><label>Municipality</label><input type="text" name="municipality"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Province</label><input type="text" name="province"></div>
                            <div class="form-group"><label>Contact Number</label><input type="text" name="contact_no"></div>
                        </div>
                        <div class="form-group"><label>Email Address</label><input type="email" name="email"></div>
                        <div class="form-row">
                            <div class="form-group"><label>Occupation</label><input type="text" name="occupation"></div>
                            <div class="form-group"><label>Monthly Income (₱)</label><input type="number" name="monthly_income" step="500"></div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-child"></i> Do you have children?</label>
                            <select name="has_children" id="hasChildren" onchange="toggleChildrenFields()"><option value="">Select</option><option value="yes">Yes</option><option value="no">No</option></select>
                        </div>
                        <div id="childrenFields" style="display: none;">
                            <div id="childrenContainer"></div>
                            <button type="button" class="btn-add" onclick="addChild()"><i class="fas fa-plus"></i> Add Child</button>
                            <div class="form-group" style="margin-top: 16px;">
                                <label>Were the children affected by the violence?</label>
                                <textarea name="children_affected" rows="2" placeholder="Describe how the children were affected"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="form-section" id="step3">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-hand-holding-heart"></i></div><h3>Step 3: VAWC Program Details</h3></div>
                        <div class="form-group">
                            <label><i class="fas fa-user-friends"></i> Relationship to the Perpetrator <span class="required">*</span></label>
                            <select name="perpetrator_relation" required><option value="">Select</option><option>Husband</option><option>Live-in Partner</option><option>Ex-Partner</option><option>Employer</option><option>Relative</option><option>Other</option></select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-exclamation-triangle"></i> Type of Abuse Experienced <span class="required">*</span></label>
                            <div class="checkbox-group">
                                <label><input type="checkbox" name="abuse_types[]" value="Physical"> Physical</label>
                                <label><input type="checkbox" name="abuse_types[]" value="Sexual"> Sexual</label>
                                <label><input type="checkbox" name="abuse_types[]" value="Psychological"> Psychological</label>
                                <label><input type="checkbox" name="abuse_types[]" value="Economic/Financial"> Economic/Financial</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-chart-line"></i> Frequency of Incidents</label>
                            <select name="incident_frequency"><option value="">Select</option><option>First Time</option><option>Occasional</option><option>Habitual</option></select>
                        </div>
                        <div class="risk-alert">
                            <div class="form-group">
                                <label><i class="fas fa-skull-crosswalk"></i> Is the client in immediate physical danger?</label>
                                <div class="toggle-container">
                                    <label class="toggle-switch"><input type="checkbox" name="in_immediate_danger" id="immediateDanger" value="1"><span class="toggle-slider"></span></label>
                                    <span class="toggle-label">In Immediate Danger</span>
                                    <span class="toggle-status inactive" id="dangerStatusLabel">No</span>
                                </div>
                                <div class="info-text">If Yes, flags Red Alert on Admin Dashboard</div>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-child"></i> Are children involved/witnesses?</label>
                                <div class="toggle-container">
                                    <label class="toggle-switch"><input type="checkbox" name="children_as_witnesses" id="childrenWitnesses" value="1"><span class="toggle-slider"></span></label>
                                    <span class="toggle-label">Children as Witnesses</span>
                                    <span class="toggle-status inactive" id="witnessStatusLabel">No</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-home"></i> Current Safe Location of Client</label>
                                <select name="current_safe_location"><option value="">Select</option><option>Barangay VAWC Desk</option><option>Relatives</option><option>Protected Shelter</option><option>Remaining at Home</option><option>Other</option></select>
                            </div>
                        </div>
                        <div class="form-group"><label><i class="fas fa-calendar-day"></i> Date of Incident <span class="required">*</span></label><input type="date" name="incident_date" required></div>
                        <div class="form-row">
                            <div class="form-group"><label>Time of Incident</label><input type="time" name="incident_time"></div>
                            <div class="form-group"><label>Location of Incident</label><input type="text" name="incident_location"></div>
                        </div>
                        <div class="form-group"><label><i class="fas fa-file-text"></i> Incident Description <span class="required">*</span></label><textarea name="incident_description" rows="3" placeholder="Describe what happened..." required></textarea></div>
                        <div class="form-group"><label><i class="fas fa-user-slash"></i> Perpetrator's Full Name</label><input type="text" name="perpetrator_name"></div>
                        <div class="form-row">
                            <div class="form-group"><label>Perpetrator's Age</label><input type="number" name="perpetrator_age"></div>
                            <div class="form-group"><label>Perpetrator's Address</label><input type="text" name="perpetrator_address"></div>
                        </div>
                        <div class="form-group"><label><i class="fas fa-gun"></i> Does perpetrator have a weapon?</label><select name="perpetrator_has_weapon"><option value="">Select</option><option value="yes">Yes</option><option value="no">No</option></select></div>
                        <div class="form-group"><label><i class="fas fa-band-aid"></i> Did you sustain physical injuries?</label><select name="physical_injuries"><option value="">Select</option><option value="yes">Yes</option><option value="no">No</option></select></div>
                        <div class="form-group"><label><i class="fas fa-gavel"></i> Do you have a Protection Order?</label><select name="has_protection_order"><option value="">Select</option><option value="yes">Yes</option><option value="no">No</option></select></div>
                        <div class="form-group"><label>Type of Protection Order</label><select name="protection_order_type"><option value="">Select</option><option>Barangay Protection Order (BPO)</option><option>Temporary Protection Order (TPO)</option><option>Permanent Protection Order (PPO)</option></select></div>
                        <div class="form-group"><label>Has Barangay Blotter / Police Report?</label><select name="has_blotter"><option value="">Select</option><option value="yes">Yes</option><option value="no">No</option></select></div>
                        <div class="form-group"><label><i class="fas fa-exclamation-triangle"></i> Problem Presented <span class="required">*</span></label><textarea name="problem_presented" rows="2" placeholder="Domestic violence, trauma, and threats to physical safety and psychological well-being..." required></textarea></div>
                        <div class="form-group">
                            <label><i class="fas fa-bullseye"></i> Rehabilitation Goal</label>
                            <div class="checkbox-group">
                                <label><input type="checkbox" name="rehabilitation_goals[]" value="To correct manifested social deviance"> To correct manifested social deviance</label>
                                <label><input type="checkbox" name="rehabilitation_goals[]" value="To overcome presented crisis"> To overcome presented crisis</label>
                                <label><input type="checkbox" name="rehabilitation_goals[]" value="To improve social functioning"> To improve social functioning</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-ambulance"></i> Action Taken / Immediate Referral</label>
                            <div class="checkbox-group">
                                <label><input type="checkbox" name="action_taken_referral[]" value="PNP-WCPD (Police)"> PNP-WCPD (Police)</label>
                                <label><input type="checkbox" name="action_taken_referral[]" value="Barangay VAWC Desk"> Barangay VAWC Desk</label>
                                <label><input type="checkbox" name="action_taken_referral[]" value="Hospital/Medico-Legal"> Hospital/Medico-Legal</label>
                                <label><input type="checkbox" name="action_taken_referral[]" value="Temporary Safehouse"> Temporary Safehouse</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-section" id="step4">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-chart-line"></i></div><h3>Step 4: Risk Assessment</h3></div>
                        <div class="form-group">
                            <label><i class="fas fa-skull-crosswalk"></i> Do you believe your life is in danger?</label>
                            <select name="life_threatened"><option value="">Select</option><option value="yes">Yes</option><option value="no">No</option></select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-chart-line"></i> Risk Level (self-assessment)</label>
                            <select name="risk_level"><option value="">Select</option><option>Low</option><option>Moderate</option><option>High</option><option>Immediate Danger</option></select>
                        </div>
                        <div class="checkbox-group">
                            <label><input type="checkbox" name="needs_emergency_shelter"> Emergency Shelter</label>
                            <label><input type="checkbox" name="needs_medical_care"> Immediate Medical Care</label>
                            <label><input type="checkbox" name="needs_psychological_support"> Crisis Counseling / Psychological Support</label>
                        </div>
                    </div>

                    <div class="form-section" id="step5">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-shield-alt"></i></div><h3>Step 5: Digital Verification</h3></div>
                        <div class="form-group"><label><input type="checkbox" name="client_consent" value="1" required> Client consents to confidential data collection & analytics.</label></div>
                        <div class="upload-section">
                            <div class="upload-label"><i class="fas fa-camera-retro" style="color: var(--secondary);"></i> 1. IDENTITY CAPTURE <span class="required">*</span></div>
                            <div class="camera-btn" onclick="document.getElementById('identity_photo').click()"><i class="fas fa-camera"></i><span>📸 SNAP PHOTO OF CLIENT HOLDING CONSENT/ID</span><span class="sub-text">Tap to open camera</span></div>
                            <input type="file" id="identity_photo" name="identity_photo" accept="image/*" style="display:none" onchange="previewIdentityPhoto(this)" capture="environment">
                            <div id="identityPhotoPreview" class="photo-preview-container"></div>
                            <div class="verification-info" style="margin-top: 12px;">
                                <p><i class="fas fa-clock"></i> Captured at: <?php echo date('F j, Y - H:i'); ?></p>
                                <p><i class="fas fa-lock"></i> Image is encrypted and NOT saved to device gallery</p>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-signature"></i> 2. DIGITAL TOUCH SIGNATURE <span class="required">*</span></label>
                            <div class="signature-container">
                                <canvas id="signatureCanvas" width="600" height="180"></canvas>
                                <div class="signature-toolbar">
                                    <div class="pen-indicator"><span class="pen-dot"></span><span>Pen: <strong>Digital Signature</strong></span><span style="color: var(--gray-400);">|</span><span id="signatureStatus" style="font-size: 0.65rem;">Not signed yet</span></div>
                                    <div class="signature-actions"><button type="button" class="btn-undo" onclick="undoSignature()"><i class="fas fa-undo"></i> Undo</button><button type="button" class="btn-clear" onclick="clearSignature()"><i class="fas fa-eraser"></i> Clear</button></div>
                                </div>
                            </div>
                            <div class="signature-status" id="signatureStatusMessage"><i class="fas fa-pen"></i> Draw your signature using your finger or stylus</div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-qrcode"></i> 3. OFFICE USE: VERIFICATION TRACKING</label>
                            <div class="verification-info">
                                <p><i class="fas fa-spinner fa-pulse"></i> System generating secure verification QR string...</p>
                                <p><i class="fas fa-lock"></i> Case No: <strong><?php echo $case_no; ?></strong></p>
                                <p><i class="fas fa-check-circle"></i> Upon approval, a Digital Certificate with QR Code will be issued.</p>
                                <div class="qr-preview">
                                    <i class="fas fa-qrcode" style="font-size: 3rem; color: var(--secondary);"></i>
                                    <p style="font-size: 0.7rem; margin-top: 8px;">QR Code for secure verification</p>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> CASEWORKER APPROVAL</label>
                            <div class="alert alert-info" style="margin-bottom: 0;"><i class="fas fa-user-check"></i> Logged in as: <?php echo htmlspecialchars($full_name); ?> (ID: #<?php echo $user_id; ?>)</div>
                        </div>
                    </div>

                    <div class="nav-buttons">
                        <button type="button" class="btn-prev" id="prevBtn" onclick="changeStep(-1)" style="display:none;"><i class="fas fa-chevron-left"></i> Previous</button>
                        <button type="button" class="btn-next" id="nextBtn" onclick="changeStep(1)">Next <i class="fas fa-chevron-right"></i></button>
                        <button type="submit" class="btn-submit" id="submitBtn" style="display:none;"><i class="fas fa-shield-alt"></i> SUBMIT CONFIDENTIAL APPLICATION</button>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>

<script>
    var childCount = 0;
    var currentStep = 1;
    var totalSteps = 5;

    document.addEventListener('DOMContentLoaded', function() {
        var menuToggle = document.getElementById('menuToggle');
        var sidebar = document.getElementById('sidebar');
        if(menuToggle && sidebar) {
            menuToggle.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('open');
            });
        }
        document.addEventListener('click', function(event) {
            if(window.innerWidth <= 768 && sidebar && menuToggle) {
                if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                    sidebar.classList.remove('open');
                }
            }
        });

        var programToggle = document.getElementById('programToggle');
        var programSubmenu = document.getElementById('programSubmenu');
        var programIcon = document.getElementById('programIcon');

        if(programToggle && programSubmenu && programIcon) {
            programSubmenu.classList.add('show');
            programIcon.classList.add('rotated');

            programToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                programSubmenu.classList.toggle('show');
                programIcon.classList.toggle('rotated');
            });
        }

        setTimeout(resizeCanvas, 200);

        var immediateDangerToggle = document.getElementById('immediateDanger');
        var childrenWitnessesToggle = document.getElementById('childrenWitnesses');
        if(immediateDangerToggle) {
            immediateDangerToggle.addEventListener('change', toggleImmediateDanger);
            toggleImmediateDanger();
        }
        if(childrenWitnessesToggle) {
            childrenWitnessesToggle.addEventListener('change', toggleChildrenWitnesses);
            toggleChildrenWitnesses();
        }
    });

    function toggleImmediateDanger() {
        var checkbox = document.getElementById('immediateDanger');
        var label = document.getElementById('dangerStatusLabel');
        if(checkbox && label) {
            if(checkbox.checked) { label.textContent = 'Yes'; label.className = 'toggle-status active'; }
            else { label.textContent = 'No'; label.className = 'toggle-status inactive'; }
        }
    }

    function toggleChildrenWitnesses() {
        var checkbox = document.getElementById('childrenWitnesses');
        var label = document.getElementById('witnessStatusLabel');
        if(checkbox && label) {
            if(checkbox.checked) { label.textContent = 'Yes'; label.className = 'toggle-status active'; }
            else { label.textContent = 'No'; label.className = 'toggle-status inactive'; }
        }
    }

    function calculateAge() {
        var birthdate = document.getElementById('birthdate');
        if(!birthdate) return;
        var val = birthdate.value;
        if(val) {
            var today = new Date();
            var birth = new Date(val);
            var age = today.getFullYear() - birth.getFullYear();
            var m = today.getMonth() - birth.getMonth();
            if(m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
            var ageInput = document.getElementById('age');
            if(ageInput) ageInput.value = age;
        }
    }

    function toggleChildrenFields() {
        var hasChildren = document.getElementById('hasChildren');
        var childrenFields = document.getElementById('childrenFields');
        if(childrenFields) {
            childrenFields.style.display = (hasChildren && hasChildren.value === 'yes') ? 'block' : 'none';
        }
    }

    function addChild() {
        childCount++;
        var container = document.getElementById('childrenContainer');
        if(container) {
            var div = document.createElement('div');
            div.className = 'child-entry';
            div.id = 'child_' + childCount;
            div.innerHTML = `
                <h4><i class="fas fa-child"></i> Child ${childCount}</h4>
                <div class="form-row">
                    <div class="form-group"><label>Child's Full Name</label><input type="text" name="child_name[]" placeholder="Full name"></div>
                    <div class="form-group"><label>Age</label><input type="number" name="child_age[]"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Sex</label><select name="child_sex[]"><option value="">Select</option><option>Male</option><option>Female</option></select></div>
                    <div class="form-group"><label>Relationship to Client</label><input type="text" name="child_relation[]" placeholder="e.g., Son, Daughter"></div>
                </div>
                <button type="button" class="btn-remove" onclick="removeChild(${childCount})"><i class="fas fa-trash"></i> Remove</button>
            `;
            container.appendChild(div);
        }
    }

    function removeChild(id) {
        var element = document.getElementById('child_' + id);
        if(element) element.remove();
    }

    var canvas = document.getElementById('signatureCanvas');
    var ctx = canvas ? canvas.getContext('2d') : null;
    var drawing = false;
    var signatureHistory = [];
    var currentPath = [];

    function resizeCanvas() {
        if(!canvas || !ctx) return;
        var container = canvas.parentElement;
        if(!container) return;
        var rect = container.getBoundingClientRect();
        canvas.width = rect.width || 600;
        canvas.height = 180;
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#1E4A8C';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        if (signatureHistory.length > 0) redrawSignature();
    }

    function redrawSignature() {
        if(!ctx) return;
        ctx.fillStyle = 'white'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#1E4A8C'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        for (var i = 0; i < signatureHistory.length; i++) {
            var path = signatureHistory[i];
            if (path.length > 1) {
                ctx.beginPath();
                ctx.moveTo(path[0].x, path[0].y);
                for (var j = 1; j < path.length; j++) ctx.lineTo(path[j].x, path[j].y);
                ctx.stroke();
            }
        }
    }

    function startDrawing(e) { e.preventDefault(); drawing = true; currentPath = []; var pos = getCanvasCoordinates(e); currentPath.push(pos); ctx.beginPath(); ctx.moveTo(pos.x, pos.y); ctx.lineTo(pos.x, pos.y); ctx.stroke(); updateSignatureStatus(true); }
    function draw(e) { e.preventDefault(); if(!drawing) return; var pos = getCanvasCoordinates(e); currentPath.push(pos); ctx.lineTo(pos.x, pos.y); ctx.stroke(); ctx.beginPath(); ctx.moveTo(pos.x, pos.y); }
    function stopDrawing(e) { e.preventDefault(); if(drawing && currentPath.length > 1) { signatureHistory.push(currentPath.slice()); var sigInput = document.getElementById('client_signature'); if(sigInput) sigInput.value = canvas.toDataURL(); } drawing = false; ctx.beginPath(); updateSignatureStatus(signatureHistory.length > 0); }

    function getCanvasCoordinates(e) {
        var rect = canvas.getBoundingClientRect();
        var scaleX = canvas.width / rect.width;
        var scaleY = canvas.height / rect.height;
        var clientX, clientY;
        if(e.touches) { clientX = e.touches[0].clientX; clientY = e.touches[0].clientY; }
        else { clientX = e.clientX; clientY = e.clientY; }
        var x = (clientX - rect.left) * scaleX;
        var y = (clientY - rect.top) * scaleY;
        x = Math.min(Math.max(0, x), canvas.width);
        y = Math.min(Math.max(0, y), canvas.height);
        return { x: x, y: y };
    }

    function undoSignature() { if (signatureHistory.length > 0) { signatureHistory.pop(); redrawSignature(); var sigInput = document.getElementById('client_signature'); if(sigInput) sigInput.value = signatureHistory.length > 0 ? canvas.toDataURL() : ''; updateSignatureStatus(signatureHistory.length > 0); } }
    function clearSignature() { signatureHistory = []; ctx.fillStyle = 'white'; ctx.fillRect(0, 0, canvas.width, canvas.height); var sigInput = document.getElementById('client_signature'); if(sigInput) sigInput.value = ''; updateSignatureStatus(false); }
    function updateSignatureStatus(signed) { var status = document.getElementById('signatureStatus'); var message = document.getElementById('signatureStatusMessage'); if(!status || !message) return; if (signed) { status.textContent = '✅ Signed'; status.style.color = '#059669'; message.innerHTML = '<i class="fas fa-check-circle" style="color: #059669;"></i> Signature captured successfully!'; message.className = 'signature-status signed'; } else { status.textContent = 'Not signed yet'; status.style.color = '#64748B'; message.innerHTML = '<i class="fas fa-pen"></i> Draw your signature using your finger or stylus'; message.className = 'signature-status'; } }

    function previewIdentityPhoto(input) {
        var previewContainer = document.getElementById('identityPhotoPreview');
        if(input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) { previewContainer.innerHTML = '<img src="' + e.target.result + '" class="photo-preview" alt="Identity Photo">'; };
            reader.readAsDataURL(input.files[0]);
        }
    }

    if(canvas) {
        canvas.addEventListener('mousedown', startDrawing);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', stopDrawing);
        canvas.addEventListener('mouseleave', stopDrawing);
        canvas.addEventListener('touchstart', startDrawing, { passive: false });
        canvas.addEventListener('touchmove', draw, { passive: false });
        canvas.addEventListener('touchend', stopDrawing, { passive: false });
    }

    function changeStep(direction) {
        if (direction > 0 && currentStep === 1) {
            var consent = document.getElementById('step1_consent');
            if (consent && !consent.checked) { alert('Please confirm that you have read and understood the information above.'); return; }
        }
        var sections = document.querySelectorAll('.form-section');
        var steps = document.querySelectorAll('.step');
        if(currentStep - 1 >= sections.length) return;
        sections[currentStep - 1].classList.remove('active-section');
        steps[currentStep - 1].classList.remove('active');
        steps[currentStep - 1].classList.add('completed');
        currentStep += direction;
        sections[currentStep - 1].classList.add('active-section');
        steps[currentStep - 1].classList.add('active');
        var prevBtn = document.getElementById('prevBtn');
        var nextBtn = document.getElementById('nextBtn');
        var submitBtn = document.getElementById('submitBtn');
        if(currentStep === 1) prevBtn.style.display = 'none'; else prevBtn.style.display = 'inline-flex';
        if(currentStep === totalSteps) { nextBtn.style.display = 'none'; submitBtn.style.display = 'inline-flex'; } else { nextBtn.style.display = 'inline-flex'; submitBtn.style.display = 'none'; }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
</script>
   <?= renderPwaServiceWorker() ?>
</body>
</html>