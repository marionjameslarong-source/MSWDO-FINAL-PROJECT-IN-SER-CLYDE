<?php
require_once 'config/database.php';

if(isset($_GET['username'])) {
    $username = trim($_GET['username']);
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    
    $exists = $stmt->fetch() ? true : false;
    
    header('Content-Type: application/json');
    echo json_encode(['exists' => $exists]);
} else {
    echo json_encode(['exists' => false]);
}
?>