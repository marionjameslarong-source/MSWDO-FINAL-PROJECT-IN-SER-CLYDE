<?php
echo "<h2>PHP Extensions Check</h2>";
echo "<p><strong>GD:</strong> " . (extension_loaded('gd') ? "✅ Enabled" : "❌ Missing") . "</p>";
echo "<p><strong>Zip:</strong> " . (extension_loaded('zip') ? "✅ Enabled" : "❌ Missing") . "</p>";
echo "<p><strong>PHP Version:</strong> " . PHP_VERSION . "</p>";

if (extension_loaded('gd') && extension_loaded('zip')) {
    echo "<h3 style='color:green;'>✅ All good! You can now install PhpWord 1.4.0.</h3>";
} else {
    echo "<h3 style='color:red;'>❌ Fix php.ini and restart Apache.</h3>";
}