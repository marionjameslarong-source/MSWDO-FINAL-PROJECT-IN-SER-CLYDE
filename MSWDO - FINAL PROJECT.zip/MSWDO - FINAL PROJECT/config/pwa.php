<?php
// config/pwa.php
require_once __DIR__ . '/../vendor/autoload.php';

use Zmrq\PWA\Pwa;

// DISABLED — we are using manual PWA setup (see config/database.php helpers)
// The library was overwriting our custom manifest.json with its default
// "PHP PWA" branding every time a page loaded, so we no longer call enable().
//
// Pwa::enable(dir: 'pwa');

// Manually crafted manifest lives at: /pwa/manifest.json
// Manually crafted service worker lives at: /pwa/sw.js