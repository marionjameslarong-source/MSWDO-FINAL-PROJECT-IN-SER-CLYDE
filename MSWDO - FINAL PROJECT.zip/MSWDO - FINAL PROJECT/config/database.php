<?php
// ============================================================
// DATABASE CONNECTION CONFIGURATION
// MSWDO Cantilan - Municipal Social Welfare & Development Office
// ============================================================

// Database credentials (adjust these to match your local setup)
$host = 'localhost';
$dbname = 'mswdo_db';
$username = 'root';
$password = '';
$charset = 'utf8mb4';

// ============================================================
// PDO CONNECTION
// ============================================================
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// ============================================================
// LOAD PWA CONFIGURATION
// ============================================================
require_once __DIR__ . '/pwa.php';

// ============================================================
// PWA HELPER FUNCTIONS (with absolute paths — works from subfolders)
// ============================================================

/**
 * Detects the project base path automatically (e.g. /mswdo/)
 */
function getPwaBasePath() {
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    if (preg_match('#^(/[^/]+/)#', $script, $matches)) {
        return $matches[1]; // returns "/mswdo/"
    }
    return '/';
}

/**
 * Renders PWA meta tags with absolute paths.
 */
function renderPwaMetaTags() {
    $base = getPwaBasePath();
    $html  = '<link rel="manifest" href="' . $base . 'pwa/manifest.json">' . "\n";
    $html .= '    <meta name="theme-color" content="#1E4A8C">' . "\n";
    $html .= '    <link rel="apple-touch-icon" href="' . $base . 'pwa/logo.png">' . "\n";
    $html .= '    <meta name="mobile-web-app-capable" content="yes">' . "\n";
    $html .= '    <meta name="apple-mobile-web-app-status-bar-style" content="default">' . "\n";
    $html .= '    <meta name="apple-mobile-web-app-title" content="MSWDO">';
    return $html;
}

/**
 * Renders PWA service worker registration with absolute paths.
 * The service worker lives in the project root so it can control
 * the entire application (all subfolders included).
 */
function renderPwaServiceWorker() {
    $base  = getPwaBasePath();      // e.g. "/mswdo/"
    $swUrl = $base . 'sw.js';       // /mswdo/sw.js  (project root)
    $scope = $base;                 // /mswdo/
    
    return <<<HTML
<script>
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('{$swUrl}', { scope: '{$scope}' })
                .then(function(reg) {
                    console.log('SW registered. Scope:', reg.scope);
                })
                .catch(function(err) {
                    console.warn('SW registration failed:', err);
                });
        });
    }
</script>
HTML;
}