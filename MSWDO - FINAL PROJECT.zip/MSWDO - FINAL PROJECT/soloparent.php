<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];
$error = '';
$success = '';

// Get sidebar household ID for dynamic navigation
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get unread notification count for sidebar badge
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

// Fetch household data
$stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
$stmt->execute([$user_id]);
$household = $stmt->fetch();

// Check existing application
$stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'solo_parent' AND status IN ('pending', 'approved')");
$stmt->execute([$user_id]);
$existing_app = $stmt->fetch();

// Generate unique Case No. and Reference Code
$case_no = 'MSWDO-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
$ref_code = strtoupper(substr(md5(uniqid($user_id, true)), 0, 8));

define('UPLOAD_BASE', 'uploads/');

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply'])) {
    if(!$household) {
        $error = "Please complete your household data first.";
    } elseif($existing_app) {
        $error = "You already have a pending or approved application.";
    } else {
        $dependents_ages = [];
        if (isset($_POST['dependents_ages'])) {
            if (is_array($_POST['dependents_ages'])) {
                $dependents_ages = array_values(array_filter(array_map('trim', $_POST['dependents_ages'])));
            } else {
                $raw = trim($_POST['dependents_ages']);
                if ($raw !== '') {
                    $dependents_ages = array_values(array_filter(array_map('trim', explode(',', $raw))));
                }
            }
        }

        $identity_photo_path = null;
        if(isset($_FILES['identity_photo']) && $_FILES['identity_photo']['error'] == 0) {
            $upload_dir = UPLOAD_BASE . 'identity_photos/';
            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $safe_name = preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['identity_photo']['name']));
            $identity_photo_path = $upload_dir . time() . '_' . $user_id . '_' . $safe_name;
            if (!move_uploaded_file($_FILES['identity_photo']['tmp_name'], $identity_photo_path)) {
                $identity_photo_path = null;
            }
        }

        $barangay_cert_path = null;
        $birth_cert_paths = [];

        if(isset($_FILES['barangay_certification']) && $_FILES['barangay_certification']['error'] == 0) {
            $upload_dir = UPLOAD_BASE . 'solo_parent/';
            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $safe_name = preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['barangay_certification']['name']));
            $barangay_cert_path = $upload_dir . time() . '_barangay_' . $safe_name;
            if (!move_uploaded_file($_FILES['barangay_certification']['tmp_name'], $barangay_cert_path)) {
                $barangay_cert_path = null;
            }
        }

        if(isset($_FILES['birth_certificates']) && is_array($_FILES['birth_certificates']['tmp_name'])) {
            foreach($_FILES['birth_certificates']['tmp_name'] as $key => $tmp_name) {
                if($_FILES['birth_certificates']['error'][$key] == 0 && !empty($tmp_name)) {
                    $upload_dir = UPLOAD_BASE . 'solo_parent/birth_certs/';
                    if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
                    $safe_name = preg_replace('/[^A-Za-z0-9._-]/', '_', basename($_FILES['birth_certificates']['name'][$key]));
                    $birth_cert_path = $upload_dir . time() . '_' . $key . '_' . $safe_name;
                    if (move_uploaded_file($tmp_name, $birth_cert_path)) {
                        $birth_cert_paths[] = $birth_cert_path;
                    }
                }
            }
        }

        $client_signature = $_POST['client_signature'] ?? null;
        if ($client_signature && strlen($client_signature) < 100) {
            $client_signature = null;
        }

        $verification_code = bin2hex(random_bytes(16));
        $verification_url  = "https://" . ($_SERVER['HTTP_HOST'] ?? 'localhost') . "/mswdo/verify.php?code=" . $verification_code;
        $caseworker_signature = hash('sha256', $_SESSION['user_id'] . time() . uniqid());

        $application_data = [
            'case_no' => $case_no,
            'reference_code' => $ref_code,
            'submission_date' => date('Y-m-d H:i:s'),
            'verification_code' => $verification_code,
            'verification_url' => $verification_url,

            'first_name' => $_POST['first_name'] ?? '',
            'middle_name' => $_POST['middle_name'] ?? '',
            'last_name' => $_POST['last_name'] ?? '',
            'suffix' => $_POST['suffix'] ?? '',
            'birthdate' => $_POST['birthdate'] ?? '',
            'age' => $_POST['age'] ?? '',
            'birthplace' => $_POST['birthplace'] ?? '',
            'sex' => $_POST['sex'] ?? '',
            'civil_status' => $_POST['civil_status'] ?? '',
            'religion' => $_POST['religion'] ?? '',
            'street_address' => $_POST['street_address'] ?? '',
            'barangay' => $_POST['barangay'] ?? '',
            'municipality' => $_POST['municipality'] ?? '',
            'province' => $_POST['province'] ?? '',
            'contact_no' => $_POST['contact_no'] ?? '',
            'email' => $_POST['email'] ?? '',
            'educational_attainment' => $_POST['educational_attainment'] ?? '',
            'occupation' => $_POST['occupation'] ?? '',

            'housing_ownership' => $_POST['housing_ownership'] ?? '',
            'housing_materials' => $_POST['housing_materials'] ?? '',
            'water_source' => $_POST['water_source'] ?? '',
            'toilet_type' => $_POST['toilet_type'] ?? '',
            'employment_status' => $_POST['employment_status'] ?? '',
            'has_insurance' => isset($_POST['has_insurance']) ? (int)$_POST['has_insurance'] : 0,

            'solo_parent_classification' => $_POST['solo_parent_classification'] ?? '',
            'number_of_dependents' => (int)($_POST['number_of_dependents'] ?? 0),
            'dependents_ages' => $dependents_ages,
            'monthly_income' => $_POST['monthly_income'] ?? '',
            'employment_status_solo' => $_POST['employment_status_solo'] ?? '',

            'identity_photo' => $identity_photo_path,
            'client_signature' => $client_signature,
            'caseworker_signature' => $caseworker_signature,
            'caseworker_name' => $full_name,
            'caseworker_id' => $user_id,
            'client_consent' => isset($_POST['client_consent']) ? 1 : 0,
            'photo_timestamp' => date('Y-m-d H:i:s'),

            'barangay_certification' => $barangay_cert_path,
            'birth_certificates' => $birth_cert_paths,

            'submitted_at' => date('Y-m-d H:i:s')
        ];

        try {
            $stmt = $pdo->prepare("INSERT INTO welfare_applications (user_id, household_id, program_type, status, application_data, created_at) VALUES (?, ?, 'solo_parent', 'pending', ?, NOW())");
            $stmt->execute([$user_id, $household['id'], json_encode($application_data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
            $success = "Your Solo Parent application (Case No: $case_no) has been submitted successfully!";
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Solo Parent Program - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   
   <?= renderPwaMetaTags() ?>
   
   <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F; --accent: #F5B042;
            --success: #059669; --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9;
            --gray-200: #E2E8F0; --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B;
            --gray-600: #475569; --gray-700: #334155; --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --radius-sm: 0.5rem; --radius-md: 0.75rem;
            --radius-lg: 1rem; --radius-xl: 1.5rem; --radius-2xl: 2rem;
        }
        .sidebar { width: 280px; background: var(--white); border-right: 1px solid var(--gray-200); position: fixed; top: 0; left: 0; bottom: 0; overflow-y: auto; z-index: 40; }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; color: var(--gray-400); margin-bottom: 12px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; margin-bottom: 4px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; transition: all 0.2s ease; position: relative; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge { margin-left: auto; background: var(--secondary); color: white; font-size: 0.65rem; font-weight: 700; padding: 2px 8px; border-radius: 20px; line-height: 1.4; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 16px; margin-bottom: 2px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; font-size: 0.8rem; }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid var(--gray-200); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--gray-50); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }
        .form-card { background: var(--white); border-radius: var(--radius-2xl); border: 1px solid var(--gray-200); overflow: hidden; box-shadow: var(--shadow-sm); }
        .form-header { padding: 28px 32px; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); text-align: center; }
        .form-header i { font-size: 3rem; color: var(--secondary); margin-bottom: 12px; }
        .form-header h2 { font-size: 1.3rem; font-weight: 700; color: var(--primary); margin-bottom: 6px; }
        .form-header p { font-size: 0.8rem; color: var(--gray-500); }
        .form-body { padding: 32px; }
        .step-progress { display: flex; justify-content: space-between; margin-bottom: 32px; padding: 0 20px; position: relative; }
        .step-progress::before { content: ''; position: absolute; top: 20px; left: 10%; right: 10%; height: 2px; background: var(--gray-200); z-index: 1; }
        .step { text-align: center; position: relative; z-index: 2; flex: 1; }
        .step-circle { width: 40px; height: 40px; background: var(--gray-200); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 8px; font-weight: 700; color: var(--gray-600); transition: all 0.3s; }
        .step.active .step-circle { background: var(--secondary); color: white; }
        .step.completed .step-circle { background: var(--success); color: white; }
        .step-label { font-size: 0.65rem; color: var(--gray-500); }
        .step.active .step-label { color: var(--secondary); font-weight: 600; }
        .form-section { display: none; animation: fadeIn 0.3s ease; }
        .form-section.active-section { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
        .section-title { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
        .section-icon { width: 40px; height: 40px; background: var(--gray-100); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; }
        .section-icon i { font-size: 1.2rem; color: var(--secondary); }
        .section-title h3 { font-size: 1.1rem; font-weight: 600; color: var(--gray-800); }
        .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 16px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 600; color: var(--gray-600); margin-bottom: 6px; }
        .form-group label i { margin-right: 6px; color: var(--secondary); font-size: 0.7rem; }
        .required { color: var(--secondary); }
        input, select, textarea { width: 100%; padding: 12px 14px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-family: 'Inter', sans-serif; font-size: 0.85rem; transition: all 0.2s ease; background: var(--white); }
        input:focus, select:focus, textarea:focus { border-color: var(--accent); outline: none; box-shadow: 0 0 0 3px rgba(245,176,66,0.15); }
        textarea { resize: vertical; min-height: 80px; }
        .radio-group, .checkbox-group { display: flex; flex-wrap: wrap; gap: 16px; margin-top: 8px; }
        .radio-group label, .checkbox-group label { display: flex; align-items: center; gap: 6px; font-weight: normal; cursor: pointer; margin-bottom: 0; }
        .radio-group input, .checkbox-group input { width: 18px; height: 18px; }
        .camera-btn { background: var(--gray-100); border: 2px dashed var(--gray-300); padding: 16px; border-radius: var(--radius-md); text-align: center; cursor: pointer; transition: all 0.2s; touch-action: manipulation; }
        .camera-btn:hover, .camera-btn:active { border-color: var(--primary); background: var(--gray-50); transform: scale(1.02); }
        .camera-btn i { font-size: 2rem; color: var(--primary); margin-bottom: 8px; display: block; }
        .camera-btn span { font-size: 0.8rem; color: var(--gray-500); display: block; }
        .camera-btn .sub-text { font-size: 0.65rem; color: var(--gray-400); margin-top: 4px; }
        .file-name { font-size: 0.7rem; color: var(--gray-500); margin-top: 8px; text-align: center; padding: 6px; background: var(--gray-50); border-radius: var(--radius-sm); }
        .photo-preview { width: 100px; height: 100px; object-fit: cover; border-radius: var(--radius-md); margin-top: 10px; border: 2px solid var(--gray-200); }
        .photo-preview-container { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px; }
        .number-control-compact { display: flex; align-items: center; gap: 8px; max-width: 200px; }
        .number-control-compact button { width: 32px; height: 32px; border-radius: var(--radius-sm); border: 1px solid var(--gray-200); background: var(--gray-50); cursor: pointer; font-size: 1rem; font-weight: bold; transition: all 0.2s; display: flex; align-items: center; justify-content: center; }
        .number-control-compact button:hover { background: var(--gray-200); }
        .number-control-compact input { width: 60px; text-align: center; padding: 6px 8px; font-size: 0.9rem; font-weight: 600; }
        .signature-container { position: relative; border: 2px solid var(--gray-200); border-radius: var(--radius-lg); background: var(--white); touch-action: none; cursor: crosshair; overflow: hidden; }
        .signature-container canvas { width: 100%; height: 180px; display: block; touch-action: none; }
        .signature-toolbar { display: flex; align-items: center; justify-content: space-between; padding: 10px 16px; background: var(--gray-50); border-top: 1px solid var(--gray-200); flex-wrap: wrap; gap: 8px; }
        .signature-toolbar .pen-indicator { display: flex; align-items: center; gap: 8px; font-size: 0.75rem; color: var(--gray-600); }
        .signature-toolbar .pen-indicator .pen-dot { width: 12px; height: 12px; border-radius: 50%; background: #1E4A8C; display: inline-block; }
        .btn-clear, .btn-undo { background: var(--gray-200); color: var(--gray-700); border: none; padding: 6px 16px; border-radius: var(--radius-md); cursor: pointer; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s; }
        .btn-clear:hover, .btn-undo:hover { background: var(--gray-300); }
        .signature-status { font-size: 0.7rem; color: var(--gray-500); margin-top: 6px; text-align: center; }
        .signature-status.signed { color: var(--success); }
        .verification-info { background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin: 16px 0; border-left: 4px solid var(--primary); }
        .verification-info p { font-size: 0.75rem; margin: 5px 0; color: var(--gray-600); }
        .nav-buttons { display: flex; justify-content: space-between; margin-top: 32px; gap: 16px; }
        .btn-prev, .btn-next, .btn-submit { padding: 12px 24px; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: all 0.2s; border: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-prev { background: var(--gray-100); color: var(--gray-700); border: 1px solid var(--gray-200); }
        .btn-prev:hover { background: var(--gray-200); }
        .btn-next, .btn-submit { background: var(--primary); color: white; }
        .btn-next:hover, .btn-submit:hover { background: var(--primary-dark); transform: translateY(-1px); }
        .alert { padding: 16px 20px; border-radius: var(--radius-lg); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }
        .alert-info { background: #FFF9EF; border-left: 3px solid var(--accent); color: #7B5E2A; }
        .info-text { font-size: 0.7rem; color: var(--gray-500); margin-top: 4px; }
        .case-badge { background: var(--primary); color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; display: inline-block; margin-bottom: 16px; }
        hr { margin: 20px 0; border: 0; height: 1px; background: var(--gray-200); }
        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .upload-section { background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin-bottom: 16px; border: 1px solid var(--gray-200); }
        .upload-section .upload-label { font-size: 0.8rem; font-weight: 600; color: var(--gray-700); margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }

        .welcome-card {
            background: linear-gradient(135deg, #1E4A8C 0%, #0A2F6C 100%);
            border-radius: var(--radius-xl);
            padding: 32px;
            color: white;
            margin-bottom: 24px;
            text-align: center;
        }
        .welcome-card .welcome-icon {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            border: 3px solid rgba(255,255,255,0.3);
        }
        .welcome-card .welcome-icon i { font-size: 2.5rem; color: #F5B042; }
        .welcome-card h2 { font-size: 1.6rem; margin-bottom: 8px; font-weight: 700; }
        .welcome-card p { opacity: 0.9; font-size: 0.9rem; line-height: 1.6; }
        .welcome-card .case-info {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(255,255,255,0.15);
            padding: 8px 20px;
            border-radius: 40px;
            margin-top: 16px;
            font-family: monospace;
            font-size: 1rem;
            font-weight: 600;
            letter-spacing: 1px;
        }
        .welcome-card .case-info i { color: #F5B042; }

        .info-card {
            background: white;
            border-radius: var(--radius-lg);
            padding: 20px;
            margin-bottom: 16px;
            border: 1px solid var(--gray-200);
            display: flex;
            gap: 16px;
            align-items: flex-start;
        }
        .info-card .info-icon {
            width: 44px;
            height: 44px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .info-card .info-icon.blue { background: #EFF6FF; color: #1E4A8C; }
        .info-card .info-icon.green { background: #ECFDF5; color: #059669; }
        .info-card .info-icon.orange { background: #FFF7ED; color: #EA580C; }
        .info-card .info-icon.red { background: #FEF2F2; color: #D32F2F; }
        .info-card .info-icon i { font-size: 1.3rem; }
        .info-card .info-body h4 { font-size: 0.95rem; font-weight: 700; color: var(--gray-800); margin-bottom: 4px; }
        .info-card .info-body p { font-size: 0.8rem; color: var(--gray-600); line-height: 1.5; }

        .checklist { list-style: none; margin-top: 12px; }
        .checklist li {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 8px 0;
            font-size: 0.85rem;
            color: var(--gray-700);
            border-bottom: 1px solid var(--gray-100);
        }
        .checklist li:last-child { border-bottom: none; }
        .checklist li i { color: #F5B042; margin-top: 3px; flex-shrink: 0; }

        .consent-box {
            background: #F8FAFC;
            border: 2px dashed var(--gray-300);
            border-radius: var(--radius-lg);
            padding: 20px;
            margin-top: 20px;
        }
        .consent-box label {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            cursor: pointer;
            font-size: 0.85rem;
            color: var(--gray-700);
            line-height: 1.6;
        }
        .consent-box input[type="checkbox"] {
            width: 20px;
            height: 20px;
            margin-top: 2px;
            flex-shrink: 0;
        }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .form-body { padding: 20px; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .step-label { font-size: 0.5rem; }
            .step-circle { width: 30px; height: 30px; font-size: 0.8rem; }
            .number-control-compact { max-width: 100%; }
            .signature-toolbar { flex-direction: column; align-items: stretch; }
            .signature-toolbar .pen-indicator { justify-content: center; }
            .signature-toolbar .signature-actions { display: flex; justify-content: center; gap: 8px; }
        }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Municipal Social Welfare</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="dashboards/resident_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Dashboard</span></a>
                <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item"><i class="fas fa-users"></i><span>Household Profile</span></a>
                <a href="modules/my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i><span>My Applications</span></a>
                <a href="notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i><span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i><span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="soloparent.php" class="submenu-item active"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="modules/survey_form.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Community Survey</span></a>
                <a href="id_application.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Application</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile_settings.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile Settings</span></a>
                <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Solo Parent Program</h1>
                    <p>Republic Act No. 8972 - Solo Parents Welfare Act</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info"><span><?php echo htmlspecialchars($full_name); ?></span><small><?php echo ucfirst($role); ?></small></div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <i class="fas fa-female"></i>
                <h2>Solo Parent Application Form</h2>
                <p>5-Step Mobile Form Wizard | Digital Verification</p>
            </div>

            <div class="form-body">
                <?php if($success): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($existing_app && !$success): ?>
                    <div class="alert alert-info"><i class="fas fa-clock"></i> You already have a pending or approved application for this program.</div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php else: ?>
                
                <div class="step-progress">
                    <div class="step active" id="step1Indicator"><div class="step-circle">1</div><div class="step-label">Getting Started</div></div>
                    <div class="step" id="step2Indicator"><div class="step-circle">2</div><div class="step-label">Client Profile</div></div>
                    <div class="step" id="step3Indicator"><div class="step-circle">3</div><div class="step-label">Socio-Economic</div></div>
                    <div class="step" id="step4Indicator"><div class="step-circle">4</div><div class="step-label">Program Details</div></div>
                    <div class="step" id="step5Indicator"><div class="step-circle">5</div><div class="step-label">Verification</div></div>
                </div>

                <form method="POST" enctype="multipart/form-data" id="soloParentForm">
                    <input type="hidden" name="apply" value="1">
                    <input type="hidden" name="client_signature" id="client_signature" value="">

                    <!-- STEP 1 -->
                    <div class="form-section active-section" id="step1">
                        <div class="welcome-card">
                            <div class="welcome-icon">
                                <i class="fas fa-hand-holding-heart"></i>
                            </div>
                            <h2>Welcome to the Solo Parent Program</h2>
                            <p>Before you begin, please review the information below. This form takes about 5–10 minutes to complete.</p>
                            <div class="case-info">
                                <i class="fas fa-hashtag"></i> <?php echo $case_no; ?>
                            </div>
                        </div>

                        <div class="info-card">
                            <div class="info-icon blue"><i class="fas fa-info-circle"></i></div>
                            <div class="info-body">
                                <h4>About This Program</h4>
                                <p>The Solo Parent Program provides benefits and privileges to solo parents under Republic Act No. 8972, including parental leave, educational discounts, and livelihood assistance.</p>
                            </div>
                        </div>

                        <div class="info-card">
                            <div class="info-icon orange"><i class="fas fa-clipboard-list"></i></div>
                            <div class="info-body">
                                <h4>What You'll Need to Prepare</h4>
                                <ul class="checklist">
                                    <li><i class="fas fa-check-circle"></i> Barangay Solo Parent Certification</li>
                                    <li><i class="fas fa-check-circle"></i> Birth Certificate(s) of dependent(s)</li>
                                    <li><i class="fas fa-check-circle"></i> Valid ID or 1x1 photo (for identity capture)</li>
                                    <li><i class="fas fa-check-circle"></i> Your complete household information</li>
                                </ul>
                            </div>
                        </div>

                        <div class="info-card">
                            <div class="info-icon green"><i class="fas fa-check-shield"></i></div>
                            <div class="info-body">
                                <h4>Data Privacy Notice</h4>
                                <p>Your personal information will be kept confidential and used only for processing your application in compliance with the Data Privacy Act of 2012 (RA 10173).</p>
                            </div>
                        </div>

                        <div class="info-card">
                            <div class="info-icon red"><i class="fas fa-clock"></i></div>
                            <div class="info-body">
                                <h4>Processing Time</h4>
                                <p>Applications are typically reviewed within <strong>3–7 working days</strong>. You will be notified once your application has been processed.</p>
                            </div>
                        </div>

                        <div class="consent-box">
                            <label>
                                <input type="checkbox" id="step1_consent" required>
                                <span>I have read and understood the information above. I confirm that I am a resident of this municipality and I am applying for the Solo Parent Program.</span>
                            </label>
                        </div>
                    </div>

                    <!-- STEP 2 -->
                    <div class="form-section" id="step2">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-id-card"></i></div>
                            <h3>Step 2: Client Profile</h3>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="first_name" id="first_name" required></div>
                            <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name"></div>
                            <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="last_name" required></div>
                            <div class="form-group"><label>Suffix (Jr., Sr., III)</label><input type="text" name="suffix" placeholder="Optional"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthdate <span class="required">*</span></label><input type="date" name="birthdate" id="birthdate" onchange="calculateAge()" required></div>
                            <div class="form-group"><label>Age</label><input type="number" name="age" id="age" readonly></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthplace</label><input type="text" name="birthplace"></div>
                            <div class="form-group"><label>Sex</label><select name="sex"><option value="">Select</option><option>Female</option><option>Male</option></select></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Civil Status <span class="required">*</span></label>
                                <select name="civil_status" id="civil_status" required>
                                    <option value="">Select</option>
                                    <option>Single</option>
                                    <option>Married</option>
                                    <option>Widowed</option>
                                    <option>Separated</option>
                                    <option>Annulled</option>
                                </select>
                            </div>
                            <div class="form-group"><label>Religion</label><input type="text" name="religion"></div>
                        </div>
                        <div class="form-group"><label>Street Address</label><input type="text" name="street_address"></div>
                        <div class="form-row">
                            <div class="form-group"><label>Barangay</label><input type="text" name="barangay"></div>
                            <div class="form-group"><label>Municipality</label><input type="text" name="municipality"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Province</label><input type="text" name="province"></div>
                            <div class="form-group"><label>Contact Number</label><input type="text" name="contact_no"></div>
                        </div>
                        <div class="form-group"><label>Email Address</label><input type="email" name="email"></div>
                        <div class="form-row">
                            <div class="form-group"><label>Educational Attainment</label>
                                <select name="educational_attainment">
                                    <option value="">Select</option>
                                    <option>No formal education</option>
                                    <option>Elementary level</option>
                                    <option>Elementary graduate</option>
                                    <option>High school level</option>
                                    <option>High school graduate</option>
                                    <option>College level</option>
                                    <option>College graduate</option>
                                    <option>Vocational/Tech</option>
                                    <option>Post-graduate</option>
                                </select>
                            </div>
                            <div class="form-group"><label>Occupation</label><input type="text" name="occupation"></div>
                        </div>
                    </div>

                    <!-- STEP 3 -->
                    <div class="form-section" id="step3">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-chart-line"></i></div>
                            <h3>Step 3: Household & Socio-Economic Assessment</h3>
                        </div>
                        <div class="form-group">
                            <label>Housing Ownership</label>
                            <div class="radio-group">
                                <label><input type="radio" name="housing_ownership" value="Owner"> Owner</label>
                                <label><input type="radio" name="housing_ownership" value="Renter"> Renter</label>
                                <label><input type="radio" name="housing_ownership" value="Sharer"> Sharer</label>
                                <label><input type="radio" name="housing_ownership" value="Informal Settler"> Informal Settler</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Housing Materials</label>
                            <select name="housing_materials">
                                <option value="">Select</option>
                                <option>Light Materials (Nipa/Bamboo)</option>
                                <option>Concrete/Wood</option>
                                <option>Mixed Materials</option>
                            </select>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Water Source</label>
                                <select name="water_source">
                                    <option value="">Select</option>
                                    <option>Level 1 (Faucets/Spring)</option>
                                    <option>Level 2 (Communal)</option>
                                    <option>Level 3 (Private Pipe)</option>
                                    <option>Deep Well</option>
                                    <option>Rain/Open Source</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Toilet Type</label>
                                <select name="toilet_type">
                                    <option value="">Select</option>
                                    <option>Flush</option>
                                    <option>Antipolo/Pit</option>
                                    <option>None</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Employment Status</label>
                            <select name="employment_status">
                                <option value="">Select</option>
                                <option>Permanent</option>
                                <option>Temporary</option>
                                <option>Casual</option>
                                <option>Unemployed</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-shield-alt"></i> Have Insurance?</label>
                            <div class="radio-group">
                                <label><input type="radio" name="has_insurance" value="1"> Yes</label>
                                <label><input type="radio" name="has_insurance" value="0"> No</label>
                            </div>
                        </div>
                    </div>

                    <!-- STEP 4 -->
                    <div class="form-section" id="step4">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-hand-holding-heart"></i></div>
                            <h3>Step 4: Solo Parent Program Details</h3>
                        </div>
                        <div class="form-group">
                            <label>Solo Parent Classification <span class="required">*</span></label>
                            <select name="solo_parent_classification" required>
                                <option value="">Select Classification</option>
                                <option>Death of Spouse</option>
                                <option>Abandonment by Spouse</option>
                                <option>Legal Separation</option>
                                <option>Imprisonment of Spouse</option>
                                <option>Unwed Parent</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Total Number of Dependents <span class="required">*</span></label>
                            <div class="number-control-compact">
                                <button type="button" onclick="decrementDependents()">−</button>
                                <input type="number" name="number_of_dependents" id="numDependents" min="0" value="0" readonly>
                                <button type="button" onclick="incrementDependents()">+</button>
                            </div>
                        </div>
                        <div id="dependentsAgesContainer"></div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Monthly Personal Income <span class="required">*</span></label>
                                <input type="number" name="monthly_income" step="500" placeholder="₱" required>
                            </div>
                            <div class="form-group">
                                <label>Employment Status</label>
                                <select name="employment_status_solo">
                                    <option value="">Select</option>
                                    <option>Permanent</option>
                                    <option>Temporary</option>
                                    <option>Casual</option>
                                    <option>Unemployed</option>
                                </select>
                            </div>
                        </div>
                        <hr>
                        <div class="upload-section">
                            <div class="upload-label">
                                <i class="fas fa-file-certificate" style="color: var(--secondary);"></i>
                                Barangay Solo Parent Certification <span class="required">*</span>
                            </div>
                            <div class="camera-btn" onclick="document.getElementById('barangay_cert').click()">
                                <i class="fas fa-camera"></i>
                                <span>📸 Capture or Upload Document</span>
                                <span class="sub-text">Tap to open camera or select from gallery</span>
                            </div>
                            <input type="file" id="barangay_cert" name="barangay_certification" accept="image/*,application/pdf" style="display:none" onchange="updateFileName(this, 'barangayFileName')" capture="environment">
                            <div id="barangayFileName" class="file-name">No file chosen</div>
                            <div id="barangayPreview" class="photo-preview-container"></div>
                        </div>
                        <div class="upload-section">
                            <div class="upload-label">
                                <i class="fas fa-baby-carriage" style="color: var(--secondary);"></i>
                                Birth Certificates of Dependents <span class="required">*</span>
                            </div>
                            <div class="camera-btn" onclick="document.getElementById('birth_certs').click()">
                                <i class="fas fa-camera"></i>
                                <span>📸 Capture or Upload (Multiple allowed)</span>
                                <span class="sub-text">Tap to open camera or select from gallery</span>
                            </div>
                            <input type="file" id="birth_certs" name="birth_certificates[]" accept="image/*,application/pdf" style="display:none" multiple onchange="updateMultipleFileNames(this, 'birthCertsFileName')" capture="environment">
                            <div id="birthCertsFileName" class="file-name">No files chosen</div>
                            <div id="birthCertsPreview" class="photo-preview-container"></div>
                        </div>
                    </div>

                    <!-- STEP 5 -->
                    <div class="form-section" id="step5">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-shield-alt"></i></div>
                            <h3>Step 5: Digital Verification</h3>
                        </div>
                        <div class="form-group">
                            <label><input type="checkbox" name="client_consent" value="1" required> Client consents to household profiling & data analytics.</label>
                        </div>
                        <div class="upload-section">
                            <div class="upload-label">
                                <i class="fas fa-camera-retro" style="color: var(--secondary);"></i>
                                1. IDENTITY CAPTURE <span class="required">*</span>
                            </div>
                            <div class="camera-btn" onclick="document.getElementById('identity_photo').click()">
                                <i class="fas fa-camera"></i>
                                <span>📸 SNAP PHOTO OF CLIENT HOLDING CONSENT/ID</span>
                                <span class="sub-text">Tap to open camera</span>
                            </div>
                            <input type="file" id="identity_photo" name="identity_photo" accept="image/*" style="display:none" onchange="previewIdentityPhoto(this)" capture="environment">
                            <div id="identityPhotoPreview" class="photo-preview-container"></div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-signature"></i> 2. DIGITAL TOUCH SIGNATURE <span class="required">*</span></label>
                            <div class="signature-container">
                                <canvas id="signatureCanvas" width="600" height="180"></canvas>
                                <div class="signature-toolbar">
                                    <div class="pen-indicator">
                                        <span class="pen-dot"></span>
                                        <span>Pen: <strong>Digital Signature</strong></span>
                                        <span style="color: var(--gray-400);">|</span>
                                        <span id="signatureStatus" style="font-size: 0.65rem;">Not signed yet</span>
                                    </div>
                                    <div class="signature-actions">
                                        <button type="button" class="btn-undo" onclick="undoSignature()"><i class="fas fa-undo"></i> Undo</button>
                                        <button type="button" class="btn-clear" onclick="clearSignature()"><i class="fas fa-eraser"></i> Clear</button>
                                    </div>
                                </div>
                            </div>
                            <div class="signature-status" id="signatureStatusMessage">
                                <i class="fas fa-pen"></i> Draw your signature using your finger or stylus
                            </div>
                        </div>
                        <div class="verification-info">
                            <p><i class="fas fa-lock"></i> Case No: <strong><?php echo $case_no; ?></strong></p>
                            <p><i class="fas fa-check-circle"></i> Upon approval, a Digital Certificate with QR Code will be issued.</p>
                        </div>
                    </div>

                    <div class="nav-buttons">
                        <button type="button" class="btn-prev" id="prevBtn" onclick="changeStep(-1)" style="display:none;"><i class="fas fa-chevron-left"></i> Previous</button>
                        <button type="button" class="btn-next" id="nextBtn" onclick="changeStep(1)">Next <i class="fas fa-chevron-right"></i></button>
                        <button type="submit" class="btn-submit" id="submitBtn" style="display:none;"><i class="fas fa-paper-plane"></i> SUBMIT APPLICATION</button>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
    let currentStep = 1;
    const totalSteps = 5;
    let dependentsCount = 0;

    function calculateAge() {
        const birthdate = document.getElementById('birthdate').value;
        if(birthdate) {
            const today = new Date();
            const birth = new Date(birthdate);
            let age = today.getFullYear() - birth.getFullYear();
            const m = today.getMonth() - birth.getMonth();
            if(m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
            document.getElementById('age').value = age;
        }
    }

    function incrementDependents() {
        dependentsCount++;
        document.getElementById('numDependents').value = dependentsCount;
        updateDependentsAges();
    }
    function decrementDependents() {
        if(dependentsCount > 0) {
            dependentsCount--;
            document.getElementById('numDependents').value = dependentsCount;
            updateDependentsAges();
        }
    }
    function updateDependentsAges() {
        let num = dependentsCount;
        let container = document.getElementById('dependentsAgesContainer');
        container.innerHTML = '';
        if(num > 0) {
            let html = '<div style="margin: 8px 0;"><strong style="font-size: 0.8rem;"><i class="fas fa-child"></i> Ages of Dependents (below 18 years old)</strong></div>';
            html += '<div class="form-group" style="margin-bottom: 8px;">';
            html += '<input type="text" name="dependents_ages" id="dependents_ages" placeholder="e.g., 5, 8, 12" style="padding: 8px 12px; font-size: 0.8rem;">';
            html += '<div class="info-text">Enter ages separated by commas</div></div>';
            container.innerHTML = html;
        }
    }

    function updateFileName(input, labelId) {
        const label = document.getElementById(labelId);
        if(input.files && input.files[0]) {
            label.textContent = '📎 ' + input.files[0].name;
            const previewContainer = document.getElementById(labelId.replace('FileName', 'Preview'));
            if(previewContainer && input.files[0].type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewContainer.innerHTML = '<img src="' + e.target.result + '" class="photo-preview" alt="Uploaded document">';
                };
                reader.readAsDataURL(input.files[0]);
            }
        } else {
            label.textContent = 'No file chosen';
        }
    }

    function updateMultipleFileNames(input, labelId) {
        const label = document.getElementById(labelId);
        const previewContainer = document.getElementById(labelId.replace('FileName', 'Preview'));
        if(input.files && input.files.length > 0) {
            label.textContent = '📎 ' + input.files.length + ' file(s) selected';
            if(previewContainer) {
                previewContainer.innerHTML = '';
                for(let i = 0; i < input.files.length; i++) {
                    if(input.files[i].type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            const img = document.createElement('img');
                            img.src = e.target.result;
                            img.className = 'photo-preview';
                            previewContainer.appendChild(img);
                        };
                        reader.readAsDataURL(input.files[i]);
                    }
                }
            }
        } else {
            label.textContent = 'No files chosen';
            if(previewContainer) previewContainer.innerHTML = '';
        }
    }

    function previewIdentityPhoto(input) {
        const previewContainer = document.getElementById('identityPhotoPreview');
        if(input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewContainer.innerHTML = '<img src="' + e.target.result + '" class="photo-preview" alt="Identity Photo">';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    let canvas = document.getElementById('signatureCanvas');
    let ctx = canvas.getContext('2d');
    let drawing = false;
    let signatureHistory = [];
    let currentPath = [];

    function resizeCanvas() {
        const container = canvas.parentElement;
        const rect = container.getBoundingClientRect();
        canvas.width = rect.width || 600;
        canvas.height = 180;
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#1E4A8C';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        if (signatureHistory.length > 0) redrawSignature();
    }

    function redrawSignature() {
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#1E4A8C';
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        for (let path of signatureHistory) {
            if (path.length > 1) {
                ctx.beginPath();
                ctx.moveTo(path[0].x, path[0].y);
                for (let i = 1; i < path.length; i++) ctx.lineTo(path[i].x, path[i].y);
                ctx.stroke();
            }
        }
    }

    window.addEventListener('resize', resizeCanvas);
    setTimeout(resizeCanvas, 100);

    function startDrawing(e) {
        e.preventDefault();
        drawing = true;
        currentPath = [];
        const pos = getCanvasCoordinates(e);
        currentPath.push(pos);
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
        updateSignatureStatus(true);
    }
    function draw(e) {
        e.preventDefault();
        if(!drawing) return;
        const pos = getCanvasCoordinates(e);
        currentPath.push(pos);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
    }
    function stopDrawing(e) {
        e.preventDefault();
        if(drawing && currentPath.length > 1) {
            signatureHistory.push([...currentPath]);
            document.getElementById('client_signature').value = canvas.toDataURL();
        }
        drawing = false;
        ctx.beginPath();
        updateSignatureStatus(signatureHistory.length > 0);
    }
    function getCanvasCoordinates(e) {
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        let clientX, clientY;
        if(e.touches) { clientX = e.touches[0].clientX; clientY = e.touches[0].clientY; }
        else { clientX = e.clientX; clientY = e.clientY; }
        let x = (clientX - rect.left) * scaleX;
        let y = (clientY - rect.top) * scaleY;
        x = Math.min(Math.max(0, x), canvas.width);
        y = Math.min(Math.max(0, y), canvas.height);
        return { x, y };
    }
    function undoSignature() {
        if (signatureHistory.length > 0) {
            signatureHistory.pop();
            redrawSignature();
            document.getElementById('client_signature').value = signatureHistory.length > 0 ? canvas.toDataURL() : '';
            updateSignatureStatus(signatureHistory.length > 0);
        }
    }
    function clearSignature() {
        signatureHistory = [];
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        document.getElementById('client_signature').value = '';
        updateSignatureStatus(false);
    }
    function updateSignatureStatus(signed) {
        const status = document.getElementById('signatureStatus');
        const message = document.getElementById('signatureStatusMessage');
        if (signed) {
            status.textContent = '✅ Signed';
            status.style.color = '#059669';
            message.innerHTML = '<i class="fas fa-check-circle" style="color: #059669;"></i> Signature captured successfully!';
            message.className = 'signature-status signed';
        } else {
            status.textContent = 'Not signed yet';
            status.style.color = '#64748B';
            message.innerHTML = '<i class="fas fa-pen"></i> Draw your signature using your finger or stylus';
            message.className = 'signature-status';
        }
    }
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);
    canvas.addEventListener('touchstart', startDrawing, { passive: false });
    canvas.addEventListener('touchmove', draw, { passive: false });
    canvas.addEventListener('touchend', stopDrawing, { passive: false });

    function changeStep(direction) {
        if (direction > 0) {
            if (currentStep === 1) {
                const consent = document.getElementById('step1_consent');
                if (consent && !consent.checked) {
                    alert('Please confirm that you have read and understood the information above.');
                    return;
                }
            }
        }

        const sections = document.querySelectorAll('.form-section');
        const steps = document.querySelectorAll('.step');
        sections[currentStep - 1].classList.remove('active-section');
        steps[currentStep - 1].classList.remove('active');
        steps[currentStep - 1].classList.add('completed');
        currentStep += direction;
        sections[currentStep - 1].classList.add('active-section');
        steps[currentStep - 1].classList.add('active');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');
        if(currentStep === 1) prevBtn.style.display = 'none';
        else prevBtn.style.display = 'inline-flex';
        if(currentStep === totalSteps) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-flex';
        } else {
            nextBtn.style.display = 'inline-flex';
            submitBtn.style.display = 'none';
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if(menuToggle) menuToggle.addEventListener('click', function() { sidebar.classList.toggle('open'); });
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) sidebar.classList.remove('open');
        }
    });

    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    if(programToggle) {
        programSubmenu.classList.add('show');
        programIcon.classList.add('rotated');
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }

    updateDependentsAges();
    document.addEventListener('DOMContentLoaded', function() { setTimeout(resizeCanvas, 200); });
</script>

   <?= renderPwaServiceWorker() ?>
</body>
</html>