<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];
$error = '';
$success = '';

// Get sidebar household ID
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get unread notification count
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

$stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
$stmt->execute([$user_id]);
$household = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'aics' AND status IN ('pending', 'approved')");
$stmt->execute([$user_id]);
$existing_app = $stmt->fetch();

$case_no = 'AICS-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
$ref_code = strtoupper(substr(md5(uniqid($user_id, true)), 0, 8));

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply'])) {
    if(!$household) {
        $error = "Please complete your household data first.";
    } elseif($existing_app) {
        $error = "You already have a pending or approved application.";
    } else {
        $identity_photo_path = null;
        if(isset($_FILES['identity_photo']) && $_FILES['identity_photo']['error'] == 0) {
            $upload_dir = 'uploads/identity_photos/';
            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $identity_photo_path = $upload_dir . time() . '_' . $user_id . '_' . basename($_FILES['identity_photo']['name']);
            move_uploaded_file($_FILES['identity_photo']['tmp_name'], $identity_photo_path);
        }
        
        $barangay_cert_path = null;
        if(isset($_FILES['barangay_certificate']) && $_FILES['barangay_certificate']['error'] == 0) {
            $upload_dir = 'uploads/aics/';
            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $barangay_cert_path = $upload_dir . time() . '_barangay_' . basename($_FILES['barangay_certificate']['name']);
            move_uploaded_file($_FILES['barangay_certificate']['tmp_name'], $barangay_cert_path);
        }
        
        $dynamic_doc_path = null;
        $dynamic_doc_type = $_POST['emergency_type'] ?? '';
        if(isset($_FILES['dynamic_document']) && $_FILES['dynamic_document']['error'] == 0) {
            $upload_dir = 'uploads/aics/documents/';
            if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $dynamic_doc_path = $upload_dir . time() . '_' . $dynamic_doc_type . '_' . basename($_FILES['dynamic_document']['name']);
            move_uploaded_file($_FILES['dynamic_document']['tmp_name'], $dynamic_doc_path);
        }

        $client_signature = $_POST['client_signature'] ?? null;
        $verification_code = bin2hex(random_bytes(16));
        $verification_url = "https://" . $_SERVER['HTTP_HOST'] . "/mswdo/verify.php?code=" . $verification_code;
        $caseworker_signature = hash('sha256', $_SESSION['user_id'] . time() . uniqid());
        
        $application_data = [
            'case_no' => $case_no, 'reference_code' => $ref_code,
            'submission_date' => date('Y-m-d H:i:s'),
            'verification_code' => $verification_code, 'verification_url' => $verification_url,
            'first_name' => $_POST['first_name'] ?? '', 'middle_name' => $_POST['middle_name'] ?? '',
            'last_name' => $_POST['last_name'] ?? '', 'suffix' => $_POST['suffix'] ?? '',
            'birthdate' => $_POST['birthdate'] ?? '', 'age' => $_POST['age'] ?? '',
            'birthplace' => $_POST['birthplace'] ?? '', 'sex' => $_POST['sex'] ?? '',
            'civil_status' => $_POST['civil_status'] ?? '', 'religion' => $_POST['religion'] ?? '',
            'street_address' => $_POST['street_address'] ?? '', 'barangay' => $_POST['barangay'] ?? '',
            'municipality' => $_POST['municipality'] ?? '', 'province' => $_POST['province'] ?? '',
            'contact_no' => $_POST['contact_no'] ?? '', 'email' => $_POST['email'] ?? '',
            'educational_attainment' => $_POST['educational_attainment'] ?? '', 'occupation' => $_POST['occupation'] ?? '',
            'housing_ownership' => $_POST['housing_ownership'] ?? '', 'housing_materials' => $_POST['housing_materials'] ?? '',
            'water_source' => $_POST['water_source'] ?? '', 'toilet_type' => $_POST['toilet_type'] ?? '',
            'employment_status' => $_POST['employment_status'] ?? '', 'has_insurance' => isset($_POST['has_insurance']) ? 1 : 0,
            'emergency_type' => $_POST['emergency_type'] ?? '', 
            'emergency_type_others' => $_POST['emergency_type_others'] ?? '',
            'relationship_to_beneficiary' => $_POST['relationship_to_beneficiary'] ?? '',
            'amount_requested' => $_POST['amount_requested'] ?? '', 'cause_of_crisis' => $_POST['cause_of_crisis'] ?? '',
            'household_disposable_cash' => $_POST['household_disposable_cash'] ?? '',
            'crisis_description' => $_POST['crisis_description'] ?? '', 'incident_date' => $_POST['incident_date'] ?? '',
            'incident_location' => $_POST['incident_location'] ?? '',
            'beneficiary_name' => $_POST['beneficiary_name'] ?? '', 'beneficiary_age' => $_POST['beneficiary_age'] ?? '',
            'medical_diagnosis' => $_POST['medical_diagnosis'] ?? '', 'hospital_name' => $_POST['hospital_name'] ?? '',
            'medical_bill_amount' => $_POST['medical_bill_amount'] ?? '',
            'food_details' => $_POST['food_details'] ?? '', 'food_persons_count' => $_POST['food_persons_count'] ?? '',
            'medicine_details' => $_POST['medicine_details'] ?? '', 'medicine_prescription' => $_POST['medicine_prescription'] ?? '',
            'housing_details' => $_POST['housing_details'] ?? '', 'housing_damage_type' => $_POST['housing_damage_type'] ?? '',
            'housing_repair_amount' => $_POST['housing_repair_amount'] ?? '',
            'others_details' => $_POST['others_details'] ?? '',
            'deceased_name' => $_POST['deceased_name'] ?? '', 'cause_of_death' => $_POST['cause_of_death'] ?? '',
            'funeral_home' => $_POST['funeral_home'] ?? '',
            'transportation_details' => $_POST['transportation_details'] ?? '', 
            'transportation_destination' => $_POST['transportation_destination'] ?? '',
            'school_name' => $_POST['school_name'] ?? '', 'school_level' => $_POST['school_level'] ?? '',
            'school_bill_amount' => $_POST['school_bill_amount'] ?? '',
            'problem_presented' => $_POST['problem_presented'] ?? '',
            'rehabilitation_goals' => isset($_POST['rehabilitation_goals']) ? $_POST['rehabilitation_goals'] : [],
            'identity_photo' => $identity_photo_path, 'client_signature' => $client_signature,
            'caseworker_signature' => $caseworker_signature, 'caseworker_name' => $full_name,
            'caseworker_id' => $user_id, 'client_consent' => isset($_POST['client_consent']) ? 1 : 0,
            'photo_timestamp' => date('Y-m-d H:i:s'),
            'barangay_certificate' => $barangay_cert_path, 'dynamic_document' => $dynamic_doc_path,
            'dynamic_document_type' => $dynamic_doc_type,
            'submitted_at' => date('Y-m-d H:i:s')
        ];
        
        try {
            $stmt = $pdo->prepare("INSERT INTO welfare_applications (user_id, household_id, program_type, status, application_data, created_at) VALUES (?, ?, 'aics', 'pending', ?, NOW())");
            $stmt->execute([$user_id, $household['id'], json_encode($application_data)]);
            $success = "Your AICS application (Case No: $case_no) has been submitted successfully! A social worker will evaluate your application.";
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>AICS Program - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <?= renderPwaMetaTags() ?>
  
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F; --accent: #F5B042;
            --success: #059669; --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9;
            --gray-200: #E2E8F0; --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B;
            --gray-600: #475569; --gray-700: #334155; --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem; --radius-md: 0.75rem; --radius-lg: 1rem; --radius-xl: 1.5rem; --radius-2xl: 2rem;
        }
        .sidebar { width: 280px; background: var(--white); border-right: 1px solid var(--gray-200); position: fixed; top: 0; left: 0; bottom: 0; overflow-y: auto; z-index: 40; }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label { font-size: 0.7rem; font-weight: 600; text-transform: uppercase; color: var(--gray-400); margin-bottom: 12px; padding-left: 12px; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 16px; margin-bottom: 4px; border-radius: var(--radius-md); color: var(--gray-600); text-decoration: none; transition: all 0.2s ease; position: relative; }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge { margin-left: auto; background: var(--secondary); color: white; font-size: 0.65rem; font-weight: 700; padding: 2px 8px; border-radius: 20px; line-height: 1.4; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item { display: flex; align-items: center; gap: 12px; padding: 8px 16px; margin-bottom: 2px; border-radius: var(--radius-md); color: var(--gray-500); text-decoration: none; font-size: 0.8rem; }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid var(--gray-200); }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu { display: flex; align-items: center; gap: 16px; background: var(--gray-50); padding: 8px 16px 8px 20px; border-radius: 40px; border: 1px solid var(--gray-200); }
        .user-avatar { width: 36px; height: 36px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }
        .form-card { background: var(--white); border-radius: var(--radius-2xl); border: 1px solid var(--gray-200); overflow: hidden; box-shadow: var(--shadow-sm); }
        .form-header { padding: 28px 32px; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); text-align: center; }
        .form-header i { font-size: 3rem; color: var(--accent); margin-bottom: 12px; }
        .form-header h2 { font-size: 1.3rem; font-weight: 700; color: var(--primary); margin-bottom: 6px; }
        .form-header p { font-size: 0.8rem; color: var(--gray-500); }
        .form-body { padding: 32px; }
        .step-progress { display: flex; justify-content: space-between; margin-bottom: 32px; padding: 0 20px; position: relative; }
        .step-progress::before { content: ''; position: absolute; top: 20px; left: 10%; right: 10%; height: 2px; background: var(--gray-200); z-index: 1; }
        .step { text-align: center; position: relative; z-index: 2; flex: 1; }
        .step-circle { width: 40px; height: 40px; background: var(--gray-200); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 8px; font-weight: 700; color: var(--gray-600); transition: all 0.3s; }
        .step.active .step-circle { background: var(--secondary); color: white; }
        .step.completed .step-circle { background: var(--success); color: white; }
        .step-label { font-size: 0.65rem; color: var(--gray-500); }
        .step.active .step-label { color: var(--secondary); font-weight: 600; }
        .form-section { display: none; }
        .form-section.active-section { display: block; }
        .section-title { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
        .section-icon { width: 40px; height: 40px; background: var(--gray-100); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; }
        .section-icon i { font-size: 1.2rem; color: var(--accent); }
        .section-title h3 { font-size: 1.1rem; font-weight: 600; color: var(--gray-800); }
        .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 16px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.75rem; font-weight: 600; color: var(--gray-600); margin-bottom: 6px; }
        .form-group label i { margin-right: 6px; color: var(--accent); font-size: 0.7rem; }
        .required { color: var(--secondary); }
        input, select, textarea { width: 100%; padding: 12px 14px; border: 1.5px solid var(--gray-200); border-radius: var(--radius-md); font-family: 'Inter', sans-serif; font-size: 0.85rem; transition: all 0.2s ease; background: var(--white); }
        input:focus, select:focus, textarea:focus { border-color: var(--accent); outline: none; box-shadow: 0 0 0 3px rgba(245,176,66,0.15); }
        textarea { resize: vertical; min-height: 80px; }
        .radio-group, .checkbox-group { display: flex; flex-wrap: wrap; gap: 16px; margin-top: 8px; }
        .radio-group label, .checkbox-group label { display: flex; align-items: center; gap: 6px; font-weight: normal; cursor: pointer; margin-bottom: 0; }
        .radio-group input, .checkbox-group input { width: 18px; height: 18px; }
        .dynamic-section { background: #FFF9EF; border-radius: var(--radius-lg); padding: 16px; margin-top: 16px; border-left: 4px solid var(--accent); display: none; }
        .dynamic-section h4 { margin-bottom: 12px; color: var(--primary); font-size: 0.9rem; }
        .camera-btn { background: var(--gray-100); border: 2px dashed var(--gray-300); padding: 16px; border-radius: var(--radius-md); text-align: center; cursor: pointer; transition: all 0.2s; touch-action: manipulation; }
        .camera-btn:hover, .camera-btn:active { border-color: var(--primary); background: var(--gray-50); transform: scale(1.02); }
        .camera-btn i { font-size: 2rem; color: var(--primary); margin-bottom: 8px; display: block; }
        .camera-btn span { font-size: 0.8rem; color: var(--gray-500); display: block; }
        .camera-btn .sub-text { font-size: 0.65rem; color: var(--gray-400); margin-top: 4px; }
        .file-name { font-size: 0.7rem; color: var(--gray-500); margin-top: 8px; text-align: center; padding: 6px; background: var(--gray-50); border-radius: var(--radius-sm); }
        .photo-preview { width: 100px; height: 100px; object-fit: cover; border-radius: var(--radius-md); margin-top: 10px; border: 2px solid var(--gray-200); }
        .photo-preview-container { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px; }
        .signature-container { position: relative; border: 2px solid var(--gray-200); border-radius: var(--radius-lg); background: var(--white); touch-action: none; cursor: crosshair; overflow: hidden; }
        .signature-container canvas { width: 100%; height: 180px; display: block; touch-action: none; }
        .signature-toolbar { display: flex; align-items: center; justify-content: space-between; padding: 10px 16px; background: var(--gray-50); border-top: 1px solid var(--gray-200); flex-wrap: wrap; gap: 8px; }
        .signature-toolbar .pen-indicator { display: flex; align-items: center; gap: 8px; font-size: 0.75rem; color: var(--gray-600); }
        .signature-toolbar .pen-indicator .pen-dot { width: 12px; height: 12px; border-radius: 50%; background: #1E4A8C; display: inline-block; }
        .btn-clear, .btn-undo { background: var(--gray-200); color: var(--gray-700); border: none; padding: 6px 16px; border-radius: var(--radius-md); cursor: pointer; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s; }
        .btn-clear:hover, .btn-undo:hover { background: var(--gray-300); }
        .signature-status { font-size: 0.7rem; color: var(--gray-500); margin-top: 6px; text-align: center; }
        .signature-status.signed { color: var(--success); }
        .verification-info { background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin: 16px 0; border-left: 4px solid var(--accent); }
        .verification-info p { font-size: 0.75rem; margin: 5px 0; color: var(--gray-600); }
        .qr-preview { text-align: center; padding: 20px; background: var(--gray-50); border-radius: var(--radius-lg); margin-top: 15px; }
        .qr-preview i { font-size: 4rem; color: var(--accent); margin-bottom: 10px; }
        .nav-buttons { display: flex; justify-content: space-between; margin-top: 32px; gap: 16px; }
        .btn-prev, .btn-next, .btn-submit { padding: 12px 24px; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; transition: all 0.2s; border: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-prev { background: var(--gray-100); color: var(--gray-700); border: 1px solid var(--gray-200); }
        .btn-prev:hover { background: var(--gray-200); }
        .btn-next, .btn-submit { background: var(--primary); color: white; }
        .btn-next:hover, .btn-submit:hover { background: var(--primary-dark); transform: translateY(-1px); }
        .alert { padding: 16px 20px; border-radius: var(--radius-lg); margin-bottom: 24px; display: flex; align-items: center; gap: 12px; }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }
        .alert-info { background: #FFF9EF; border-left: 3px solid var(--accent); color: #7B5E2A; }
        .info-text { font-size: 0.7rem; color: var(--gray-500); margin-top: 4px; }
        .case-badge { background: var(--accent); color: var(--gray-800); padding: 4px 12px; border-radius: 20px; font-size: 0.7rem; display: inline-block; margin-bottom: 16px; }
        hr { margin: 20px 0; border: 0; height: 1px; background: var(--gray-200); }
        .menu-toggle { display: none; background: none; border: none; font-size: 1.3rem; color: var(--gray-700); cursor: pointer; padding: 8px; border-radius: var(--radius-md); }
        .upload-section { background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin-bottom: 16px; border: 1px solid var(--gray-200); }
        .upload-section .upload-label { font-size: 0.8rem; font-weight: 600; color: var(--gray-700); margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .welcome-card { background: linear-gradient(135deg, #D97706 0%, #92400E 100%); border-radius: var(--radius-xl); padding: 32px; color: white; margin-bottom: 24px; text-align: center; }
        .welcome-card .welcome-icon { width: 80px; height: 80px; background: rgba(255,255,255,0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; border: 3px solid rgba(255,255,255,0.3); }
        .welcome-card .welcome-icon i { font-size: 2.5rem; color: #FEF3C7; }
        .welcome-card h2 { font-size: 1.6rem; margin-bottom: 8px; font-weight: 700; }
        .welcome-card p { opacity: 0.9; font-size: 0.9rem; line-height: 1.6; }
        .welcome-card .case-info { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.15); padding: 8px 20px; border-radius: 40px; margin-top: 16px; font-family: monospace; font-size: 1rem; font-weight: 600; letter-spacing: 1px; }
        .welcome-card .case-info i { color: #FEF3C7; }
        .info-card { background: white; border-radius: var(--radius-lg); padding: 20px; margin-bottom: 16px; border: 1px solid var(--gray-200); display: flex; gap: 16px; align-items: flex-start; }
        .info-card .info-icon { width: 44px; height: 44px; border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .info-card .info-icon.blue { background: #EFF6FF; color: #1E4A8C; }
        .info-card .info-icon.green { background: #ECFDF5; color: #059669; }
        .info-card .info-icon.orange { background: #FFF7ED; color: #EA580C; }
        .info-card .info-icon.red { background: #FEF2F2; color: #D32F2F; }
        .info-card .info-icon i { font-size: 1.3rem; }
        .info-card .info-body h4 { font-size: 0.95rem; font-weight: 700; color: var(--gray-800); margin-bottom: 4px; }
        .info-card .info-body p { font-size: 0.8rem; color: var(--gray-600); line-height: 1.5; }
        .checklist { list-style: none; margin-top: 12px; }
        .checklist li { display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; font-size: 0.85rem; color: var(--gray-700); border-bottom: 1px solid var(--gray-100); }
        .checklist li:last-child { border-bottom: none; }
        .checklist li i { color: #EA580C; margin-top: 3px; flex-shrink: 0; }
        .consent-box { background: #F8FAFC; border: 2px dashed var(--gray-300); border-radius: var(--radius-lg); padding: 20px; margin-top: 20px; }
        .consent-box label { display: flex; align-items: flex-start; gap: 12px; cursor: pointer; font-size: 0.85rem; color: var(--gray-700); line-height: 1.6; }
        .consent-box input[type="checkbox"] { width: 20px; height: 20px; margin-top: 2px; flex-shrink: 0; }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .form-body { padding: 20px; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .step-label { font-size: 0.5rem; }
            .step-circle { width: 30px; height: 30px; font-size: 0.8rem; }
        }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Municipal Social Welfare</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="dashboards/resident_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Dashboard</span></a>
                <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item"><i class="fas fa-users"></i><span>Household Profile</span></a>
                <a href="modules/my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i><span>My Applications</span></a>
                <a href="notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i><span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i><span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="aics.php" class="submenu-item active"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="modules/survey_form.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Community Survey</span></a>
                <a href="id_application.php" class="nav-item"><i class="fas fa-id-card"></i><span>ID Application</span></a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile_settings.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile Settings</span></a>
                <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Assistance to Individuals in Crisis Situation (AICS)</h1>
                    <p>Emergency financial and material assistance for individuals and families in crisis</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info"><span><?php echo htmlspecialchars($full_name); ?></span><small><?php echo ucfirst($role); ?></small></div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <i class="fas fa-coins"></i>
                <h2>AICS Application Form</h2>
                <p>5-Step Mobile Form Wizard | Digital Verification with QR Code</p>
            </div>

            <div class="form-body">
                <?php if($success): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($existing_app && !$success): ?>
                    <div class="alert alert-info"><i class="fas fa-clock"></i> You already have a pending or approved application for this program.</div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back" style="display:block; text-align:center; padding:10px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php else: ?>
                
                <div class="step-progress">
                    <div class="step active" id="step1Indicator"><div class="step-circle">1</div><div class="step-label">Getting Started</div></div>
                    <div class="step" id="step2Indicator"><div class="step-circle">2</div><div class="step-label">Client Profile</div></div>
                    <div class="step" id="step3Indicator"><div class="step-circle">3</div><div class="step-label">Socio-Economic</div></div>
                    <div class="step" id="step4Indicator"><div class="step-circle">4</div><div class="step-label">AICS Details</div></div>
                    <div class="step" id="step5Indicator"><div class="step-circle">5</div><div class="step-label">Verification</div></div>
                </div>

                <form method="POST" enctype="multipart/form-data" id="aicsForm">
                    <input type="hidden" name="apply" value="1">
                    <input type="hidden" name="client_signature" id="client_signature" value="">

                    <div class="form-section active-section" id="step1">
                        <div class="welcome-card">
                            <div class="welcome-icon"><i class="fas fa-coins"></i></div>
                            <h2>Welcome to the AICS Program</h2>
                            <p>Before you begin, please review the information below. This form takes about 5–10 minutes to complete.</p>
                            <div class="case-info"><i class="fas fa-hashtag"></i> <?php echo $case_no; ?></div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon blue"><i class="fas fa-info-circle"></i></div>
                            <div class="info-body">
                                <h4>About This Program</h4>
                                <p>AICS (Assistance to Individuals in Crisis Situation) provides emergency financial and material assistance to individuals and families facing unforeseen crises.</p>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon orange"><i class="fas fa-clipboard-list"></i></div>
                            <div class="info-body">
                                <h4>What You'll Need to Prepare</h4>
                                <ul class="checklist">
                                    <li><i class="fas fa-check-circle"></i> Barangay Certificate of Indigency</li>
                                    <li><i class="fas fa-check-circle"></i> Supporting document (Medical Abstract, Death Certificate, or School Billing)</li>
                                    <li><i class="fas fa-check-circle"></i> Valid ID or 1x1 photo (for identity capture)</li>
                                    <li><i class="fas fa-check-circle"></i> Details of the crisis situation</li>
                                </ul>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon green"><i class="fas fa-check-shield"></i></div>
                            <div class="info-body">
                                <h4>Data Privacy Notice</h4>
                                <p>Your personal information will be kept confidential and used only for processing your application in compliance with the Data Privacy Act of 2012 (RA 10173).</p>
                            </div>
                        </div>
                        <div class="info-card">
                            <div class="info-icon red"><i class="fas fa-clock"></i></div>
                            <div class="info-body">
                                <h4>Processing Time</h4>
                                <p>AICS applications are prioritized. Most cases are reviewed within <strong>1–3 working days</strong>.</p>
                            </div>
                        </div>
                        <div class="consent-box">
                            <label>
                                <input type="checkbox" id="step1_consent" required>
                                <span>I have read and understood the information above. I confirm that I am experiencing a crisis and I am requesting assistance.</span>
                            </label>
                        </div>
                    </div>

                    <div class="form-section" id="step2">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-id-card"></i></div><h3>Step 2: Client Profile</h3></div>
                        <div class="form-row">
                            <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="first_name" required></div>
                            <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name"></div>
                            <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="last_name" required></div>
                            <div class="form-group"><label>Suffix</label><input type="text" name="suffix" placeholder="Jr., Sr., III"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthdate <span class="required">*</span></label><input type="date" name="birthdate" id="birthdate" onchange="calculateAge()" required></div>
                            <div class="form-group"><label>Age</label><input type="number" name="age" id="age" readonly></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthplace</label><input type="text" name="birthplace"></div>
                            <div class="form-group"><label>Sex</label><select name="sex"><option value="">Select</option><option>Male</option><option>Female</option></select></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Civil Status</label><select name="civil_status"><option value="">Select</option><option>Single</option><option>Married</option><option>Widowed</option><option>Separated</option></select></div>
                            <div class="form-group"><label>Religion</label><input type="text" name="religion"></div>
                        </div>
                        <div class="form-group"><label>Street Address</label><input type="text" name="street_address"></div>
                        <div class="form-row">
                            <div class="form-group"><label>Barangay</label><input type="text" name="barangay"></div>
                            <div class="form-group"><label>Municipality</label><input type="text" name="municipality"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Province</label><input type="text" name="province"></div>
                            <div class="form-group"><label>Contact Number</label><input type="text" name="contact_no"></div>
                        </div>
                        <div class="form-group"><label>Email Address</label><input type="email" name="email"></div>
                        <div class="form-row">
                            <div class="form-group"><label>Educational Attainment</label><select name="educational_attainment"><option value="">Select</option><option>No formal education</option><option>Elementary level</option><option>Elementary graduate</option><option>High school level</option><option>High school graduate</option><option>College level</option><option>College graduate</option><option>Vocational/Technical</option></select></div>
                            <div class="form-group"><label>Occupation</label><input type="text" name="occupation"></div>
                        </div>
                    </div>

                    <div class="form-section" id="step3">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-chart-line"></i></div><h3>Step 3: Household & Socio-Economic Assessment</h3></div>
                        <div class="form-group">
                            <label>Housing Ownership</label>
                            <div class="radio-group">
                                <label><input type="radio" name="housing_ownership" value="Owner"> Owner</label>
                                <label><input type="radio" name="housing_ownership" value="Renter"> Renter</label>
                                <label><input type="radio" name="housing_ownership" value="Sharer"> Sharer</label>
                                <label><input type="radio" name="housing_ownership" value="Informal Settler"> Informal Settler</label>
                            </div>
                        </div>
                        <div class="form-group"><label>Housing Materials</label><select name="housing_materials"><option value="">Select</option><option>Light Materials (Nipa/Bamboo)</option><option>Concrete/Wood</option><option>Mixed Materials</option></select></div>
                        <div class="form-row">
                            <div class="form-group"><label>Water Source</label><select name="water_source"><option value="">Select</option><option>Level 1 (Faucets/Spring)</option><option>Level 2 (Communal)</option><option>Level 3 (Private Pipe)</option><option>Deep Well</option></select></div>
                            <div class="form-group"><label>Toilet Type</label><select name="toilet_type"><option value="">Select</option><option>Flush</option><option>Antipolo/Pit</option><option>None</option></select></div>
                        </div>
                        <div class="form-group"><label>Employment Status</label><select name="employment_status"><option value="">Select</option><option>Employed</option><option>Self-employed</option><option>Unemployed</option><option>Student</option><option>Retired</option><option>Homemaker</option></select></div>
                        <div class="form-group">
                            <label><i class="fas fa-shield-alt"></i> Have Health Insurance (PhilHealth/Private)?</label>
                            <div class="radio-group">
                                <label><input type="radio" name="has_insurance" value="1"> Yes</label>
                                <label><input type="radio" name="has_insurance" value="0"> No</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-section" id="step4">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-hand-holding-heart"></i></div><h3>Step 4: AICS Program Details</h3></div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-tag"></i> Type of Emergency Assistance Requested <span class="required">*</span></label>
                            <select name="emergency_type" id="emergencyType" required onchange="showDynamicFields()">
                                <option value="">Select</option>
                                <option value="medical">Medical Assistance</option>
                                <option value="burial">Burial Assistance</option>
                                <option value="transportation">Transportation Assistance</option>
                                <option value="educational">Educational Assistance</option>
                                <option value="food">Food Assistance</option>
                                <option value="medicine">Medicine Assistance</option>
                                <option value="housing">Housing Assistance</option>
                                <option value="others">Others (Please specify)</option>
                            </select>
                            <input type="text" 
                                   name="emergency_type_others" 
                                   id="emergencyTypeOthers" 
                                   placeholder="Please specify the type of assistance needed..." 
                                   style="display: none; margin-top: 10px;" 
                                   maxlength="255">
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-user-friends"></i> Relationship of Requestor to the Beneficiary <span class="required">*</span></label>
                            <select name="relationship_to_beneficiary" required><option value="">Select</option><option>Self</option><option>Spouse</option><option>Child</option><option>Parent</option><option>Sibling</option><option>Relative</option></select>
                        </div>
                        <div class="form-group"><label><i class="fas fa-money-bill-wave"></i> Amount Requested (Estimate) <span class="required">*</span></label><input type="number" name="amount_requested" step="100" placeholder="₱" required></div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-exclamation-triangle"></i> Cause of Crisis <span class="required">*</span></label>
                            <select name="cause_of_crisis" required>
                                <option value="">Select</option>
                                <option>Hospital Billing</option>
                                <option>Death in the Family</option>
                                <option>In Need of Transportation Assistance</option>
                                <option>Fire/Disaster</option>
                                <option>Accident</option>
                                <option>Educational Support</option>
                            </select>
                        </div>
                        
                        <div class="form-group"><label><i class="fas fa-coins"></i> Current Household Disposable Cash (₱)</label><input type="number" name="household_disposable_cash" step="100" placeholder="₱"></div>
                        <div class="form-group"><label><i class="fas fa-align-left"></i> Crisis Description <span class="required">*</span></label><textarea name="crisis_description" rows="3" placeholder="Describe the crisis situation in detail" required></textarea></div>
                        <div class="form-row">
                            <div class="form-group"><label><i class="fas fa-calendar-alt"></i> Date of Incident</label><input type="date" name="incident_date"></div>
                            <div class="form-group"><label><i class="fas fa-map-marker-alt"></i> Location of Incident</label><input type="text" name="incident_location"></div>
                        </div>
                        <div class="form-group"><label><i class="fas fa-user"></i> Name of Beneficiary (if not self)</label><input type="text" name="beneficiary_name"></div>
                        <div class="form-group"><label><i class="fas fa-chart-line"></i> Age of Beneficiary</label><input type="number" name="beneficiary_age"></div>
                        
                        <!-- Medical Assistance Fields -->
                        <div id="medicalFields" class="dynamic-section">
                            <h4><i class="fas fa-stethoscope"></i> Medical Assistance Details</h4>
                            <div class="form-group"><label>Medical Diagnosis</label><input type="text" name="medical_diagnosis"></div>
                            <div class="form-group"><label>Hospital Name</label><input type="text" name="hospital_name"></div>
                            <div class="form-group"><label>Medical Bill Amount (₱)</label><input type="number" name="medical_bill_amount" step="100"></div>
                        </div>
                        
                        <!-- Burial Assistance Fields -->
                        <div id="burialFields" class="dynamic-section">
                            <h4><i class="fas fa-cross"></i> Burial Assistance Details</h4>
                            <div class="form-group"><label>Name of Deceased</label><input type="text" name="deceased_name"></div>
                            <div class="form-group"><label>Cause of Death</label><input type="text" name="cause_of_death"></div>
                            <div class="form-group"><label>Funeral Home</label><input type="text" name="funeral_home"></div>
                        </div>
                        
                        <!-- Transportation Assistance Fields -->
                        <div id="transportationFields" class="dynamic-section">
                            <h4><i class="fas fa-bus"></i> Transportation Assistance Details</h4>
                            <div class="form-group"><label>Purpose of Travel / Details</label><input type="text" name="transportation_details" placeholder="e.g., Going home to province after being stranded"></div>
                            <div class="form-group"><label>Destination</label><input type="text" name="transportation_destination" placeholder="e.g., Surigao City, Manila"></div>
                        </div>
                        
                        <!-- Educational Assistance Fields -->
                        <div id="educationalFields" class="dynamic-section">
                            <h4><i class="fas fa-graduation-cap"></i> Educational Assistance Details</h4>
                            <div class="form-group"><label>School Name</label><input type="text" name="school_name"></div>
                            <div class="form-group"><label>School Level</label><select name="school_level"><option value="">Select</option><option>Elementary</option><option>High School</option><option>Senior High</option><option>College</option><option>Vocational</option></select></div>
                            <div class="form-group"><label>School Bill Amount (₱)</label><input type="number" name="school_bill_amount" step="100"></div>
                        </div>
                        
                        <!-- Food Assistance Fields -->
                        <div id="foodFields" class="dynamic-section">
                            <h4><i class="fas fa-utensils"></i> Food Assistance Details</h4>
                            <div class="form-group"><label>Food Details / Type of Food Needed</label><input type="text" name="food_details" placeholder="e.g., Rice, canned goods, noodles"></div>
                            <div class="form-group"><label>Number of Persons in Household</label><input type="number" name="food_persons_count" min="1" placeholder="e.g., 5"></div>
                        </div>
                        
                        <!-- Medicine Assistance Fields -->
                        <div id="medicineFields" class="dynamic-section">
                            <h4><i class="fas fa-prescription-bottle-medical"></i> Medicine Assistance Details</h4>
                            <div class="form-group"><label>Medicine Details / Name of Medicine</label><input type="text" name="medicine_details" placeholder="e.g., Antibiotics, maintenance medicine"></div>
                            <div class="form-group"><label>With Prescription?</label><select name="medicine_prescription"><option value="">Select</option><option value="Yes">Yes</option><option value="No">No</option></select></div>
                        </div>
                        
                        <!-- Housing Assistance Fields -->
                        <div id="housingFields" class="dynamic-section">
                            <h4><i class="fas fa-home"></i> Housing Assistance Details</h4>
                            <div class="form-group"><label>Housing Details / Description of Need</label><input type="text" name="housing_details" placeholder="e.g., House repair after typhoon, roof replacement"></div>
                            <div class="form-group"><label>Type of Damage / Assistance Needed</label>
                                <select name="housing_damage_type">
                                    <option value="">Select</option>
                                    <option>Roof Repair</option>
                                    <option>Wall Repair</option>
                                    <option>Full House Repair</option>
                                    <option>House Construction</option>
                                    <option>Rental Assistance</option>
                                    <option>Others</option>
                                </select>
                            </div>
                            <div class="form-group"><label>Estimated Repair Amount (₱)</label><input type="number" name="housing_repair_amount" step="100"></div>
                        </div>
                        
                        <!-- Others Assistance Fields -->
                        <div id="othersFields" class="dynamic-section">
                            <h4><i class="fas fa-ellipsis-h"></i> Other Assistance Details</h4>
                            <div class="form-group"><label>Please describe the assistance needed</label><textarea name="others_details" rows="3" placeholder="Describe the specific assistance you are requesting..."></textarea></div>
                        </div>
                        
                        <div class="form-group"><label><i class="fas fa-exclamation-triangle"></i> Problem Presented <span class="required">*</span></label><textarea name="problem_presented" rows="3" placeholder="Immediate financial crisis due to an unforeseen emergency event..." required></textarea></div>
                        <div class="form-group">
                            <label><i class="fas fa-bullseye"></i> Rehabilitation Goal</label>
                            <div class="checkbox-group"><label><input type="checkbox" name="rehabilitation_goals[]" value="To overcome presented crisis"> To overcome presented crisis</label></div>
                        </div>
                        <hr>
                        <div class="upload-section">
                            <div class="upload-label"><i class="fas fa-file-certificate" style="color: var(--secondary);"></i> Barangay Certificate of Indigency <span class="required">*</span></div>
                            <div class="camera-btn" onclick="document.getElementById('barangay_cert').click()"><i class="fas fa-camera"></i><span>📸 Capture or Upload Document</span><span class="sub-text">Tap to open camera or select from gallery</span></div>
                            <input type="file" id="barangay_cert" name="barangay_certificate" accept="image/*,application/pdf" style="display:none" onchange="updateFileName(this, 'barangayFileName')" capture="environment">
                            <div id="barangayFileName" class="file-name">No file chosen</div>
                            <div id="barangayPreview" class="photo-preview-container"></div>
                        </div>
                        <div class="upload-section" id="dynamicDocGroup">
                            <div class="upload-label"><i class="fas fa-file-alt" style="color: var(--secondary);"></i> <span id="dynamicDocLabel">Supporting Document</span> <span class="required">*</span></div>
                            <div class="camera-btn" onclick="document.getElementById('dynamic_doc').click()"><i class="fas fa-camera"></i><span id="dynamicDocBtnText">📸 Capture or Upload Document</span><span class="sub-text" id="dynamicDocInfo">Upload supporting document for your request</span></div>
                            <input type="file" id="dynamic_doc" name="dynamic_document" accept="image/*,application/pdf" style="display:none" onchange="updateFileName(this, 'dynamicFileName')" capture="environment">
                            <div id="dynamicFileName" class="file-name">No file chosen</div>
                            <div id="dynamicPreview" class="photo-preview-container"></div>
                        </div>
                    </div>

                    <div class="form-section" id="step5">
                        <div class="section-title"><div class="section-icon"><i class="fas fa-shield-alt"></i></div><h3>Step 5: Digital Verification</h3></div>
                        <div class="form-group"><label><input type="checkbox" name="client_consent" value="1" required> Client consents to household profiling & data analytics.</label></div>
                        <div class="upload-section">
                            <div class="upload-label"><i class="fas fa-camera-retro" style="color: var(--secondary);"></i> 1. IDENTITY CAPTURE <span class="required">*</span></div>
                            <div class="camera-btn" onclick="document.getElementById('identity_photo').click()"><i class="fas fa-camera"></i><span>📸 SNAP PHOTO OF CLIENT HOLDING CONSENT/ID</span><span class="sub-text">Tap to open camera</span></div>
                            <input type="file" id="identity_photo" name="identity_photo" accept="image/*" style="display:none" onchange="previewIdentityPhoto(this)" capture="environment">
                            <div id="identityPhotoPreview" class="photo-preview-container"></div>
                            <div class="verification-info" style="margin-top: 12px;"><p><i class="fas fa-clock"></i> Captured at: <?php echo date('F j, Y - H:i'); ?></p></div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-signature"></i> 2. DIGITAL TOUCH SIGNATURE <span class="required">*</span></label>
                            <div class="signature-container">
                                <canvas id="signatureCanvas" width="600" height="180"></canvas>
                                <div class="signature-toolbar">
                                    <div class="pen-indicator"><span class="pen-dot"></span><span>Pen: <strong>Digital Signature</strong></span><span style="color: var(--gray-400);">|</span><span id="signatureStatus" style="font-size: 0.65rem;">Not signed yet</span></div>
                                    <div class="signature-actions"><button type="button" class="btn-undo" onclick="undoSignature()"><i class="fas fa-undo"></i> Undo</button><button type="button" class="btn-clear" onclick="clearSignature()"><i class="fas fa-eraser"></i> Clear</button></div>
                                </div>
                            </div>
                            <div class="signature-status" id="signatureStatusMessage"><i class="fas fa-pen"></i> Draw your signature using your finger or stylus</div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-qrcode"></i> 3. OFFICE USE: VERIFICATION TRACKING</label>
                            <div class="verification-info">
                                <p><i class="fas fa-spinner fa-pulse"></i> System generating secure verification QR string...</p>
                                <p><i class="fas fa-lock"></i> Case No: <strong><?php echo $case_no; ?></strong></p>
                                <p><i class="fas fa-check-circle"></i> Upon approval, a Digital Certificate with QR Code will be issued.</p>
                                <div class="qr-preview"><i class="fas fa-qrcode"></i><p style="font-size: 0.8rem; font-weight: 600; margin: 10px 0 5px;">Issued MSWDO AICS Certificate</p><p style="font-size: 0.7rem; color: var(--gray-500);">Scan QR code to verify: "Verified Authentic: [Client Name] is an approved AICS beneficiary"</p></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> CASEWORKER APPROVAL</label>
                            <div class="alert alert-info" style="margin-bottom: 0;"><i class="fas fa-user-check"></i> Logged in as: <?php echo htmlspecialchars($full_name); ?> (ID: #<?php echo $user_id; ?>)</div>
                        </div>
                    </div>

                    <div class="nav-buttons">
                        <button type="button" class="btn-prev" id="prevBtn" onclick="changeStep(-1)" style="display:none;"><i class="fas fa-chevron-left"></i> Previous</button>
                        <button type="button" class="btn-next" id="nextBtn" onclick="changeStep(1)">Next <i class="fas fa-chevron-right"></i></button>
                        <button type="submit" class="btn-submit" id="submitBtn" style="display:none;"><i class="fas fa-paper-plane"></i> SUBMIT AICS APPLICATION</button>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
    let currentStep = 1;
    const totalSteps = 5;
    
    function showDynamicFields() {
        const emergencyType = document.getElementById('emergencyType').value;
        
        // Hide all dynamic sections
        document.getElementById('medicalFields').style.display = 'none';
        document.getElementById('burialFields').style.display = 'none';
        document.getElementById('transportationFields').style.display = 'none';
        document.getElementById('educationalFields').style.display = 'none';
        document.getElementById('foodFields').style.display = 'none';
        document.getElementById('medicineFields').style.display = 'none';
        document.getElementById('housingFields').style.display = 'none';
        document.getElementById('othersFields').style.display = 'none';
        
        // Show/hide "Others" text input
        const othersInput = document.getElementById('emergencyTypeOthers');
        if(emergencyType === 'others') {
            othersInput.style.display = 'block';
            othersInput.required = true;
        } else {
            othersInput.style.display = 'none';
            othersInput.required = false;
            othersInput.value = '';
        }
        
        // Update dynamic document labels
        const dynamicDocLabel = document.getElementById('dynamicDocLabel');
        const dynamicDocInfo = document.getElementById('dynamicDocInfo');
        const dynamicDocBtnText = document.getElementById('dynamicDocBtnText');
        
        if(emergencyType === 'medical') {
            document.getElementById('medicalFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'Clinical Abstract';
            dynamicDocInfo.innerHTML = 'Upload Clinical Abstract or Medical Certificate';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Clinical Abstract';
        } else if(emergencyType === 'burial') {
            document.getElementById('burialFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'Death Certificate';
            dynamicDocInfo.innerHTML = 'Upload Death Certificate of the deceased';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Death Certificate';
        } else if(emergencyType === 'transportation') {
            document.getElementById('transportationFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'Proof of Travel / Ticket';
            dynamicDocInfo.innerHTML = 'Upload any proof of travel need (ticket, ID, or supporting document)';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Proof of Travel';
        } else if(emergencyType === 'educational') {
            document.getElementById('educationalFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'School Billing';
            dynamicDocInfo.innerHTML = 'Upload School Billing or Registration Form';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload School Billing';
        } else if(emergencyType === 'food') {
            document.getElementById('foodFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'Proof of Need (Barangay Certificate)';
            dynamicDocInfo.innerHTML = 'Upload Barangay Certificate or supporting document for food assistance';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Supporting Document';
        } else if(emergencyType === 'medicine') {
            document.getElementById('medicineFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'Medical Prescription';
            dynamicDocInfo.innerHTML = 'Upload Medical Prescription or Doctor\'s Order';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Prescription';
        } else if(emergencyType === 'housing') {
            document.getElementById('housingFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'Proof of Housing Damage';
            dynamicDocInfo.innerHTML = 'Upload photos of damage or Barangay certification of housing condition';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Proof of Damage';
        } else if(emergencyType === 'others') {
            document.getElementById('othersFields').style.display = 'block';
            dynamicDocLabel.innerHTML = 'Supporting Document';
            dynamicDocInfo.innerHTML = 'Upload any supporting document for your request';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Supporting Document';
        } else {
            dynamicDocLabel.innerHTML = 'Supporting Document';
            dynamicDocInfo.innerHTML = 'Upload any supporting document for your request';
            dynamicDocBtnText.innerHTML = '📸 Capture or Upload Document';
        }
    }
    
    function calculateAge() {
        const birthdate = document.getElementById('birthdate').value;
        if(birthdate) {
            const today = new Date();
            const birth = new Date(birthdate);
            let age = today.getFullYear() - birth.getFullYear();
            const m = today.getMonth() - birth.getMonth();
            if(m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
            document.getElementById('age').value = age;
        }
    }
    
    function updateFileName(input, labelId) {
        const label = document.getElementById(labelId);
        const previewContainer = document.getElementById(labelId.replace('FileName', 'Preview'));
        if(input.files && input.files[0]) {
            label.textContent = '📎 ' + input.files[0].name;
            if(previewContainer && input.files[0].type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) { previewContainer.innerHTML = `<img src="${e.target.result}" class="photo-preview" alt="Document">`; };
                reader.readAsDataURL(input.files[0]);
            }
        } else {
            label.textContent = 'No file chosen';
            if(previewContainer) previewContainer.innerHTML = '';
        }
    }
    
    function previewIdentityPhoto(input) {
        const previewContainer = document.getElementById('identityPhotoPreview');
        if(input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) { previewContainer.innerHTML = `<img src="${e.target.result}" class="photo-preview" alt="Identity Photo">`; };
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    let canvas = document.getElementById('signatureCanvas');
    let ctx = canvas.getContext('2d');
    let drawing = false;
    let signatureHistory = [];
    let currentPath = [];
    
    function resizeCanvas() {
        const container = canvas.parentElement;
        const rect = container.getBoundingClientRect();
        canvas.width = rect.width || 600;
        canvas.height = 180;
        ctx.fillStyle = 'white'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#1E4A8C'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        if (signatureHistory.length > 0) redrawSignature();
    }
    
    function redrawSignature() {
        ctx.fillStyle = 'white'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#1E4A8C'; ctx.lineWidth = 2.5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        for (let path of signatureHistory) { if (path.length > 1) { ctx.beginPath(); ctx.moveTo(path[0].x, path[0].y); for (let i = 1; i < path.length; i++) ctx.lineTo(path[i].x, path[i].y); ctx.stroke(); } }
    }
    
    window.addEventListener('resize', resizeCanvas);
    setTimeout(resizeCanvas, 100);
    
    function startDrawing(e) { e.preventDefault(); drawing = true; currentPath = []; const pos = getCanvasCoordinates(e); currentPath.push(pos); ctx.beginPath(); ctx.moveTo(pos.x, pos.y); ctx.lineTo(pos.x, pos.y); ctx.stroke(); updateSignatureStatus(true); }
    function draw(e) { e.preventDefault(); if(!drawing) return; const pos = getCanvasCoordinates(e); currentPath.push(pos); ctx.lineTo(pos.x, pos.y); ctx.stroke(); ctx.beginPath(); ctx.moveTo(pos.x, pos.y); }
    function stopDrawing(e) { e.preventDefault(); if(drawing && currentPath.length > 1) { signatureHistory.push([...currentPath]); document.getElementById('client_signature').value = canvas.toDataURL(); } drawing = false; ctx.beginPath(); updateSignatureStatus(signatureHistory.length > 0); }
    function getCanvasCoordinates(e) { const rect = canvas.getBoundingClientRect(); const scaleX = canvas.width / rect.width; const scaleY = canvas.height / rect.height; let clientX, clientY; if(e.touches) { clientX = e.touches[0].clientX; clientY = e.touches[0].clientY; } else { clientX = e.clientX; clientY = e.clientY; } let x = (clientX - rect.left) * scaleX; let y = (clientY - rect.top) * scaleY; x = Math.min(Math.max(0, x), canvas.width); y = Math.min(Math.max(0, y), canvas.height); return { x, y }; }
    function undoSignature() { if (signatureHistory.length > 0) { signatureHistory.pop(); redrawSignature(); document.getElementById('client_signature').value = signatureHistory.length > 0 ? canvas.toDataURL() : ''; updateSignatureStatus(signatureHistory.length > 0); } }
    function clearSignature() { signatureHistory = []; ctx.fillStyle = 'white'; ctx.fillRect(0, 0, canvas.width, canvas.height); document.getElementById('client_signature').value = ''; updateSignatureStatus(false); }
    function updateSignatureStatus(signed) { const status = document.getElementById('signatureStatus'); const message = document.getElementById('signatureStatusMessage'); if (signed) { status.textContent = '✅ Signed'; status.style.color = '#059669'; message.innerHTML = '<i class="fas fa-check-circle" style="color: #059669;"></i> Signature captured successfully!'; message.className = 'signature-status signed'; } else { status.textContent = 'Not signed yet'; status.style.color = '#64748B'; message.innerHTML = '<i class="fas fa-pen"></i> Draw your signature using your finger or stylus'; message.className = 'signature-status'; } }
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);
    canvas.addEventListener('touchstart', startDrawing, { passive: false });
    canvas.addEventListener('touchmove', draw, { passive: false });
    canvas.addEventListener('touchend', stopDrawing, { passive: false });
    
    function changeStep(direction) {
        if (direction > 0 && currentStep === 1) { const consent = document.getElementById('step1_consent'); if (consent && !consent.checked) { alert('Please confirm that you have read and understood the information above.'); return; } }
        const sections = document.querySelectorAll('.form-section');
        const steps = document.querySelectorAll('.step');
        sections[currentStep - 1].classList.remove('active-section');
        steps[currentStep - 1].classList.remove('active');
        steps[currentStep - 1].classList.add('completed');
        currentStep += direction;
        sections[currentStep - 1].classList.add('active-section');
        steps[currentStep - 1].classList.add('active');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');
        if(currentStep === 1) prevBtn.style.display = 'none'; else prevBtn.style.display = 'inline-flex';
        if(currentStep === totalSteps) { nextBtn.style.display = 'none'; submitBtn.style.display = 'inline-flex'; } else { nextBtn.style.display = 'inline-flex'; submitBtn.style.display = 'none'; }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if(menuToggle) menuToggle.addEventListener('click', function() { sidebar.classList.toggle('open'); });
    document.addEventListener('click', function(event) { if(window.innerWidth <= 768) { if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) sidebar.classList.remove('open'); } });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    if(programToggle) { programSubmenu.classList.add('show'); programIcon.classList.add('rotated'); programToggle.addEventListener('click', function() { programSubmenu.classList.toggle('show'); programIcon.classList.toggle('rotated'); }); }
    
    document.addEventListener('DOMContentLoaded', function() { setTimeout(resizeCanvas, 200); });
</script>

   <?= renderPwaServiceWorker() ?>
</body>
</html>