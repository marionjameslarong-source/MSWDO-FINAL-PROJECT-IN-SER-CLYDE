const CACHE_NAME = 'mswdo-v1';
const ASSETS = [
    './index.php',
    './assets/img/mswdo_logo.jpg',
    './pwa/manifest.json'
];

// ============================================================
// INSTALL — cache core assets (tolerant of missing files)
// ============================================================
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            // Use individual add() calls with catch so one
            // missing file does NOT break the whole install
            return Promise.all(
                ASSETS.map((url) =>
                    cache.add(url).catch((err) => {
                        console.warn('[SW] Skipped caching:', url, err);
                    })
                )
            );
        }).then(() => self.skipWaiting())
    );
});

// ============================================================
// ACTIVATE — clean old caches
// ============================================================
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) =>
            Promise.all(
                keys
                    .filter((key) => key !== CACHE_NAME)
                    .map((key) => caches.delete(key))
            )
        ).then(() => self.clients.claim())
    );
});

// ============================================================
// FETCH — cache-first for GET, network-first for POST
// ============================================================
self.addEventListener('fetch', (event) => {
    const req = event.request;

    // Only handle GET requests
    if (req.method !== 'GET') return;

    event.respondWith(
        caches.match(req).then((cached) => {
            if (cached) return cached;

            return fetch(req)
                .then((response) => {
                    // Cache successful same-origin responses
                    if (
                        response &&
                        response.status === 200 &&
                        response.type === 'basic'
                    ) {
                        const copy = response.clone();
                        caches.open(CACHE_NAME).then((cache) => {
                            cache.put(req, copy).catch(() => {});
                        });
                    }
                    return response;
                })
                .catch(() => {
                    // Optional: offline fallback
                    // return caches.match('./offline.html');
                    return new Response('Offline', {
                        status: 503,
                        statusText: 'Offline'
                    });
                });
        })
    );
});