<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>MSWDO Dashboard</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #eef2f7;
            padding: 20px;
        }
        .dashboard-container {
            max-width: 500px;
            margin: 0 auto;
            background: white;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .top-bar {
            background: #0b3b5f;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .welcome {
            padding: 25px;
            background: #f4f9ff;
            border-bottom: 1px solid #ddd;
        }
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            padding: 25px;
        }
        .card {
            background: #f8fafc;
            padding: 20px;
            text-align: center;
            border-radius: 20px;
            text-decoration: none;
            color: #0b3b5f;
            font-weight: bold;
            transition: 0.2s;
            border: 1px solid #e2e8f0;
        }
        .card span {
            font-size: 2rem;
            display: block;
            margin-bottom: 10px;
        }
        .logout-btn {
            display: block;
            background: #d63031;
            color: white;
            text-align: center;
            padding: 14px;
            margin: 10px 25px 25px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: bold;
        }
        .logout-btn:hover {
            background: #b12a2a;
        }
        @media (max-width: 480px) {
            .menu-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="top-bar">
            <h2>🏛️ MSWDO</h2>
            <p>Mobile Service Portal</p>
        </div>
        <div class="welcome">
            <h3>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?> 👋</h3>
            <p>Role: <?php echo htmlspecialchars($_SESSION['role']); ?></p>
        </div>
        <div class="menu-grid">
            <a href="#" class="card"><span>📋</span>Beneficiaries</a>
            <a href="#" class="card"><span>📅</span>Appointments</a>
            <a href="#" class="card"><span>📢</span>Announcements</a>
            <a href="#" class="card"><span>📊</span>Reports</a>
        </div>
        <a href="logout.php" class="logout-btn">🚪 Logout</a>
    </div>
</body>
</html>