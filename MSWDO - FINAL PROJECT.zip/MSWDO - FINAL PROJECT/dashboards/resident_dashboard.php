<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Initialize variables
$full_name = $_SESSION['full_name'] ?? 'Resident';
$role = $_SESSION['role'] ?? '';
$user_id = $_SESSION['user_id'];

// Get household_id
$household_id = null;

// Check if household profile exists and its completion status
$household = null;
$household_complete = false;
$household_incomplete_fields = [];

try {
    $stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $household = $stmt->fetch();
    
    if($household) {
        $household_id = $household['id'];
        $required_fields = ['head_first_name', 'head_last_name', 'barangay', 'monthly_income', 'total_members'];
        $missing_fields = [];
        
        foreach($required_fields as $field) {
            if(empty($household[$field]) || $household[$field] == '') {
                $missing_fields[] = $field;
            }
        }
        
        if(count($missing_fields) > 0) {
            $household_complete = false;
            $household_incomplete_fields = $missing_fields;
        } else {
            $household_complete = true;
        }
    }
} catch(PDOException $e) {
    $household = null;
}

// Get unread notification count
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

// Get total applications count
$total_applications = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM welfare_applications WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_applications = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {}

// Get pending applications count
$pending_applications = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM welfare_applications WHERE user_id = ? AND status = 'pending'");
    $stmt->execute([$user_id]);
    $pending_applications = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {}

// Get approved applications count
$approved_applications = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM welfare_applications WHERE user_id = ? AND status = 'approved'");
    $stmt->execute([$user_id]);
    $approved_applications = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {}

// Get application counts for each program
$program_counts = [];
$program_names = ['solo_parent', 'senior_citizen', 'pwd', 'aics', 'vawc', 'financial_assistance', 'id_application'];
foreach($program_names as $prog) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM welfare_applications WHERE user_id = ? AND program_type = ?");
        $stmt->execute([$user_id, $prog]);
        $program_counts[$prog] = $stmt->fetch()['count'];
    } catch(PDOException $e) {
        $program_counts[$prog] = 0;
    }
}

// Get detailed status for each program
$program_status = [];
foreach($program_names as $prog) {
    try {
        $stmt = $pdo->prepare("SELECT status, id, created_at FROM welfare_applications WHERE user_id = ? AND program_type = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$user_id, $prog]);
        $last_app = $stmt->fetch();
        if($last_app) {
            $program_status[$prog] = [
                'status' => $last_app['status'],
                'id' => $last_app['id'],
                'date' => $last_app['created_at']
            ];
        } else {
            $program_status[$prog] = null;
        }
    } catch(PDOException $e) {
        $program_status[$prog] = null;
    }
}

// Get all applications
$all_applications = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $all_applications = $stmt->fetchAll();
} catch(PDOException $e) {
    $all_applications = [];
}

// Success message
$success_message = '';
if(isset($_GET['msg'])) {
    switch($_GET['msg']) {
        case 'household_saved': $success_message = 'Household data saved successfully!'; break;
        case 'household_updated': $success_message = 'Household data updated successfully!'; break;
    }
}

// Helpers
function getProgramDisplayName($program_type) {
    $names = [
        'solo_parent' => 'Solo Parent',
        'senior_citizen' => 'Senior Citizen',
        'pwd' => 'PWD',
        'aics' => 'AICS',
        'vawc' => 'VAWC',
        'financial_assistance' => 'Financial Assistance',
        'id_application' => 'ID Application'
    ];
    return $names[$program_type] ?? ucfirst(str_replace('_', ' ', $program_type));
}

function getStatusClass($status) {
    switch($status) {
        case 'pending': return 'status-pending';
        case 'approved': return 'status-approved';
        case 'rejected': return 'status-rejected';
        default: return 'status-pending';
    }
}

function getStatusIcon($status) {
    switch($status) {
        case 'pending': return 'fa-clock';
        case 'approved': return 'fa-check-circle';
        case 'rejected': return 'fa-times-circle';
        default: return 'fa-question-circle';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Resident Dashboard - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- ADD THIS: PWA meta tags -->
    <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --radius-2xl: 2rem;
        }

        .app { display: flex; min-height: 100vh; }

        /* SIDEBAR */
        .sidebar {
            width: 280px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0; left: 0; bottom: 0;
            overflow-y: auto;
            z-index: 40;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.7rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 0.5px; color: var(--gray-400);
            margin-bottom: 12px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 16px; margin-bottom: 4px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
            position: relative;
        }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge {
            margin-left: auto; background: var(--secondary); color: white;
            font-size: 0.65rem; font-weight: 700; padding: 2px 8px;
            border-radius: 20px; line-height: 1.4;
        }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item {
            display: flex; align-items: center; gap: 12px;
            padding: 8px 16px; margin-bottom: 2px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            transition: all 0.2s ease;
        }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }
        .submenu-item.active i { color: white; }

        /* MAIN */
        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 28px; padding-bottom: 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu {
            display: flex; align-items: center; gap: 16px;
            background: var(--gray-50);
            padding: 8px 16px 8px 20px;
            border-radius: 40px;
            border: 1px solid var(--gray-200);
        }
        .user-avatar {
            width: 36px; height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        /* HERO BANNER */
        .hero-banner {
            background: linear-gradient(135deg, #1E4A8C 0%, #0A2F6C 50%, #3B6CB0 100%);
            border-radius: var(--radius-2xl);
            padding: 28px 32px;
            margin-bottom: 24px;
            color: white;
            position: relative;
            overflow: hidden;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .hero-banner::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(245,176,66,0.25) 0%, transparent 70%);
            border-radius: 50%;
        }
        .hero-banner::after {
            content: '';
            position: absolute;
            bottom: -60%; left: 20%;
            width: 250px; height: 250px;
            background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%);
            border-radius: 50%;
        }
        .hero-content { position: relative; z-index: 2; flex: 1; min-width: 200px; }
        .hero-content .greeting {
            font-size: 0.75rem; font-weight: 500;
            color: rgba(255,255,255,0.7);
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 6px;
        }
        .hero-content h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 8px;
            line-height: 1.2;
        }
        .hero-content h2 .accent-name { color: var(--accent); }
        .hero-content p {
            font-size: 0.85rem;
            color: rgba(255,255,255,0.75);
            max-width: 420px;
        }
        .hero-illustration {
            position: relative;
            z-index: 2;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .hero-badge {
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            padding: 8px 14px;
            border-radius: 40px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.75rem;
            font-weight: 600;
            border: 1px solid rgba(255,255,255,0.15);
        }
        .hero-badge i { color: var(--accent); }

        /* STATS ROW */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 28px;
        }
        .stat-box {
            background: var(--white);
            border-radius: var(--radius-xl);
            padding: 18px 20px;
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
            transition: all 0.25s ease;
        }
        .stat-box:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-md);
            border-color: var(--gray-300);
        }
        .stat-box::before {
            content: '';
            position: absolute;
            top: 0; left: 0;
            width: 4px; height: 100%;
        }
        .stat-box.blue::before { background: #1E4A8C; }
        .stat-box.green::before { background: #059669; }
        .stat-box.orange::before { background: #F5B042; }
        .stat-box.red::before { background: #D32F2F; }
        .stat-box-inner {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }
        .stat-box-text .stat-value {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--gray-800);
            line-height: 1;
            margin-bottom: 4px;
        }
        .stat-box-text .stat-title {
            font-size: 0.7rem;
            color: var(--gray-500);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }
        .stat-box-icon {
            width: 44px; height: 44px;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.15rem;
            flex-shrink: 0;
        }
        .stat-box.blue .stat-box-icon { background: #EFF6FF; color: #1E4A8C; }
        .stat-box.green .stat-box-icon { background: #D1FAE5; color: #059669; }
        .stat-box.orange .stat-box-icon { background: #FEF3C7; color: #B45309; }
        .stat-box.red .stat-box-icon { background: #FEE2E2; color: #D32F2F; }

        /* SHORTCUTS */
        .shortcuts-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .shortcuts-header h3 {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--gray-800);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .shortcuts-header h3 i {
            color: var(--accent);
            font-size: 1.1rem;
            background: #FFF7ED;
            padding: 8px;
            border-radius: var(--radius-md);
        }
        .shortcuts-header small { font-size: 0.72rem; color: var(--gray-500); }
        .shortcuts-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 12px;
            margin-bottom: 28px;
        }
        .shortcut-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            padding: 16px 12px;
            text-decoration: none;
            border: 1px solid var(--gray-200);
            transition: all 0.25s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .shortcut-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }
        .shortcut-card .sc-icon {
            width: 48px; height: 48px;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem;
            color: white;
            transition: all 0.25s ease;
            position: relative;
        }
        .shortcut-card:hover .sc-icon {
            transform: scale(1.08) rotate(-5deg);
        }
        .shortcut-card .sc-label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-700);
            line-height: 1.2;
        }
        .shortcut-card .sc-sub {
            font-size: 0.62rem;
            color: var(--gray-400);
            margin-top: -4px;
        }
        .shortcut-card .sc-badge {
            position: absolute;
            top: 10px; right: 10px;
            background: var(--secondary);
            color: white;
            font-size: 0.6rem;
            font-weight: 700;
            padding: 2px 7px;
            border-radius: 20px;
            line-height: 1.2;
        }
        .sc-icon.blue { background: linear-gradient(135deg, #3B82F6, #1E40AF); }
        .sc-icon.indigo { background: linear-gradient(135deg, #6366F1, #4338CA); }
        .sc-icon.amber { background: linear-gradient(135deg, #F59E0B, #B45309); }
        .sc-icon.teal { background: linear-gradient(135deg, #14B8A6, #115E59); }
        .sc-icon.cyan { background: linear-gradient(135deg, #06B6D4, #155E75); }
        .sc-icon.slate { background: linear-gradient(135deg, #64748B, #1E293B); }

        /* Alerts */
        .alert {
            padding: 16px 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 24px;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Household Card */
        .household-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            padding: 24px;
            margin-bottom: 32px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .household-card h4 {
            display: flex; align-items: center; gap: 10px;
            font-weight: 700; color: var(--gray-800);
            margin-bottom: 16px; font-size: 1rem;
        }
        .household-card h4 i { color: var(--secondary); }
        .progress-container {
            background: var(--gray-200);
            border-radius: 30px;
            height: 8px;
            margin: 16px 0;
            overflow: hidden;
        }
        .progress-bar {
            background: linear-gradient(90deg, var(--accent), var(--secondary));
            border-radius: 30px;
            height: 100%;
            transition: width 0.5s ease;
        }
        .missing-fields {
            background: #FEF2F2;
            padding: 14px 16px;
            border-radius: var(--radius-md);
            margin: 16px 0;
            font-size: 0.75rem;
            color: #991B1B;
        }
        .field-badge {
            display: inline-block;
            background: #FEE2E2;
            color: #991B1B;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.65rem;
            margin: 3px;
        }
        .btn-continue {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.85rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.2s ease;
        }
        .btn-continue:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        /* Section Title */
        .section-title { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
        .section-icon {
            width: 36px; height: 36px;
            background: var(--gray-100);
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
        }
        .section-icon i { font-size: 1rem; color: var(--secondary); }
        .section-title h2 { font-size: 1.2rem; font-weight: 600; color: var(--gray-800); }

        /* Program Grid */
        .program-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            margin-bottom: 32px;
        }
        .program-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            padding: 24px 16px;
            text-align: center;
            text-decoration: none;
            transition: all 0.25s ease;
            border: 1px solid var(--gray-200);
            position: relative;
            box-shadow: var(--shadow-sm);
        }
        .program-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: var(--accent);
        }
        .program-icon {
            width: 56px; height: 56px;
            background: var(--gray-100);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 16px;
        }
        .program-icon i { font-size: 1.6rem; color: var(--primary); }
        .program-card strong { display: block; font-size: 0.9rem; font-weight: 600; color: var(--gray-800); margin-bottom: 6px; }
        .program-card small { font-size: 0.7rem; color: var(--gray-500); }
        .program-status {
            position: absolute; top: 12px; right: 12px;
            font-size: 0.6rem; padding: 3px 8px;
            border-radius: 20px; font-weight: 600;
        }
        .program-status.pending { background: #FEF3C7; color: #B45309; }
        .program-status.approved { background: #E0F2E9; color: #1E7B48; }
        .program-status.rejected { background: #FEE2E2; color: #B91C1C; }
        .program-status.new { background: var(--primary); color: white; }

        /* Applications */
        .applications-list {
            background: var(--white);
            border-radius: var(--radius-xl);
            overflow: hidden;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .application-item {
            padding: 18px 24px;
            border-bottom: 1px solid var(--gray-200);
            display: flex; justify-content: space-between;
            align-items: center; flex-wrap: wrap; gap: 16px;
            transition: background 0.2s;
        }
        .application-item:hover { background: var(--gray-50); }
        .application-item:last-child { border-bottom: none; }
        .app-info { flex: 2; }
        .app-program {
            font-weight: 700; color: var(--gray-800);
            display: flex; align-items: center; gap: 10px;
            flex-wrap: wrap; margin-bottom: 6px;
        }
        .app-program i { font-size: 0.9rem; color: var(--secondary); }
        .app-date { font-size: 0.7rem; color: var(--gray-500); }
        .app-status { display: flex; align-items: center; gap: 12px; }
        .status-badge {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 6px 14px; border-radius: 40px;
            font-size: 0.7rem; font-weight: 600;
        }
        .status-pending { background: #FEF3C7; color: #B45309; }
        .status-approved { background: #E0F2E9; color: #1E7B48; }
        .status-rejected { background: #FEE2E2; color: #B91C1C; }
        .view-details {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.75rem;
            font-weight: 500;
            padding: 6px 12px;
            border-radius: 20px;
            transition: background 0.2s;
        }
        .view-details:hover { background: var(--gray-100); text-decoration: underline; }
        .empty-applications { text-align: center; padding: 48px; color: var(--gray-500); }
        .empty-applications i { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; }
        .btn-view-all {
            display: block; text-align: center;
            padding: 14px; background: var(--gray-50);
            color: var(--primary); text-decoration: none;
            font-weight: 600; font-size: 0.85rem;
            border-top: 1px solid var(--gray-200);
            transition: background 0.2s;
        }
        .btn-view-all:hover { background: var(--gray-100); }

        .menu-toggle {
            display: none; background: none; border: none;
            font-size: 1.3rem; color: var(--gray-700);
            cursor: pointer; padding: 8px; border-radius: var(--radius-md);
        }
        .menu-toggle:hover { background: var(--gray-100); }

        @media (max-width: 1200px) {
            .shortcuts-grid { grid-template-columns: repeat(4, 1fr); }
            .stats-row { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 1024px) {
            .program-grid { grid-template-columns: repeat(3, 1fr); gap: 16px; }
            .shortcuts-grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .program-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
            .program-card { padding: 16px 12px; }
            .program-icon { width: 44px; height: 44px; }
            .program-icon i { font-size: 1.2rem; }
            .application-item { flex-direction: column; align-items: flex-start; }
            .app-status { width: 100%; justify-content: space-between; }
            .household-card { padding: 20px; }
            .shortcuts-grid { grid-template-columns: repeat(3, 1fr); }
            .hero-banner { padding: 22px; }
            .hero-content h2 { font-size: 1.3rem; }
            .stats-row { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 480px) {
            .program-grid { grid-template-columns: 1fr; }
            .shortcuts-grid { grid-template-columns: repeat(2, 1fr); }
            .stats-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="app">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Municipal Social Welfare</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="resident_dashboard.php" class="nav-item active">
                    <i class="fas fa-home"></i><span>Dashboard</span>
                </a>
                <a href="<?php echo ($household_id) ? '../modules/household_data.php?view=' . $household_id : '../modules/household_form.php'; ?>" class="nav-item">
                    <i class="fas fa-users"></i><span>Household Profile</span>
                </a>
                <a href="../modules/my_applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i><span>My Applications</span>
                </a>
                <a href="../notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i><span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i><span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="../soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="../seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="../pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="../aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="../vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="../modules/survey_form.php" class="nav-item">
                    <i class="fas fa-chart-line"></i><span>Community Survey</span>
                </a>
                <a href="../id_application.php" class="nav-item">
                    <i class="fas fa-id-card"></i><span>ID Application</span>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../profile_settings.php" class="nav-item">
                    <i class="fas fa-user-circle"></i><span>Profile Settings</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i><span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Dashboard</h1>
                    <p>Welcome to MSWDO Cantilan Resident Portal</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Resident</small>
                </div>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <!-- HERO BANNER -->
        <div class="hero-banner">
            <div class="hero-content">
                <div class="greeting">Welcome back</div>
                <h2>Kumusta, <span class="accent-name"><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>! 👋</h2>
                <p>Access MSWDO Cantilan social welfare programs and services — all in one place.</p>
            </div>
            <div class="hero-illustration">
                <?php if($household_complete): ?>
                    <div class="hero-badge">
                        <i class="fas fa-check-circle"></i> Household Verified
                    </div>
                <?php else: ?>
                    <div class="hero-badge">
                        <i class="fas fa-exclamation-triangle"></i> Complete Household
                    </div>
                <?php endif; ?>
                <?php if($unread_notif_count > 0): ?>
                    <div class="hero-badge">
                        <i class="fas fa-bell"></i> <?php echo $unread_notif_count; ?> New Alert<?php echo $unread_notif_count > 1 ? 's' : ''; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- STATS ROW -->
        <div class="stats-row">
            <div class="stat-box blue">
                <div class="stat-box-inner">
                    <div class="stat-box-text">
                        <div class="stat-value"><?php echo $total_applications; ?></div>
                        <div class="stat-title">Total Applications</div>
                    </div>
                    <div class="stat-box-icon"><i class="fas fa-file-signature"></i></div>
                </div>
            </div>
            <div class="stat-box orange">
                <div class="stat-box-inner">
                    <div class="stat-box-text">
                        <div class="stat-value"><?php echo $pending_applications; ?></div>
                        <div class="stat-title">Pending</div>
                    </div>
                    <div class="stat-box-icon"><i class="fas fa-clock"></i></div>
                </div>
            </div>
            <div class="stat-box green">
                <div class="stat-box-inner">
                    <div class="stat-box-text">
                        <div class="stat-value"><?php echo $approved_applications; ?></div>
                        <div class="stat-title">Approved</div>
                    </div>
                    <div class="stat-box-icon"><i class="fas fa-check-circle"></i></div>
                </div>
            </div>
            <div class="stat-box red">
                <div class="stat-box-inner">
                    <div class="stat-box-text">
                        <div class="stat-value"><?php echo $unread_notif_count; ?></div>
                        <div class="stat-title">Unread Alerts</div>
                    </div>
                    <div class="stat-box-icon"><i class="fas fa-bell"></i></div>
                </div>
            </div>
        </div>

        <!-- SHORTCUTS -->
        <div class="shortcuts-header">
            <h3><i class="fas fa-bolt"></i> Quick Shortcuts</h3>
            <small>Tap any card to jump directly</small>
        </div>

        <div class="shortcuts-grid">
            <a href="<?php echo ($household_id) ? '../modules/household_data.php?view=' . $household_id : '../modules/household_form.php'; ?>" class="shortcut-card">
                <div class="sc-icon blue"><i class="fas fa-home"></i></div>
                <div class="sc-label">Household</div>
                <div class="sc-sub"><?php echo $household_complete ? 'Complete' : 'Incomplete'; ?></div>
            </a>

            <a href="../modules/my_applications.php" class="shortcut-card">
                <div class="sc-icon indigo"><i class="fas fa-file-alt"></i></div>
                <div class="sc-label">My Apps</div>
                <div class="sc-sub"><?php echo $total_applications; ?> total</div>
            </a>

            <a href="../notifications.php" class="shortcut-card">
                <?php if($unread_notif_count > 0): ?>
                    <span class="sc-badge"><?php echo $unread_notif_count; ?></span>
                <?php endif; ?>
                <div class="sc-icon amber"><i class="fas fa-bell"></i></div>
                <div class="sc-label">Notifications</div>
                <div class="sc-sub"><?php echo $unread_notif_count; ?> unread</div>
            </a>

            <a href="../modules/survey_form.php" class="shortcut-card">
                <div class="sc-icon teal"><i class="fas fa-chart-line"></i></div>
                <div class="sc-label">Survey</div>
                <div class="sc-sub">Community</div>
            </a>

            <a href="../id_application.php" class="shortcut-card">
                <div class="sc-icon cyan"><i class="fas fa-id-card"></i></div>
                <div class="sc-label">ID App</div>
                <div class="sc-sub">Apply now</div>
            </a>

            <a href="../profile_settings.php" class="shortcut-card">
                <div class="sc-icon slate"><i class="fas fa-user-circle"></i></div>
                <div class="sc-label">Settings</div>
                <div class="sc-sub">Profile</div>
            </a>
        </div>

        <!-- Success Message -->
        <?php if($success_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?php echo $success_message; ?></span>
            </div>
        <?php endif; ?>

        <!-- Household Card -->
        <div class="household-card">
            <h4><i class="fas fa-home"></i> Household Profile</h4>
            <?php if($household && $household_complete): ?>
                <p style="color: #059669; margin-bottom: 12px;">
                    <i class="fas fa-check-circle"></i> Your household profile is complete!
                </p>
                <div class="progress-container">
                    <div class="progress-bar" style="width: 100%;"></div>
                </div>
                <a href="../modules/household_data.php?view=<?php echo $household['id']; ?>" class="btn-continue" style="background: #059669;">
                    <i class="fas fa-eye"></i> View My Household Profile
                </a>
            <?php elseif($household && !$household_complete): ?>
                <p style="color: var(--accent); margin-bottom: 12px;">
                    <i class="fas fa-exclamation-triangle"></i> Your household profile is incomplete. Please provide the missing information:
                </p>
                <div class="progress-container">
                    <?php 
                    $total_fields = 5;
                    $completed_fields = $total_fields - count($household_incomplete_fields);
                    $progress_percent = ($completed_fields / $total_fields) * 100;
                    ?>
                    <div class="progress-bar" style="width: <?php echo $progress_percent; ?>%;"></div>
                </div>
                <div class="missing-fields">
                    <strong>Missing fields:</strong><br>
                    <?php 
                    $field_labels = [
                        'head_first_name' => 'First Name',
                        'head_last_name' => 'Last Name',
                        'barangay' => 'Barangay',
                        'monthly_income' => 'Monthly Income',
                        'total_members' => 'Number of Household Members'
                    ];
                    foreach($household_incomplete_fields as $field):
                    ?>
                        <span class="field-badge"><?php echo $field_labels[$field] ?? $field; ?></span>
                    <?php endforeach; ?>
                </div>
                <a href="../modules/household_form.php?continue=<?php echo $household['id']; ?>" class="btn-continue">
                    <i class="fas fa-pen"></i> Continue Household Profile
                </a>
            <?php else: ?>
                <p style="color: var(--gray-500); margin-bottom: 12px;">
                    <i class="fas fa-info-circle"></i> No household profile yet. Please create one to access programs.
                </p>
                <div class="progress-container">
                    <div class="progress-bar" style="width: 0%;"></div>
                </div>
                <a href="../modules/household_form.php" class="btn-continue">
                    <i class="fas fa-plus-circle"></i> Create Household Profile
                </a>
            <?php endif; ?>
        </div>

        <!-- Available Welfare Programs -->
        <div class="section-title">
            <div class="section-icon"><i class="fas fa-clipboard-list"></i></div>
            <h2>Available Welfare Programs</h2>
        </div>

        <div class="program-grid">
            <a href="../soloparent.php" class="program-card">
                <?php if(isset($program_status['solo_parent']) && $program_status['solo_parent']): ?>
                    <span class="program-status <?php echo $program_status['solo_parent']['status']; ?>">
                        <?php echo ucfirst($program_status['solo_parent']['status']); ?>
                    </span>
                <?php elseif($program_counts['solo_parent'] > 0): ?>
                    <span class="program-status new">Applied</span>
                <?php endif; ?>
                <div class="program-icon"><i class="fas fa-female"></i></div>
                <strong>Solo Parent</strong>
                <small>Benefits for single parents</small>
            </a>

            <a href="../seniorcitizen.php" class="program-card">
                <?php if(isset($program_status['senior_citizen']) && $program_status['senior_citizen']): ?>
                    <span class="program-status <?php echo $program_status['senior_citizen']['status']; ?>">
                        <?php echo ucfirst($program_status['senior_citizen']['status']); ?>
                    </span>
                <?php elseif($program_counts['senior_citizen'] > 0): ?>
                    <span class="program-status new">Applied</span>
                <?php endif; ?>
                <div class="program-icon"><i class="fas fa-user-graduate"></i></div>
                <strong>Senior Citizen</strong>
                <small>Benefits for elderly aged 60+</small>
            </a>

            <a href="../pwd.php" class="program-card">
                <?php if(isset($program_status['pwd']) && $program_status['pwd']): ?>
                    <span class="program-status <?php echo $program_status['pwd']['status']; ?>">
                        <?php echo ucfirst($program_status['pwd']['status']); ?>
                    </span>
                <?php elseif($program_counts['pwd'] > 0): ?>
                    <span class="program-status new">Applied</span>
                <?php endif; ?>
                <div class="program-icon"><i class="fas fa-wheelchair"></i></div>
                <strong>PWD</strong>
                <small>Persons with Disability</small>
            </a>

            <a href="../aics.php" class="program-card">
                <?php if(isset($program_status['aics']) && $program_status['aics']): ?>
                    <span class="program-status <?php echo $program_status['aics']['status']; ?>">
                        <?php echo ucfirst($program_status['aics']['status']); ?>
                    </span>
                <?php elseif($program_counts['aics'] > 0): ?>
                    <span class="program-status new">Applied</span>
                <?php endif; ?>
                <div class="program-icon"><i class="fas fa-coins"></i></div>
                <strong>AICS</strong>
                <small>Assistance to Individuals in Crisis</small>
            </a>

            <a href="../vawc.php" class="program-card">
                <?php if(isset($program_status['vawc']) && $program_status['vawc']): ?>
                    <span class="program-status <?php echo $program_status['vawc']['status']; ?>">
                        <?php echo ucfirst($program_status['vawc']['status']); ?>
                    </span>
                <?php elseif($program_counts['vawc'] > 0): ?>
                    <span class="program-status new">Applied</span>
                <?php endif; ?>
                <div class="program-icon"><i class="fas fa-shield-alt"></i></div>
                <strong>VAWC</strong>
                <small>Violence Against Women & Children</small>
            </a>
        </div>

        <!-- My Applications -->
        <div class="section-title">
            <div class="section-icon"><i class="fas fa-file-alt"></i></div>
            <h2>My Applications</h2>
        </div>

        <div class="applications-list">
            <?php if(count($all_applications) > 0): ?>
                <?php 
                $display_apps = array_slice($all_applications, 0, 5);
                foreach($display_apps as $app): 
                ?>
                    <div class="application-item">
                        <div class="app-info">
                            <div class="app-program">
                                <i class="fas fa-file-signature"></i>
                                <strong><?php echo getProgramDisplayName($app['program_type']); ?></strong>
                            </div>
                            <div class="app-date">
                                <i class="fas fa-calendar-alt"></i> Applied on: <?php echo date('F d, Y', strtotime($app['created_at'])); ?>
                            </div>
                        </div>
                        <div class="app-status">
                            <span class="status-badge <?php echo getStatusClass($app['status']); ?>">
                                <i class="fas <?php echo getStatusIcon($app['status']); ?>"></i>
                                <?php echo ucfirst($app['status']); ?>
                            </span>
                            <a href="../modules/my_application_details.php?id=<?php echo $app['id']; ?>" class="view-details">
                                View Details <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if(count($all_applications) > 5): ?>
                    <a href="../modules/my_applications.php" class="btn-view-all">
                        View all <?php echo count($all_applications); ?> applications <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            <?php else: ?>
                <div class="empty-applications">
                    <i class="fas fa-folder-open"></i>
                    <p>No applications yet.</p>
                    <p style="font-size: 0.75rem; margin-top: 4px;">Start by applying to a welfare program above.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    
    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
        });
    }
    
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
    
    setTimeout(function() {
        const alert = document.querySelector('.alert-success');
        if(alert) {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(function() {
                if(alert) alert.remove();
            }, 500);
        }
    }, 5000);
</script>

<!-- ✅ Service worker REMOVED from this page. Only index.php registers it now. -->

</body>
</html>