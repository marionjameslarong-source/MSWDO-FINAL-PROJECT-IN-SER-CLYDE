<?php
session_start();
header('Content-Type: text/plain');

echo "=== SESSION ===\n";
echo "user_id:   " . ($_SESSION['user_id'] ?? 'NONE') . "\n";
echo "username:  " . ($_SESSION['username'] ?? 'NONE') . "\n";
echo "full_name: " . ($_SESSION['full_name'] ?? 'NONE') . "\n";
echo "role:      " . ($_SESSION['role'] ?? 'NONE') . "\n";
echo "\n=== COOKIE ===\n";
echo "PHPSESSID: " . ($_COOKIE['PHPSESSID'] ?? 'NONE') . "\n";