<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$error = '';
$success = '';
$application_id = null;

// Check if user has household data
$stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
$stmt->execute([$user_id]);
$household = $stmt->fetch();

// Get existing VAWC application if any
$stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'vawc' ORDER BY created_at DESC LIMIT 1");
$stmt->execute([$user_id]);
$existing_app = $stmt->fetch();

// Handle form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize inputs
    $victim_name = trim($_POST['victim_name'] ?? '');
    $victim_age = intval($_POST['victim_age'] ?? 0);
    $victim_gender = $_POST['victim_gender'] ?? '';
    $incident_date = $_POST['incident_date'] ?? '';
    $incident_type = $_POST['incident_type'] ?? '';
    $incident_description = trim($_POST['incident_description'] ?? '');
    $perpetrator_name = trim($_POST['perpetrator_name'] ?? '');
    $perpetrator_relation = trim($_POST['perpetrator_relation'] ?? '');
    $has_blotter = $_POST['has_blotter'] ?? 'no';
    $blotter_number = trim($_POST['blotter_number'] ?? '');
    $assistance_needed = trim($_POST['assistance_needed'] ?? '');
    $additional_notes = trim($_POST['additional_notes'] ?? '');
    
    // Validation
    $errors = [];
    
    if(empty($victim_name)) {
        $errors[] = "Victim's full name is required.";
    }
    if($victim_age < 1 || $victim_age > 120) {
        $errors[] = "Please enter a valid age.";
    }
    if(empty($victim_gender)) {
        $errors[] = "Please select gender.";
    }
    if(empty($incident_date)) {
        $errors[] = "Date of incident is required.";
    }
    if(empty($incident_type)) {
        $errors[] = "Please select type of incident.";
    }
    if(empty($incident_description)) {
        $errors[] = "Please provide a description of the incident.";
    }
    if(empty($assistance_needed)) {
        $errors[] = "Please specify the assistance needed.";
    }
    
    if(empty($errors)) {
        try {
            // Insert VAWC application
            $stmt = $pdo->prepare("
                INSERT INTO welfare_applications (
                    user_id, program_type, status, application_data, created_at
                ) VALUES (?, ?, 'pending', ?, NOW())
            ");
            
            $application_data = json_encode([
                'victim_name' => $victim_name,
                'victim_age' => $victim_age,
                'victim_gender' => $victim_gender,
                'incident_date' => $incident_date,
                'incident_type' => $incident_type,
                'incident_description' => $incident_description,
                'perpetrator_name' => $perpetrator_name,
                'perpetrator_relation' => $perpetrator_relation,
                'has_blotter' => $has_blotter,
                'blotter_number' => $blotter_number,
                'assistance_needed' => $assistance_needed,
                'additional_notes' => $additional_notes,
                'submitted_at' => date('Y-m-d H:i:s')
            ]);
            
            $stmt->execute([$user_id, 'vawc', $application_data]);
            $application_id = $pdo->lastInsertId();
            $success = "Your VAWC assistance application has been submitted successfully. A social worker will contact you within 24-48 hours.";
            
            // Clear form data after success
            $_POST = [];
            
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = implode("<br>", $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>VAWC Assistance Application - MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0A2F6C 0%, #1E4A8C 100%);
            min-height: 100vh;
            padding: 20px;
            position: relative;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: radial-gradient(circle at 10% 20%, rgba(245,176,66,0.08) 2%, transparent 2.5%);
            background-size: 48px 48px;
            pointer-events: none;
        }

        .page-wrapper {
            max-width: 800px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
        }

        /* top bar */
        .top-bar {
            background: white;
            padding: 16px 24px;
            border-radius: 28px 28px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }

        .logo {
            font-weight: 700;
            font-size: 1.2rem;
            background: linear-gradient(135deg, #1E4A8C, #0A2F6C);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo i {
            color: #F5B042;
        }

        .back-btn {
            background: #F5F7FB;
            padding: 8px 16px;
            border-radius: 40px;
            text-decoration: none;
            color: #1E4A8C;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
        }

        .back-btn:hover {
            background: #1E4A8C;
            color: white;
        }

        /* main card */
        .form-card {
            background: white;
            border-radius: 0 0 32px 32px;
            padding: 32px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }

        .header-section {
            text-align: center;
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 3px solid #F5B042;
        }

        .header-section i {
            font-size: 3rem;
            background: linear-gradient(135deg, #D32F2F, #F5B042);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            margin-bottom: 12px;
        }

        .header-section h1 {
            font-size: 1.8rem;
            color: #1E4A8C;
            margin-bottom: 8px;
        }

        .header-section p {
            color: #5B6E8C;
            font-size: 0.85rem;
        }

        .alert {
            padding: 14px 18px;
            border-radius: 20px;
            margin-bottom: 24px;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background: #E8F5E9;
            border-left: 4px solid #2E7D32;
            color: #1E5A2E;
        }

        .alert-danger {
            background: #FEF2F0;
            border-left: 4px solid #D32F2F;
            color: #B91C1C;
        }

        .alert-info {
            background: #FFF9EF;
            border-left: 4px solid #F5B042;
            color: #7B5E2A;
        }

        .form-group {
            margin-bottom: 24px;
        }

        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            font-size: 0.85rem;
            color: #1E2F4E;
            margin-bottom: 8px;
        }

        .form-label i {
            color: #F5B042;
            width: 20px;
        }

        .required {
            color: #D32F2F;
            font-size: 0.8rem;
        }

        .form-control, select, textarea {
            width: 100%;
            padding: 12px 16px;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            border: 1.5px solid #E2E8F0;
            border-radius: 20px;
            transition: all 0.2s;
            background-color: #FEFEFE;
            outline: none;
        }

        .form-control:focus, select:focus, textarea:focus {
            border-color: #F5B042;
            box-shadow: 0 0 0 3px rgba(245, 176, 66, 0.2);
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .radio-group {
            display: flex;
            gap: 20px;
            padding: 8px 0;
        }

        .radio-option {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .radio-option input[type="radio"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #D32F2F;
        }

        .btn-submit {
            width: 100%;
            background: linear-gradient(135deg, #1E4A8C, #0A2F6C);
            border: none;
            padding: 14px 24px;
            border-radius: 48px;
            font-weight: 700;
            font-size: 1rem;
            color: white;
            cursor: pointer;
            transition: all 0.25s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 16px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(30, 74, 140, 0.3);
        }

        .confidential-note {
            background: #F9FAFE;
            padding: 16px;
            border-radius: 20px;
            margin-top: 24px;
            text-align: center;
            font-size: 0.75rem;
            color: #6C86A3;
            border: 1px solid #E2E8F0;
        }

        .existing-application {
            background: #FFF9EF;
            padding: 16px;
            border-radius: 20px;
            margin-bottom: 24px;
            border: 1px solid #F5B042;
        }

        @media (max-width: 600px) {
            .form-card {
                padding: 24px;
            }
            .form-row {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            .header-section h1 {
                font-size: 1.4rem;
            }
        }

        hr {
            margin: 20px 0;
            border: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, #E2E8F0, transparent);
        }
    </style>
</head>
<body>
<div class="page-wrapper">
    <div class="top-bar">
        <div class="logo">
            <i class="fas fa-hand-holding-heart"></i>
            <span>MSWDO Portal</span>
        </div>
        <a href="resident_dashboard.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>

    <div class="form-card">
        <div class="header-section">
            <i class="fas fa-shield-alt"></i>
            <h1>VAWC Assistance Application</h1>
            <p>Violence Against Women and Children · Confidential Support Program</p>
        </div>

        <?php if($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?php echo htmlspecialchars($success); ?></span>
            </div>
            <div class="confidential-note">
                <i class="fas fa-phone-alt"></i> Need immediate help? Contact MSWDO Hotline: (02) 8123-4567 or 0917-123-4567
            </div>
        <?php else: ?>

            <?php if($existing_app && $existing_app['status'] == 'pending'): ?>
                <div class="existing-application">
                    <i class="fas fa-clock" style="color: #F5B042;"></i>
                    <strong>You have a pending VAWC application</strong><br>
                    Submitted on: <?php echo date('F d, Y', strtotime($existing_app['created_at'])); ?><br>
                    Status: <span style="color: #F5B042;">Pending Review</span><br>
                    A social worker will contact you soon.
                </div>
            <?php endif; ?>

            <?php if($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <?php if(!$household): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <span>Please complete your <a href="household_form.php" style="color: #D32F2F;">Household Profile</a> first before applying for assistance.</span>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-user"></i> Victim's Full Name <span class="required">*</span></label>
                        <input type="text" name="victim_name" class="form-control" value="<?php echo htmlspecialchars($_POST['victim_name'] ?? $full_name ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-calendar-alt"></i> Age <span class="required">*</span></label>
                        <input type="number" name="victim_age" class="form-control" min="1" max="120" value="<?php echo htmlspecialchars($_POST['victim_age'] ?? ''); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label"><i class="fas fa-venus-mars"></i> Gender <span class="required">*</span></label>
                    <div class="radio-group">
                        <label class="radio-option"><input type="radio" name="victim_gender" value="Female" <?php echo (isset($_POST['victim_gender']) && $_POST['victim_gender'] == 'Female') ? 'checked' : ''; ?> required> Female</label>
                        <label class="radio-option"><input type="radio" name="victim_gender" value="Male" <?php echo (isset($_POST['victim_gender']) && $_POST['victim_gender'] == 'Male') ? 'checked' : ''; ?>> Male</label>
                        <label class="radio-option"><input type="radio" name="victim_gender" value="Prefer not to say" <?php echo (isset($_POST['victim_gender']) && $_POST['victim_gender'] == 'Prefer not to say') ? 'checked' : ''; ?>> Prefer not to say</label>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-calendar-day"></i> Date of Incident <span class="required">*</span></label>
                        <input type="date" name="incident_date" class="form-control" value="<?php echo htmlspecialchars($_POST['incident_date'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-tag"></i> Type of Incident <span class="required">*</span></label>
                        <select name="incident_type" class="form-control" required>
                            <option value="">Select incident type</option>
                            <option value="physical_abuse" <?php echo (isset($_POST['incident_type']) && $_POST['incident_type'] == 'physical_abuse') ? 'selected' : ''; ?>>Physical Abuse</option>
                            <option value="psychological_abuse" <?php echo (isset($_POST['incident_type']) && $_POST['incident_type'] == 'psychological_abuse') ? 'selected' : ''; ?>>Psychological/Emotional Abuse</option>
                            <option value="economic_abuse" <?php echo (isset($_POST['incident_type']) && $_POST['incident_type'] == 'economic_abuse') ? 'selected' : ''; ?>>Economic Abuse</option>
                            <option value="sexual_abuse" <?php echo (isset($_POST['incident_type']) && $_POST['incident_type'] == 'sexual_abuse') ? 'selected' : ''; ?>>Sexual Abuse</option>
                            <option value="child_abuse" <?php echo (isset($_POST['incident_type']) && $_POST['incident_type'] == 'child_abuse') ? 'selected' : ''; ?>>Child Abuse</option>
                            <option value="neglect" <?php echo (isset($_POST['incident_type']) && $_POST['incident_type'] == 'neglect') ? 'selected' : ''; ?>>Neglect</option>
                            <option value="others" <?php echo (isset($_POST['incident_type']) && $_POST['incident_type'] == 'others') ? 'selected' : ''; ?>>Others</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label"><i class="fas fa-file-alt"></i> Description of Incident <span class="required">*</span></label>
                    <textarea name="incident_description" class="form-control" placeholder="Please describe what happened in detail..." required><?php echo htmlspecialchars($_POST['incident_description'] ?? ''); ?></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-user-slash"></i> Perpetrator's Name</label>
                        <input type="text" name="perpetrator_name" class="form-control" value="<?php echo htmlspecialchars($_POST['perpetrator_name'] ?? ''); ?>" placeholder="If known">
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-handshake"></i> Relationship to Perpetrator</label>
                        <input type="text" name="perpetrator_relation" class="form-control" value="<?php echo htmlspecialchars($_POST['perpetrator_relation'] ?? ''); ?>" placeholder="e.g., spouse, relative, neighbor">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label"><i class="fas fa-gavel"></i> Barangay Blotter / Police Report</label>
                    <div class="radio-group">
                        <label class="radio-option"><input type="radio" name="has_blotter" value="yes" <?php echo (isset($_POST['has_blotter']) && $_POST['has_blotter'] == 'yes') ? 'checked' : ''; ?>> Yes</label>
                        <label class="radio-option"><input type="radio" name="has_blotter" value="no" <?php echo (!isset($_POST['has_blotter']) || $_POST['has_blotter'] == 'no') ? 'checked' : ''; ?>> No</label>
                    </div>
                </div>

                <div class="form-group" id="blotterField" style="display: none;">
                    <label class="form-label"><i class="fas fa-file-signature"></i> Blotter / Report Number</label>
                    <input type="text" name="blotter_number" class="form-control" value="<?php echo htmlspecialchars($_POST['blotter_number'] ?? ''); ?>" placeholder="If applicable">
                </div>

                <div class="form-group">
                    <label class="form-label"><i class="fas fa-hands-helping"></i> Type of Assistance Needed <span class="required">*</span></label>
                    <textarea name="assistance_needed" class="form-control" placeholder="e.g., Medical assistance, Legal assistance, Psychological counseling, Temporary shelter, Financial aid, etc." required><?php echo htmlspecialchars($_POST['assistance_needed'] ?? ''); ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label"><i class="fas fa-sticky-note"></i> Additional Notes (Optional)</label>
                    <textarea name="additional_notes" class="form-control" placeholder="Any other information you'd like to share..."><?php echo htmlspecialchars($_POST['additional_notes'] ?? ''); ?></textarea>
                </div>

                <div class="confidential-note">
                    <i class="fas fa-lock"></i> <strong>100% Confidential</strong><br>
                    All information you provide will be kept strictly confidential and will only be used for processing your assistance request. Your safety and privacy are our priority.
                </div>

                <button type="submit" class="btn-submit" <?php echo (!$household) ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : ''; ?>>
                    <i class="fas fa-paper-plane"></i> Submit VAWC Application
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
    // Show/hide blotter field based on selection
    document.querySelectorAll('input[name="has_blotter"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const blotterField = document.getElementById('blotterField');
            if(this.value === 'yes') {
                blotterField.style.display = 'block';
            } else {
                blotterField.style.display = 'none';
            }
        });
    });
    
    // Trigger on page load
    const selectedBlotter = document.querySelector('input[name="has_blotter"]:checked');
    if(selectedBlotter && selectedBlotter.value === 'yes') {
        document.getElementById('blotterField').style.display = 'block';
    }
</script>
</body>
</html>