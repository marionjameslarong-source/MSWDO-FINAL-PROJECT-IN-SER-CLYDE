<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is staff
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$allowed_roles = ['staff', 'social_worker', 'encoder'];
if(!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];
$full_name = $_SESSION['full_name'];
$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];

// ============================================================
// CHECK AND CREATE TABLES IF THEY DON'T EXIST
// ============================================================
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'master_households'");
    if($stmt->rowCount() == 0) {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS master_households (
                household_id INT AUTO_INCREMENT PRIMARY KEY,
                barangay VARCHAR(100) NOT NULL,
                total_members INT NOT NULL,
                monthly_income DECIMAL(12,2) NOT NULL,
                poverty_status ENUM('POOR', 'MIDDLE_CLASS', 'RICH') DEFAULT 'MIDDLE_CLASS',
                housing_type VARCHAR(50) DEFAULT 'INFORMAL_SETTLER',
                per_capita_income DECIMAL(12,2),
                created_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_barangay (barangay),
                INDEX idx_poverty_status (poverty_status),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS staff_collection_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                staff_id INT NOT NULL,
                household_id INT NOT NULL,
                action_type VARCHAR(50) NOT NULL,
                poverty_classification VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_staff_id (staff_id),
                INDEX idx_household_id (household_id),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS household_members (
                id INT AUTO_INCREMENT PRIMARY KEY,
                household_id INT NOT NULL,
                first_name VARCHAR(100) NOT NULL,
                last_name VARCHAR(100),
                birth_date DATE,
                is_pwd TINYINT(1) DEFAULT 0,
                is_senior TINYINT(1) DEFAULT 0,
                relationship VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_household_id (household_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS poverty_analytics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                barangay VARCHAR(100) NOT NULL,
                poverty_status VARCHAR(50) NOT NULL,
                count INT DEFAULT 0,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_barangay_status (barangay, poverty_status),
                INDEX idx_barangay (barangay)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS offline_sync_queue (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                table_name VARCHAR(50),
                record_id INT,
                action VARCHAR(20),
                data JSON,
                sync_attempts INT DEFAULT 0,
                synced_at TIMESTAMP NULL,
                timestamp_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_id (user_id),
                INDEX idx_synced_at (synced_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }
} catch(PDOException $e) {
    error_log("Table creation error: " . $e->getMessage());
}

// ============================================================
// QR CODE SCANNER - Handle scan results
// ============================================================
if(isset($_GET['scan_result']) && !empty($_GET['scan_result'])) {
    $scan_data = $_GET['scan_result'];
    header("Location: ../modules/household_data.php?view=" . urlencode($scan_data) . "&scanned=1");
    exit();
}

// ============================================================
// OFFLINE SYNC STATUS
// ============================================================
$pending_sync_count = 0;
$last_sync_status = 'success';
$sync_error_message = '';
$sync_attempts = 0;

try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'offline_sync_queue'");
    if($stmt->rowCount() > 0) {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM offline_sync_queue WHERE user_id = ? AND synced_at IS NULL");
        $stmt->execute([$user_id]);
        $pending_sync_count = $stmt->fetch()['count'] ?? 0;
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as count, MAX(sync_attempts) as max_attempts FROM offline_sync_queue WHERE user_id = ? AND sync_attempts > 0");
        $stmt->execute([$user_id]);
        $sync_stats = $stmt->fetch();
        $sync_attempts = $sync_stats['max_attempts'] ?? 0;
        
        if($sync_attempts > 3) {
            $last_sync_status = 'failed';
            $sync_error_message = 'Multiple sync attempts failed. Please check your network connection.';
        }
    }
} catch(PDOException $e) {}

// ============================================================
// HANDLE SYNC RETRY
// ============================================================
if(isset($_GET['retry_sync'])) {
    $retry_success = false;
    $retry_message = '';
    
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'offline_sync_queue'");
        if($stmt->rowCount() > 0) {
            $stmt = $pdo->prepare("SELECT * FROM offline_sync_queue WHERE user_id = ? AND synced_at IS NULL ORDER BY timestamp_created ASC LIMIT 10");
            $stmt->execute([$user_id]);
            $pending_records = $stmt->fetchAll();
            
            $synced_count = 0;
            $failed_count = 0;
            
            foreach($pending_records as $record) {
                if($record['sync_attempts'] < 3) {
                    $new_attempts = $record['sync_attempts'] + 1;
                    $stmt = $pdo->prepare("UPDATE offline_sync_queue SET sync_attempts = ?, synced_at = NOW() WHERE id = ?");
                    $stmt->execute([$new_attempts, $record['id']]);
                    $synced_count++;
                } else {
                    $failed_count++;
                }
            }
            
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM offline_sync_queue WHERE user_id = ? AND synced_at IS NULL");
            $stmt->execute([$user_id]);
            $pending_sync_count = $stmt->fetch()['count'] ?? 0;
            
            if($synced_count > 0 || $failed_count == 0) {
                $retry_success = true;
                $retry_message = "✅ Sync retry completed. $synced_count records synced successfully.";
                if($failed_count > 0) $retry_message .= " $failed_count records failed after multiple attempts.";
                $last_sync_status = 'success';
            } else {
                $retry_success = false;
                $retry_message = "❌ Sync retry failed. Please check your network connection.";
                $last_sync_status = 'failed';
            }
        } else {
            $retry_message = "No offline sync records found.";
        }
    } catch(PDOException $e) {
        $retry_message = "Error during sync: " . $e->getMessage();
        $last_sync_status = 'failed';
    }
    
    $_SESSION['sync_retry_message'] = $retry_message;
    header("Location: mswdstaff_dashboard.php#sync-status");
    exit();
}

if(isset($_GET['dismiss_sync_error'])) {
    $_SESSION['sync_error_dismissed'] = true;
    header("Location: mswdstaff_dashboard.php");
    exit();
}

$show_sync_error = ($pending_sync_count > 0 && $sync_attempts > 3 && !isset($_SESSION['sync_error_dismissed']));

// ============================================================
// HANDLE HOUSEHOLD DATA COLLECTION SUBMISSION
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_household_collection'])) {
    $errors = [];
    $success = false;
    $assigned_classification = '';
    
    $barangay_zone = $_POST['barangay_zone'] ?? '';
    $total_roster_count = intval($_POST['total_roster_count'] ?? 0);
    $monthly_declared_income = floatval($_POST['monthly_declared_income'] ?? 0);
    $housing_type = $_POST['housing_type'] ?? 'INFORMAL_SETTLER';
    $roster_members = isset($_POST['roster_members']) ? json_decode($_POST['roster_members'], true) : [];
    
    if(empty($barangay_zone)) $errors[] = "Barangay zone is required";
    if($total_roster_count < 1) $errors[] = "Total roster count must be at least 1";
    if($monthly_declared_income < 0) $errors[] = "Monthly income cannot be negative";
    
    if(empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            $perCapitaIncome = $monthly_declared_income / $total_roster_count;
            
            // ============================================================
            // POVERTY ID ENGINE (3-Class)
            // POOR:          ₱5,000  - ₱10,000
            // MIDDLE-CLASS:  ₱10,001 - ₱25,000
            // RICH:          ₱25,001 and above
            // ============================================================
            $assignedPovertyBadge = "MIDDLE_CLASS";
            if ($perCapitaIncome >= 5000 && $perCapitaIncome <= 10000) {
                $assignedPovertyBadge = "POOR";
            } else if ($perCapitaIncome > 10000 && $perCapitaIncome <= 25000) {
                $assignedPovertyBadge = "MIDDLE_CLASS";
            } else if ($perCapitaIncome > 25000) {
                $assignedPovertyBadge = "RICH";
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO master_households (
                    barangay, total_members, monthly_income, poverty_status, housing_type,
                    per_capita_income, created_by, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $barangay_zone, $total_roster_count, $monthly_declared_income,
                $assignedPovertyBadge, $housing_type,
                $perCapitaIncome, $user_id
            ]);
            
            $generatedHouseholdId = $pdo->lastInsertId();
            
            $stmt = $pdo->prepare("
                INSERT INTO staff_collection_logs (staff_id, household_id, action_type, poverty_classification, created_at) 
                VALUES (?, ?, 'FIELD_COLLECTION_SUBMIT', ?, NOW())
            ");
            $stmt->execute([$user_id, $generatedHouseholdId, $assignedPovertyBadge]);
            
            if(!empty($roster_members) && is_array($roster_members)) {
                $stmt = $pdo->prepare("
                    INSERT INTO household_members (household_id, first_name, birth_date, is_pwd, created_at) 
                    VALUES (?, ?, ?, ?, NOW())
                ");
                foreach($roster_members as $member) {
                    $stmt->execute([
                        $generatedHouseholdId,
                        $member['first_name'] ?? '',
                        $member['birth_date'] ?? null,
                        isset($member['is_pwd']) ? 1 : 0
                    ]);
                }
            }
            
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO poverty_analytics (barangay, poverty_status, count) 
                    VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE count = count + 1
                ");
                $stmt->execute([$barangay_zone, $assignedPovertyBadge]);
            } catch(PDOException $e) {}
            
            $pdo->commit();
            
            $_SESSION['collection_success'] = true;
            $_SESSION['collection_message'] = "✅ Household data submitted successfully!";
            $_SESSION['poverty_badge'] = $assignedPovertyBadge;
            $_SESSION['per_capita_income'] = number_format($perCapitaIncome, 2);
            $_SESSION['household_id'] = $generatedHouseholdId;
            
            header("Location: mswdstaff_dashboard.php?collection_success=1");
            exit();
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    $_SESSION['collection_errors'] = $errors;
    header("Location: mswdstaff_dashboard.php?collection_error=1");
    exit();
}

$collection_success = isset($_GET['collection_success']) || isset($_SESSION['collection_success']);
$poverty_badge = $_SESSION['poverty_badge'] ?? '';
$per_capita_income = $_SESSION['per_capita_income'] ?? '';
$household_id = $_SESSION['household_id'] ?? '';
$collection_message = $_SESSION['collection_message'] ?? '';
$collection_errors = $_SESSION['collection_errors'] ?? [];

if(isset($_GET['collection_success']) || isset($_GET['collection_error'])) {
    unset($_SESSION['collection_success'], $_SESSION['collection_message'], $_SESSION['poverty_badge'], $_SESSION['per_capita_income'], $_SESSION['household_id'], $_SESSION['collection_errors']);
}

// ============================================================
// HOUSEHOLD STATISTICS
// ============================================================
$total_households = 0;
$poor_count = 0;
$middle_class_count = 0;
$rich_count = 0;
$monthly_data = [];
$barangay_data = [];

try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'master_households'");
    if($stmt->rowCount() > 0) {
        $total_households = $pdo->query("SELECT COUNT(*) as total FROM master_households")->fetch()['total'] ?? 0;
        $poor_count = $pdo->query("SELECT COUNT(*) as total FROM master_households WHERE poverty_status = 'POOR'")->fetch()['total'] ?? 0;
        $middle_class_count = $pdo->query("SELECT COUNT(*) as total FROM master_households WHERE poverty_status = 'MIDDLE_CLASS'")->fetch()['total'] ?? 0;
        $rich_count = $pdo->query("SELECT COUNT(*) as total FROM master_households WHERE poverty_status = 'RICH'")->fetch()['total'] ?? 0;
        
        $monthly_data = $pdo->query("
            SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
            FROM master_households 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            GROUP BY month ORDER BY month ASC
        ")->fetchAll();
        
        $barangay_data = $pdo->query("
            SELECT barangay, COUNT(*) as total,
                   SUM(CASE WHEN poverty_status = 'POOR' THEN 1 ELSE 0 END) as poor,
                   SUM(CASE WHEN poverty_status = 'MIDDLE_CLASS' THEN 1 ELSE 0 END) as middle_class,
                   SUM(CASE WHEN poverty_status = 'RICH' THEN 1 ELSE 0 END) as rich
            FROM master_households GROUP BY barangay ORDER BY total DESC LIMIT 10
        ")->fetchAll();
    }
} catch(PDOException $e) {
    error_log("Household stats error: " . $e->getMessage());
}

// ============================================================
// PROGRAM-SPECIFIC APPLICATION STATISTICS
// ============================================================
$program_stats = [
    'soloparent' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'Solo Parent', 'icon' => 'fa-female', 'color' => '#EC4899'],
    'senior_citizen' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'Senior Citizen', 'icon' => 'fa-user-graduate', 'color' => '#3B82F6'],
    'pwd' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'PWD', 'icon' => 'fa-wheelchair', 'color' => '#8B5CF6'],
    'aics' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'AICS', 'icon' => 'fa-coins', 'color' => '#F97316'],
    'vawc' => ['total' => 0, 'pending' => 0, 'approved' => 0, 'rejected' => 0, 'label' => 'VAWC', 'icon' => 'fa-shield-alt', 'color' => '#831843']
];

$total_applications = 0;
$total_pending = 0;
$total_approved = 0;
$total_rejected = 0;

try {
    $stmt = $pdo->query("
        SELECT program_type, status, COUNT(*) as count 
        FROM welfare_applications 
        GROUP BY program_type, status
    ");
    $rows = $stmt->fetchAll();
    
    foreach($rows as $row) {
        $pt = $row['program_type'];
        $status = $row['status'];
        $count = $row['count'];
        
        if(isset($program_stats[$pt])) {
            $program_stats[$pt]['total'] += $count;
            if($status === 'pending') {
                $program_stats[$pt]['pending'] = $count;
                $total_pending += $count;
            } elseif($status === 'approved') {
                $program_stats[$pt]['approved'] = $count;
                $total_approved += $count;
            } elseif($status === 'rejected') {
                $program_stats[$pt]['rejected'] = $count;
                $total_rejected += $count;
            }
            $total_applications += $count;
        }
    }
} catch(PDOException $e) {
    error_log("Program stats error: " . $e->getMessage());
}

// Recent applications
$recent_applications = [];
try {
    $stmt = $pdo->query("
        SELECT wa.id, wa.program_type, wa.status, wa.created_at, 
               u.full_name, u.username,
               JSON_EXTRACT(wa.application_data, '$.case_no') as case_no,
               JSON_EXTRACT(wa.application_data, '$.red_alert') as red_alert
        FROM welfare_applications wa
        JOIN users u ON wa.user_id = u.id
        ORDER BY wa.created_at DESC
        LIMIT 10
    ");
    $recent_applications = $stmt->fetchAll();
} catch(PDOException $e) {}

// Monthly application trend
$monthly_applications = [];
try {
    $stmt = $pdo->query("
        SELECT DATE_FORMAT(created_at, '%Y-%m') as month, 
               program_type, COUNT(*) as count 
        FROM welfare_applications 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY month, program_type ORDER BY month ASC
    ");
    $rows = $stmt->fetchAll();
    foreach($rows as $row) {
        $month = $row['month'];
        if(!isset($monthly_applications[$month])) {
            $monthly_applications[$month] = ['soloparent' => 0, 'senior_citizen' => 0, 'pwd' => 0, 'aics' => 0, 'vawc' => 0];
        }
        $monthly_applications[$month][$row['program_type']] = $row['count'];
    }
} catch(PDOException $e) {}

// Pending by program
$pending_by_program = [];
try {
    $stmt = $pdo->query("SELECT program_type, COUNT(*) as count FROM welfare_applications WHERE status = 'pending' GROUP BY program_type");
    foreach($stmt->fetchAll() as $row) {
        $pending_by_program[$row['program_type']] = $row['count'];
    }
} catch(PDOException $e) {}

// Red alerts
$red_alert_count = 0;
try {
    $stmt = $pdo->query("
        SELECT COUNT(*) as count FROM welfare_applications 
        WHERE program_type = 'vawc' AND status = 'pending'
        AND JSON_EXTRACT(application_data, '$.red_alert') = 1
    ");
    $red_alert_count = $stmt->fetch()['count'] ?? 0;
} catch(PDOException $e) {}

// Total residents
$total_residents = 0;
try {
    $total_residents = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'resident'")->fetch()['total'] ?? 0;
} catch(PDOException $e) {}

// Recent collections
$recent_collections = [];
try {
    $stmt = $pdo->query("
        SELECT mh.*, u.full_name as collector_name
        FROM master_households mh
        LEFT JOIN users u ON mh.created_by = u.id
        ORDER BY mh.created_at DESC LIMIT 5
    ");
    $recent_collections = $stmt->fetchAll();
} catch(PDOException $e) {}

$deleted_count = 0;
try {
    $deleted_count = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL")->fetch()['total'] ?? 0;
} catch(PDOException $e) {}

$sync_retry_message = $_SESSION['sync_retry_message'] ?? '';
unset($_SESSION['sync_retry_message']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>MSWD Staff Dashboard - Data Analytics</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    
    <?= renderPwaMetaTags() ?>
   
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
            background-image: 
                radial-gradient(at 0% 0%, rgba(30, 74, 140, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(245, 176, 66, 0.05) 0px, transparent 50%);
            background-attachment: fixed;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #3B6BB5;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --accent-dark: #D99524;
            --success: #059669;
            --warning: #F59E0B;
            --danger: #DC2626;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed; top: 0; left: 0; height: 100%; width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%); transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000; overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed; inset: 0; background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px); z-index: 999; display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        /* ============================================================
           UPDATED: Logo container now displays MSWDO logo image
           ============================================================ */
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem; font-weight: 700; text-transform: uppercase;
            letter-spacing: 0.08em; color: var(--gray-400); margin-bottom: 8px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 12px; border-radius: var(--radius-md);
            color: var(--gray-600); text-decoration: none; font-size: 0.85rem;
            font-weight: 500; transition: all 0.2s ease; margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white; box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 32px; overflow: hidden;
            max-height: 0; transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 500px; }
        .submenu-item {
            display: flex; align-items: center; gap: 12px;
            padding: 8px 12px; border-radius: var(--radius-md);
            color: var(--gray-500); text-decoration: none; font-size: 0.8rem;
            transition: all 0.2s;
        }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item .badge-count {
            margin-left: auto; background: #FEF3C7; color: #B45309;
            font-size: 0.6rem; padding: 2px 8px; border-radius: 10px; font-weight: 700;
        }
        
        .main-content { width: 100%; min-height: 100vh; padding: 16px; }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none; border: none; font-size: 1.3rem;
            cursor: pointer; padding: 8px; color: var(--gray-600);
            border-radius: var(--radius-md); transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 {
            font-size: 1.35rem; font-weight: 800; letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex; align-items: center; gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px; border-radius: 40px;
            text-decoration: none; color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm); transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        
        /* ============================================================ */
        /* QR Scanner Card - Enhanced with Camera API                   */
        /* ============================================================ */
        .field-ops-section { margin-bottom: 24px; }
        .qr-scanner-button {
            display: flex; align-items: center; gap: 16px;
            background: #FFFFFF; padding: 18px 22px; border-radius: 16px;
            border: 1px solid #E2E8F0; width: 100%; cursor: pointer;
            transition: all 0.25s ease; text-decoration: none;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
            position: relative; overflow: hidden;
        }
        .qr-scanner-button::before {
            content: ''; position: absolute; left: 0; top: 0; bottom: 0;
            width: 3px; background: linear-gradient(180deg, #6366F1, #8B5CF6);
            opacity: 0; transition: opacity 0.25s ease;
        }
        .qr-scanner-button:hover {
            border-color: #C7D2FE; transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.08);
        }
        .qr-scanner-button:hover::before { opacity: 1; }
        .qr-scanner-button .scanner-icon {
            width: 48px; height: 48px; border-radius: 12px;
            background: #EEF2FF; color: #6366F1;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0; font-size: 1.25rem; transition: all 0.25s ease;
        }
        .qr-scanner-button:hover .scanner-icon {
            background: #6366F1; color: #FFFFFF;
        }
        .qr-scanner-button .text-frame { flex: 1; text-align: left; }
        .qr-scanner-button .scanner-button-title {
            color: #1E293B; font-size: 0.95rem; font-weight: 600;
            letter-spacing: -0.01em; margin-bottom: 2px;
        }
        .qr-scanner-button .scanner-button-subtitle {
            color: #94A3B8; font-size: 0.75rem; font-weight: 400; line-height: 1.4;
        }
        .qr-scanner-button .scanner-arrow {
            color: #CBD5E1; font-size: 0.9rem;
            transition: all 0.25s ease; flex-shrink: 0;
        }
        .qr-scanner-button:hover .scanner-arrow {
            color: #6366F1; transform: translateX(3px);
        }
        
        /* QR Scanner Modal - Live Camera */
        .scanner-modal {
            display: none; position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.95); z-index: 5000;
            align-items: center; justify-content: center;
            flex-direction: column; padding: 20px;
        }
        .scanner-modal.active { display: flex; }
        .scanner-modal .scanner-close {
            position: absolute; top: 20px; right: 20px;
            background: rgba(255,255,255,0.15); border: none;
            color: white; font-size: 1.5rem;
            padding: 12px 16px; border-radius: 50%; cursor: pointer;
            transition: all 0.2s;
        }
        .scanner-modal .scanner-close:hover { background: rgba(255,255,255,0.25); }
        .scanner-modal .scanner-title {
            color: white; font-size: 1.1rem; font-weight: 700;
            margin-bottom: 6px; text-align: center;
        }
        .scanner-modal .scanner-subtitle {
            color: rgba(255,255,255,0.6); font-size: 0.8rem;
            margin-bottom: 20px; text-align: center;
        }
        .scanner-modal #qr-reader {
            width: 100%;
            max-width: 400px;
            border-radius: 16px;
            overflow: hidden;
            background: #1a1a2e;
            box-shadow: 0 0 60px rgba(0, 122, 255, 0.2);
            border: 2px solid rgba(0, 122, 255, 0.4);
        }
        .scanner-modal #qr-reader video { border-radius: 14px; }
        .scanner-modal .scanner-frame-fallback {
            width: 280px; height: 280px;
            border: 3px solid #007AFF; border-radius: 24px;
            position: relative; background: #1a1a2e;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 0 60px rgba(0, 122, 255, 0.2);
            margin: 0 auto;
        }
        .scanner-modal .scanner-frame-fallback .scan-line {
            position: absolute; width: 80%; height: 3px;
            background: #007AFF; border-radius: 2px;
            animation: scanLine 2s ease-in-out infinite;
            box-shadow: 0 0 20px #007AFF;
        }
        @keyframes scanLine {
            0%, 100% { top: 10%; }
            50% { top: 85%; }
        }
        .scanner-modal .scanner-frame-fallback .scan-corner {
            position: absolute; width: 30px; height: 30px;
            border-color: #007AFF; border-style: solid; border-width: 0;
        }
        .scanner-modal .scanner-frame-fallback .scan-corner.tl { top: -2px; left: -2px; border-top-width: 4px; border-left-width: 4px; border-radius: 8px 0 0 0; }
        .scanner-modal .scanner-frame-fallback .scan-corner.tr { top: -2px; right: -2px; border-top-width: 4px; border-right-width: 4px; border-radius: 0 8px 0 0; }
        .scanner-modal .scanner-frame-fallback .scan-corner.bl { bottom: -2px; left: -2px; border-bottom-width: 4px; border-left-width: 4px; border-radius: 0 0 0 8px; }
        .scanner-modal .scanner-frame-fallback .scan-corner.br { bottom: -2px; right: -2px; border-bottom-width: 4px; border-right-width: 4px; border-radius: 0 0 8px 0; }
        .scanner-modal .scanner-frame-fallback .scan-placeholder {
            color: rgba(255,255,255,0.3); font-size: 0.8rem; text-align: center;
        }
        .scanner-modal .scanner-frame-fallback .scan-placeholder i {
            font-size: 3rem; display: block; margin-bottom: 12px;
            color: rgba(255,255,255,0.2);
        }
        .scanner-modal .scanner-status {
            margin-top: 16px;
            padding: 8px 18px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .scanner-modal .scanner-status.initializing {
            background: rgba(245, 176, 66, 0.15); color: #FCD34D;
        }
        .scanner-modal .scanner-status.scanning {
            background: rgba(16, 185, 129, 0.15); color: #6EE7B7;
        }
        .scanner-modal .scanner-status.error {
            background: rgba(220, 38, 38, 0.15); color: #FCA5A5;
        }
        .scanner-modal .manual-entry {
            margin-top: 20px; display: flex; gap: 10px;
            width: 100%; max-width: 400px;
        }
        .scanner-modal .manual-entry input {
            flex: 1; padding: 12px 16px;
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: var(--radius-md);
            background: rgba(255,255,255,0.08);
            color: white; font-size: 0.85rem; outline: none;
            font-family: inherit;
        }
        .scanner-modal .manual-entry input::placeholder { color: rgba(255,255,255,0.4); }
        .scanner-modal .manual-entry input:focus {
            border-color: #007AFF; background: rgba(255,255,255,0.12);
        }
        .scanner-modal .manual-entry .btn-manual-scan {
            padding: 12px 20px; background: #007AFF; color: white;
            border: none; border-radius: var(--radius-md);
            font-weight: 600; cursor: pointer; white-space: nowrap;
            font-family: inherit; transition: all 0.2s;
        }
        .scanner-modal .manual-entry .btn-manual-scan:hover { background: #0055CC; transform: translateY(-1px); }
        
        /* Analytics Section */
        .analytics-section-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 16px;
        }
        .analytics-section-header h2 {
            font-size: 0.8rem; font-weight: 700; color: var(--gray-500);
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .analytics-section-header .timestamp {
            font-size: 0.7rem; color: var(--gray-500);
        }
        
        /* Program Cards */
        .program-grid {
            display: grid; grid-template-columns: repeat(5, 1fr);
            gap: 16px; margin-bottom: 24px;
        }
        .program-card {
            background: white; border-radius: var(--radius-xl);
            padding: 18px; border: 1px solid var(--gray-200);
            text-decoration: none; color: inherit;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex; flex-direction: column; gap: 8px;
            box-shadow: var(--shadow-sm);
            position: relative; overflow: hidden;
        }
        .program-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0;
            height: 3px; opacity: 0; transition: opacity 0.3s;
        }
        .program-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }
        .program-card:hover::before { opacity: 1; }
        .program-card-header {
            display: flex; align-items: center; gap: 10px; margin-bottom: 4px;
        }
        .program-card-icon {
            width: 40px; height: 40px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 1.05rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.12);
            transition: transform 0.3s;
        }
        .program-card:hover .program-card-icon { transform: scale(1.1) rotate(-5deg); }
        .program-card-title { font-size: 0.78rem; font-weight: 700; color: var(--gray-800); }
        .program-card-total { font-size: 1.9rem; font-weight: 800; color: var(--gray-800); letter-spacing: -0.03em; }
        .program-card-breakdown {
            display: flex; flex-wrap: wrap; gap: 6px; font-size: 0.62rem;
        }
        .program-card-breakdown .pb {
            padding: 3px 8px; border-radius: 10px; font-weight: 700;
        }
        .program-card-breakdown .pb.pending { background: #FEF3C7; color: #B45309; }
        .program-card-breakdown .pb.approved { background: #D1FAE5; color: #065F46; }
        .program-card-breakdown .pb.rejected { background: #FEE2E2; color: #991B1B; }
        
        /* Stats Grid */
        .stats-grid {
            display: grid; grid-template-columns: repeat(4, 1fr);
            gap: 16px; margin-bottom: 24px;
        }
        .stat-card {
            background: var(--white); padding: 20px;
            border-radius: var(--radius-xl); text-align: center;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative; overflow: hidden;
            cursor: pointer;
        }
        .stat-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0;
            height: 4px; background: linear-gradient(90deg, var(--primary), var(--primary-light));
            opacity: 0; transition: opacity 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }
        .stat-card:hover::before { opacity: 1; }
        .stat-card i { font-size: 1.7rem; color: var(--primary); margin-bottom: 8px; transition: transform 0.3s; display: inline-block; }
        .stat-card:hover i { transform: scale(1.15); }
        .stat-card .stat-number { font-size: 1.7rem; font-weight: 800; color: var(--gray-800); letter-spacing: -0.03em; }
        .stat-card .stat-label { font-size: 0.68rem; color: var(--gray-500); font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; margin-top: 4px; }
        .stat-card.total-apps i { color: #1E4A8C; }
        .stat-card.pending-apps i { color: #B45309; }
        .stat-card.approved-apps i { color: #059669; }
        .stat-card.red-alert-stat { border-color: #FCA5A5; background: linear-gradient(135deg, #FFF5F5, #FEF2F2); }
        .stat-card.red-alert-stat i { color: #DC2626; }
        .stat-card.red-alert-stat .stat-number { color: #DC2626; }
        
        /* Alerts */
        .alert {
            padding: 16px 20px; border-radius: var(--radius-xl);
            margin-bottom: 16px;
            display: flex; align-items: center; gap: 12px;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .alert-success { background: #D1FAE5; color: #065F46; border-left: 4px solid #059669; }
        .alert-error { background: #FEE2E2; color: #991B1B; border-left: 4px solid #D32F2F; }
        .alert-info { background: #EFF6FF; color: #1E4A8C; border-left: 4px solid #1E4A8C; }
        
        /* Red Alert Banner */
        .red-alert-banner {
            background: linear-gradient(135deg, #7F1D1D, #991B1B);
            color: white; padding: 18px 22px;
            border-radius: var(--radius-xl); margin-bottom: 20px;
            display: flex; align-items: center; gap: 14px;
            animation: pulse-alert 2s infinite;
            border-left: 5px solid #FCD34D;
            text-decoration: none;
            box-shadow: 0 12px 24px -8px rgba(127, 29, 29, 0.4);
        }
        @keyframes pulse-alert {
            0%, 100% { box-shadow: 0 0 0 0 rgba(211, 47, 47, 0.4); }
            50% { box-shadow: 0 0 0 8px rgba(211, 47, 47, 0); }
        }
        .red-alert-banner .alert-icon { font-size: 1.9rem; color: #FCD34D; }
        .red-alert-banner .alert-text h3 { font-size: 1rem; font-weight: 700; margin-bottom: 2px; }
        .red-alert-banner .alert-text p { font-size: 0.78rem; opacity: 0.9; }
        
        /* Section header */
        .section-header {
            font-size: 0.8rem; font-weight: 700; color: var(--gray-500);
            text-transform: uppercase; letter-spacing: 0.5px;
            margin-bottom: 12px;
            display: flex; align-items: center; gap: 8px;
        }
        
        /* Tableau-style Charts */
        .charts-row {
            display: grid; grid-template-columns: repeat(2, 1fr);
            gap: 20px; margin-bottom: 24px;
        }
        .chart-container {
            background: white; border-radius: var(--radius-xl);
            padding: 20px; border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.3s;
            position: relative;
        }
        .chart-container:hover {
            box-shadow: var(--shadow-lg);
            border-color: var(--primary-light);
        }
        .chart-container h4 {
            font-size: 0.9rem; font-weight: 700; margin-bottom: 16px;
            display: flex; align-items: center; gap: 8px;
            color: var(--gray-800);
            padding-bottom: 12px;
            border-bottom: 1px solid var(--gray-100);
        }
        .chart-container h4 i { color: var(--primary); }
        .chart-container .chart-wrapper {
            position: relative; height: 280px;
        }
        
        /* Applications Section */
        .applications-section {
            background: var(--white); border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200); padding: 20px;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
        }
        .application-item {
            display: flex; align-items: center; gap: 12px;
            padding: 12px 0; border-bottom: 1px solid var(--gray-100);
            text-decoration: none; color: inherit;
            transition: all 0.2s;
            border-radius: 8px;
        }
        .application-item:last-child { border-bottom: none; }
        .application-item:hover {
            background: var(--gray-50);
            margin: 0 -12px; padding: 12px;
        }
        .application-item .app-icon {
            width: 42px; height: 42px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 1rem; flex-shrink: 0;
            box-shadow: 0 4px 10px rgba(0,0,0,0.12);
        }
        .application-item .app-content { flex: 1; min-width: 0; }
        .application-item .app-content .app-title {
            font-size: 0.85rem; font-weight: 600; color: var(--gray-800);
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .application-item .app-content .app-meta {
            font-size: 0.7rem; color: var(--gray-500); margin-top: 2px;
        }
        .application-item .app-status {
            font-size: 0.65rem; font-weight: 700;
            padding: 5px 12px; border-radius: 12px; white-space: nowrap;
            letter-spacing: 0.03em;
        }
        .app-status.pending { background: #FEF3C7; color: #B45309; }
        .app-status.approved { background: #D1FAE5; color: #065F46; }
        .app-status.rejected { background: #FEE2E2; color: #991B1B; }
        
        /* Empty state */
        .empty-mini {
            text-align: center; padding: 40px 20px;
            color: var(--gray-500); font-size: 0.85rem;
        }
        .empty-mini i { font-size: 2.5rem; display: block; margin-bottom: 8px; opacity: 0.4; }
        
        /* Household Collection Form */
        .collection-section {
            background: var(--white); border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200); padding: 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
        }
        .collection-section h3 {
            font-size: 1.1rem; font-weight: 700; margin-bottom: 20px;
            display: flex; align-items: center; gap: 10px;
            color: var(--gray-800);
            padding-bottom: 14px;
            border-bottom: 1px solid var(--gray-100);
        }
        .collection-section h3 .badge {
            font-size: 0.65rem; background: linear-gradient(135deg, var(--success), #10B981); color: white;
            padding: 4px 12px; border-radius: 20px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.04em;
        }
        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
        .form-group { margin-bottom: 12px; }
        .form-group label {
            display: block; font-size: 0.75rem; font-weight: 700;
            color: var(--gray-600); margin-bottom: 6px;
            text-transform: uppercase; letter-spacing: 0.04em;
        }
        .form-group label i { color: var(--primary); margin-right: 4px; }
        .form-group input, .form-group select {
            width: 100%; padding: 11px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.85rem; font-family: inherit;
            transition: all 0.2s;
            background: white;
        }
        .form-group input:focus, .form-group select:focus {
            outline: none; border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
        }
        .btn-submit-collection {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white; padding: 15px 32px; border: none;
            border-radius: var(--radius-md); font-size: 0.9rem;
            font-weight: 700; cursor: pointer; transition: all 0.2s;
            display: inline-flex; align-items: center; gap: 10px;
            width: 100%; justify-content: center;
            font-family: inherit;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
            letter-spacing: 0.02em;
        }
        .btn-submit-collection:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35);
        }
        .btn-submit-collection:active { transform: translateY(0); }
        
        /* Sync Status Banner */
        .sync-status-banner {
            background: var(--white); border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200); padding: 14px 22px;
            margin-bottom: 20px;
            display: flex; justify-content: space-between; align-items: center;
            flex-wrap: wrap; gap: 12px;
            box-shadow: var(--shadow-sm);
        }
        .sync-status-banner .sync-status-info { display: flex; align-items: center; gap: 12px; }
        .sync-dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
        .sync-dot.success { background: #059669; box-shadow: 0 0 0 3px rgba(5, 150, 105, 0.2); }
        .sync-dot.pending { background: #F5B042; box-shadow: 0 0 0 3px rgba(245, 176, 66, 0.2); animation: livePulse 1.6s ease-in-out infinite; }
        .sync-dot.failed { background: #D32F2F; box-shadow: 0 0 0 3px rgba(211, 47, 47, 0.2); }
        @keyframes livePulse {
            0%, 100% { box-shadow: 0 0 0 3px rgba(245, 176, 66, 0.2); }
            50% { box-shadow: 0 0 0 6px rgba(245, 176, 66, 0); }
        }
        .btn-sync-small {
            padding: 7px 16px; border-radius: 20px; border: none;
            font-size: 0.72rem; font-weight: 700; cursor: pointer;
            text-decoration: none; display: inline-flex; align-items: center; gap: 4px;
            font-family: inherit; transition: all 0.2s;
        }
        .btn-sync-small.retry { background: #2563EB; color: white; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3); }
        .btn-sync-small.retry:hover { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(37, 99, 235, 0.4); }
        .btn-sync-small.dismiss { background: var(--gray-200); color: var(--gray-700); }
        
        /* Bottom nav */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex; justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200); z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex; flex-direction: column; align-items: center;
            font-size: 0.68rem; color: var(--gray-600); text-decoration: none;
            font-weight: 600; padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        
        @media (max-width: 1100px) { .program-grid { grid-template-columns: repeat(3, 1fr); } }
        @media (max-width: 768px) {
            .program-grid { grid-template-columns: repeat(2, 1fr); }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-row { grid-template-columns: 1fr; }
            .form-grid { grid-template-columns: 1fr; }
            .qr-scanner-button { padding: 16px 18px; gap: 14px; }
            .qr-scanner-button .scanner-icon { width: 42px; height: 42px; font-size: 1.1rem; }
            .qr-scanner-button .scanner-button-title { font-size: 0.9rem; }
            .qr-scanner-button .scanner-button-subtitle { font-size: 0.7rem; }
            .scanner-modal .manual-entry { flex-direction: column; }
        }
        @media (max-width: 480px) { .program-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- QR SCANNER MODAL - Live Camera -->
    <div class="scanner-modal" id="scannerModal">
        <button class="scanner-close" onclick="closeScanner()"><i class="fas fa-times"></i></button>
        <div class="scanner-title">📷 Scan Resident QR Code</div>
        <div class="scanner-subtitle">Point your camera at the resident's QR code</div>
        
        <div id="qr-reader"></div>
        
        <div id="scannerFrameFallback" style="display:none;">
            <div class="scanner-frame-fallback">
                <div class="scan-corner tl"></div>
                <div class="scan-corner tr"></div>
                <div class="scan-corner bl"></div>
                <div class="scan-corner br"></div>
                <div class="scan-line"></div>
                <div class="scan-placeholder">
                    <i class="fas fa-camera-slash"></i>
                    <span>Camera not available</span>
                </div>
            </div>
        </div>
        
        <div class="scanner-status initializing" id="scannerStatus">
            <i class="fas fa-spinner fa-spin"></i> Initializing camera...
        </div>
        
        <div class="manual-entry">
            <input type="text" id="manualHouseholdId" placeholder="Or enter Household ID manually..." />
            <button class="btn-manual-scan" onclick="manualLookup()"><i class="fas fa-search"></i> Lookup</button>
        </div>
    </div>

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <!-- ============================================================
                     UPDATED: MSWDO Logo Image replaces Font Awesome icon
                     ============================================================ -->
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Staff Portal</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="mswdstaff_dashboard.php" class="nav-item active">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="../modules/mswdstaff_communityservice.php" class="nav-item">
                    <i class="fas fa-clipboard-list"></i> <span>Community Service</span>
                </a>
                <a href="../modules/household.php" class="nav-item">
                    <i class="fas fa-users"></i> <span>Household Records</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Applications</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i> <span>Welfare Programs</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="../modules/mswdstaff_soloparent.php" class="submenu-item">
                        <i class="fas fa-female"></i> Solo Parent
                        <?php if(($pending_by_program['soloparent'] ?? 0) > 0): ?>
                            <span class="badge-count"><?php echo $pending_by_program['soloparent']; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="../modules/mswdstaff_seniorcitizen.php" class="submenu-item">
                        <i class="fas fa-user-graduate"></i> Senior Citizen
                        <?php if(($pending_by_program['senior_citizen'] ?? 0) > 0): ?>
                            <span class="badge-count"><?php echo $pending_by_program['senior_citizen']; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="../modules/mswdstaff_pwd.php" class="submenu-item">
                        <i class="fas fa-wheelchair"></i> PWD
                        <?php if(($pending_by_program['pwd'] ?? 0) > 0): ?>
                            <span class="badge-count"><?php echo $pending_by_program['pwd']; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="../modules/mswdstaff_aics.php" class="submenu-item">
                        <i class="fas fa-coins"></i> AICS
                        <?php if(($pending_by_program['aics'] ?? 0) > 0): ?>
                            <span class="badge-count"><?php echo $pending_by_program['aics']; ?></span>
                        <?php endif; ?>
                    </a>
                    <a href="../modules/mswdstaff_vawc.php" class="submenu-item">
                        <i class="fas fa-shield-alt"></i> VAWC
                        <?php if(($pending_by_program['vawc'] ?? 0) > 0): ?>
                            <span class="badge-count"><?php echo $pending_by_program['vawc']; ?></span>
                        <?php endif; ?>
                    </a>
                </div>
                <a href="../modules/mswdstaff_idapplication.php" class="nav-item">
                    <i class="fas fa-id-card"></i> <span>ID Applications</span>
                </a>
                <a href="../modules/staff_eligibility_engine.php" class="nav-item">
                    <i class="fas fa-balance-scale"></i> <span>Eligibility Engine</span>
                </a>
                <a href="../modules/reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../modules/mswdstaff_profile.php" class="nav-item">
                    <i class="fas fa-user-circle"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Staff Dashboard</h1>
                    <p>Welcome back, <?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?>!</p>
                </div>
            </div>
            <a href="../modules/mswdstaff_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-check"></i></div>
                <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Sync Status -->
        <div class="sync-status-banner" id="sync-status">
            <div class="sync-status-info">
                <span class="sync-dot <?php echo $pending_sync_count > 0 ? 'pending' : 'success'; ?>"></span>
                <span class="sync-text">
                    <strong>Sync:</strong> 
                    <?php if($pending_sync_count > 0): ?>
                        <span style="color: #B45309;"><?php echo $pending_sync_count; ?> pending records</span>
                    <?php else: ?>
                        <span style="color: #059669;">All data synced</span>
                    <?php endif; ?>
                </span>
            </div>
            <div>
                <?php if($pending_sync_count > 0): ?>
                    <a href="?retry_sync=1#sync-status" class="btn-sync-small retry"><i class="fas fa-sync-alt"></i> Sync Now</a>
                <?php endif; ?>
            </div>
        </div>

        <?php if($sync_retry_message): ?>
            <div class="alert <?php echo strpos($sync_retry_message, '✅') !== false ? 'alert-success' : 'alert-error'; ?>">
                <i class="fas <?php echo strpos($sync_retry_message, '✅') !== false ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                <?php echo $sync_retry_message; ?>
            </div>
        <?php endif; ?>

        <?php if($collection_success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle" style="font-size: 1.5rem;"></i>
                <div>
                    <strong><?php echo $collection_message; ?></strong>
                    <br>
                    <span style="font-size: 0.85rem;">
                        Household ID: <strong>#<?php echo $household_id; ?></strong> | 
                        Classification: <strong><?php echo str_replace('_', ' ', $poverty_badge); ?></strong> | 
                        Per Capita: ₱<?php echo $per_capita_income; ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <?php if(!empty($collection_errors)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle" style="font-size: 1.5rem;"></i>
                <div>
                    <strong>Errors found:</strong>
                    <ul style="margin-top: 4px; font-size: 0.85rem;">
                        <?php foreach($collection_errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>

        <!-- QR CODE SCANNER BUTTON -->
        <div class="field-ops-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                <h2 style="font-size: 0.8rem; font-weight: 700; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; margin: 0;">
                    <i class="fas fa-crosshairs" style="color: #6366F1;"></i> Field Operations
                </h2>
            </div>
            <button class="qr-scanner-button" onclick="openScanner()">
                <span class="scanner-icon"><i class="fas fa-qrcode"></i></span>
                <div class="text-frame">
                    <div class="scanner-button-title">Scan Resident QR Code</div>
                    <div class="scanner-button-subtitle">Instantly lookup a household profile using your camera</div>
                </div>
                <span class="scanner-arrow"><i class="fas fa-arrow-right"></i></span>
            </button>
        </div>

        <!-- RED ALERT BANNER (VAWC) -->
        <?php if($red_alert_count > 0): ?>
        <a href="../modules/mswdstaff_vawc.php" class="red-alert-banner">
            <div class="alert-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="alert-text">
                <h3>🚨 RED ALERT: <?php echo $red_alert_count; ?> VAWC Case<?php echo $red_alert_count > 1 ? 's' : ''; ?> Require Immediate Attention</h3>
                <p>Life-threatening danger reported. Click to view and prioritize intervention.</p>
            </div>
        </a>
        <?php endif; ?>

        <!-- PROGRAM ANALYTICS - REAL DATA -->
        <div class="analytics-section-header">
            <h2><i class="fas fa-chart-pie" style="color: var(--primary);"></i> Live Program Analytics</h2>
            <span class="timestamp"><i class="fas fa-sync-alt"></i> Updated <?php echo date('M d, Y h:i A'); ?></span>
        </div>

        <div class="program-grid">
            <?php foreach($program_stats as $key => $stats): ?>
                <a href="../modules/mswdstaff_<?php echo $key === 'senior_citizen' ? 'seniorcitizen' : $key; ?>.php" class="program-card">
                    <div class="program-card-header">
                        <div class="program-card-icon" style="background: <?php echo $stats['color']; ?>;">
                            <i class="fas <?php echo $stats['icon']; ?>"></i>
                        </div>
                        <div class="program-card-title"><?php echo $stats['label']; ?></div>
                    </div>
                    <div class="program-card-total"><?php echo $stats['total']; ?></div>
                    <div class="program-card-breakdown">
                        <?php if($stats['pending'] > 0): ?><span class="pb pending"><?php echo $stats['pending']; ?> pending</span><?php endif; ?>
                        <?php if($stats['approved'] > 0): ?><span class="pb approved"><?php echo $stats['approved']; ?> approved</span><?php endif; ?>
                        <?php if($stats['rejected'] > 0): ?><span class="pb rejected"><?php echo $stats['rejected']; ?> rejected</span><?php endif; ?>
                        <?php if($stats['total'] == 0): ?><span style="color: var(--gray-500);">No applications yet</span><?php endif; ?>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- KPI STATS -->
        <div class="stats-grid">
            <div class="stat-card total-apps">
                <i class="fas fa-file-alt"></i>
                <div class="stat-number"><?php echo $total_applications; ?></div>
                <div class="stat-label">Total Applications</div>
            </div>
            <div class="stat-card pending-apps">
                <i class="fas fa-clock"></i>
                <div class="stat-number"><?php echo $total_pending; ?></div>
                <div class="stat-label">Pending Review</div>
            </div>
            <div class="stat-card approved-apps">
                <i class="fas fa-check-circle"></i>
                <div class="stat-number"><?php echo $total_approved; ?></div>
                <div class="stat-label">Approved</div>
            </div>
            <div class="stat-card red-alert-stat">
                <i class="fas fa-exclamation-triangle"></i>
                <div class="stat-number"><?php echo $red_alert_count; ?></div>
                <div class="stat-label">VAWC Red Alerts</div>
            </div>
        </div>

        <!-- CHARTS - TABLEAU STYLE -->
        <div class="charts-row">
            <div class="chart-container">
                <h4><i class="fas fa-chart-bar"></i> Applications by Program</h4>
                <div class="chart-wrapper">
                    <canvas id="programChart"></canvas>
                </div>
            </div>
            <div class="chart-container">
                <h4><i class="fas fa-chart-line"></i> 6-Month Application Trend</h4>
                <div class="chart-wrapper">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
        </div>

        <!-- RECENT APPLICATIONS -->
        <div class="applications-section">
            <h4 style="font-size: 0.9rem; font-weight: 700; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; color: var(--gray-800);">
                <i class="fas fa-clock" style="color: var(--primary);"></i> Recent Applications from All Programs
            </h4>
            <?php if(empty($recent_applications)): ?>
                <div class="empty-mini">
                    <i class="fas fa-inbox"></i>
                    No applications submitted yet.
                </div>
            <?php else: ?>
                <?php foreach($recent_applications as $app): 
                    $meta = $program_stats[$app['program_type']] ?? ['label' => $app['program_type'], 'icon' => 'fa-file', 'color' => '#64748B'];
                    $case_no = str_replace('"', '', $app['case_no'] ?? '');
                    $has_red_alert = !empty($app['red_alert']) && $app['red_alert'] != 0;
                ?>
                    <a href="../modules/mswdstaff_<?php echo $app['program_type'] === 'senior_citizen' ? 'seniorcitizen' : $app['program_type']; ?>.php" class="application-item">
                        <div class="app-icon" style="background: <?php echo $meta['color']; ?>;">
                            <i class="fas <?php echo $meta['icon']; ?>"></i>
                        </div>
                        <div class="app-content">
                            <div class="app-title">
                                <?php echo htmlspecialchars($app['full_name']); ?>
                                <?php if($has_red_alert): ?>
                                    <span style="color: #D32F2F; font-weight: 700; font-size: 0.7rem;">🚨 RED ALERT</span>
                                <?php endif; ?>
                            </div>
                            <div class="app-meta">
                                <strong><?php echo $meta['label']; ?></strong>
                                <?php if($case_no): ?> • <?php echo htmlspecialchars($case_no); ?><?php endif; ?>
                                • <?php echo date('M d, Y', strtotime($app['created_at'])); ?>
                            </div>
                        </div>
                        <span class="app-status <?php echo $app['status']; ?>">
                            <?php echo ucfirst($app['status']); ?>
                        </span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- HOUSEHOLD COLLECTION FORM -->
        <div class="collection-section">
            <h3>
                <i class="fas fa-home" style="color: var(--primary);"></i> 
                Household Data Collection
                <span class="badge">Poverty ID Engine (3-Class)</span>
            </h3>
            
            <form method="POST" action="" id="collectionForm">
                <div class="form-grid">
                    <div>
                        <div class="form-group">
                            <label for="barangay_zone"><i class="fas fa-map-marker-alt"></i> Barangay Zone *</label>
                            <select name="barangay_zone" id="barangay_zone" required>
                                <option value="">Select Barangay Zone</option>
                                <option value="Barangay_Zone_1">Barangay Zone 1</option>
                                <option value="Barangay_Zone_2">Barangay Zone 2</option>
                                <option value="Barangay_Zone_3">Barangay Zone 3</option>
                                <option value="Barangay_Zone_4">Barangay Zone 4</option>
                                <option value="Barangay_Zone_5">Barangay Zone 5</option>
                                <option value="Barangay_Zone_6">Barangay Zone 6</option>
                                <option value="Barangay_Zone_7">Barangay Zone 7</option>
                                <option value="Barangay_Zone_8">Barangay Zone 8</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="total_roster_count"><i class="fas fa-users"></i> Total Roster Count *</label>
                            <input type="number" name="total_roster_count" id="total_roster_count" min="1" max="20" required placeholder="Number of household members" />
                        </div>
                        <div class="form-group">
                            <label for="monthly_declared_income"><i class="fas fa-coins"></i> Monthly Declared Income (₱) *</label>
                            <input type="number" name="monthly_declared_income" id="monthly_declared_income" step="0.01" min="0" required placeholder="0.00" />
                        </div>
                    </div>
                    <div>
                        <div class="form-group">
                            <label for="housing_type"><i class="fas fa-building"></i> Housing Type</label>
                            <select name="housing_type" id="housing_type">
                                <option value="INFORMAL_SETTLER">Informal Settler</option>
                                <option value="OWNED">Owned</option>
                                <option value="RENTED">Rented</option>
                                <option value="LIVING_WITH_RELATIVES">Living with Relatives</option>
                                <option value="HOMELESS">Homeless</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-info-circle"></i> Poverty ID Engine (3-Class)</label>
                            <div style="background: linear-gradient(135deg, #FFF9EF, #FEF3C7); padding: 14px; border-radius: var(--radius-md); border: 1px dashed #FCD34D; font-size: 0.72rem; color: #78350F; line-height: 1.9;">
                                <strong>Per capita income = Monthly Income ÷ Total Members</strong>
                                <br>
                                • ₱5,000 - ₱10,000 → <strong style="color: #DC2626;">POOR</strong>
                                <br>
                                • ₱10,001 - ₱25,000 → <strong style="color: #1E4A8C;">MIDDLE CLASS</strong>
                                <br>
                                • ₱25,001 and above → <strong style="color: #B45309;">RICH</strong>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="roster_members" id="roster_members" value="[]" />
                <button type="submit" name="submit_household_collection" class="btn-submit-collection">
                    <i class="fas fa-cloud-upload-alt"></i> SUBMIT HOUSEHOLD COLLECTION & RUN POVERTY ID ENGINE
                </button>
            </form>
        </div>

        <!-- HOUSEHOLD STATS -->
        <div class="section-header">
            <i class="fas fa-home"></i> Household Poverty Classification
        </div>
        <div class="stats-grid" style="margin-bottom: 24px;">
            <div class="stat-card">
                <i class="fas fa-home" style="color: var(--primary);"></i>
                <div class="stat-number"><?php echo $total_households; ?></div>
                <div class="stat-label">Total Households</div>
            </div>
            <div class="stat-card" style="border-color: #FCA5A5; background: linear-gradient(135deg, #FFF5F5, #FEF2F2);">
                <i class="fas fa-exclamation-triangle" style="color: #DC2626;"></i>
                <div class="stat-number" style="color: #DC2626;"><?php echo $poor_count; ?></div>
                <div class="stat-label">Poor (₱5k-₱10k)</div>
            </div>
            <div class="stat-card" style="border-color: #93C5FD; background: linear-gradient(135deg, #F0F7FF, #EFF6FF);">
                <i class="fas fa-chart-line" style="color: #1E4A8C;"></i>
                <div class="stat-number" style="color: #1E4A8C;"><?php echo $middle_class_count; ?></div>
                <div class="stat-label">Middle Class (₱10k-₱25k)</div>
            </div>
            <div class="stat-card" style="border-color: #FCD34D; background: linear-gradient(135deg, #FFFAF0, #FEF3C7);">
                <i class="fas fa-crown" style="color: #B45309;"></i>
                <div class="stat-number" style="color: #B45309;"><?php echo $rich_count; ?></div>
                <div class="stat-label">Rich (₱25k+)</div>
            </div>
        </div>

        <!-- HOUSEHOLD CHARTS -->
        <div class="charts-row">
            <div class="chart-container">
                <h4><i class="fas fa-chart-bar"></i> Poverty Distribution by Barangay</h4>
                <div class="chart-wrapper">
                    <canvas id="barangayChart"></canvas>
                </div>
            </div>
            <div class="chart-container">
                <h4><i class="fas fa-clock"></i> Household Collection Trend</h4>
                <div class="chart-wrapper">
                    <canvas id="householdTrendChart"></canvas>
                </div>
            </div>
        </div>

        <!-- RECENT COLLECTIONS -->
        <div class="applications-section">
            <h4 style="font-size: 0.9rem; font-weight: 700; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; color: var(--gray-800);">
                <i class="fas fa-clock" style="color: var(--primary);"></i> Recent Household Collections
            </h4>
            <?php if(empty($recent_collections)): ?>
                <div class="empty-mini">
                    <i class="fas fa-inbox"></i>
                    No collections yet. Submit your first household data!
                </div>
            <?php else: ?>
                <?php foreach($recent_collections as $collection): 
                    $color = $collection['poverty_status'] === 'POOR' ? '#DC2626' : ($collection['poverty_status'] === 'RICH' ? '#B45309' : '#1E4A8C');
                ?>
                    <div class="application-item">
                        <div class="app-icon" style="background: <?php echo $color; ?>;">
                            <i class="fas fa-home"></i>
                        </div>
                        <div class="app-content">
                            <div class="app-title">
                                Household #<?php echo $collection['household_id']; ?> 
                                (<?php echo htmlspecialchars($collection['barangay']); ?>)
                            </div>
                            <div class="app-meta">
                                ₱<?php echo number_format($collection['monthly_income'], 2); ?> • 
                                <?php echo $collection['total_members']; ?> members • 
                                By <?php echo htmlspecialchars($collection['collector_name'] ?? 'Unknown'); ?> • 
                                <?php echo date('M d, Y h:i A', strtotime($collection['created_at'])); ?>
                            </div>
                        </div>
                        <span class="app-status" style="background: <?php echo $color; ?>20; color: <?php echo $color; ?>;">
                            <?php echo str_replace('_', ' ', $collection['poverty_status']); ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>

    <!-- BOTTOM NAV -->
    <div class="bottom-nav">
        <a href="mswdstaff_dashboard.php" class="nav-item active"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="../modules/mswdstaff_communityservice.php" class="nav-item"><i class="fas fa-clipboard-list"></i><span>Community</span></a>
        <a href="../modules/household.php" class="nav-item"><i class="fas fa-users"></i><span>Households</span></a>
        <a href="../modules/staff_eligibility_engine.php" class="nav-item"><i class="fas fa-balance-scale"></i><span>Eligibility</span></a>
        <a href="../modules/reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="../modules/mswdstaff_profile.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>

    <script>
        // ============================================================
        // Chart.js GLOBAL TABLEAU-STYLE DEFAULTS
        // ============================================================
        Chart.defaults.font.family = "'Inter', sans-serif";
        Chart.defaults.font.size = 11;
        Chart.defaults.color = '#475569';
        Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(15, 23, 42, 0.95)';
        Chart.defaults.plugins.tooltip.padding = 12;
        Chart.defaults.plugins.tooltip.cornerRadius = 8;
        Chart.defaults.plugins.tooltip.titleFont = { size: 12, weight: '700' };
        Chart.defaults.plugins.tooltip.bodyFont = { size: 11 };
        Chart.defaults.plugins.legend.labels.boxWidth = 12;
        Chart.defaults.plugins.legend.labels.padding = 14;
        Chart.defaults.plugins.legend.labels.font = { size: 11, weight: '600' };

        // ============================================================
        // QR CODE SCANNER - LIVE CAMERA via html5-qrcode
        // ============================================================
        let html5QrCode = null;
        let scannerActive = false;

        function openScanner() {
            document.getElementById('scannerModal').classList.add('active');
            startScanner();
        }

        function closeScanner() {
            document.getElementById('scannerModal').classList.remove('active');
            stopScanner();
        }

        function updateScannerStatus(type, message) {
            const statusEl = document.getElementById('scannerStatus');
            statusEl.className = 'scanner-status ' + type;
            let icon = 'fa-spinner fa-spin';
            if(type === 'scanning') icon = 'fa-circle-dot';
            else if(type === 'error') icon = 'fa-exclamation-triangle';
            statusEl.innerHTML = `<i class="fas ${icon}"></i> ${message}`;
        }

        function startScanner() {
            if(scannerActive) return;
            
            if(typeof Html5Qrcode === 'undefined') {
                updateScannerStatus('error', 'QR library failed to load');
                document.getElementById('scannerFrameFallback').style.display = 'block';
                document.getElementById('qr-reader').style.display = 'none';
                return;
            }
            
            updateScannerStatus('initializing', 'Initializing camera...');
            
            try {
                html5QrCode = new Html5Qrcode("qr-reader");
                
                const config = {
                    fps: 10,
                    qrbox: { width: 250, height: 250 },
                    aspectRatio: 1.0
                };
                
                html5QrCode.start(
                    { facingMode: "environment" },
                    config,
                    (decodedText, decodedResult) => {
                        updateScannerStatus('scanning', '✅ QR code detected! Redirecting...');
                        handleQrResult(decodedText);
                    },
                    (errorMessage) => {}
                ).then(() => {
                    scannerActive = true;
                    updateScannerStatus('scanning', 'Camera active — point at QR code');
                    document.getElementById('qr-reader').style.display = 'block';
                    document.getElementById('scannerFrameFallback').style.display = 'none';
                }).catch((err) => {
                    console.error('Camera start failed:', err);
                    updateScannerStatus('error', 'Camera access denied or unavailable');
                    document.getElementById('scannerFrameFallback').style.display = 'block';
                    document.getElementById('qr-reader').style.display = 'none';
                });
            } catch(err) {
                console.error('Scanner error:', err);
                updateScannerStatus('error', 'Scanner initialization failed');
                document.getElementById('scannerFrameFallback').style.display = 'block';
                document.getElementById('qr-reader').style.display = 'none';
            }
        }

        function stopScanner() {
            if(html5QrCode && scannerActive) {
                html5QrCode.stop().then(() => {
                    scannerActive = false;
                    html5QrCode.clear();
                    html5QrCode = null;
                }).catch(err => {
                    console.error('Stop error:', err);
                    scannerActive = false;
                });
            } else if(html5QrCode) {
                try { html5QrCode.clear(); } catch(e) {}
                html5QrCode = null;
                scannerActive = false;
            }
        }

        function handleQrResult(decodedText) {
            let householdId = decodedText.trim();
            
            try {
                if(householdId.includes('view=')) {
                    const url = new URL(householdId);
                    householdId = url.searchParams.get('view');
                } else if(householdId.includes('/')) {
                    const match = householdId.match(/(\d+)/);
                    if(match) householdId = match[1];
                }
            } catch(e) {}
            
            setTimeout(() => {
                window.location.href = '../modules/household_data.php?view=' + encodeURIComponent(householdId) + '&scanned=1';
            }, 800);
        }

        function manualLookup() {
            const input = document.getElementById('manualHouseholdId');
            const householdId = input.value.trim();
            if(householdId === '') {
                alert('Please enter a valid Household ID');
                return;
            }
            window.location.href = '../modules/household_data.php?view=' + encodeURIComponent(householdId) + '&scanned=1';
        }

        document.getElementById('manualHouseholdId')?.addEventListener('keypress', function(e) {
            if(e.key === 'Enter') manualLookup();
        });

        document.addEventListener('keydown', function(e) {
            if(e.key === 'Escape') closeScanner();
            if((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                openScanner();
            }
        });

        // ============================================================
        // SIDEBAR & MENU TOGGLES
        // ============================================================
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };
        
        const progToggle = document.getElementById('programToggle');
        const progSub = document.getElementById('programSubmenu');
        const progIcon = document.getElementById('programIcon');
        if(progToggle) {
            progSub.classList.add('show');
            progIcon.classList.add('rotated');
            progToggle.addEventListener('click', () => { 
                progSub.classList.toggle('show'); 
                progIcon.classList.toggle('rotated'); 
            });
        }

        // ============================================================
        // PROGRAM ANALYTICS CHART - TABLEAU STYLE
        // ============================================================
        const programCtx = document.getElementById('programChart')?.getContext('2d');
        if(programCtx) {
            const programLabels = <?php echo json_encode(array_values(array_map(fn($s) => $s['label'], $program_stats))); ?>;
            const programPending = <?php echo json_encode(array_values(array_map(fn($s) => $s['pending'], $program_stats))); ?>;
            const programApproved = <?php echo json_encode(array_values(array_map(fn($s) => $s['approved'], $program_stats))); ?>;
            const programRejected = <?php echo json_encode(array_values(array_map(fn($s) => $s['rejected'], $program_stats))); ?>;
            
            new Chart(programCtx, {
                type: 'bar',
                data: {
                    labels: programLabels,
                    datasets: [
                        { label: 'Pending', data: programPending, backgroundColor: 'rgba(245, 176, 66, 0.85)', borderColor: '#F5B042', borderWidth: 2, borderRadius: 6, borderSkipped: false, barPercentage: 0.7 },
                        { label: 'Approved', data: programApproved, backgroundColor: 'rgba(5, 150, 105, 0.85)', borderColor: '#059669', borderWidth: 2, borderRadius: 6, borderSkipped: false, barPercentage: 0.7 },
                        { label: 'Rejected', data: programRejected, backgroundColor: 'rgba(220, 38, 38, 0.85)', borderColor: '#DC2626', borderWidth: 2, borderRadius: 6, borderSkipped: false, barPercentage: 0.7 }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 11, weight: '600' } } }
                    },
                    plugins: {
                        legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } }
                    },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        }

        // ============================================================
        // 6-MONTH TREND CHART - TABLEAU STYLE
        // ============================================================
        const trendCtx = document.getElementById('trendChart')?.getContext('2d');
        if(trendCtx) {
            const monthlyData = <?php echo json_encode($monthly_applications); ?>;
            const sortedMonths = Object.keys(monthlyData).sort();
            const monthLabels = sortedMonths.map(m => {
                const d = new Date(m + '-01');
                return d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            });
            
            const spData = sortedMonths.map(m => monthlyData[m]['soloparent'] || 0);
            const scData = sortedMonths.map(m => monthlyData[m]['senior_citizen'] || 0);
            const pwdData = sortedMonths.map(m => monthlyData[m]['pwd'] || 0);
            const aicsData = sortedMonths.map(m => monthlyData[m]['aics'] || 0);
            const vawcData = sortedMonths.map(m => monthlyData[m]['vawc'] || 0);
            
            new Chart(trendCtx, {
                type: 'line',
                data: {
                    labels: monthLabels.length > 0 ? monthLabels : ['No Data'],
                    datasets: [
                        { label: 'Solo Parent', data: spData.length > 0 ? spData : [0], borderColor: '#EC4899', backgroundColor: 'rgba(236, 72, 153, 0.08)', tension: 0.4, borderWidth: 3, pointBackgroundColor: '#FFFFFF', pointBorderColor: '#EC4899', pointBorderWidth: 2, pointRadius: 4, pointHoverRadius: 7 },
                        { label: 'Senior Citizen', data: scData.length > 0 ? scData : [0], borderColor: '#3B82F6', backgroundColor: 'rgba(59, 130, 246, 0.08)', tension: 0.4, borderWidth: 3, pointBackgroundColor: '#FFFFFF', pointBorderColor: '#3B82F6', pointBorderWidth: 2, pointRadius: 4, pointHoverRadius: 7 },
                        { label: 'PWD', data: pwdData.length > 0 ? pwdData : [0], borderColor: '#8B5CF6', backgroundColor: 'rgba(139, 92, 246, 0.08)', tension: 0.4, borderWidth: 3, pointBackgroundColor: '#FFFFFF', pointBorderColor: '#8B5CF6', pointBorderWidth: 2, pointRadius: 4, pointHoverRadius: 7 },
                        { label: 'AICS', data: aicsData.length > 0 ? aicsData : [0], borderColor: '#F97316', backgroundColor: 'rgba(249, 115, 22, 0.08)', tension: 0.4, borderWidth: 3, pointBackgroundColor: '#FFFFFF', pointBorderColor: '#F97316', pointBorderWidth: 2, pointRadius: 4, pointHoverRadius: 7 },
                        { label: 'VAWC', data: vawcData.length > 0 ? vawcData : [0], borderColor: '#831843', backgroundColor: 'rgba(131, 24, 67, 0.08)', tension: 0.4, borderWidth: 3, pointBackgroundColor: '#FFFFFF', pointBorderColor: '#831843', pointBorderWidth: 2, pointRadius: 4, pointHoverRadius: 7 }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    },
                    plugins: {
                        legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } }
                    },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        }

        // ============================================================
        // BARANGAY POVERTY CHART - TABLEAU STYLE
        // ============================================================
        const barangayCtx = document.getElementById('barangayChart')?.getContext('2d');
        if(barangayCtx) {
            let barangayLabels = [], poorData = [], middleClassData = [], richData = [];
            <?php foreach($barangay_data as $row): ?>
                barangayLabels.push('<?php echo addslashes($row['barangay']); ?>');
                poorData.push(<?php echo intval($row['poor']); ?>);
                middleClassData.push(<?php echo intval($row['middle_class']); ?>);
                richData.push(<?php echo intval($row['rich']); ?>);
            <?php endforeach; ?>
            
            new Chart(barangayCtx, {
                type: 'bar',
                data: {
                    labels: barangayLabels.length > 0 ? barangayLabels : ['No Data'],
                    datasets: [
                        { label: 'Poor', data: poorData.length > 0 ? poorData : [0], backgroundColor: 'rgba(220, 38, 38, 0.85)', borderColor: '#DC2626', borderWidth: 2, borderRadius: 6, borderSkipped: false },
                        { label: 'Middle Class', data: middleClassData.length > 0 ? middleClassData : [0], backgroundColor: 'rgba(30, 74, 140, 0.85)', borderColor: '#1E4A8C', borderWidth: 2, borderRadius: 6, borderSkipped: false },
                        { label: 'Rich', data: richData.length > 0 ? richData : [0], backgroundColor: 'rgba(245, 176, 66, 0.85)', borderColor: '#F5B042', borderWidth: 2, borderRadius: 6, borderSkipped: false }
                    ]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    },
                    plugins: {
                        legend: { position: 'bottom', labels: { padding: 14, font: { size: 11, weight: '600' } } }
                    },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        }

        // ============================================================
        // HOUSEHOLD TREND CHART - TABLEAU STYLE
        // ============================================================
        const householdTrendCtx = document.getElementById('householdTrendChart')?.getContext('2d');
        if(householdTrendCtx) {
            let months = [], counts = [];
            <?php foreach(array_reverse($monthly_data) as $m): ?>
                months.push('<?php echo date('M Y', strtotime($m['month'].'-01')); ?>');
                counts.push(<?php echo intval($m['count']); ?>);
            <?php endforeach; ?>
            
            const gradient = householdTrendCtx.createLinearGradient(0, 0, 0, 280);
            gradient.addColorStop(0, 'rgba(30, 74, 140, 0.3)');
            gradient.addColorStop(1, 'rgba(30, 74, 140, 0.02)');
            
            new Chart(householdTrendCtx, {
                type: 'line',
                data: {
                    labels: months.length > 0 ? months : ['No Data'],
                    datasets: [{
                        label: 'Households Collected',
                        data: counts.length > 0 ? counts : [0],
                        borderColor: '#1E4A8C',
                        backgroundColor: gradient,
                        fill: true, tension: 0.4, borderWidth: 3,
                        pointBackgroundColor: '#FFFFFF',
                        pointBorderColor: '#1E4A8C',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 8
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    interaction: { intersect: false, mode: 'index' },
                    scales: {
                        y: { beginAtZero: true, grid: { color: '#F1F5F9', drawBorder: false }, ticks: { precision: 0, font: { size: 11 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    },
                    plugins: { legend: { display: false } },
                    animation: { duration: 1400, easing: 'easeOutQuart' }
                }
            });
        }

        // ============================================================
        // FORM VALIDATION - 3-Class Classification Preview
        // ============================================================
        document.getElementById('collectionForm')?.addEventListener('submit', function(e) {
            const income = parseFloat(document.getElementById('monthly_declared_income').value);
            const members = parseInt(document.getElementById('total_roster_count').value);
            if(income < 0 || members < 1) {
                e.preventDefault();
                alert('Please enter valid income and member count.');
                return;
            }
            const perCapita = income / members;
            
            let classification = 'MIDDLE_CLASS';
            let rangeText = '';
            if(perCapita >= 5000 && perCapita <= 10000) {
                classification = 'POOR';
                rangeText = '₱5,000 - ₱10,000';
            } else if(perCapita > 10000 && perCapita <= 25000) {
                classification = 'MIDDLE_CLASS';
                rangeText = '₱10,001 - ₱25,000';
            } else if(perCapita > 25000) {
                classification = 'RICH';
                rangeText = '₱25,001 and above';
            } else {
                classification = 'NOT CLASSIFIED';
                rangeText = 'Below ₱5,000 (unclassified)';
            }
            
            if(!confirm(`Submit household data?\n\nPer Capita Income: ₱${perCapita.toFixed(2)}\nRange: ${rangeText}\nClassification: ${classification}`)) {
                e.preventDefault();
            }
        });

        console.log('%c✅ Staff Dashboard loaded', 'color: #059669; font-weight: bold; font-size: 14px;');
        console.log('%c📷 QR Scanner: Live camera ready (Ctrl+K to open)', 'color: #6366F1; font-weight: 600;');
        console.log('%c📊 Charts: Tableau-style with animations', 'color: #8B5CF6; font-weight: 600;');
    </script>

   <?= renderPwaServiceWorker() ?>
</body>
</html>