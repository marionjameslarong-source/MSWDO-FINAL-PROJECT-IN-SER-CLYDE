<?php
// ============================================================================
// 1. SHARED VARIABLE DECLARATIONS (TOP LEVEL)
// ============================================================================
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];


// ============================================================================
// 2. SHARED HELPER FUNCTIONS
// ============================================================================

function getPovertyClass($income) {
    if($income >= 5000 && $income <= 10000) return 'POOR';
    elseif($income > 10000 && $income <= 25000) return 'MIDDLE-CLASS';
    elseif($income > 25000) return 'RICH';
    else return 'Not Classified';
}

function escapeHtml($text) {
    if(!$text) return '';
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

// ============================================================================
// 3. SHARED CONFIGURATIONS
// ============================================================================

$program_names = [
    'solo_parent' => 'Solo Parent',
    'senior_citizen' => 'Senior Citizen',
    'pwd' => 'PWD',
    'aics' => 'AICS',
    'vawc' => 'VAWC',
    'financial_assistance' => 'Financial Assistance',
    'id_application' => 'ID Application'
];

// ============================================================================
// 4. BUDGET MANAGEMENT - GET & SET
// ============================================================================

function getBudgetAllocation() {
    global $pdo;
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'budget_settings'");
        if($stmt->rowCount() > 0) {
            $stmt = $pdo->query("SELECT setting_value FROM budget_settings WHERE setting_key = 'initial_allocation' LIMIT 1");
            $result = $stmt->fetch();
            if($result) {
                return floatval($result['setting_value']);
            }
        } else {
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS budget_settings (
                    id INT(11) AUTO_INCREMENT PRIMARY KEY,
                    setting_key VARCHAR(100) NOT NULL UNIQUE,
                    setting_value DECIMAL(15,2) NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            $pdo->exec("INSERT INTO budget_settings (setting_key, setting_value) VALUES ('initial_allocation', 5000000.00) ON DUPLICATE KEY UPDATE setting_value = setting_value");
        }
    } catch(PDOException $e) {
        return 5000000.00;
    }
    return 5000000.00;
}

function updateBudgetAllocation($amount) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            INSERT INTO budget_settings (setting_key, setting_value) 
            VALUES ('initial_allocation', ?) 
            ON DUPLICATE KEY UPDATE setting_value = ?
        ");
        return $stmt->execute([$amount, $amount]);
    } catch(PDOException $e) {
        return false;
    }
}

$initial_allocation = getBudgetAllocation();

$budget_update_message = '';
$budget_update_status = '';

if(isset($_POST['update_budget']) && isset($_POST['budget_amount'])) {
    $new_amount = floatval(str_replace(',', '', $_POST['budget_amount']));
    if($new_amount > 0) {
        if(updateBudgetAllocation($new_amount)) {
            $budget_update_message = 'Budget updated successfully! New allocation: ₱ ' . number_format($new_amount, 2);
            $budget_update_status = 'success';
            $initial_allocation = $new_amount;
        } else {
            $budget_update_message = 'Failed to update budget. Please try again.';
            $budget_update_status = 'error';
        }
    } else {
        $budget_update_message = 'Please enter a valid budget amount.';
        $budget_update_status = 'error';
    }
}

// ============================================================================
// 5. BUDGET BURN-RATE METRICS
// ============================================================================

$burn_rate = [];
try {
    $stmt = $pdo->query("SELECT COALESCE(SUM(actual_amount_paid), 0) as total_disbursed FROM welfare_applications WHERE status = 'disbursed'");
    $total_disbursed = $stmt->fetch()['total_disbursed'] ?? 0;
    
    $current_remaining = max(0, $initial_allocation - $total_disbursed);
    
    $stmt = $pdo->query("
        SELECT COALESCE(SUM(actual_amount_paid), 0) as total, 
               DATEDIFF(NOW(), MIN(created_at)) as days 
        FROM welfare_applications 
        WHERE status = 'disbursed' 
        AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $last_30 = $stmt->fetch();
    $avg_daily = 0;
    
    if($last_30['days'] > 0 && $last_30['total'] > 0) {
        $avg_daily = $last_30['total'] / $last_30['days'];
    }
    
    $burn_rate = [
        'fund_name' => 'MUNICIPAL_CRISIS_BUDGET_2026',
        'initial_allocation' => $initial_allocation,
        'remaining_balance' => $current_remaining,
        'total_disbursed' => $total_disbursed,
        'avg_daily_disbursement' => $avg_daily,
        'days_until_depletion' => ($avg_daily > 0) ? floor($current_remaining / $avg_daily) : 0,
        'spent_percentage' => ($initial_allocation > 0) ? (($total_disbursed / $initial_allocation) * 100) : 0
    ];
} catch(PDOException $e) {
    $burn_rate = [
        'fund_name' => 'MUNICIPAL_CRISIS_BUDGET_2026',
        'initial_allocation' => $initial_allocation,
        'remaining_balance' => $initial_allocation,
        'total_disbursed' => 0,
        'avg_daily_disbursement' => 0,
        'days_until_depletion' => 0,
        'spent_percentage' => 0
    ];
}


// ============================================================================
// BLOCK 6: BARANGAY POVERTY TRACKING - 3 CLASSES (UPDATED RANGES)
// ============================================================================

$barangay_poverty = [];
try {
    $stmt = $pdo->query("
        SELECT 
            barangay,
            COUNT(*) as total_households,
            SUM(CASE WHEN poverty_status = 'POOR' OR (monthly_income >= 5000 AND monthly_income <= 10000) THEN 1 ELSE 0 END) as poor,
            SUM(CASE WHEN poverty_status = 'MIDDLE_CLASS' OR (monthly_income > 10000 AND monthly_income <= 25000) THEN 1 ELSE 0 END) as middle_class,
            SUM(CASE WHEN poverty_status = 'RICH' OR monthly_income > 25000 THEN 1 ELSE 0 END) as rich
        FROM households 
        WHERE barangay IS NOT NULL AND barangay != ''
        AND barangay LIKE '%Cantilan%'
        GROUP BY barangay
        ORDER BY poor DESC
        LIMIT 10
    ");
    $barangay_poverty = $stmt->fetchAll();
    
    if(empty($barangay_poverty)) {
        $stmt = $pdo->query("
            SELECT 
                barangay,
                COUNT(*) as total_households,
                SUM(CASE WHEN poverty_status = 'POOR' OR (monthly_income >= 5000 AND monthly_income <= 10000) THEN 1 ELSE 0 END) as poor,
                SUM(CASE WHEN poverty_status = 'MIDDLE_CLASS' OR (monthly_income > 10000 AND monthly_income <= 25000) THEN 1 ELSE 0 END) as middle_class,
                SUM(CASE WHEN poverty_status = 'RICH' OR monthly_income > 25000 THEN 1 ELSE 0 END) as rich
            FROM households 
            WHERE barangay IS NOT NULL AND barangay != ''
            GROUP BY barangay
            ORDER BY poor DESC
            LIMIT 10
        ");
        $barangay_poverty = $stmt->fetchAll();
    }
} catch(PDOException $e) {
    $barangay_poverty = [];
}


// ============================================================================
// BLOCK 7: STAFF PERFORMANCE AUDIT
// ============================================================================

$staff_performance = [];
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'verification_audit_logs'");
    if($stmt->rowCount() > 0) {
        $stmt = $pdo->query("
            SELECT 
                val.action_by_staff_id,
                u.full_name AS staff_name,
                COUNT(*) AS total_actions,
                COUNT(CASE WHEN val.new_status = 'VERIFIED_APPROVED' THEN 1 END) AS approvals,
                COUNT(CASE WHEN val.new_status IN ('REJECTED', 'REJECTED_NEEDS_CORRECTION') THEN 1 END) AS rejections
            FROM verification_audit_logs val
            LEFT JOIN users u ON val.action_by_staff_id = u.id
            WHERE val.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY val.action_by_staff_id, u.full_name
            ORDER BY total_actions DESC
            LIMIT 10
        ");
        $staff_performance = $stmt->fetchAll();
    }
} catch(PDOException $e) {
    $staff_performance = [];
}


// ============================================================================
// BLOCK 8: SYSTEM STATISTICS
// ============================================================================

$stats = [];
try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users");
    $stats['total_users'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'resident'");
    $stats['residents'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role != 'resident'");
    $stats['staff'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM households");
    $stats['households'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM households WHERE barangay LIKE '%Cantilan%'");
    $stats['cantilan_households'] = $stmt->fetch()['total'] ?? 0;
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications");
    $stats['applications'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications WHERE status = 'pending'");
    $stats['pending'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM welfare_applications WHERE status = 'approved'");
    $stats['approved'] = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
    $stats['deleted'] = $stmt->fetch()['total'];
} catch(PDOException $e) {
    $stats = [
        'total_users' => 0, 'residents' => 0, 'staff' => 0,
        'households' => 0, 'cantilan_households' => 0,
        'applications' => 0, 'pending' => 0,
        'approved' => 0, 'deleted' => 0
    ];
}

$deleted_count = $stats['deleted'] ?? 0;


// ============================================================================
// BLOCK 9: POVERTY STATISTICS - 3 CLASSES
// ============================================================================

$poverty_stats = [];
try {
    $stmt = $pdo->query("
        SELECT 
            SUM(CASE WHEN monthly_income >= 5000 AND monthly_income <= 10000 THEN 1 ELSE 0 END) as poor,
            SUM(CASE WHEN monthly_income > 10000 AND monthly_income <= 25000 THEN 1 ELSE 0 END) as middle_class,
            SUM(CASE WHEN monthly_income > 25000 THEN 1 ELSE 0 END) as rich,
            COUNT(*) as total
        FROM households WHERE monthly_income IS NOT NULL
    ");
    $poverty_stats = $stmt->fetch();
} catch(PDOException $e) {
    $poverty_stats = ['poor' => 0, 'middle_class' => 0, 'rich' => 0, 'total' => 0];
}


// ============================================================================
// BLOCK 10: MONTHLY TRENDS
// ============================================================================

$monthly_trend = [];
try {
    $stmt = $pdo->query("
        SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
        FROM welfare_applications 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY month 
        ORDER BY month ASC
    ");
    $monthly_trend = $stmt->fetchAll();
} catch(PDOException $e) {
    $monthly_trend = [];
}


// ============================================================================
// BLOCK 11: APPLICATIONS BY PROGRAM
// ============================================================================

$apps_by_program = [];
try {
    $stmt = $pdo->query("
        SELECT program_type, COUNT(*) as count 
        FROM welfare_applications 
        GROUP BY program_type
    ");
    $apps_by_program = $stmt->fetchAll();
} catch(PDOException $e) {
    $apps_by_program = [];
}


// ============================================================================
// BLOCK 12: RECENT ACTIVITY
// ============================================================================

$recent_users = [];
try {
    $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
    $recent_users = $stmt->fetchAll();
} catch(PDOException $e) {
    $recent_users = [];
}

$recent_households = [];
try {
    $stmt = $pdo->query("SELECT h.*, u.full_name as user_name FROM households h LEFT JOIN users u ON h.user_id = u.id ORDER BY h.created_at DESC LIMIT 5");
    $recent_households = $stmt->fetchAll();
} catch(PDOException $e) {
    $recent_households = [];
}


// ============================================================================
// BLOCK 13: POVERTY CLUSTER STATISTICS - 3 CLASSES
// ============================================================================

$poverty_clusters = [];
try {
    $stmt = $pdo->query("
        SELECT 
            barangay,
            COUNT(*) as total,
            SUM(CASE WHEN poverty_status = 'POOR' OR (monthly_income >= 5000 AND monthly_income <= 10000) THEN 1 ELSE 0 END) as poor,
            SUM(CASE WHEN poverty_status = 'MIDDLE_CLASS' OR (monthly_income > 10000 AND monthly_income <= 25000) THEN 1 ELSE 0 END) as middle_class,
            SUM(CASE WHEN poverty_status = 'RICH' OR monthly_income > 25000 THEN 1 ELSE 0 END) as rich,
            ROUND(AVG(monthly_income), 2) as avg_income
        FROM households 
        WHERE barangay IS NOT NULL AND barangay != ''
        AND barangay LIKE '%Cantilan%'
        GROUP BY barangay
        ORDER BY poor DESC
        LIMIT 20
    ");
    $poverty_clusters = $stmt->fetchAll();
    
    if(empty($poverty_clusters)) {
        $stmt = $pdo->query("
            SELECT 
                barangay,
                COUNT(*) as total,
                SUM(CASE WHEN poverty_status = 'POOR' OR (monthly_income >= 5000 AND monthly_income <= 10000) THEN 1 ELSE 0 END) as poor,
                SUM(CASE WHEN poverty_status = 'MIDDLE_CLASS' OR (monthly_income > 10000 AND monthly_income <= 25000) THEN 1 ELSE 0 END) as middle_class,
                SUM(CASE WHEN poverty_status = 'RICH' OR monthly_income > 25000 THEN 1 ELSE 0 END) as rich,
                ROUND(AVG(monthly_income), 2) as avg_income
            FROM households 
            WHERE barangay IS NOT NULL AND barangay != ''
            GROUP BY barangay
            ORDER BY poor DESC
            LIMIT 20
        ");
        $poverty_clusters = $stmt->fetchAll();
    }
} catch(PDOException $e) {
    $poverty_clusters = [];
}


// ============================================================================
// BLOCK 14: HTML VIEW - BEGIN
// ============================================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Admin Dashboard - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    
     <?= renderPwaMetaTags() ?>

    <style>
        /* ====================================================================
           BASE STYLES
           ==================================================================== */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
            background-image: 
                radial-gradient(at 0% 0%, rgba(30, 74, 140, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 0%, rgba(245, 176, 66, 0.05) 0px, transparent 50%);
            background-attachment: fixed;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #3B6BB5;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --accent-dark: #D99524;
            --success: #059669;
            --warning: #F59E0B;
            --danger: #DC2626;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 24px 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 800; color: var(--primary); letter-spacing: -0.02em; }
        .logo-text p { font-size: 0.62rem; color: var(--gray-500); font-weight: 500; }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-400);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s ease;
            margin-bottom: 2px;
        }
        .nav-item i { width: 20px; color: var(--gray-400); font-size: 0.95rem; transition: color 0.2s; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { 
            background: linear-gradient(135deg, var(--primary), var(--primary-dark)); 
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }

        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }

        /* Top Bar */
        .top-bar {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
            border-radius: var(--radius-md);
            transition: background 0.2s;
        }
        .menu-toggle:hover { background: var(--gray-100); }
        .page-title h1 { 
            font-size: 1.35rem; 
            font-weight: 800; 
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 600; color: var(--gray-700); }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; }

        /* Cantilan Badge */
        .cantilan-badge {
            display: inline-block;
            background: linear-gradient(135deg, #F5B042, #D99524);
            color: white;
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 700;
            box-shadow: 0 2px 8px rgba(245, 176, 66, 0.3);
        }

        /* ================================================================
           REDESIGNED BUDGET CARD — FIXED "BLACK" THEME
           ================================================================ */
        .burn-rate-card {
            background: linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%);
            padding: 24px;
            border-radius: var(--radius-xl);
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-md);
        }
        .burn-rate-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent), var(--secondary));
        }
        .burn-rate-card::after {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 350px; height: 350px;
            background: radial-gradient(circle, rgba(30, 74, 140, 0.04) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .burn-rate-card .card-subtitle {
            color: var(--gray-500);
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .burn-rate-card .card-subtitle i { color: var(--primary); }
        .burn-rate-card .main-metrics-value {
            color: var(--gray-800);
            font-size: 2.2rem;
            font-weight: 800;
            margin-top: 6px;
            letter-spacing: -0.03em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .burn-rate-card .progress-bar-background {
            height: 10px;
            background: var(--gray-100);
            border-radius: 6px;
            overflow: hidden;
            margin-top: 14px;
            margin-bottom: 10px;
            position: relative;
        }
        .burn-rate-card .progress-bar-fill {
            height: 100%;
            border-radius: 6px;
            transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        .burn-rate-card .progress-bar-fill::after {
            content: '';
            position: absolute; inset: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        .burn-rate-card .progress-bar-fill.danger { background: linear-gradient(90deg, #DC2626, #EF4444); }
        .burn-rate-card .progress-bar-fill.warning { background: linear-gradient(90deg, #D99524, #F5B042); }
        .burn-rate-card .progress-bar-fill.success { background: linear-gradient(90deg, #047857, #10B981); }
        .burn-rate-card .meta-flex-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
        }
        .burn-rate-card .bar-label { color: var(--gray-600); font-size: 0.8rem; font-weight: 600; }
        .burn-rate-card .alert-text { 
            font-size: 0.8rem; font-weight: 700;
            display: inline-flex; align-items: center; gap: 6px;
            padding: 4px 12px; border-radius: 20px;
        }
        .burn-rate-card .alert-text.danger { background: #FEE2E2; color: #991B1B; }
        .burn-rate-card .alert-text.warning { background: #FEF3C7; color: #B45309; }
        .burn-rate-card .alert-text.success { background: #D1FAE5; color: #065F46; }
        .burn-rate-card .burn-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px dashed var(--gray-200);
        }
        .burn-rate-card .burn-grid .burn-item {
            background: white;
            padding: 12px 14px;
            border-radius: var(--radius-md);
            border: 1px solid var(--gray-200);
            transition: all 0.2s;
        }
        .burn-rate-card .burn-grid .burn-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-sm);
            border-color: var(--primary);
        }
        .burn-rate-card .burn-grid .burn-item .burn-label {
            font-size: 0.6rem;
            color: var(--gray-500);
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.05em;
        }
        .burn-rate-card .burn-grid .burn-item .burn-value {
            font-size: 1rem;
            font-weight: 800;
            color: var(--gray-800);
            margin-top: 4px;
        }
        .burn-rate-card .burn-grid .burn-item .burn-value.danger { color: #DC2626; }
        .burn-rate-card .burn-grid .burn-item .burn-value.success { color: #059669; }
        .burn-rate-card .burn-grid .burn-item .burn-value.warning { color: #D99524; }

        /* Budget Edit Form */
        .budget-edit-form {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px dashed var(--gray-200);
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .budget-edit-form .form-group {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        .budget-edit-form label {
            color: var(--gray-600);
            font-size: 0.78rem;
            font-weight: 700;
        }
        .budget-edit-form label i { color: var(--primary); }
        .budget-edit-form input {
            padding: 9px 14px;
            border-radius: var(--radius-md);
            border: 1.5px solid var(--gray-200);
            background: white;
            color: var(--gray-800);
            font-size: 0.9rem;
            width: 200px;
            font-weight: 600;
            transition: all 0.2s;
        }
        .budget-edit-form input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
        }
        .budget-edit-form .btn-update {
            padding: 9px 22px;
            border-radius: var(--radius-md);
            border: none;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: #78350F;
            font-weight: 700;
            font-size: 0.82rem;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 4px 12px rgba(245, 176, 66, 0.3);
        }
        .budget-edit-form .btn-update:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(245, 176, 66, 0.4);
        }
        .budget-edit-form .btn-update:active {
            transform: translateY(0);
        }

        /* Alert Messages */
        .alert-message {
            padding: 12px 18px;
            border-radius: var(--radius-md);
            margin-bottom: 16px;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .alert-message.success {
            background: #D1FAE5;
            color: #065F46;
            border-left: 4px solid #059669;
        }
        .alert-message.error {
            background: #FEE2E2;
            color: #991B1B;
            border-left: 4px solid #DC2626;
        }

        /* ================================================================
           INTERACTIVE STATS CARDS
           ================================================================ */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: var(--white);
            padding: 18px;
            border-radius: var(--radius-xl);
            text-align: center;
            border: 1px solid var(--gray-200);
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            opacity: 0;
            transition: opacity 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
            border-color: transparent;
        }
        .stat-card:hover::before { opacity: 1; }
        .stat-card i { 
            font-size: 1.8rem; 
            margin-bottom: 8px;
            display: inline-block;
            transition: transform 0.3s;
        }
        .stat-card:hover i { transform: scale(1.15); }
        .stat-card .stat-number { 
            font-size: 1.6rem; 
            font-weight: 800; 
            color: var(--gray-800);
            letter-spacing: -0.03em;
        }
        .stat-card .stat-label { 
            font-size: 0.68rem; 
            color: var(--gray-500); 
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            margin-top: 4px;
        }
        .stat-card small { font-size: 0.65rem; color: var(--gray-400); display: block; margin-top: 4px; }

        /* ================================================================
           INTERACTIVE ACTION CARDS
           ================================================================ */
        .action-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .action-card {
            background: var(--white);
            padding: 22px 18px;
            border-radius: var(--radius-xl);
            text-align: center;
            text-decoration: none;
            border: 1px solid var(--gray-200);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        .action-card::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(30, 74, 140, 0.04), transparent);
            opacity: 0;
            transition: opacity 0.3s;
        }
        .action-card:hover { 
            transform: translateY(-4px); 
            box-shadow: var(--shadow-lg);
            border-color: var(--primary);
        }
        .action-card:hover::after { opacity: 1; }
        .action-card i { 
            font-size: 1.9rem; 
            margin-bottom: 10px;
            display: inline-block;
            transition: all 0.3s;
        }
        .action-card:hover i { transform: scale(1.15) rotate(-5deg); }
        .action-card strong { 
            display: block; 
            font-size: 0.82rem; 
            color: var(--gray-700); 
            font-weight: 700;
            position: relative;
            z-index: 1;
        }
        .action-card small { 
            font-size: 0.68rem; 
            color: var(--gray-500);
            position: relative;
            z-index: 1;
        }
        .badge-count {
            position: absolute;
            top: 10px;
            right: 12px;
            background: linear-gradient(135deg, var(--secondary), #B71C1C);
            color: white;
            border-radius: 20px;
            padding: 2px 9px;
            font-size: 0.65rem;
            font-weight: 800;
            box-shadow: 0 2px 8px rgba(211, 47, 47, 0.4);
            z-index: 2;
        }

        /* ================================================================
           MODERN POVERTY TRACKING
           ================================================================ */
        .poverty-tracking-card {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 20px 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
        }
        .poverty-tracking-card .data-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #F1F5F9;
            transition: background 0.2s;
            border-radius: 8px;
        }
        .poverty-tracking-card .data-row:hover {
            background: var(--gray-50);
            padding-left: 12px;
            padding-right: 12px;
            margin: 0 -12px;
        }
        .poverty-tracking-card .data-row:last-child { border-bottom: none; }
        .poverty-tracking-card .geo-label-block {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
        }
        .poverty-tracking-card .row-title-text {
            font-size: 0.85rem;
            font-weight: 700;
            color: #1E293B;
        }
        .poverty-tracking-card .count-badge-value {
            font-size: 0.72rem;
            font-weight: 700;
            color: var(--gray-700);
            background: var(--gray-100);
            padding: 5px 12px;
            border-radius: 8px;
            white-space: nowrap;
            border: 1px solid var(--gray-200);
        }
        .poverty-tracking-card .poverty-bar {
            height: 6px;
            background: #E2E8F0;
            border-radius: 3px;
            margin-top: 6px;
            overflow: hidden;
        }
        .poverty-tracking-card .poverty-bar .poverty-fill {
            height: 100%;
            border-radius: 3px;
            transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .poverty-tracking-card .poverty-bar .poverty-fill::after {
            content: '';
            position: absolute; inset: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            animation: shimmer 2.5s infinite;
        }

        /* ================================================================
           STAFF PERFORMANCE
           ================================================================ */
        .staff-performance-card {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            padding: 20px 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow-sm);
        }
        .staff-performance-card .staff-block {
            padding: 12px 0;
            border-bottom: 1px solid #F1F5F9;
            transition: all 0.2s;
        }
        .staff-performance-card .staff-block:hover {
            background: var(--gray-50);
            padding-left: 12px;
            padding-right: 12px;
            margin: 0 -12px;
            border-radius: 8px;
        }
        .staff-performance-card .staff-block:last-child { border-bottom: none; }
        .staff-performance-card .staff-block .staff-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
        }
        .staff-performance-card .staff-block .staff-name {
            font-size: 0.85rem;
            font-weight: 700;
            color: #334155;
        }
        .staff-performance-card .staff-block .staff-actions {
            font-size: 0.75rem;
            color: #64748B;
            font-weight: 500;
        }
        .staff-performance-card .staff-block .staff-actions strong { 
            color: #1E293B; 
            font-weight: 800;
            font-size: 0.85rem;
        }
        .staff-performance-card .staff-block .staff-bar-track {
            height: 6px;
            background: #E2E8F0;
            border-radius: 3px;
            overflow: hidden;
            margin-top: 8px;
        }
        .staff-performance-card .staff-block .staff-bar-fill {
            height: 100%;
            border-radius: 3px;
            transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* ================================================================
           TABLEAU-STYLE CHARTS
           ================================================================ */
        .charts-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        .chart-container {
            background: white;
            border-radius: var(--radius-xl);
            padding: 20px;
            border: 1px solid var(--gray-200);
            transition: all 0.3s;
            box-shadow: var(--shadow-sm);
            position: relative;
        }
        .chart-container:hover {
            box-shadow: var(--shadow-lg);
            border-color: var(--primary-light);
        }
        .chart-container h4 { 
            margin-bottom: 16px; 
            color: var(--gray-800); 
            font-size: 0.9rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--gray-100);
        }
        .chart-container h4 i { color: var(--primary); }
        .chart-container .chart-wrapper {
            position: relative;
            height: 280px;
        }

        /* ================================================================
           POVERTY SUMMARY - 3 CLASSES
           ================================================================ */
        .poverty-summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .poverty-item {
            background: white;
            padding: 20px;
            border-radius: var(--radius-xl);
            text-align: center;
            border: 1px solid var(--gray-200);
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        .poverty-item::before {
            content: '';
            position: absolute;
            top: 0; left: 0;
            width: 4px; height: 100%;
        }
        .poverty-item.poor::before { background: linear-gradient(180deg, #DC2626, #EF4444); }
        .poverty-item.middle::before { background: linear-gradient(180deg, #1E4A8C, #3B82F6); }
        .poverty-item.rich::before { background: linear-gradient(180deg, #D99524, #F5B042); }
        .poverty-item:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }
        .poverty-count { font-size: 1.8rem; font-weight: 800; letter-spacing: -0.03em; }
        .poverty-label { 
            font-size: 0.75rem; 
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-top: 4px;
        }
        .poverty-range { font-size: 0.65rem; color: var(--gray-500); margin-top: 2px; }

        /* ================================================================
           TABLES
           ================================================================ */
        .table-responsive {
            overflow-x: auto;
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
        }
        .table th {
            padding: 14px 16px;
            background: linear-gradient(180deg, #F8FAFC, #F1F5F9);
            font-weight: 700;
            border-bottom: 2px solid var(--accent);
            text-align: left;
            font-size: 0.7rem;
            color: var(--gray-600);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .table td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
        }
        .table tbody tr {
            transition: background 0.15s;
        }
        .table tbody tr:hover {
            background: var(--gray-50);
        }
        .table .empty-state {
            text-align: center;
            padding: 30px;
            color: var(--gray-500);
        }
        .status-badge, .poverty-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .poverty-poor { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
        .poverty-middle { background: #DBEAFE; color: #1E40AF; border: 1px solid #93C5FD; }
        .poverty-rich { background: #FEF3C7; color: #B45309; border: 1px solid #FCD34D; }

        /* Two Column Grid */
        .two-col-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 10px;
        }

        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.68rem;
            color: var(--gray-600);
            text-decoration: none;
            position: relative;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: #EFF6FF; }
        .nav-badge {
            position: absolute;
            top: -4px;
            right: -4px;
            background: var(--secondary);
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.6rem;
            font-weight: 700;
        }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        /* ================================================================
           SECTION TOGGLES - INTERACTIVE HEADERS
           ================================================================ */
        .section-toggle {
            cursor: pointer;
            user-select: none;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 14px 18px;
            background: white;
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-200);
            margin-bottom: 12px;
            transition: all 0.25s;
            box-shadow: var(--shadow-sm);
        }
        .section-toggle:hover {
            background: var(--gray-50);
            transform: translateX(4px);
            border-color: var(--primary-light);
            box-shadow: var(--shadow-md);
        }
        .section-toggle h2 {
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--gray-700);
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
        }
        .section-toggle .toggle-icon {
            transition: transform 0.3s ease;
            color: var(--gray-400);
            font-size: 0.85rem;
        }
        .section-toggle .toggle-icon.collapsed {
            transform: rotate(-90deg);
        }
        .section-content {
            transition: all 0.3s ease;
            overflow: hidden;
            margin-bottom: 16px;
        }
        .section-content.hidden {
            display: none;
        }
        .section-divider {
            margin: 8px 0 16px;
            border: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--gray-200), transparent);
        }
        .section-title {
            font-size: 0.95rem;
            font-weight: 700;
            margin: 20px 0 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-left: 4px solid var(--secondary);
            padding-left: 14px;
            color: var(--gray-800);
        }
        .section-title .section-badge {
            font-size: 0.6rem;
            font-weight: 700;
            padding: 3px 12px;
            border-radius: 20px;
            margin-left: 8px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .section-badge.primary { background: #DBEAFE; color: #1E40AF; }
        .section-badge.success { background: #D1FAE5; color: #065F46; }
        .section-badge.danger { background: #FEE2E2; color: #991B1B; }
        .section-badge.warning { background: #FEF3C7; color: #B45309; }

        .btn-toggle-all {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.72rem;
            font-weight: 700;
            cursor: pointer;
            color: white;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .btn-toggle-all:hover { 
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35);
        }

        /* Cantilan Info Banner */
        .cantilan-info {
            background: linear-gradient(135deg, #1E4A8C 0%, #0A2F6C 50%, #1E4A8C 100%);
            color: white;
            padding: 18px 24px;
            border-radius: var(--radius-xl);
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 12px 24px -8px rgba(30, 74, 140, 0.4);
        }
        .cantilan-info::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, rgba(245, 176, 66, 0.15) 0%, transparent 70%);
            border-radius: 50%;
        }
        .cantilan-info .info-title {
            font-size: 1.1rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
            z-index: 1;
        }
        .cantilan-info .info-title i { color: var(--accent); }
        .cantilan-info .info-stats {
            display: flex;
            gap: 12px;
            font-size: 0.78rem;
            position: relative;
            z-index: 1;
            flex-wrap: wrap;
        }
        .cantilan-info .info-stats span {
            background: rgba(255,255,255,0.12);
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: 600;
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255,255,255,0.15);
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .cantilan-info .info-stats span i { color: var(--accent); }

        /* ================================================================
           RESPONSIVE
           ================================================================ */
        @media (max-width: 992px) {
            .stats-grid { grid-template-columns: repeat(3, 1fr); }
            .action-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-row { grid-template-columns: 1fr; }
            .poverty-summary { grid-template-columns: repeat(2, 1fr); }
            .burn-rate-card .burn-grid { grid-template-columns: repeat(2, 1fr); }
            .cantilan-info .info-stats { flex-wrap: wrap; }
            .budget-edit-form { flex-direction: column; align-items: stretch; }
            .budget-edit-form input { width: 100%; }
        }
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .action-grid { grid-template-columns: 1fr; }
            .poverty-summary { grid-template-columns: 1fr; }
            .two-col-grid { grid-template-columns: 1fr; }
            .burn-rate-card .main-metrics-value { font-size: 1.7rem; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr; }
            .burn-rate-card .burn-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Administrator</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="admin_dashboard.php" class="nav-item active">
                    <i class="fas fa-chart-line"></i> <span>Dashboard</span>
                </a>
                <a href="../modules/manage_users.php" class="nav-item">
                    <i class="fas fa-users-cog"></i> <span>User Management</span>
                </a>
                <a href="../modules/admin_household.php" class="nav-item">
                    <i class="fas fa-home"></i> <span>All Households</span>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="../modules/admin_povertyanalysis.php" class="nav-item">
                    <i class="fas fa-chart-line"></i> <span>Poverty Analysis</span>
                </a>
                <a href="../modules/admin_reports.php" class="nav-item">
                    <i class="fas fa-chart-bar"></i> <span>Reports</span>
                </a>
                <a href="../admin/recycle_bin.php" class="nav-item">
                    <i class="fas fa-trash-restore"></i> <span>Recycle Bin</span>
                    <?php if($deleted_count > 0): ?>
                        <span style="margin-left: auto; background: var(--secondary); color: white; padding: 0px 8px; border-radius: 20px; font-size: 0.65rem; font-weight: 700;"><?php echo $deleted_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../modules/admin_profile.php" class="nav-item">
                    <i class="fas fa-user-cog"></i> <span>Profile</span>
                </a>
                <a href="../logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content">
        <div class="top-bar">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>Admin Dashboard <span class="cantilan-badge">📍 Cantilan</span></h1>
                    <p>Municipal Social Welfare and Development Office - Cantilan, Surigao del Sur</p>
                </div>
            </div>
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="btn-toggle-all" onclick="toggleAllSections()">
                    <i class="fas fa-chevron-down" id="toggleAllIcon"></i> Toggle All
                </button>
                <a href="../modules/admin_profile.php" class="user-menu">
                    <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                    <div class="user-details">
                        <span><?php echo htmlspecialchars($full_name); ?></span>
                        <small>Administrator</small>
                    </div>
                    <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
                </a>
            </div>
        </div>

        <!-- Cantilan Info Banner -->
        <div class="cantilan-info">
            <div class="info-title">
                <i class="fas fa-map-pin"></i> Cantilan, Surigao del Sur
            </div>
            <div class="info-stats">
                <span><i class="fas fa-home"></i> <?php echo $stats['cantilan_households'] ?? 0; ?> Households</span>
                <span><i class="fas fa-users"></i> <?php echo $stats['residents']; ?> Residents</span>
                <span><i class="fas fa-chart-line"></i> <?php echo $stats['households'] > 0 ? round(($stats['cantilan_households'] / max($stats['households'], 1)) * 100, 1) : 0; ?>% Coverage</span>
            </div>
        </div>

        <!-- ================================================================
        BUDGET BURN-RATE SECTION — REDESIGNED
        ================================================================ -->
        <div class="section-toggle" onclick="toggleSection('budgetSection')">
            <h2>
                <i class="fas fa-coins" style="color:var(--accent);"></i> Budget & Financial Overview
                <span class="section-badge danger">Critical</span>
            </h2>
            <i class="fas fa-chevron-down toggle-icon" id="budgetSectionIcon"></i>
        </div>
        <div class="section-content" id="budgetSection">
            <?php if(!empty($budget_update_message)): ?>
                <div class="alert-message <?php echo $budget_update_status; ?>">
                    <i class="fas <?php echo $budget_update_status == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                    <?php echo $budget_update_message; ?>
                </div>
            <?php endif; ?>

            <div class="burn-rate-card">
                <div class="card-subtitle">
                    <i class="fas fa-landmark"></i> <?php echo $burn_rate['fund_name']; ?>
                </div>
                <div class="main-metrics-value">₱ <?php echo number_format($burn_rate['remaining_balance'], 2); ?></div>
                <div style="font-size:0.82rem; color:var(--gray-500); font-weight:600;">
                    <i class="fas fa-wallet"></i> Remaining Balance
                </div>
                
                <div class="progress-bar-background">
                    <?php 
                        $spent = $burn_rate['spent_percentage'];
                        $bar_class = $spent > 80 ? 'danger' : ($spent > 50 ? 'warning' : 'success');
                    ?>
                    <div class="progress-bar-fill <?php echo $bar_class; ?>" style="width: <?php echo min($spent, 100); ?>%;"></div>
                </div>
                
                <div class="meta-flex-row">
                    <span class="bar-label"><i class="fas fa-percentage"></i> <?php echo number_format($spent, 1); ?>% Budget Consumed</span>
                    <span class="alert-text <?php echo $burn_rate['days_until_depletion'] < 30 ? 'danger' : ($burn_rate['days_until_depletion'] < 60 ? 'warning' : 'success'); ?>">
                        <i class="fas fa-hourglass-half"></i> Est. Depletion: <?php echo $burn_rate['days_until_depletion']; ?> Days
                    </span>
                </div>

                <div class="burn-grid">
                    <div class="burn-item">
                        <div class="burn-label"><i class="fas fa-piggy-bank"></i> Initial Allocation</div>
                        <div class="burn-value">₱ <?php echo number_format($burn_rate['initial_allocation'], 2); ?></div>
                    </div>
                    <div class="burn-item">
                        <div class="burn-label"><i class="fas fa-money-bill-transfer"></i> Total Disbursed</div>
                        <div class="burn-value">₱ <?php echo number_format($burn_rate['total_disbursed'], 2); ?></div>
                    </div>
                    <div class="burn-item">
                        <div class="burn-label"><i class="fas fa-chart-line"></i> Avg Daily Spend</div>
                        <div class="burn-value">₱ <?php echo number_format($burn_rate['avg_daily_disbursement'], 2); ?></div>
                    </div>
                    <div class="burn-item">
                        <div class="burn-label"><i class="fas fa-shield-alt"></i> Status</div>
                        <div class="burn-value <?php echo $burn_rate['remaining_balance'] > 1000000 ? 'success' : ($burn_rate['remaining_balance'] > 500000 ? 'warning' : 'danger'); ?>">
                            <?php echo $burn_rate['remaining_balance'] > 1000000 ? '✅ Healthy' : ($burn_rate['remaining_balance'] > 500000 ? '⚠️ Moderate' : '🔴 Critical'); ?>
                        </div>
                    </div>
                </div>

                <form method="POST" class="budget-edit-form" onsubmit="return confirm('Are you sure you want to update the budget allocation? This will affect all budget calculations.');">
                    <div class="form-group">
                        <label for="budget_amount"><i class="fas fa-pen"></i> Edit Budget:</label>
                        <input type="text" id="budget_amount" name="budget_amount" 
                               value="<?php echo number_format($initial_allocation, 2); ?>" 
                               placeholder="Enter budget amount">
                    </div>
                    <button type="submit" name="update_budget" class="btn-update">
                        <i class="fas fa-save"></i> Update Budget
                    </button>
                    <span style="color:var(--gray-500); font-size:0.7rem; margin-left:8px;">
                        <i class="fas fa-info-circle"></i> Enter amount without commas (e.g., 5000000)
                    </span>
                </form>
            </div>
        </div>

        <hr class="section-divider">

        <!-- ================================================================
        SYSTEM STATISTICS - INTERACTIVE KPI CARDS
        ================================================================ -->
        <div class="section-toggle" onclick="toggleSection('statsSection')">
            <h2>
                <i class="fas fa-chart-simple" style="color:var(--primary);"></i> System Overview
                <span class="section-badge primary">Live</span>
            </h2>
            <i class="fas fa-chevron-down toggle-icon" id="statsSectionIcon"></i>
        </div>
        <div class="section-content" id="statsSection">
            <div class="stats-grid">
                <div class="stat-card" onclick="scrollToSection('recentSection')" title="Click to view recent registrations">
                    <i class="fas fa-users" style="color: var(--primary);"></i>
                    <div class="stat-number"><?php echo $stats['total_users']; ?></div>
                    <div class="stat-label">Total Users</div>
                    <small><?php echo $stats['residents']; ?> residents · <?php echo $stats['staff']; ?> staff</small>
                </div>
                <div class="stat-card" onclick="scrollToSection('recentSection')" title="Click to view recent households">
                    <i class="fas fa-home" style="color: #2E7D32;"></i>
                    <div class="stat-number"><?php echo $stats['households']; ?></div>
                    <div class="stat-label">Households</div>
                    <small>Cantilan coverage</small>
                </div>
                <div class="stat-card" onclick="filterCharts('pending')" title="View pending applications">
                    <i class="fas fa-clock" style="color: #F5B042;"></i>
                    <div class="stat-number"><?php echo $stats['pending']; ?></div>
                    <div class="stat-label">Pending</div>
                    <small>Awaiting action</small>
                </div>
                <div class="stat-card" onclick="filterCharts('approved')" title="View approved applications">
                    <i class="fas fa-check-circle" style="color: #2E7D32;"></i>
                    <div class="stat-number"><?php echo $stats['approved']; ?></div>
                    <div class="stat-label">Approved</div>
                    <small>Successfully processed</small>
                </div>
                <div class="stat-card" onclick="scrollToSection('povertySection')" title="View poverty analysis">
                    <i class="fas fa-chart-line" style="color: #9C27B0;"></i>
                    <div class="stat-number"><?php echo $stats['households'] > 0 ? round(($stats['households'] / max($stats['residents'], 1)) * 100, 1) : 0; ?>%</div>
                    <div class="stat-label">Coverage</div>
                    <small>Household ratio</small>
                </div>
                <div class="stat-card" onclick="scrollToSection('chartsSection')" title="View all applications">
                    <i class="fas fa-file-alt" style="color: var(--accent);"></i>
                    <div class="stat-number"><?php echo $stats['applications']; ?></div>
                    <div class="stat-label">Applications</div>
                    <small>All programs</small>
                </div>
            </div>
        </div>

        <hr class="section-divider">

        <!-- ================================================================
        ADMIN ACTIONS - INTERACTIVE
        ================================================================ -->
        <div class="section-toggle" onclick="toggleSection('actionsSection')">
            <h2>
                <i class="fas fa-cogs" style="color:var(--secondary);"></i> Quick Actions
                <span class="section-badge warning">Tools</span>
            </h2>
            <i class="fas fa-chevron-down toggle-icon" id="actionsSectionIcon"></i>
        </div>
        <div class="section-content" id="actionsSection">
            <div class="action-grid">
                <a href="../modules/manage_users.php" class="action-card">
                    <i class="fas fa-users-cog" style="color: var(--primary);"></i>
                    <strong>Manage Users</strong>
                    <small>Add, edit, delete</small>
                </a>
                <a href="../modules/admin_household.php" class="action-card">
                    <i class="fas fa-home" style="color: #2E7D32;"></i>
                    <strong>Household Profiles</strong>
                    <small>View all records</small>
                </a>
                <a href="../modules/admin_reports.php" class="action-card">
                    <i class="fas fa-chart-bar" style="color: var(--accent);"></i>
                    <strong>Statistics</strong>
                    <small>Analytics</small>
                </a>
                <a href="../modules/admin_povertyanalysis.php" class="action-card">
                    <i class="fas fa-chart-line" style="color: #9C27B0;"></i>
                    <strong>Poverty Report</strong>
                    <small>Classification analysis</small>
                </a>
                <a href="../admin/recycle_bin.php" class="action-card">
                    <i class="fas fa-trash-restore" style="color: #FF9800;"></i>
                    <strong>Recycle Bin</strong>
                    <small>Restore records</small>
                    <?php if($deleted_count > 0): ?><span class="badge-count"><?php echo $deleted_count; ?></span><?php endif; ?>
                </a>
            </div>
        </div>

        <hr class="section-divider">

        <!-- ================================================================
        BARANGAY POVERTY SECTION - INTERACTIVE
        ================================================================ -->
        <div class="section-toggle" onclick="toggleSection('povertySection')">
            <h2>
                <i class="fas fa-map-marker-alt" style="color:var(--secondary);"></i> Cantilan Barangay Poverty Tracking
                <span class="section-badge danger">Priority</span>
            </h2>
            <i class="fas fa-chevron-down toggle-icon" id="povertySectionIcon"></i>
        </div>
        <div class="section-content" id="povertySection">
            <div class="poverty-tracking-card">
                <?php if(count($barangay_poverty) > 0): ?>
                    <?php 
                    $max_poor = max(array_column($barangay_poverty, 'poor')) ?: 1;
                    foreach($barangay_poverty as $bp): 
                        $poor_total = $bp['poor'] ?? 0;
                        $percentage = min(($poor_total / $max_poor) * 100, 100);
                        $bar_color = $percentage > 70 ? '#DC2626' : ($percentage > 40 ? '#1E4A8C' : '#F5B042');
                    ?>
                    <div class="data-row">
                        <div class="geo-label-block">
                            <span style="font-size:1rem;">📍</span>
                            <span class="row-title-text"><?php echo escapeHtml($bp['barangay']); ?></span>
                            <span style="font-size:0.62rem; color:var(--gray-500); background:var(--gray-100); padding:3px 10px; border-radius:10px; font-weight:600;">
                                Total: <?php echo $bp['total_households']; ?>
                            </span>
                        </div>
                        <span class="count-badge-value">
                            <span style="color:#DC2626;"><?php echo $poor_total; ?> Poor</span> · 
                            <span style="color:#1E4A8C;"><?php echo $bp['middle_class'] ?? 0; ?> Middle</span> · 
                            <span style="color:#B45309;"><?php echo $bp['rich'] ?? 0; ?> Rich</span>
                        </span>
                    </div>
                    <div class="poverty-bar">
                        <div class="poverty-fill" style="width: <?php echo $percentage; ?>%; background: linear-gradient(90deg, <?php echo $bar_color; ?>, <?php echo $bar_color; ?>CC);"></div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div style="text-align:center; padding:30px; color:var(--gray-400);">
                        <i class="fas fa-info-circle" style="font-size:1.5rem; margin-bottom:8px; display:block;"></i> 
                        No barangay poverty data available for Cantilan
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <hr class="section-divider">

        <!-- ================================================================
        STAFF PERFORMANCE
        ================================================================ -->
        <div class="section-toggle" onclick="toggleSection('staffSection')">
            <h2>
                <i class="fas fa-users" style="color:var(--success);"></i> Staff Performance Audit
                <span class="section-badge success">30 Days</span>
            </h2>
            <i class="fas fa-chevron-down toggle-icon" id="staffSectionIcon"></i>
        </div>
        <div class="section-content" id="staffSection">
            <div class="staff-performance-card">
                <?php if(count($staff_performance) > 0): ?>
                    <?php 
                    $max_actions = max(array_column($staff_performance, 'total_actions')) ?: 1;
                    $bar_colors = ['#3B82F6', '#059669', '#7C3AED', '#F5B042', '#EF4444', '#8B5CF6'];
                    $idx = 0;
                    foreach($staff_performance as $sp): 
                        $percentage = min(($sp['total_actions'] / $max_actions) * 100, 100);
                        $color = $bar_colors[$idx % count($bar_colors)];
                        $idx++;
                    ?>
                    <div class="staff-block">
                        <div class="staff-meta">
                            <span class="staff-name">👤 <?php echo escapeHtml($sp['staff_name'] ?? 'Unknown Staff'); ?></span>
                            <span class="staff-actions">
                                <strong><?php echo $sp['total_actions']; ?></strong> Actions
                                <?php if(($sp['approvals'] ?? 0) > 0): ?>
                                    <span style="color:#059669; margin-left:8px; font-weight:700;">✅ <?php echo $sp['approvals']; ?></span>
                                <?php endif; ?>
                                <?php if(($sp['rejections'] ?? 0) > 0): ?>
                                    <span style="color:#DC2626; margin-left:6px; font-weight:700;">❌ <?php echo $sp['rejections']; ?></span>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="staff-bar-track">
                            <div class="staff-bar-fill" style="width: <?php echo $percentage; ?>%; background: linear-gradient(90deg, <?php echo $color; ?>, <?php echo $color; ?>CC);"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div style="text-align:center; padding:30px; color:var(--gray-400);">
                        <i class="fas fa-info-circle" style="font-size:1.5rem; margin-bottom:8px; display:block;"></i> 
                        No staff performance data available
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <hr class="section-divider">

        <!-- ================================================================
        ANALYTICS CHARTS - TABLEAU STYLE
        ================================================================ -->
        <div class="section-toggle" onclick="toggleSection('chartsSection')">
            <h2>
                <i class="fas fa-chart-line" style="color:var(--accent);"></i> Analytics Dashboard
                <span class="section-badge primary">Visual</span>
            </h2>
            <i class="fas fa-chevron-down toggle-icon" id="chartsSectionIcon"></i>
        </div>
        <div class="section-content" id="chartsSection">
            <div class="charts-row">
                <div class="chart-container">
                    <h4><i class="fas fa-chart-pie"></i> Applications by Program</h4>
                    <div class="chart-wrapper">
                        <canvas id="programChart"></canvas>
                    </div>
                </div>
                <div class="chart-container">
                    <h4><i class="fas fa-chart-line"></i> Monthly Application Trend</h4>
                    <div class="chart-wrapper">
                        <canvas id="trendChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="chart-container" style="margin-bottom:24px">
                <h4><i class="fas fa-chart-bar"></i> Poverty Distribution (3-Class Classification)</h4>
                <div class="chart-wrapper" style="height:320px;">
                    <canvas id="povertyChart"></canvas>
                </div>
            </div>

            <!-- Poverty Clusters -->
            <div class="section-title" style="margin-top:0; border-left-color: var(--accent);">
                <i class="fas fa-table" style="color: var(--accent);"></i> Cantilan Poverty Density Clusters
            </div>
            <div class="table-responsive" style="margin-bottom:24px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Barangay</th>
                            <th>Poor</th>
                            <th>Middle-Class</th>
                            <th>Rich</th>
                            <th>Total</th>
                            <th>Poverty Rate</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($poverty_clusters as $cluster): 
                            $total = $cluster['total'] ?? 1;
                            $poor_total = $cluster['poor'] ?? 0;
                            $poverty_rate = ($total > 0) ? round(($poor_total / $total) * 100, 1) : 0;
                            $rate_color = $poverty_rate > 60 ? '#DC2626' : ($poverty_rate > 30 ? '#1E4A8C' : '#B45309');
                        ?>
                        <tr>
                            <td><strong><?php echo escapeHtml($cluster['barangay']); ?></strong></td>
                            <td><span class="poverty-badge poverty-poor"><?php echo $cluster['poor'] ?? 0; ?></span></td>
                            <td><span class="poverty-badge poverty-middle"><?php echo $cluster['middle_class'] ?? 0; ?></span></td>
                            <td><span class="poverty-badge poverty-rich"><?php echo $cluster['rich'] ?? 0; ?></span></td>
                            <td><strong><?php echo $total; ?></strong></td>
                            <td>
                                <span style="font-weight:800; color:<?php echo $rate_color; ?>; font-size:0.85rem;">
                                    <?php echo $poverty_rate; ?>%
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($poverty_clusters)): ?>
                        <tr><td colspan="6" class="empty-state">No poverty cluster data available for Cantilan</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Poverty Summary - 3 CLASSES -->
            <div class="section-title" style="margin-top:0; border-left-color: var(--accent);">
                <i class="fas fa-chart-line" style="color: var(--accent);"></i> Poverty Analysis (3-Class)
            </div>
            <div class="poverty-summary">
                <div class="poverty-item poor">
                    <div class="poverty-count" style="color:#DC2626;"><?php echo $poverty_stats['poor'] ?? 0; ?></div>
                    <div class="poverty-label" style="color:#DC2626;">POOR</div>
                    <div class="poverty-range">₱5k – ₱10k</div>
                </div>
                <div class="poverty-item middle">
                    <div class="poverty-count" style="color:#1E4A8C;"><?php echo $poverty_stats['middle_class'] ?? 0; ?></div>
                    <div class="poverty-label" style="color:#1E4A8C;">MIDDLE-CLASS</div>
                    <div class="poverty-range">₱10k – ₱25k</div>
                </div>
                <div class="poverty-item rich">
                    <div class="poverty-count" style="color:#B45309;"><?php echo $poverty_stats['rich'] ?? 0; ?></div>
                    <div class="poverty-label" style="color:#B45309;">RICH</div>
                    <div class="poverty-range">₱25k and above</div>
                </div>
            </div>
        </div>

        <hr class="section-divider">

        <!-- ================================================================
        RECENT ACTIVITY
        ================================================================ -->
        <div class="section-toggle" onclick="toggleSection('recentSection')">
            <h2>
                <i class="fas fa-clock" style="color:var(--gray-500);"></i> Recent Activity
                <span class="section-badge">Live</span>
            </h2>
            <i class="fas fa-chevron-down toggle-icon" id="recentSectionIcon"></i>
        </div>
        <div class="section-content" id="recentSection">
            <div class="two-col-grid">
                <div>
                    <h4 style="margin-bottom:12px; font-size:0.88rem; color:var(--gray-800);">
                        <i class="fas fa-user-plus" style="color:var(--primary);"></i> Recent Registrations
                    </h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead><tr><th>Username</th><th>Full Name</th><th>Role</th><th>Registered</th></tr></thead>
                            <tbody>
                                <?php if(count($recent_users)>0): foreach($recent_users as $user): ?>
                                <tr>
                                    <td><strong><?php echo escapeHtml($user['username']); ?></strong></td>
                                    <td><?php echo escapeHtml($user['full_name']); ?></td>
                                    <td><span class="status-badge" style="background:#DBEAFE;color:#1E40AF;"><?php echo ucfirst($user['role']); ?></span></td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                </tr>
                                <?php endforeach; else: ?><tr><td colspan="4" class="empty-state">No recent registrations</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div>
                    <h4 style="margin-bottom:12px; font-size:0.88rem; color:var(--gray-800);">
                        <i class="fas fa-home" style="color:#2E7D32;"></i> Recent Households
                    </h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead><tr><th>Household Head</th><th>Barangay</th><th>Income</th><th>Class</th></tr></thead>
                            <tbody>
                                <?php if(count($recent_households)>0): foreach($recent_households as $hh): 
                                    $poverty = getPovertyClass($hh['monthly_income'] ?? 0); 
                                    $povClass = match($poverty){
                                        'POOR'=>'poverty-poor',
                                        'MIDDLE-CLASS'=>'poverty-middle',
                                        'RICH'=>'poverty-rich',
                                        default=>'poverty-middle'
                                    }; 
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo escapeHtml($hh['head_first_name'].' '.$hh['head_last_name']); ?></strong>
                                        <br><small style="color:var(--gray-400);"><?php echo escapeHtml($hh['user_name']??'N/A'); ?></small>
                                    </td>
                                    <td><?php echo escapeHtml($hh['barangay']??'N/A'); ?></td>
                                    <td>₱ <?php echo number_format($hh['monthly_income']??0,2); ?></td>
                                    <td><span class="poverty-badge <?php echo $povClass; ?>"><?php echo $poverty; ?></span></td>
                                </tr>
                                <?php endforeach; else: ?><tr><td colspan="4" class="empty-state">No recent households</td></tr><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- BOTTOM NAVIGATION -->
    <div class="bottom-nav">
        <a href="admin_dashboard.php" class="nav-item active"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="../modules/manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="../modules/admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="../modules/admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="../modules/admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Poverty</span></a>
        <a href="../modules/admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <!-- SCRIPTS -->
    <script>
        // ====================================================================
        // SECTION TOGGLE FUNCTIONS
        // ====================================================================
        function toggleSection(sectionId) {
            const content = document.getElementById(sectionId);
            const icon = document.getElementById(sectionId + 'Icon');
            
            if (content) {
                content.classList.toggle('hidden');
                if (icon) {
                    icon.classList.toggle('collapsed');
                }
            }
        }

        function toggleAllSections() {
            const sections = document.querySelectorAll('.section-content');
            const icons = document.querySelectorAll('.toggle-icon');
            const allHidden = Array.from(sections).every(s => s.classList.contains('hidden'));
            
            sections.forEach(s => {
                if (allHidden) {
                    s.classList.remove('hidden');
                } else {
                    s.classList.add('hidden');
                }
            });
            
            icons.forEach(i => {
                if (allHidden) {
                    i.classList.remove('collapsed');
                } else {
                    i.classList.add('collapsed');
                }
            });
            
            const toggleBtn = document.querySelector('.btn-toggle-all');
            if (toggleBtn) {
                toggleBtn.innerHTML = allHidden ? 
                    '<i class="fas fa-chevron-up"></i> Collapse All' : 
                    '<i class="fas fa-chevron-down"></i> Expand All';
            }
        }

        // ====================================================================
        // INTERACTIVE SCROLL NAVIGATION
        // ====================================================================
        function scrollToSection(sectionId) {
            const section = document.getElementById(sectionId);
            if (section && section.classList.contains('hidden')) {
                section.classList.remove('hidden');
                const icon = document.getElementById(sectionId + 'Icon');
                if (icon) icon.classList.remove('collapsed');
            }
            setTimeout(() => {
                section.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 100);
        }

        function filterCharts(filterType) {
            if (filterType === 'pending' || filterType === 'approved') {
                scrollToSection('chartsSection');
                const chartsSection = document.getElementById('chartsSection');
                chartsSection.style.transition = 'all 0.5s';
                chartsSection.style.boxShadow = '0 0 0 3px rgba(30, 74, 140, 0.2)';
                setTimeout(() => {
                    chartsSection.style.boxShadow = 'none';
                }, 1500);
            }
        }

        // ====================================================================
        // SIDEBAR TOGGLE
        // ====================================================================
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };

        // ====================================================================
        // AUTO-FORMAT BUDGET INPUT
        // ====================================================================
        document.addEventListener('DOMContentLoaded', function() {
            const budgetInput = document.getElementById('budget_amount');
            if (budgetInput) {
                budgetInput.addEventListener('focus', function() {
                    this.value = this.value.replace(/,/g, '');
                });
                budgetInput.addEventListener('blur', function() {
                    const val = this.value.replace(/,/g, '');
                    if (!isNaN(val) && val !== '') {
                        this.value = parseFloat(val).toLocaleString('en-US', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                    }
                });
            }
        });

        // ====================================================================
        // TABLEAU-STYLE CHART CONFIGURATION
        // ====================================================================
        Chart.defaults.font.family = "'Inter', sans-serif";
        Chart.defaults.font.size = 11;
        Chart.defaults.color = '#475569';
        Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(15, 23, 42, 0.95)';
        Chart.defaults.plugins.tooltip.padding = 12;
        Chart.defaults.plugins.tooltip.cornerRadius = 8;
        Chart.defaults.plugins.tooltip.titleFont = { size: 12, weight: '700' };
        Chart.defaults.plugins.tooltip.bodyFont = { size: 11 };
        Chart.defaults.plugins.legend.labels.boxWidth = 12;
        Chart.defaults.plugins.legend.labels.padding = 14;
        Chart.defaults.plugins.legend.labels.font = { size: 11, weight: '600' };

        // Program Chart - Modern Doughnut
        const progCtx = document.getElementById('programChart')?.getContext('2d');
        if(progCtx) {
            let labels=[], data=[];
            <?php foreach($apps_by_program as $app): ?>
                labels.push('<?php echo $program_names[$app['program_type']] ?? ucfirst(str_replace('_',' ',$app['program_type'])); ?>');
                data.push(<?php echo $app['count']; ?>);
            <?php endforeach; ?>
            
            if (labels.length === 0) {
                labels = ['No Data'];
                data = [1];
            }
            
            new Chart(progCtx, { 
                type: 'doughnut', 
                data: { 
                    labels: labels, 
                    datasets: [{ 
                        data: data, 
                        backgroundColor: [
                            '#F5B042', '#10B981', '#1E4A8C', '#DC2626', 
                            '#8B5CF6', '#F97316', '#06B6D4', '#EC4899'
                        ], 
                        borderWidth: 3,
                        borderColor: '#FFFFFF',
                        hoverOffset: 12
                    }] 
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '62%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { padding: 12, font: { size: 10 } }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const pct = ((context.parsed / total) * 100).toFixed(1);
                                    return ` ${context.label}: ${context.parsed} (${pct}%)`;
                                }
                            }
                        }
                    },
                    animation: {
                        animateRotate: true,
                        animateScale: true,
                        duration: 1200,
                        easing: 'easeOutQuart'
                    }
                }
            });
        }

        // Trend Chart - Modern Line
        const trendCtx = document.getElementById('trendChart')?.getContext('2d');
        if(trendCtx) {
            let months=[], counts=[];
            <?php foreach($monthly_trend as $m): ?>
                months.push('<?php echo date('M Y', strtotime($m['month'].'-01')); ?>');
                counts.push(<?php echo $m['count']; ?>);
            <?php endforeach; ?>
            
            if (months.length === 0) {
                months = ['No Data'];
                counts = [0];
            }
            
            const gradient = trendCtx.createLinearGradient(0, 0, 0, 280);
            gradient.addColorStop(0, 'rgba(30, 74, 140, 0.3)');
            gradient.addColorStop(1, 'rgba(30, 74, 140, 0.02)');
            
            new Chart(trendCtx, { 
                type: 'line', 
                data: { 
                    labels: months, 
                    datasets: [{ 
                        label: 'Applications', 
                        data: counts, 
                        borderColor: '#1E4A8C', 
                        backgroundColor: gradient, 
                        tension: 0.4, 
                        fill: true,
                        borderWidth: 3,
                        pointBackgroundColor: '#FFFFFF',
                        pointBorderColor: '#1E4A8C',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 8,
                        pointHoverBackgroundColor: '#1E4A8C',
                        pointHoverBorderColor: '#FFFFFF',
                        pointHoverBorderWidth: 3
                    }] 
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    scales: {
                        y: { 
                            beginAtZero: true, 
                            grid: { color: '#F1F5F9', drawBorder: false },
                            ticks: { precision: 0, font: { size: 10 } }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { size: 10 } }
                        }
                    },
                    plugins: {
                        legend: { display: false }
                    },
                    animation: {
                        duration: 1400,
                        easing: 'easeOutQuart'
                    }
                }
            });
        }

        // Poverty Chart - Modern Grouped Bar
        const povCtx = document.getElementById('povertyChart')?.getContext('2d');
        if(povCtx) {
            const poorVal = <?php echo $poverty_stats['poor'] ?? 0; ?>;
            const middleVal = <?php echo $poverty_stats['middle_class'] ?? 0; ?>;
            const richVal = <?php echo $poverty_stats['rich'] ?? 0; ?>;
            
            new Chart(povCtx, { 
                type: 'bar', 
                data: { 
                    labels: ['Poor (₱5k–₱10k)', 'Middle-Class (₱10k–₱25k)', 'Rich (₱25k+)'], 
                    datasets: [{ 
                        label: 'Households', 
                        data: [poorVal, middleVal, richVal], 
                        backgroundColor: [
                            'rgba(220, 38, 38, 0.85)',
                            'rgba(30, 74, 140, 0.85)',
                            'rgba(245, 176, 66, 0.85)'
                        ],
                        borderColor: ['#DC2626', '#1E4A8C', '#F5B042'],
                        borderWidth: 2,
                        borderRadius: 8,
                        borderSkipped: false,
                        barPercentage: 0.65,
                        hoverBackgroundColor: ['#DC2626', '#1E4A8C', '#F5B042']
                    }] 
                }, 
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false,
                    scales: { 
                        y: { 
                            beginAtZero: true, 
                            grid: { color: '#F1F5F9', drawBorder: false },
                            ticks: { precision: 0, font: { size: 11 } }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { size: 11, weight: '600' } }
                        }
                    },
                    plugins: { 
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const total = [poorVal, middleVal, richVal].reduce((a, b) => a + b, 0);
                                    const pct = total > 0 ? ((context.parsed.y / total) * 100).toFixed(1) : 0;
                                    return ` Households: ${context.parsed.y} (${pct}%)`;
                                }
                            }
                        }
                    },
                    animation: {
                        duration: 1400,
                        easing: 'easeOutQuart'
                    }
                } 
            });
        }

        // ====================================================================
        // KEYBOARD SHORTCUTS
        // ====================================================================
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
                e.preventDefault();
                toggleSection('budgetSection');
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                toggleAllSections();
            }
        });

        console.log('%c✅ Admin Dashboard loaded', 'color: #059669; font-weight: bold; font-size: 14px;');
        console.log('%c📍 Focus: Cantilan, Surigao del Sur', 'color: #1E4A8C; font-weight: 600;');
        console.log('%c💰 Budget: ₱<?php echo number_format($initial_allocation, 2); ?>', 'color: #F5B042; font-weight: 600;');
        console.log('%c📊 Charts: Tableau-style with animations', 'color: #8B5CF6; font-weight: 600;');
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>