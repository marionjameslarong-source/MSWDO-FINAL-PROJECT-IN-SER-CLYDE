// pwa/sync-ui.js
// Floating badge showing online/offline + queued count.

(function () {
  let badge = null;
  let toastEl = null;
  let toastTimer = null;

  function createBadge() {
    if (badge) return badge;
    badge = document.createElement('div');
    badge.id = 'mswdo-sync-badge';
    badge.style.cssText = `
      position: fixed; top: 12px; right: 12px; z-index: 99999;
      font: 600 13px system-ui, sans-serif;
      padding: 8px 14px; border-radius: 999px;
      color: #fff; background: #2563eb;
      box-shadow: 0 4px 12px rgba(0,0,0,0.18);
      cursor: pointer; user-select: none;
    `;
    badge.title = 'Click to sync now';
    badge.addEventListener('click', () => window.MSWDOSync.processQueue());
    document.body.appendChild(badge);
    return badge;
  }

  function createToast() {
    if (toastEl) return toastEl;
    toastEl = document.createElement('div');
    toastEl.style.cssText = `
      position: fixed; bottom: 20px; left: 50%;
      transform: translateX(-50%) translateY(120%);
      background: #111827; color: #fff; padding: 12px 20px;
      border-radius: 8px; font: 500 14px system-ui, sans-serif;
      z-index: 100000; opacity: 0; transition: all .3s ease;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      max-width: 90vw; text-align: center;
    `;
    document.body.appendChild(toastEl);
    return toastEl;
  }

  function toast(msg, ms = 2800) {
    const el = createToast();
    el.textContent = msg;
    el.style.transform = 'translateX(-50%) translateY(0)';
    el.style.opacity = '1';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      el.style.transform = 'translateX(-50%) translateY(120%)';
      el.style.opacity = '0';
    }, ms);
  }

  async function refresh() {
    const b = createBadge();
    const pending = await window.OfflineDB.countPending();

    if (!navigator.onLine) {
      b.style.background = '#dc2626';
      b.textContent = `🔴 Offline — ${pending} queued`;
    } else if (pending > 0) {
      b.style.background = '#f59e0b';
      b.textContent = `🟡 Syncing… ${pending}`;
    } else {
      b.style.background = '#16a34a';
      b.textContent = `✅ All synced`;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    refresh();

    window.MSWDOSync.onEvent((e) => {
      switch (e.type) {
        case 'queued':          toast('Saved offline. Will sync when online.'); break;
        case 'submitted-online': toast('Saved.'); break;
        case 'sync-complete':
          if (e.success > 0) toast(`Synced ${e.success} item(s).`);
          if (e.failed > 0)  toast(`${e.failed} failed — will retry.`, 4000);
          break;
        case 'online':  toast('Back online — syncing…'); break;
        case 'offline': toast('You are offline. Submissions will be queued.'); break;
      }
      refresh();
    });

    setInterval(refresh, 5000);
  });
})();