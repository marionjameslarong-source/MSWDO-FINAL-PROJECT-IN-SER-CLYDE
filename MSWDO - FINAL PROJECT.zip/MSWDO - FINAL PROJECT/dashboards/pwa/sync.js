// pwa/sync.js
// Reads the offline queue and POSTs each item to the API.

(function () {
  const API_URL = '/mswdo/api/save_household.php';
  const MAX_ATTEMPTS = 5;
  let syncing = false;
  let listeners = [];

  function emit(event) {
    listeners.forEach((fn) => { try { fn(event); } catch (e) { console.error(e); } });
  }

  async function postOne(payload) {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(payload),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || !json.success) {
      throw new Error(json.message || ('HTTP ' + res.status));
    }
    return json;
  }

  async function submitOrQueue(payload) {
    if (navigator.onLine) {
      try {
        const result = await postOne(payload);
        emit({ type: 'submitted-online', result });
        return { queued: false, result };
      } catch (err) {
        const id = await window.OfflineDB.add(payload);
        emit({ type: 'queued', id, error: err.message });
        return { queued: true, id };
      }
    }
    const id = await window.OfflineDB.add(payload);
    emit({ type: 'queued', id });
    return { queued: true, id };
  }

  async function processQueue() {
    if (syncing) return;
    if (!navigator.onLine) { emit({ type: 'offline-skip' }); return; }

    syncing = true;
    emit({ type: 'sync-start' });

    const records = await window.OfflineDB.all();
    let success = 0, failed = 0;

    for (const rec of records) {
      if (rec.status !== 'pending') continue;
      try {
        await postOne(rec.payload);
        await window.OfflineDB.remove(rec.id);
        success++;
      } catch (err) {
        failed++;
        const attempts = (rec.attempts || 0) + 1;
        const status = attempts >= MAX_ATTEMPTS ? 'failed' : 'pending';
        await window.OfflineDB.update(rec.id, { attempts, status, last_error: err.message });
      }
    }

    syncing = false;
    const remaining = await window.OfflineDB.countPending();
    emit({ type: 'sync-complete', success, failed, remaining });
  }

  // Expose globally
  window.MSWDOSync = {
    submitOrQueue,
    processQueue,
    onEvent(fn) { listeners.push(fn); },
  };

  // Auto-run
  window.addEventListener('online', () => { emit({ type: 'online' }); processQueue(); });
  window.addEventListener('offline', () => emit({ type: 'offline' }));
  setInterval(() => { if (navigator.onLine) processQueue(); }, 30000);
  if (navigator.onLine) setTimeout(processQueue, 1000);
})();