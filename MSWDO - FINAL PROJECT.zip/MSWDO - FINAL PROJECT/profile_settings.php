<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'resident') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];
$error = '';
$success = '';

// ============================================================
// GET RESIDENT DATA
// ============================================================
$resident_data = [];
$household_id = null;
$profile_completion_status = 'INCOMPLETE';
$notification_preferences = [];

try {
    $stmt = $pdo->prepare("SELECT username, full_name, email, contact_number, created_at FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $resident_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $pdo->prepare("SELECT id, verification_status FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $household = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($household) {
        $household_id = $household['id'];
        $profile_completion_status = $household['verification_status'] ?? 'INCOMPLETE';
    }
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM user_preferences WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $notification_preferences = $stmt->fetch(PDO::FETCH_ASSOC);
        if(!$notification_preferences) {
            $notification_preferences = [
                'preferred_channel' => 'SMS',
                'sms_reminders_enabled' => 1,
                'email_reminders_enabled' => 1
            ];
        }
    } catch(PDOException $e) {
        $notification_preferences = [
            'preferred_channel' => 'SMS',
            'sms_reminders_enabled' => 1,
            'email_reminders_enabled' => 1
        ];
    }
    
} catch(PDOException $e) {
    $resident_data = [
        'username' => $_SESSION['username'] ?? '',
        'full_name' => $full_name,
        'email' => '',
        'contact_number' => '',
        'created_at' => date('Y-m-d H:i:s')
    ];
}

// ============================================================
// GET UNREAD NOTIFICATION COUNT FOR SIDEBAR BADGE
// ============================================================
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

// ============================================================
// HANDLE NOTIFICATION PREFERENCES UPDATE
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_notifications'])) {
    $preferred_channel = $_POST['preferred_channel'] ?? 'SMS';
    $sms_reminders = isset($_POST['sms_reminders_enabled']) ? 1 : 0;
    $email_reminders = isset($_POST['email_reminders_enabled']) ? 1 : 0;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO user_preferences (
                user_id, 
                preferred_channel, 
                sms_reminders_enabled, 
                email_reminders_enabled
            ) VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                preferred_channel = VALUES(preferred_channel),
                sms_reminders_enabled = VALUES(sms_reminders_enabled),
                email_reminders_enabled = VALUES(email_reminders_enabled)
        ");
        $stmt->execute([$user_id, $preferred_channel, $sms_reminders, $email_reminders]);
        
        $notification_success = "Notification preferences updated successfully!";
        $notification_preferences['preferred_channel'] = $preferred_channel;
        $notification_preferences['sms_reminders_enabled'] = $sms_reminders;
        $notification_preferences['email_reminders_enabled'] = $email_reminders;
        
    } catch(PDOException $e) {
        $notification_error = "Failed to update notification preferences.";
    }
}

// ============================================================
// HANDLE PROFILE UPDATE
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $new_full_name = trim($_POST['full_name'] ?? '');
    $new_email = trim($_POST['email'] ?? '');
    $new_contact = trim($_POST['contact_number'] ?? '');
    
    $errors = [];
    if(empty($new_full_name)) $errors[] = "Full name is required.";
    if(!empty($new_email) && !filter_var($new_email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    
    if(!empty($new_contact)) {
        $cleaned = preg_replace('/[^0-9]/', '', $new_contact);
        if(strlen($cleaned) < 10) {
            $errors[] = "Contact number must be at least 10 digits.";
        }
    }
    
    if(empty($errors)) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, contact_number = ? WHERE id = ?");
            $stmt->execute([$new_full_name, $new_email, $new_contact, $user_id]);
            
            $success = "Profile updated successfully!";
            $_SESSION['full_name'] = $new_full_name;
            $resident_data['full_name'] = $new_full_name;
            $resident_data['email'] = $new_email;
            $resident_data['contact_number'] = $new_contact;
            
        } catch(PDOException $e) {
            $error = "Database error. Please try again.";
        }
    } else {
        $error = implode("<br>", $errors);
    }
}

// ============================================================
// HANDLE PASSWORD CHANGE
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $errors = [];
    if(empty($current_password)) $errors[] = "Current password is required.";
    if(empty($new_password)) $errors[] = "New password is required.";
    if(strlen($new_password) < 6) $errors[] = "New password must be at least 6 characters.";
    if($new_password !== $confirm_password) $errors[] = "New passwords do not match.";
    
    if(empty($errors)) {
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        if($user && password_verify($current_password, $user['password'])) {
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed, $user_id]);
            $password_success = "Password changed successfully!";
        } else {
            $password_error = "Current password is incorrect.";
        }
    } else {
        $password_error = implode("<br>", $errors);
    }
}

// ============================================================
// PROFILE PHOTO UPLOAD
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['upload_photo'])) {
    if(isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == 0) {
        $file = $_FILES['profile_photo'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $max_size = 5 * 1024 * 1024;
        
        if(!in_array($file['type'], $allowed_types)) {
            $photo_error = "Only JPG, JPEG, and PNG files are allowed.";
        } elseif($file['size'] > $max_size) {
            $photo_error = "File size must be less than 5MB.";
        } else {
            $upload_dir = 'uploads/profile_photos/';
            if(!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $filename = 'profile_' . $user_id . '_' . time() . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
            $filepath = $upload_dir . $filename;
            
            if(move_uploaded_file($file['tmp_name'], $filepath)) {
                $photo_url = $filepath;
                $stmt = $pdo->prepare("
                    INSERT INTO user_preferences (user_id, profile_photo_url) 
                    VALUES (?, ?) 
                    ON DUPLICATE KEY UPDATE profile_photo_url = ?
                ");
                $stmt->execute([$user_id, $photo_url, $photo_url]);
                
                $photo_success = "Profile photo uploaded successfully!";
            } else {
                $photo_error = "Failed to upload photo. Please try again.";
            }
        }
    } else {
        $photo_error = "Please select a photo to upload.";
    }
}

// ============================================================
// SIGNATURE UPLOAD
// ============================================================
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['upload_signature'])) {
    if(isset($_FILES['signature_file']) && $_FILES['signature_file']['error'] == 0) {
        $file = $_FILES['signature_file'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $max_size = 2 * 1024 * 1024;
        
        if(!in_array($file['type'], $allowed_types)) {
            $sig_error = "Only JPG, JPEG, and PNG files are allowed.";
        } elseif($file['size'] > $max_size) {
            $sig_error = "File size must be less than 2MB.";
        } else {
            $upload_dir = 'uploads/signatures/';
            if(!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $filename = 'signature_' . $user_id . '_' . time() . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
            $filepath = $upload_dir . $filename;
            
            if(move_uploaded_file($file['tmp_name'], $filepath)) {
                $sig_url = $filepath;
                $stmt = $pdo->prepare("
                    INSERT INTO user_preferences (user_id, signature_url) 
                    VALUES (?, ?) 
                    ON DUPLICATE KEY UPDATE signature_url = ?
                ");
                $stmt->execute([$user_id, $sig_url, $sig_url]);
                
                $sig_success = "Signature uploaded successfully!";
            } else {
                $sig_error = "Failed to upload signature. Please try again.";
            }
        }
    } else {
        $sig_error = "Please select a signature file to upload.";
    }
}

// Get user preferences for photo and signature
$user_preferences = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM user_preferences WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user_preferences = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$user_preferences) {
        $user_preferences = ['preferred_channel' => 'SMS'];
    }
} catch(PDOException $e) {
    $user_preferences = ['preferred_channel' => 'SMS'];
}

// Get sidebar household ID
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get initials for avatar
$initials = '';
if(!empty($resident_data['full_name'])) {
    $nameParts = explode(' ', $resident_data['full_name']);
    foreach($nameParts as $part) {
        if(!empty($part)) {
            $initials .= strtoupper($part[0]);
        }
    }
    $initials = substr($initials, 0, 2);
} else {
    $initials = 'JD';
}

$has_photo = !empty($user_preferences['profile_photo_url']) && file_exists($user_preferences['profile_photo_url']);
$has_signature = !empty($user_preferences['signature_url']) && file_exists($user_preferences['signature_url']);
$has_household = !empty($household_id);

// Calculate profile completion percentage
$completion_items = 0;
$total_items = 3;
if($has_household) $completion_items++;
if($has_photo) $completion_items++;
if($has_signature) $completion_items++;
$completion_percentage = round(($completion_items / $total_items) * 100);
$profile_ready = ($completion_items === $total_items);

// Member since
$member_since = isset($resident_data['created_at']) ? date('F Y', strtotime($resident_data['created_at'])) : 'Recently';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Profile Settings - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <?= renderPwaMetaTags() ?>
   
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F1F5F9;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --primary-light: #EFF6FF;
            --secondary: #D32F2F;
            --secondary-light: #FEF2F2;
            --accent: #F5B042;
            --accent-light: #FFFBEB;
            --success: #059669;
            --success-light: #ECFDF5;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
            --radius-2xl: 2rem;
        }
        .app { display: flex; min-height: 100vh; }

        /* ============================================================
           SIDEBAR
           ============================================================ */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%);
            border-right: 1px solid var(--gray-200);
            position: fixed;
            top: 0; left: 0; bottom: 0;
            overflow-y: auto;
            z-index: 40;
            transition: transform 0.3s ease;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 28px; }
        .nav-label {
            font-size: 0.7rem; font-weight: 600; text-transform: uppercase;
            letter-spacing: 0.5px; color: var(--gray-400);
            margin-bottom: 12px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 16px; margin-bottom: 4px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            transition: all 0.2s ease;
            position: relative;
        }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .nav-item.active i { color: var(--accent); }
        .nav-item .nav-badge {
            margin-left: auto;
            background: var(--secondary);
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 20px;
            line-height: 1.4;
        }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .chevron { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .chevron.rotated { transform: rotate(90deg); }
        .submenu { margin-left: 36px; overflow: hidden; max-height: 0; transition: max-height 0.3s ease; }
        .submenu.show { max-height: 300px; }
        .submenu-item {
            display: flex; align-items: center; gap: 12px;
            padding: 8px 16px; margin-bottom: 2px;
            border-radius: var(--radius-md);
            color: var(--gray-500);
            text-decoration: none;
            font-size: 0.8rem;
            transition: all 0.2s ease;
        }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
        }
        .submenu-item.active i { color: var(--accent); }

        /* ============================================================
           MAIN CONTENT
           ============================================================ */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 24px 32px 80px 32px;
            max-width: 1000px;
        }

        /* Top Header */
        .top-header {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            padding: 14px 20px;
            border-radius: var(--radius-xl);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: var(--shadow-md);
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-title h1 {
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .page-title p { font-size: 0.72rem; color: var(--gray-500); margin-top: 2px; font-weight: 500; }
        .user-menu {
            display: flex; align-items: center; gap: 10px;
            background: linear-gradient(135deg, #FFFFFF, #F8FAFC);
            padding: 6px 14px 6px 6px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.2s;
        }
        .user-menu:hover { box-shadow: var(--shadow-md); transform: translateY(-1px); }
        .user-avatar-top {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 2px 8px rgba(30, 74, 140, 0.25);
        }
        .user-avatar-top i { color: var(--accent); font-size: 0.9rem; }
        .user-info span { font-size: 0.85rem; font-weight: 600; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }
        .menu-toggle {
            display: none; background: none; border: none;
            font-size: 1.2rem; color: var(--gray-700);
            cursor: pointer; padding: 8px; border-radius: var(--radius-md);
        }
        .menu-toggle:hover { background: var(--gray-100); }

        /* ============================================================
           HERO PROFILE CARD
           ============================================================ */
        .profile-hero {
            background: linear-gradient(135deg, #1E4A8C 0%, #0A2F6C 50%, #1E4A8C 100%);
            border-radius: var(--radius-2xl);
            padding: 32px 28px;
            margin-bottom: 24px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 40px -12px rgba(30, 74, 140, 0.35);
        }
        .profile-hero::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 400px; height: 400px;
            background: radial-gradient(circle, rgba(245, 176, 66, 0.18) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .profile-hero::after {
            content: '';
            position: absolute;
            bottom: -40%; left: -5%;
            width: 350px; height: 350px;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.08) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
        }
        .profile-hero-inner {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 24px;
            flex-wrap: wrap;
        }
        .hero-avatar {
            width: 96px; height: 96px;
            background: linear-gradient(135deg, #F5B042, #FCD34D);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 2.2rem;
            font-weight: 800;
            color: #1E4A8C;
            border: 4px solid rgba(255, 255, 255, 0.25);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.25);
            flex-shrink: 0;
            overflow: hidden;
            position: relative;
        }
        .hero-avatar img {
            width: 100%; height: 100%;
            object-fit: cover;
        }
        .hero-avatar .status-dot-hero {
            position: absolute;
            bottom: 4px; right: 4px;
            width: 20px; height: 20px;
            background: #34D399;
            border: 3px solid #1E4A8C;
            border-radius: 50%;
            box-shadow: 0 0 12px rgba(52, 211, 153, 0.6);
        }
        .hero-avatar .status-dot-hero.incomplete {
            background: #F87171;
            box-shadow: 0 0 12px rgba(248, 113, 113, 0.6);
        }
        .hero-info { flex: 1; min-width: 240px; }
        .hero-info h2 {
            font-size: 1.6rem;
            font-weight: 800;
            color: white;
            letter-spacing: -0.02em;
            margin-bottom: 6px;
        }
        .hero-info .hero-role {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.75);
            font-weight: 500;
            margin-bottom: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .hero-info .hero-role .role-chip {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: rgba(255, 255, 255, 0.15);
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            backdrop-filter: blur(8px);
        }
        .hero-info .hero-role .role-chip i { color: var(--accent); font-size: 0.65rem; }

        /* Progress Bar */
        .progress-wrapper {
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(8px);
            border-radius: var(--radius-lg);
            padding: 14px 18px;
            border: 1px solid rgba(255, 255, 255, 0.15);
        }
        .progress-label-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        .progress-label-row .p-label {
            font-size: 0.72rem;
            color: rgba(255, 255, 255, 0.85);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .progress-label-row .p-value {
            font-size: 1rem;
            font-weight: 800;
            color: var(--accent);
        }
        .progress-track {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            height: 8px;
            overflow: hidden;
        }
        .progress-fill {
            background: linear-gradient(90deg, var(--accent), #FCD34D);
            height: 100%;
            border-radius: 20px;
            transition: width 0.8s ease;
            box-shadow: 0 0 12px rgba(245, 176, 66, 0.5);
        }

        /* Completion Chips */
        .completion-chips {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 14px;
        }
        .chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            backdrop-filter: blur(8px);
            transition: all 0.3s;
        }
        .chip:hover { transform: translateY(-2px); }
        .chip.complete {
            background: rgba(52, 211, 153, 0.15);
            color: #34D399;
            border: 1px solid rgba(52, 211, 153, 0.3);
        }
        .chip.incomplete {
            background: rgba(248, 113, 113, 0.15);
            color: #F87171;
            border: 1px solid rgba(248, 113, 113, 0.3);
        }
        .chip i { font-size: 0.75rem; }

        .hero-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-left: auto;
        }
        .hero-btn {
            padding: 10px 20px;
            border-radius: var(--radius-md);
            border: 1px solid rgba(255, 255, 255, 0.25);
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(8px);
            color: white;
            font-size: 0.75rem;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
            white-space: nowrap;
        }
        .hero-btn:hover {
            background: rgba(255, 255, 255, 0.22);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }
        .hero-btn i { color: var(--accent); font-size: 0.85rem; }

        /* ============================================================
           SECTION CARDS
           ============================================================ */
        .section-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            margin-bottom: 20px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: box-shadow 0.3s;
        }
        .section-card:hover { box-shadow: var(--shadow-lg); }
        .section-header {
            padding: 18px 24px;
            background: linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%);
            border-bottom: 2px solid var(--accent);
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .section-header .section-icon {
            width: 36px; height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            color: var(--accent);
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        .section-header h3 {
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
            letter-spacing: -0.01em;
        }
        .section-header p {
            font-size: 0.72rem;
            color: var(--gray-500);
            margin-top: 2px;
            width: 100%;
        }
        .section-body { padding: 24px; }

        /* ============================================================
           FORM STYLING
           ============================================================ */
        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.72rem;
            font-weight: 700;
            color: var(--gray-600);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }
        .form-group label i { color: var(--accent); font-size: 0.75rem; }
        .form-group label .required { color: var(--secondary); }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s;
            background: var(--gray-50);
            color: var(--gray-800);
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 74, 140, 0.1);
            background: white;
        }
        .form-group small {
            font-size: 0.68rem;
            color: var(--gray-500);
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .form-group small i { color: var(--primary); font-size: 0.6rem; }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: var(--radius-md);
            font-size: 0.82rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.25s;
            border: none;
            font-family: inherit;
            text-decoration: none;
            letter-spacing: 0.02em;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12); }
        .btn:active { transform: translateY(0); }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.25);
        }
        .btn-primary:hover { box-shadow: 0 8px 20px rgba(30, 74, 140, 0.35); }
        .btn-success {
            background: linear-gradient(135deg, #059669, #047857);
            color: white;
            box-shadow: 0 4px 12px rgba(5, 150, 105, 0.25);
        }
        .btn-success:hover { box-shadow: 0 8px 20px rgba(5, 150, 105, 0.35); }
        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }
        .btn-secondary:hover { background: var(--gray-200); }
        .btn-block { width: 100%; }

        /* ============================================================
           ALERTS
           ============================================================ */
        .alert {
            padding: 14px 18px;
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            font-size: 0.82rem;
            font-weight: 500;
            border-left: 4px solid;
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .alert i { font-size: 1rem; margin-top: 1px; flex-shrink: 0; }
        .alert-success { background: var(--success-light); border-color: var(--success); color: #065F46; }
        .alert-success i { color: var(--success); }
        .alert-danger { background: var(--secondary-light); border-color: var(--secondary); color: #991B1B; }
        .alert-danger i { color: var(--secondary); }
        .alert-info { background: var(--primary-light); border-color: var(--primary); color: var(--primary); }
        .alert-info i { color: var(--primary); }

        /* ============================================================
           TOGGLE SWITCH
           ============================================================ */
        .toggle-group {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 16px;
            margin-bottom: 10px;
            background: var(--gray-50);
            border-radius: var(--radius-lg);
            border: 1px solid var(--gray-100);
            transition: all 0.2s;
        }
        .toggle-group:hover {
            background: var(--primary-light);
            border-color: rgba(30, 74, 140, 0.15);
            transform: translateX(4px);
        }
        .toggle-group .toggle-info { flex: 1; }
        .toggle-group .toggle-title {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--gray-700);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .toggle-group .toggle-title i { color: var(--primary); font-size: 0.8rem; }
        .toggle-group .toggle-subtitle {
            font-size: 0.7rem;
            color: var(--gray-500);
            margin-top: 2px;
        }
        .toggle-switch {
            position: relative;
            width: 48px;
            height: 26px;
            flex-shrink: 0;
        }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0; left: 0; right: 0; bottom: 0;
            background: var(--gray-300);
            border-radius: 26px;
            transition: all 0.3s ease;
        }
        .toggle-slider:before {
            content: '';
            position: absolute;
            height: 20px; width: 20px;
            left: 3px; bottom: 3px;
            background: white;
            border-radius: 50%;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
        }
        .toggle-switch input:checked + .toggle-slider {
            background: linear-gradient(135deg, var(--success), #047857);
            box-shadow: 0 0 12px rgba(5, 150, 105, 0.3);
        }
        .toggle-switch input:checked + .toggle-slider:before {
            transform: translateX(22px);
        }

        /* ============================================================
           UPLOAD SECTION
           ============================================================ */
        .upload-row {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: center;
            margin-top: 8px;
        }
        .upload-row input[type="file"] {
            flex: 1;
            min-width: 180px;
            padding: 10px 14px;
            font-size: 0.78rem;
            background: var(--gray-50);
            border: 1.5px dashed var(--gray-300);
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: all 0.2s;
        }
        .upload-row input[type="file"]:hover {
            border-color: var(--primary);
            background: var(--primary-light);
        }
        .upload-row input[type="file"]::file-selector-button {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border: none;
            padding: 6px 14px;
            border-radius: var(--radius-sm);
            font-weight: 600;
            font-size: 0.72rem;
            margin-right: 12px;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
        }

        .signature-preview {
            display: inline-block;
            margin-top: 10px;
            padding: 8px;
            background: white;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            max-width: 180px;
        }
        .signature-preview img {
            max-width: 100%;
            max-height: 50px;
            display: block;
        }
        .signature-preview .preview-label {
            font-size: 0.65rem;
            color: var(--gray-500);
            margin-bottom: 4px;
            font-weight: 600;
        }

        /* ============================================================
           INFO BOX
           ============================================================ */
        .info-box {
            background: var(--primary-light);
            border-left: 4px solid var(--primary);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            margin-top: 16px;
            display: flex;
            gap: 12px;
            align-items: flex-start;
        }
        .info-box i {
            color: var(--primary);
            font-size: 1.1rem;
            margin-top: 2px;
        }
        .info-box strong {
            color: var(--primary);
            font-size: 0.82rem;
            display: block;
            margin-bottom: 4px;
        }
        .info-box p {
            font-size: 0.75rem;
            color: var(--gray-600);
            line-height: 1.5;
        }

        /* ============================================================
           BOTTOM NAV
           ============================================================ */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(12px);
            display: flex; justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
            box-shadow: 0 -4px 12px rgba(0,0,0,0.04);
        }
        .bottom-nav .nav-item {
            display: flex; flex-direction: column; align-items: center;
            font-size: 0.68rem; color: var(--gray-600); text-decoration: none;
            font-weight: 600;
            padding: 6px 8px;
            border-radius: var(--radius-md);
            transition: all 0.2s;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); background: var(--primary-light); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }

        /* ============================================================
           SIDEBAR OVERLAY
           ============================================================ */
        .sidebar-overlay {
            position: fixed; inset: 0;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 39;
            display: none;
        }
        .sidebar-overlay.active { display: block; }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 992px) {
            .main-content { max-width: 100%; }
        }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); box-shadow: var(--shadow-lg); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .menu-toggle { display: block; }
            .top-header { padding: 12px 16px; }
            .page-title h1 { font-size: 1.1rem; }
            .page-title p { display: none; }
            .profile-hero { padding: 24px 20px; }
            .profile-hero-inner { flex-direction: column; text-align: center; }
            .hero-info { text-align: center; }
            .hero-info h2 { font-size: 1.3rem; }
            .hero-info .hero-role { justify-content: center; }
            .hero-actions { margin-left: 0; width: 100%; justify-content: center; }
            .hero-avatar { width: 80px; height: 80px; font-size: 1.8rem; }
            .section-body { padding: 18px; }
            .upload-row { flex-direction: column; }
            .upload-row input[type="file"] { width: 100%; }
            .toggle-group { flex-wrap: wrap; gap: 10px; }
        }
        @media (max-width: 480px) {
            .section-header { padding: 14px 18px; }
            .section-body { padding: 16px; }
            .completion-chips { justify-content: center; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="app">
    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text">
                    <h1>MSWDO Cantilan</h1>
                    <p>Municipal Social Welfare</p>
                </div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="dashboards/resident_dashboard.php" class="nav-item">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item">
                    <i class="fas fa-users"></i>
                    <span>Household Profile</span>
                </a>
                <a href="modules/my_applications.php" class="nav-item">
                    <i class="fas fa-file-alt"></i>
                    <span>My Applications</span>
                </a>
                <a href="notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Services</div>
                <div class="nav-item collapsible" id="programToggle">
                    <i class="fas fa-folder"></i>
                    <span>Program</span>
                    <i class="fas fa-chevron-right chevron" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>
                <a href="modules/survey_form.php" class="nav-item">
                    <i class="fas fa-chart-line"></i>
                    <span>Community Survey</span>
                </a>
                <a href="id_application.php" class="nav-item">
                    <i class="fas fa-id-card"></i>
                    <span>ID Application</span>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile_settings.php" class="nav-item active">
                    <i class="fas fa-user-circle"></i>
                    <span>Profile Settings</span>
                </a>
                <a href="logout.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content">
        <div class="top-header">
            <div style="display: flex; align-items: center; gap: 12px;">
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1><i class="fas fa-user-circle" style="color: var(--primary);"></i> Profile Settings</h1>
                    <p>Manage your personal information and preferences</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar-top"><i class="fas fa-user"></i></div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars(explode(' ', $full_name)[0]); ?></span>
                    <small><?php echo ucfirst($role); ?></small>
                </div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <!-- ============================================================
             HERO PROFILE CARD
             ============================================================ -->
        <div class="profile-hero">
            <div class="profile-hero-inner">
                <div class="hero-avatar">
                    <?php if($has_photo): ?>
                        <img src="<?php echo htmlspecialchars($user_preferences['profile_photo_url']); ?>" alt="Profile Photo">
                    <?php else: ?>
                        <?php echo $initials; ?>
                    <?php endif; ?>
                    <span class="status-dot-hero <?php echo $profile_ready ? '' : 'incomplete'; ?>"></span>
                </div>
                <div class="hero-info">
                    <h2><?php echo htmlspecialchars($resident_data['full_name'] ?? $full_name); ?></h2>
                    <div class="hero-role">
                        <span class="role-chip">
                            <i class="fas fa-id-badge"></i> 
                            <?php echo ($household_id) ? 'Household Head' : 'Resident'; ?>
                        </span>
                        <span class="role-chip">
                            <i class="fas fa-user"></i> 
                            @<?php echo htmlspecialchars($resident_data['username'] ?? ''); ?>
                        </span>
                        <span class="role-chip">
                            <i class="fas fa-calendar"></i> 
                            Member since <?php echo $member_since; ?>
                        </span>
                    </div>

                    <div class="progress-wrapper">
                        <div class="progress-label-row">
                            <span class="p-label">Profile Completion</span>
                            <span class="p-value"><?php echo $completion_percentage; ?>%</span>
                        </div>
                        <div class="progress-track">
                            <div class="progress-fill" style="width: <?php echo $completion_percentage; ?>%;"></div>
                        </div>
                        <div class="completion-chips">
                            <span class="chip <?php echo $has_household ? 'complete' : 'incomplete'; ?>">
                                <i class="fas <?php echo $has_household ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                Household
                            </span>
                            <span class="chip <?php echo $has_photo ? 'complete' : 'incomplete'; ?>">
                                <i class="fas <?php echo $has_photo ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                Photo
                            </span>
                            <span class="chip <?php echo $has_signature ? 'complete' : 'incomplete'; ?>">
                                <i class="fas <?php echo $has_signature ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                Signature
                            </span>
                        </div>
                    </div>
                </div>
                <div class="hero-actions">
                    <?php if(!$has_household): ?>
                    <a href="modules/household_form.php" class="hero-btn">
                        <i class="fas fa-home"></i> Complete Household
                    </a>
                    <?php endif; ?>
                    <?php if($profile_ready): ?>
                    <span class="hero-btn" style="cursor: default; background: rgba(52, 211, 153, 0.2); border-color: rgba(52, 211, 153, 0.4);">
                        <i class="fas fa-crown" style="color: #FCD34D;"></i> Profile Complete
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ============================================================
             EDIT PROFILE SECTION
             ============================================================ -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-edit"></i></div>
                <h3>Edit Profile Information</h3>
                <p>Update your contact information</p>
            </div>
            <div class="section-body">
                <form method="POST">
                    <?php if($success): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <div><?php echo $success; ?></div></div>
                    <?php endif; ?>
                    <?php if($error): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <div><?php echo $error; ?></div></div>
                    <?php endif; ?>
                    
                    <input type="hidden" name="update_profile" value="1">
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Full Name <span class="required">*</span></label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($resident_data['full_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email Address</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($resident_data['email'] ?? ''); ?>" placeholder="juan.delacruz@email.com">
                        <small><i class="fas fa-info-circle"></i> Used for account recovery and notifications</small>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Mobile Number <span class="required">*</span></label>
                        <input type="text" name="contact_number" value="<?php echo htmlspecialchars($resident_data['contact_number'] ?? ''); ?>" placeholder="0917-123-4567" required>
                        <small><i class="fas fa-info-circle"></i> Used for SMS notifications and emergency alerts</small>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-save"></i> Update Profile
                    </button>
                </form>
            </div>
        </div>

        <!-- ============================================================
             CHANGE PASSWORD SECTION
             ============================================================ -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-key"></i></div>
                <h3>Change Password</h3>
                <p>Keep your account secure</p>
            </div>
            <div class="section-body">
                <form method="POST">
                    <?php if(isset($password_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <div><?php echo $password_success; ?></div></div>
                    <?php endif; ?>
                    <?php if(isset($password_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <div><?php echo $password_error; ?></div></div>
                    <?php endif; ?>
                    
                    <input type="hidden" name="change_password" value="1">
                    
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Current Password <span class="required">*</span></label>
                        <input type="password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-key"></i> New Password <span class="required">*</span></label>
                        <input type="password" name="new_password" required>
                        <small><i class="fas fa-info-circle"></i> Minimum 6 characters</small>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-check-circle"></i> Confirm New Password <span class="required">*</span></label>
                        <input type="password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn btn-secondary btn-block">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </form>
            </div>
        </div>

        <!-- ============================================================
             PROFILE PHOTO UPLOAD
             ============================================================ -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-camera"></i></div>
                <h3>Profile Photo</h3>
                <p>Upload a clear photo of yourself</p>
            </div>
            <div class="section-body">
                <form method="POST" enctype="multipart/form-data">
                    <?php if(isset($photo_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <div><?php echo $photo_success; ?></div></div>
                    <?php endif; ?>
                    <?php if(isset($photo_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <div><?php echo $photo_error; ?></div></div>
                    <?php endif; ?>
                    
                    <input type="hidden" name="upload_photo" value="1">
                    
                    <div class="upload-row">
                        <input type="file" name="profile_photo" accept="image/*">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Upload
                        </button>
                    </div>
                    <small><i class="fas fa-info-circle"></i> JPG, JPEG, or PNG. Max 5MB.</small>
                </form>
            </div>
        </div>

        <!-- ============================================================
             DIGITAL SIGNATURE UPLOAD
             ============================================================ -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-signature"></i></div>
                <h3>Digital Signature</h3>
                <p>Upload your signature for official documents</p>
            </div>
            <div class="section-body">
                <form method="POST" enctype="multipart/form-data">
                    <?php if(isset($sig_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <div><?php echo $sig_success; ?></div></div>
                    <?php endif; ?>
                    <?php if(isset($sig_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <div><?php echo $sig_error; ?></div></div>
                    <?php endif; ?>
                    
                    <input type="hidden" name="upload_signature" value="1">
                    
                    <div class="upload-row">
                        <input type="file" name="signature_file" accept="image/*">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-upload"></i> Upload
                        </button>
                    </div>
                    <small><i class="fas fa-info-circle"></i> JPG, JPEG, or PNG. Max 2MB. Signature on white background.</small>
                    
                    <?php if($has_signature): ?>
                        <div class="signature-preview">
                            <div class="preview-label"><i class="fas fa-check-circle" style="color: var(--success);"></i> Current Signature</div>
                            <img src="<?php echo htmlspecialchars($user_preferences['signature_url']); ?>" alt="Signature">
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- ============================================================
             NOTIFICATION PREFERENCES
             ============================================================ -->
        <div class="section-card">
            <div class="section-header">
                <div class="section-icon"><i class="fas fa-bell"></i></div>
                <h3>Notification Preferences</h3>
                <p>Manage how you receive reminders and updates</p>
            </div>
            <div class="section-body">
                <form method="POST">
                    <?php if(isset($notification_success)): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <div><?php echo $notification_success; ?></div></div>
                    <?php endif; ?>
                    <?php if(isset($notification_error)): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <div><?php echo $notification_error; ?></div></div>
                    <?php endif; ?>
                    
                    <input type="hidden" name="update_notifications" value="1">

                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Preferred Channel</label>
                        <select name="preferred_channel">
                            <option value="SMS" <?php echo ($notification_preferences['preferred_channel'] ?? 'SMS') == 'SMS' ? 'selected' : ''; ?>>SMS (Text Message)</option>
                            <option value="EMAIL" <?php echo ($notification_preferences['preferred_channel'] ?? '') == 'EMAIL' ? 'selected' : ''; ?>>Email</option>
                            <option value="BOTH" <?php echo ($notification_preferences['preferred_channel'] ?? '') == 'BOTH' ? 'selected' : ''; ?>>Both SMS and Email</option>
                            <option value="NONE" <?php echo ($notification_preferences['preferred_channel'] ?? '') == 'NONE' ? 'selected' : ''; ?>>None</option>
                        </select>
                        <small><i class="fas fa-info-circle"></i> Choose how you want to receive notifications</small>
                    </div>

                    <div class="toggle-group">
                        <div class="toggle-info">
                            <div class="toggle-title"><i class="fas fa-sms"></i> SMS Reminders</div>
                            <div class="toggle-subtitle">Receive text message reminders</div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="sms_reminders_enabled" <?php echo ($notification_preferences['sms_reminders_enabled'] ?? 1) ? 'checked' : ''; ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="toggle-group">
                        <div class="toggle-info">
                            <div class="toggle-title"><i class="fas fa-envelope-open-text"></i> Email Reminders</div>
                            <div class="toggle-subtitle">Receive email notifications</div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="email_reminders_enabled" <?php echo ($notification_preferences['email_reminders_enabled'] ?? 1) ? 'checked' : ''; ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" style="margin-top: 16px;">
                        <i class="fas fa-save"></i> Save Preferences
                    </button>
                </form>
            </div>
        </div>

        <!-- ============================================================
             SECURITY NOTICE
             ============================================================ -->
        <div class="info-box">
            <i class="fas fa-shield-alt"></i>
            <div>
                <strong>Account Security</strong>
                <p>
                    Keep your contact information updated to receive important notifications.
                    Change your password regularly for account security.
                    Complete your profile to unlock all program benefits.
                </p>
            </div>
        </div>

    </main>

    <!-- BOTTOM NAV -->
    <div class="bottom-nav">
        <a href="dashboards/resident_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item"><i class="fas fa-users"></i><span>Household</span></a>
        <a href="modules/my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i><span>Apps</span></a>
        <a href="profile_settings.php" class="nav-item active"><i class="fas fa-user-circle"></i><span>Profile</span></a>
        <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>
</div>

<script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    if(menuToggle) {
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.classList.toggle('active');
        });
    }
    
    if(overlay) {
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
    }
    
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target) && !overlay.contains(event.target)) {
                sidebar.classList.remove('open');
                overlay.classList.remove('active');
            }
        }
    });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
</script>

   <?= renderPwaServiceWorker() ?>
</body>
</html>