<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$role = $_SESSION['role'];
$error = '';
$success = '';

// Get sidebar household ID
$sidebar_household_id = null;
try {
    $stmt = $pdo->prepare("SELECT id FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $hh = $stmt->fetch();
    if($hh) $sidebar_household_id = $hh['id'];
} catch(PDOException $e) {
    $sidebar_household_id = null;
}

// Get unread notification count for sidebar badge
$unread_notif_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM resident_notifications WHERE user_id = ? AND (is_read = 0 OR is_read IS NULL)");
    $stmt->execute([$user_id]);
    $unread_notif_count = $stmt->fetch()['c'] ?? 0;
} catch(PDOException $e) {
    $unread_notif_count = 0;
}

$household = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM households WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $household = $stmt->fetch();
} catch(PDOException $e) {
    $household = null;
}

// Get user contact info
$user_data = [];
try {
    $stmt = $pdo->prepare("SELECT email, contact_number FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $user_data = ['email' => '', 'contact_number' => ''];
}

// Create sectoral registry tables if they don't exist
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS solo_parent_registry (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL UNIQUE,
        household_id INT,
        application_id INT,
        registry_no VARCHAR(50) UNIQUE,
        status ENUM('active', 'expired', 'revoked') DEFAULT 'active',
        id_card_printed TINYINT DEFAULT 0,
        qr_code_path VARCHAR(255),
        date_registered TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expiry_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX(user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS senior_registry (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL UNIQUE,
        household_id INT,
        application_id INT,
        registry_no VARCHAR(50) UNIQUE,
        status ENUM('active', 'expired', 'revoked') DEFAULT 'active',
        id_card_printed TINYINT DEFAULT 0,
        qr_code_path VARCHAR(255),
        date_registered TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expiry_date DATE DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX(user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS pwd_registry (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL UNIQUE,
        household_id INT,
        application_id INT,
        registry_no VARCHAR(50) UNIQUE,
        pwd_id_number VARCHAR(50),
        disability_type TEXT,
        status ENUM('active', 'expired', 'revoked') DEFAULT 'active',
        id_card_printed TINYINT DEFAULT 0,
        qr_code_path VARCHAR(255),
        date_registered TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expiry_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX(user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS id_applications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        household_id INT,
        ref_number VARCHAR(50) UNIQUE,
        program_linked VARCHAR(50),
        application_data TEXT,
        status ENUM('pending_verification', 'for_board_review', 'approved_printed', 'rejected') DEFAULT 'pending_verification',
        qr_code_path VARCHAR(255),
        photo_2x2_path VARCHAR(255),
        signature_path VARCHAR(255),
        id_printed_at TIMESTAMP NULL,
        claimed_at TIMESTAMP NULL,
        reviewed_by INT,
        review_notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX(user_id),
        INDEX(household_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
} catch(PDOException $e) {
    // Tables might already exist
}

// Get approved applications for program-based IDs
$eligible_programs = [];
$approved_applications = [];

try {
    $stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'solo_parent' AND status = 'approved' ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$user_id]);
    $solo_parent = $stmt->fetch();
    if($solo_parent) {
        $eligible_programs[] = 'solo_parent';
        $approved_applications['solo_parent'] = $solo_parent;
    }
    
    $stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'senior_citizen' AND status = 'approved' ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$user_id]);
    $senior = $stmt->fetch();
    if($senior) {
        $eligible_programs[] = 'senior_citizen';
        $approved_applications['senior_citizen'] = $senior;
    }
    
    $stmt = $pdo->prepare("SELECT * FROM welfare_applications WHERE user_id = ? AND program_type = 'pwd' AND status = 'approved' ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$user_id]);
    $pwd_app = $stmt->fetch();
    if($pwd_app) {
        $eligible_programs[] = 'pwd';
        $approved_applications['pwd'] = $pwd_app;
    }
} catch(PDOException $e) {
    // Ignore
}

// Generate Application Reference Number
$program_code = '';
$id_type = isset($_POST['id_type']) ? $_POST['id_type'] : (isset($_GET['type']) ? $_GET['type'] : '');
switch($id_type) {
    case 'solo_parent_id': $program_code = 'SP'; break;
    case 'senior_citizen_id': $program_code = 'SC'; break;
    case 'pwd_id': $program_code = 'PWD'; break;
    default: $program_code = 'GEN';
}

$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM id_applications WHERE ref_number LIKE 'ID-" . $program_code . "-" . date('Y') . "-%'");
$stmt->execute();
$count = $stmt->fetch()['count'] + 1;
$ref_number = 'ID-' . $program_code . '-' . date('Y') . '-' . str_pad($count, 4, '0', STR_PAD_LEFT);

$registry_no = 'REG-' . $program_code . '-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

$verification_code = bin2hex(random_bytes(16));
$verification_url = "https://" . $_SERVER['HTTP_HOST'] . "/mswdo/verify_id.php?code=" . $verification_code;

$existing_app = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM id_applications WHERE user_id = ? AND status IN ('pending_verification', 'for_board_review')");
    $stmt->execute([$user_id]);
    $existing_app = $stmt->fetch();
} catch(PDOException $e) {
    $existing_app = null;
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply'])) {
    $photo_2x2_path = null;
    if(isset($_FILES['photo_2x2']) && $_FILES['photo_2x2']['error'] == 0) {
        $upload_dir = 'uploads/id_photos/';
        if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $photo_2x2_path = $upload_dir . time() . '_' . $user_id . '_2x2.jpg';
        move_uploaded_file($_FILES['photo_2x2']['tmp_name'], $photo_2x2_path);
    }
    
    $signature_path = null;
    $digital_signature = $_POST['client_signature'] ?? null;
    if($digital_signature) {
        $upload_dir = 'uploads/signatures/';
        if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $signature_path = $upload_dir . time() . '_' . $user_id . '_signature.png';
        $signature_data = explode(',', $digital_signature);
        if(count($signature_data) > 1) {
            file_put_contents($signature_path, base64_decode($signature_data[1]));
        }
    }
    
    $latitude = $_POST['latitude'] ?? null;
    $longitude = $_POST['longitude'] ?? null;
    
    $id_type_selected = $_POST['id_type'] ?? '';
    $expiry_date = null;
    if($id_type_selected == 'senior_citizen_id') {
        $expiry_date = null;
    } elseif($id_type_selected == 'solo_parent_id') {
        $expiry_date = date('Y-m-d', strtotime('+1 year'));
    } elseif($id_type_selected == 'pwd_id') {
        $expiry_date = date('Y-m-d', strtotime('+5 years'));
    } else {
        $expiry_date = date('Y-m-d', strtotime('+3 years'));
    }
    
    $qr_dir = 'uploads/qrcodes/';
    if(!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
    $qr_path = $qr_dir . $ref_number . '.png';
    
    $application_data = [
        'ref_number' => $ref_number,
        'registry_no' => $registry_no,
        'verification_code' => $verification_code,
        'verification_url' => $verification_url,
        'latitude' => $latitude,
        'longitude' => $longitude,
        
        'first_name' => $_POST['first_name'] ?? '',
        'middle_name' => $_POST['middle_name'] ?? '',
        'last_name' => $_POST['last_name'] ?? '',
        'suffix' => $_POST['suffix'] ?? '',
        'birthdate' => $_POST['birthdate'] ?? '',
        'place_of_birth' => $_POST['place_of_birth'] ?? '',
        'sex' => $_POST['sex'] ?? '',
        'civil_status' => $_POST['civil_status'] ?? '',
        'occupation' => $_POST['occupation'] ?? '',
        'monthly_income' => $_POST['monthly_income'] ?? '',
        
        'contact_number' => $_POST['contact_number'] ?? '',
        'email' => $_POST['email'] ?? '',
        'address' => $_POST['address'] ?? '',
        'barangay' => $_POST['barangay'] ?? '',
        
        'id_type' => $id_type_selected,
        'id_type_other' => ($id_type_selected == 'other') ? ($_POST['id_type_other'] ?? '') : null,
        'previous_id_number' => $_POST['previous_id_number'] ?? '',
        
        'linked_application' => $approved_applications[$id_type_selected] ?? null,
        
        'validity_period' => $expiry_date === null ? 'Lifetime' : $expiry_date,
        
        'reason_for_application' => $_POST['reason_for_application'] ?? '',
        'lost_reason' => $_POST['lost_reason'] ?? '',
        'lost_report_number' => $_POST['lost_report_number'] ?? '',
        
        'government_issued_id' => $_POST['government_issued_id'] ?? '',
        'valid_id_type' => $_POST['valid_id_type'] ?? '',
        'valid_id_number' => $_POST['valid_id_number'] ?? '',
        
        'photo_2x2' => $photo_2x2_path,
        'signature' => $signature_path,
        
        'declaration_agreed' => isset($_POST['declaration_agreed']) ? 1 : 0,
        'client_consent' => isset($_POST['client_consent']) ? 1 : 0,
        
        'submitted_at' => date('Y-m-d H:i:s')
    ];
    
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("INSERT INTO id_applications (user_id, household_id, ref_number, program_linked, application_data, status, qr_code_path, photo_2x2_path, signature_path, created_at) VALUES (?, ?, ?, ?, ?, 'pending_verification', ?, ?, ?, NOW())");
        $stmt->execute([
            $user_id, 
            $household['id'] ?? null, 
            $ref_number, 
            $id_type_selected, 
            json_encode($application_data),
            $qr_path,
            $photo_2x2_path,
            $signature_path
        ]);
        
        $app_id = $pdo->lastInsertId();
        
        if($id_type_selected == 'solo_parent_id') {
            $stmt = $pdo->prepare("INSERT INTO solo_parent_registry (user_id, household_id, application_id, registry_no, status, qr_code_path, expiry_date) VALUES (?, ?, ?, ?, 'pending', ?, ?) 
                                   ON DUPLICATE KEY UPDATE application_id = VALUES(application_id), status = 'pending', updated_at = NOW()");
            $stmt->execute([$user_id, $household['id'] ?? null, $app_id, $registry_no, $qr_path, $expiry_date]);
        } elseif($id_type_selected == 'senior_citizen_id') {
            $stmt = $pdo->prepare("INSERT INTO senior_registry (user_id, household_id, application_id, registry_no, status, qr_code_path, expiry_date) VALUES (?, ?, ?, ?, 'pending', ?, ?) 
                                   ON DUPLICATE KEY UPDATE application_id = VALUES(application_id), status = 'pending', updated_at = NOW()");
            $stmt->execute([$user_id, $household['id'] ?? null, $app_id, $registry_no, $qr_path, $expiry_date]);
        } elseif($id_type_selected == 'pwd_id') {
            $disability_type = '';
            if(isset($approved_applications['pwd'])) {
                $pwd_data = json_decode($approved_applications['pwd']['application_data'], true);
                $disability_type = implode(', ', $pwd_data['type_of_disability'] ?? []);
            }
            $stmt = $pdo->prepare("INSERT INTO pwd_registry (user_id, household_id, application_id, registry_no, pwd_id_number, disability_type, status, qr_code_path, expiry_date) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?) 
                                   ON DUPLICATE KEY UPDATE application_id = VALUES(application_id), disability_type = VALUES(disability_type), status = 'pending', updated_at = NOW()");
            $stmt->execute([$user_id, $household['id'] ?? null, $app_id, $registry_no, $ref_number, $disability_type, $qr_path, $expiry_date]);
        }
        
        $stmt2 = $pdo->prepare("INSERT INTO welfare_applications (user_id, household_id, program_type, status, application_data, created_at) VALUES (?, ?, 'id_application', 'pending', ?, NOW())");
        $stmt2->execute([$user_id, $household['id'] ?? null, json_encode($application_data)]);
        
        $pdo->commit();
        
        $success = "Your ID application (Ref No: $ref_number) has been submitted successfully! Please wait for staff approval.";
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        $error = "Database error: " . $e->getMessage();
    }
}

$household_barangay = '';
$household_address = '';
if($household) {
    $household_barangay = $household['barangay'] ?? '';
    $household_address = $household['address'] ?? '';
}

$program_labels = [
    'solo_parent' => 'Solo Parent ID',
    'senior_citizen' => 'Senior Citizen ID',
    'pwd' => 'PWD ID'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>ID Application - MSWDO Cantilan</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <?= renderPwaMetaTags() ?>
  
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #F5F7FB; color: #1E2F4E; }
        :root {
            --primary: #1E4A8C; --primary-dark: #0A2F6C; --secondary: #D32F2F; --accent: #F5B042;
            --success: #059669; --white: #FFFFFF; --gray-50: #F8FAFC; --gray-100: #F1F5F9;
            --gray-200: #E2E8F0; --gray-300: #CBD5E1; --gray-400: #94A3B8; --gray-500: #64748B;
            --gray-600: #475569; --gray-700: #334155; --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05); --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --radius-sm: 0.5rem; --radius-md: 0.75rem; --radius-lg: 1rem; --radius-xl: 1.5rem; --radius-2xl: 2rem;
        }
        .app { display: flex; min-height: 100vh; }

        .sidebar {
            width: 280px; background: var(--white);
            border-right: 1px solid var(--gray-200);
            position: fixed; top: 0; left: 0; bottom: 0;
            overflow-y: auto; z-index: 40;
            transition: transform 0.3s ease;
        }
        .sidebar-header { padding: 28px 24px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 12px; }
        .logo-icon {
            width: 44px; height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1.1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.65rem; color: var(--gray-500); }
        .nav-menu { padding: 24px 16px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.7rem; font-weight: 600; text-transform: uppercase;
            color: var(--gray-400); margin-bottom: 12px; padding-left: 12px;
        }
        .nav-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 16px; margin-bottom: 4px;
            border-radius: var(--radius-md);
            color: var(--gray-600); text-decoration: none;
            transition: all 0.2s ease;
            position: relative;
        }
        .nav-item i { width: 20px; font-size: 1rem; color: var(--gray-400); }
        .nav-item span { font-size: 0.85rem; font-weight: 500; }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item:hover i { color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .nav-item .nav-badge {
            margin-left: auto;
            background: var(--secondary); color: white;
            font-size: 0.65rem; font-weight: 700;
            padding: 2px 8px; border-radius: 20px; line-height: 1.4;
        }
        .nav-item.collapsible { cursor: pointer; }
        .nav-item .dropdown-icon { margin-left: auto; transition: transform 0.3s ease; }
        .nav-item .dropdown-icon.rotated { transform: rotate(90deg); }
        .submenu {
            margin-left: 36px; overflow: hidden;
            max-height: 0; transition: max-height 0.3s ease;
        }
        .submenu.show { max-height: 300px; }
        .submenu-item {
            display: flex; align-items: center; gap: 12px;
            padding: 8px 16px; margin-bottom: 2px;
            border-radius: var(--radius-md);
            color: var(--gray-500); text-decoration: none; font-size: 0.8rem;
        }
        .submenu-item i { width: 16px; font-size: 0.8rem; color: var(--gray-400); }
        .submenu-item:hover { background: var(--gray-100); color: var(--primary); }
        .submenu-item.active { background: var(--primary); color: white; }

        .main-content { flex: 1; margin-left: 280px; padding: 32px 40px 80px 40px; }
        .top-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 32px; padding-bottom: 20px;
            border-bottom: 1px solid var(--gray-200);
        }
        .page-title h1 { font-size: 1.5rem; font-weight: 600; color: var(--gray-800); margin-bottom: 4px; }
        .page-title p { font-size: 0.8rem; color: var(--gray-500); }
        .user-menu {
            display: flex; align-items: center; gap: 16px;
            background: var(--gray-50);
            padding: 8px 16px 8px 20px;
            border-radius: 40px;
            border: 1px solid var(--gray-200);
        }
        .user-avatar {
            width: 36px; height: 36px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 1rem; }
        .user-info span { font-size: 0.85rem; font-weight: 500; color: var(--gray-700); }
        .user-info small { font-size: 0.65rem; color: var(--gray-400); }
        .logout-btn { color: var(--secondary); text-decoration: none; font-size: 0.9rem; }

        .form-card {
            background: var(--white);
            border-radius: var(--radius-2xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .form-header {
            padding: 28px 32px;
            background: var(--gray-50);
            border-bottom: 1px solid var(--gray-200);
            text-align: center;
        }
        .form-header i { font-size: 3rem; color: var(--accent); margin-bottom: 12px; }
        .form-header h2 { font-size: 1.3rem; font-weight: 700; color: var(--primary); margin-bottom: 6px; }
        .form-header p { font-size: 0.8rem; color: var(--gray-500); }
        .form-body { padding: 32px; }

        .step-progress {
            display: flex; justify-content: space-between;
            margin-bottom: 32px; padding: 0 20px; position: relative;
        }
        .step-progress::before {
            content: ''; position: absolute; top: 20px;
            left: 10%; right: 10%; height: 2px;
            background: var(--gray-200); z-index: 1;
        }
        .step { text-align: center; position: relative; z-index: 2; flex: 1; }
        .step-circle {
            width: 40px; height: 40px;
            background: var(--gray-200); border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 8px; font-weight: 700;
            color: var(--gray-600); transition: all 0.3s;
        }
        .step.active .step-circle { background: var(--secondary); color: white; }
        .step.completed .step-circle { background: var(--success); color: white; }
        .step-label { font-size: 0.65rem; color: var(--gray-500); }
        .step.active .step-label { color: var(--secondary); font-weight: 600; }
        
        .form-section { display: none; animation: fadeIn 0.3s ease; }
        .form-section.active-section { display: block; }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        .section-title {
            display: flex; align-items: center; gap: 12px; margin-bottom: 24px;
        }
        .section-icon {
            width: 40px; height: 40px;
            background: var(--gray-100); border-radius: var(--radius-md);
            display: flex; align-items: center; justify-content: center;
        }
        .section-icon i { font-size: 1.2rem; color: var(--accent); }
        .section-title h3 { font-size: 1.1rem; font-weight: 600; color: var(--gray-800); }
        .form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 16px; }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block; font-size: 0.75rem; font-weight: 600;
            color: var(--gray-600); margin-bottom: 6px;
        }
        .form-group label i { margin-right: 6px; color: var(--accent); font-size: 0.7rem; }
        .required { color: var(--secondary); }
        input, select, textarea {
            width: 100%; padding: 12px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s ease;
            background: var(--white);
        }
        input:focus, select:focus, textarea:focus {
            border-color: var(--accent); outline: none;
            box-shadow: 0 0 0 3px rgba(245,176,66,0.15);
        }
        textarea { resize: vertical; min-height: 80px; }
        
        .camera-btn {
            background: var(--gray-100);
            border: 1.5px dashed var(--gray-300);
            padding: 12px; border-radius: var(--radius-md);
            text-align: center; cursor: pointer;
            transition: all 0.2s;
        }
        .camera-btn:hover { border-color: var(--accent); background: var(--gray-50); }
        .camera-btn i { font-size: 1.5rem; color: var(--accent); margin-bottom: 5px; display: block; }
        .camera-btn span { font-size: 0.7rem; color: var(--gray-500); }
        .file-name { font-size: 0.7rem; color: var(--gray-500); margin-top: 5px; text-align: center; }
        .photo-preview { width: 100px; height: 100px; object-fit: cover; border-radius: var(--radius-md); margin-top: 10px; }
        
        .signature-pad {
            border: 2px dashed var(--gray-300);
            border-radius: var(--radius-lg);
            background: var(--white);
            touch-action: none;
            cursor: crosshair;
        }
        .signature-pad canvas {
            width: 100%; height: 150px;
            border-radius: var(--radius-lg);
        }
        .signature-actions { display: flex; gap: 10px; margin-top: 10px; }
        .btn-clear {
            background: var(--gray-200); color: var(--gray-700);
            border: none; padding: 8px 16px;
            border-radius: var(--radius-md); cursor: pointer; font-size: 0.75rem;
        }
        
        .info-note {
            background: #FFF9EF; padding: 10px 14px;
            border-radius: var(--radius-md); font-size: 0.7rem;
            color: #7B5E2A; margin-top: 8px;
        }
        .eligible-badge {
            background: #D1FAE5; color: #065F46;
            padding: 4px 12px; border-radius: 20px;
            font-size: 0.7rem; display: inline-block; margin-left: 8px;
        }
        
        .nav-buttons {
            display: flex; justify-content: space-between;
            margin-top: 32px; gap: 16px;
        }
        .btn-prev, .btn-next, .btn-submit {
            padding: 12px 24px; border-radius: var(--radius-md);
            font-weight: 600; cursor: pointer;
            transition: all 0.2s; border: none;
            display: inline-flex; align-items: center; gap: 8px;
        }
        .btn-prev {
            background: var(--gray-100); color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }
        .btn-prev:hover { background: var(--gray-200); }
        .btn-next, .btn-submit { background: var(--primary); color: white; }
        .btn-next:hover, .btn-submit:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }
        .alert {
            padding: 16px 20px; border-radius: var(--radius-lg);
            margin-bottom: 24px; display: flex; align-items: center; gap: 12px;
        }
        .alert-success { background: #ECFDF5; border-left: 3px solid #059669; color: #065F46; }
        .alert-danger { background: #FEF2F2; border-left: 3px solid var(--secondary); color: #991B1B; }
        .alert-info { background: #FFF9EF; border-left: 3px solid var(--accent); color: #7B5E2A; }
        .info-text { font-size: 0.7rem; color: var(--gray-500); margin-top: 4px; }
        .case-badge {
            background: var(--primary); color: white;
            padding: 4px 12px; border-radius: 20px;
            font-size: 0.7rem; display: inline-block; margin-bottom: 16px;
        }
        hr { margin: 20px 0; border: 0; height: 1px; background: var(--gray-200); }
        .menu-toggle {
            display: none; background: none; border: none;
            font-size: 1.3rem; color: var(--gray-700);
            cursor: pointer; padding: 8px; border-radius: var(--radius-md);
        }
        .qr-preview {
            text-align: center; padding: 15px;
            background: var(--gray-50); border-radius: var(--radius-lg);
            margin-top: 15px;
        }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.3s ease; }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 20px; }
            .menu-toggle { display: block; }
            .form-row { grid-template-columns: 1fr; gap: 0; }
            .form-body { padding: 20px; }
            .top-header { flex-direction: column; gap: 16px; align-items: flex-start; }
            .step-label { font-size: 0.5rem; }
            .step-circle { width: 30px; height: 30px; font-size: 0.8rem; }
        }
    </style>
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Municipal Social Welfare</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="dashboards/resident_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Dashboard</span></a>
                <a href="<?php echo ($sidebar_household_id) ? 'modules/household_data.php?view=' . $sidebar_household_id : 'modules/household_form.php'; ?>" class="nav-item"><i class="fas fa-users"></i><span>Household Profile</span></a>
                <a href="modules/my_applications.php" class="nav-item"><i class="fas fa-file-alt"></i><span>My Applications</span></a>
                <a href="notifications.php" class="nav-item">
                    <i class="fas fa-bell"></i><span>Notifications</span>
                    <?php if($unread_notif_count > 0): ?>
                        <span class="nav-badge"><?php echo $unread_notif_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Services</div>
                
                <div class="nav-item" id="programToggle">
                    <i class="fas fa-folder"></i><span>Program</span>
                    <i class="fas fa-chevron-right dropdown-icon" id="programIcon"></i>
                </div>
                <div class="submenu" id="programSubmenu">
                    <a href="soloparent.php" class="submenu-item"><i class="fas fa-female"></i><span>Solo Parent</span></a>
                    <a href="seniorcitizen.php" class="submenu-item"><i class="fas fa-user-graduate"></i><span>Senior Citizen</span></a>
                    <a href="pwd.php" class="submenu-item"><i class="fas fa-wheelchair"></i><span>PWD</span></a>
                    <a href="aics.php" class="submenu-item"><i class="fas fa-coins"></i><span>AICS</span></a>
                    <a href="vawc.php" class="submenu-item"><i class="fas fa-shield-alt"></i><span>VAWC</span></a>
                </div>

                <a href="modules/survey_form.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Community Survey</span></a>
                <a href="id_application.php" class="nav-item active"><i class="fas fa-id-card"></i><span>ID Application</span></a>
            </div>

            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="profile_settings.php" class="nav-item"><i class="fas fa-user-circle"></i><span>Profile Settings</span></a>
                <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-header">
            <div>
                <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
                <div class="page-title">
                    <h1>ID Application</h1>
                    <p>Apply for MSWDO-issued identification cards | Digital ID System</p>
                </div>
            </div>
            <div class="user-menu">
                <div class="user-avatar"><i class="fas fa-user"></i></div>
                <div class="user-info"><span><?php echo htmlspecialchars($full_name); ?></span><small><?php echo ucfirst($role); ?></small></div>
                <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <i class="fas fa-id-card"></i>
                <h2>ID Application Form</h2>
                <p>5-Step Mobile Form Wizard | Digital ID Application with QR Code Verification</p>
            </div>

            <div class="form-body">
                <?php if($success): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> <strong>Application Reference Number:</strong> <?php echo $ref_number; ?><br>
                        <strong>Registry Number:</strong> <?php echo $registry_no; ?><br>
                        You can check your application status in "My Applications" page.
                    </div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($error): ?>
                    <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php elseif($existing_app && !$success): ?>
                    <div class="alert alert-info"><i class="fas fa-clock"></i> You already have a pending ID application. Please wait for processing.</div>
                    <div class="info-note">Application Status: <?php echo ucfirst(str_replace('_', ' ', $existing_app['status'])); ?></div>
                    <a href="dashboards/resident_dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                <?php else: ?>
                
                <div class="step-progress">
                    <div class="step active" id="step1Indicator"><div class="step-circle">1</div><div class="step-label">System Metadata</div></div>
                    <div class="step" id="step2Indicator"><div class="step-circle">2</div><div class="step-label">Personal Info</div></div>
                    <div class="step" id="step3Indicator"><div class="step-circle">3</div><div class="step-label">ID Details</div></div>
                    <div class="step" id="step4Indicator"><div class="step-circle">4</div><div class="step-label">Photo & Signature</div></div>
                    <div class="step" id="step5Indicator"><div class="step-circle">5</div><div class="step-label">Verification</div></div>
                </div>

                <form method="POST" enctype="multipart/form-data" id="idApplicationForm">
                    <input type="hidden" name="apply" value="1">
                    <input type="hidden" name="latitude" id="gps_latitude">
                    <input type="hidden" name="longitude" id="gps_longitude">
                    <input type="hidden" name="client_signature" id="client_signature" value="">

                    <div class="form-section active-section" id="step1">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-microchip"></i></div>
                            <h3>Step 1: System-Generated Metadata</h3>
                        </div>
                        <div class="case-badge"><i class="fas fa-qrcode"></i> Reference Number: <?php echo $ref_number; ?></div>
                        <div class="case-badge" style="background: var(--success);"><i class="fas fa-database"></i> Registry No: <?php echo $registry_no; ?></div>
                        <div class="form-row">
                            <div class="form-group">
                                <label><i class="fas fa-calendar"></i> Submission Date & Time</label>
                                <input type="text" value="<?php echo date('Y-m-d H:i:s'); ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label><i class="fas fa-map-marker-alt"></i> GPS Location</label>
                                <input type="text" id="gps_status" value="Detecting location..." disabled>
                                <div class="info-text"><i class="fas fa-sync-alt"></i> Automatically captured from device</div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-globe"></i> Region / Barangay</label>
                            <input type="text" id="barangay_auto" placeholder="Auto-detecting from GPS..." disabled>
                        </div>
                        <div class="info-note">
                            <i class="fas fa-info-circle"></i> <strong>ID Validity Periods:</strong><br>
                            Senior Citizen ID: Lifetime<br>
                            Solo Parent ID: 1 Year (Renewable)<br>
                            PWD ID: 5 Years<br>
                            Other IDs: 3 Years
                        </div>
                    </div>

                    <div class="form-section" id="step2">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-id-card"></i></div>
                            <h3>Step 2: Personal Information</h3>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>First Name <span class="required">*</span></label><input type="text" name="first_name" value="<?php echo htmlspecialchars(explode(' ', $full_name)[0] ?? ''); ?>" required></div>
                            <div class="form-group"><label>Middle Name</label><input type="text" name="middle_name"></div>
                            <div class="form-group"><label>Last Name <span class="required">*</span></label><input type="text" name="last_name" value="<?php echo htmlspecialchars(explode(' ', $full_name)[count(explode(' ', $full_name))-1] ?? ''); ?>" required></div>
                            <div class="form-group"><label>Suffix</label><input type="text" name="suffix" placeholder="Jr., Sr., III"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Birthdate</label><input type="date" name="birthdate" id="birthdate" onchange="calculateAge()"></div>
                            <div class="form-group"><label>Place of Birth</label><input type="text" name="place_of_birth"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Sex</label><select name="sex"><option value="">Select</option><option>Male</option><option>Female</option></select></div>
                            <div class="form-group"><label>Civil Status</label><select name="civil_status"><option value="">Select</option><option>Single</option><option>Married</option><option>Widowed</option><option>Separated</option></select></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group"><label>Occupation</label><input type="text" name="occupation"></div>
                            <div class="form-group"><label>Monthly Income (₱)</label><input type="number" name="monthly_income" step="500"></div>
                        </div>
                        <div class="form-group"><label>Contact Number <span class="required">*</span></label><input type="text" name="contact_number" value="<?php echo htmlspecialchars($user_data['contact_number'] ?? ''); ?>" required></div>
                        <div class="form-group"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>"></div>
                        <div class="form-group"><label>Complete Address</label><input type="text" name="address" value="<?php echo htmlspecialchars($household_address); ?>"></div>
                        <div class="form-group"><label>Barangay <span class="required">*</span></label><input type="text" name="barangay" value="<?php echo htmlspecialchars($household_barangay); ?>" required></div>
                    </div>

                    <div class="form-section" id="step3">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-id-card"></i></div>
                            <h3>Step 3: ID Details</h3>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> Type of ID Requested <span class="required">*</span></label>
                            <select name="id_type" id="idType" required>
                                <option value="">Select ID Type</option>
                                <optgroup label="Program-Based IDs (Eligibility Required)">
                                    <option value="solo_parent_id" <?php echo in_array('solo_parent', $eligible_programs) ? '' : 'disabled'; ?>>
                                        Solo Parent ID <?php echo in_array('solo_parent', $eligible_programs) ? '✓ Eligible' : '(Apply for Solo Parent first)'; ?>
                                    </option>
                                    <option value="senior_citizen_id" <?php echo in_array('senior_citizen', $eligible_programs) ? '' : 'disabled'; ?>>
                                        Senior Citizen ID <?php echo in_array('senior_citizen', $eligible_programs) ? '✓ Eligible' : '(Apply for Senior Citizen first)'; ?>
                                    </option>
                                    <option value="pwd_id" <?php echo in_array('pwd', $eligible_programs) ? '' : 'disabled'; ?>>
                                        PWD ID <?php echo in_array('pwd', $eligible_programs) ? '✓ Eligible' : '(Apply for PWD first)'; ?>
                                    </option>
                                </optgroup>
                                <optgroup label="General IDs">
                                    <option value="mswdo_id">MSWDO ID Card</option>
                                    <option value="replacement">Replacement of Lost ID</option>
                                    <option value="other">Other</option>
                                </optgroup>
                            </select>
                            <?php if(empty($eligible_programs)): ?>
                                <div class="info-text"><i class="fas fa-info-circle"></i> To apply for a program-based ID (Solo Parent, Senior Citizen, or PWD), please complete the corresponding program application first.</div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group" id="otherIdGroup" style="display: none;">
                            <label>Please specify</label>
                            <input type="text" name="id_type_other">
                        </div>
                        
                        <div class="form-group">
                            <label>Previous ID Number (if renewal/replacement)</label>
                            <input type="text" name="previous_id_number" placeholder="Enter previous ID number">
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-question-circle"></i> Reason for Application <span class="required">*</span></label>
                            <select name="reason_for_application" id="reasonSelect" onchange="toggleReasonFields()" required>
                                <option value="">Select reason</option>
                                <option value="first_time">First time applicant</option>
                                <option value="lost">Lost ID</option>
                                <option value="damaged">Damaged ID</option>
                                <option value="renewal">Renewal</option>
                                <option value="update">Update information</option>
                            </select>
                        </div>
                        
                        <div id="lostReasonDiv" style="display: none;">
                            <div class="form-group">
                                <label>Lost ID Details</label>
                                <textarea name="lost_reason" rows="2" placeholder="Explain how the ID was lost, when and where..."></textarea>
                            </div>
                        </div>
                        <div id="lostReportDiv" style="display: none;">
                            <div class="form-group">
                                <label>Affidavit of Loss / Barangay Report Number</label>
                                <input type="text" name="lost_report_number" placeholder="If available">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-id-card"></i> Do you have any government-issued ID?</label>
                            <select name="government_issued_id">
                                <option value="">Select</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Valid ID Type</label>
                                <input type="text" name="valid_id_type" placeholder="e.g., Passport, Driver's License, UMID">
                            </div>
                            <div class="form-group">
                                <label>ID Number</label>
                                <input type="text" name="valid_id_number">
                            </div>
                        </div>
                    </div>

                    <div class="form-section" id="step4">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-camera"></i></div>
                            <h3>Step 4: Photo & Signature Capture</h3>
                            <p style="font-size: 0.65rem; color: var(--gray-500);">These images will be printed on your ID card</p>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-camera-retro"></i> 2x2 ID Picture <span class="required">*</span></label>
                            <div class="camera-btn" onclick="document.getElementById('photo_2x2').click()">
                                <i class="fas fa-camera"></i>
                                <span>Capture 2x2 Photo (Front Camera)</span>
                            </div>
                            <input type="file" id="photo_2x2" name="photo_2x2" accept="image/*" style="display:none" onchange="previewPhoto2x2(this)">
                            <div id="photo2x2Preview"></div>
                            <div class="info-text">Please ensure your face is clearly visible against a plain background</div>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-signature"></i> Digital Signature <span class="required">*</span></label>
                            <div class="signature-pad" id="signaturePad">
                                <canvas id="signatureCanvas" width="500" height="150" style="width:100%; height:150px; border:1px solid var(--gray-200); border-radius:12px;"></canvas>
                            </div>
                            <div class="signature-actions">
                                <button type="button" class="btn-clear" onclick="clearSignature()"><i class="fas fa-eraser"></i> Clear Signature</button>
                            </div>
                            <div class="info-text">Draw your signature using your finger or stylus. This will be printed on the back of your ID.</div>
                        </div>
                    </div>

                    <div class="form-section" id="step5">
                        <div class="section-title">
                            <div class="section-icon"><i class="fas fa-shield-alt"></i></div>
                            <h3>Step 5: Verification & Submit</h3>
                        </div>
                        
                        <div class="form-group">
                            <label><input type="checkbox" name="client_consent" value="1" required> I certify that the information provided is true and correct. I understand that any false statement may result in the denial of my application.</label>
                        </div>
                        
                        <div class="form-group">
                            <label><input type="checkbox" name="declaration_agreed" value="1" required> I agree to the collection and processing of my personal data for ID issuance purposes.</label>
                        </div>
                        
                        <div class="verification-info" style="background: var(--gray-50); border-radius: var(--radius-lg); padding: 16px; margin: 16px 0;">
                            <p><i class="fas fa-qrcode"></i> <strong>QR Code Verification System</strong></p>
                            <p>A unique QR code will be embedded on your ID card. When scanned, it will display your live verification status on the MSWDO portal to prevent fake ID usage for discounts.</p>
                            <div class="qr-preview">
                                <i class="fas fa-qrcode" style="font-size: 3rem; color: var(--primary);"></i>
                                <p style="font-size: 0.7rem; margin-top: 8px;">Your unique QR code will be generated upon approval</p>
                                <p style="font-size: 0.65rem; color: var(--gray-500);">Verification URL: <?php echo $verification_url; ?></p>
                            </div>
                        </div>
                        
                        <div class="info-note">
                            <i class="fas fa-info-circle"></i> <strong>ID Claim Instructions:</strong><br>
                            1. Wait for approval notification (SMS/Email)<br>
                            2. Application Status will change to "Approved: ID Printed"<br>
                            3. Bring a valid ID and the reference number <?php echo $ref_number; ?><br>
                            4. Claim your ID at the MSWDO office
                        </div>
                        
                        <div class="info-note">
                            <i class="fas fa-chart-line"></i> <strong>Application Status Flow:</strong><br>
                            Pending Verification → For Board Review → Approved: ID Printed → Claimed
                        </div>
                    </div>

                    <div class="nav-buttons">
                        <button type="button" class="btn-prev" id="prevBtn" onclick="changeStep(-1)" style="display:none;"><i class="fas fa-chevron-left"></i> Previous</button>
                        <button type="button" class="btn-next" id="nextBtn" onclick="changeStep(1)">Next <i class="fas fa-chevron-right"></i></button>
                        <button type="submit" class="btn-submit" id="submitBtn" style="display:none;"><i class="fas fa-paper-plane"></i> SUBMIT ID APPLICATION</button>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<script>
    let currentStep = 1;
    const totalSteps = 5;
    
    function getLocation() {
        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                document.getElementById('gps_latitude').value = position.coords.latitude;
                document.getElementById('gps_longitude').value = position.coords.longitude;
                document.getElementById('gps_status').value = `Lat: ${position.coords.latitude.toFixed(6)}, Lng: ${position.coords.longitude.toFixed(6)}`;
                
                fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${position.coords.latitude}&lon=${position.coords.longitude}&zoom=18&addressdetails=1`)
                    .then(response => response.json())
                    .then(data => {
                        if(data.address && data.address.village) {
                            document.getElementById('barangay_auto').value = data.address.village;
                            document.querySelector('input[name="barangay"]').value = data.address.village;
                        }
                    })
                    .catch(() => {});
            });
        }
    }
    getLocation();
    
    function calculateAge() {
        const birthdate = document.getElementById('birthdate').value;
        if(birthdate) {
            const today = new Date();
            const birth = new Date(birthdate);
            let age = today.getFullYear() - birth.getFullYear();
            const m = today.getMonth() - birth.getMonth();
            if(m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
        }
    }
    
    function toggleReasonFields() {
        let reason = document.getElementById('reasonSelect').value;
        let lostReasonDiv = document.getElementById('lostReasonDiv');
        let lostReportDiv = document.getElementById('lostReportDiv');
        if(reason === 'lost' || reason === 'damaged') {
            lostReasonDiv.style.display = 'block';
            lostReportDiv.style.display = 'block';
        } else {
            lostReasonDiv.style.display = 'none';
            lostReportDiv.style.display = 'none';
        }
    }
    
    function previewPhoto2x2(input) {
        const previewDiv = document.getElementById('photo2x2Preview');
        if(input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewDiv.innerHTML = `<img src="${e.target.result}" class="photo-preview" alt="2x2 Photo"><div class="info-text">Photo captured successfully</div>`;
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    const idType = document.getElementById('idType');
    const otherIdGroup = document.getElementById('otherIdGroup');
    if(idType) {
        idType.addEventListener('change', function() {
            otherIdGroup.style.display = this.value === 'other' ? 'block' : 'none';
        });
    }
    
    let canvas = document.getElementById('signatureCanvas');
    let ctx = canvas.getContext('2d');
    let drawing = false;
    
    function resizeCanvas() {
        const container = canvas.parentElement;
        canvas.width = container.clientWidth;
        canvas.height = 150;
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#1E4A8C';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
    }
    
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    
    function startDrawing(e) {
        drawing = true;
        const pos = getCanvasCoordinates(e);
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
    }
    
    function draw(e) {
        if(!drawing) return;
        const pos = getCanvasCoordinates(e);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
    }
    
    function stopDrawing() {
        drawing = false;
        ctx.beginPath();
        document.getElementById('client_signature').value = canvas.toDataURL();
    }
    
    function getCanvasCoordinates(e) {
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        let clientX, clientY;
        if(e.touches) {
            clientX = e.touches[0].clientX;
            clientY = e.touches[0].clientY;
        } else {
            clientX = e.clientX;
            clientY = e.clientY;
        }
        let x = (clientX - rect.left) * scaleX;
        let y = (clientY - rect.top) * scaleY;
        x = Math.min(Math.max(0, x), canvas.width);
        y = Math.min(Math.max(0, y), canvas.height);
        return { x, y };
    }
    
    function clearSignature() {
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        document.getElementById('client_signature').value = '';
    }
    
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);
    canvas.addEventListener('touchstart', startDrawing);
    canvas.addEventListener('touchmove', draw);
    canvas.addEventListener('touchend', stopDrawing);
    
    function changeStep(direction) {
        const sections = document.querySelectorAll('.form-section');
        const steps = document.querySelectorAll('.step');
        
        sections[currentStep - 1].classList.remove('active-section');
        steps[currentStep - 1].classList.remove('active');
        steps[currentStep - 1].classList.add('completed');
        
        currentStep += direction;
        
        sections[currentStep - 1].classList.add('active-section');
        steps[currentStep - 1].classList.add('active');
        
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');
        
        if(currentStep === 1) prevBtn.style.display = 'none';
        else prevBtn.style.display = 'inline-flex';
        
        if(currentStep === totalSteps) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-flex';
        } else {
            nextBtn.style.display = 'inline-flex';
            submitBtn.style.display = 'none';
        }
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    if(menuToggle) {
        menuToggle.addEventListener('click', function() { sidebar.classList.toggle('open'); });
    }
    document.addEventListener('click', function(event) {
        if(window.innerWidth <= 768) {
            if(!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
    
    const programToggle = document.getElementById('programToggle');
    const programSubmenu = document.getElementById('programSubmenu');
    const programIcon = document.getElementById('programIcon');
    if(programToggle) {
        programToggle.addEventListener('click', function() {
            programSubmenu.classList.toggle('show');
            programIcon.classList.toggle('rotated');
        });
    }
</script>

   <?= renderPwaServiceWorker() ?>
</body>
</html>