<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];
$error = '';
$success = '';

// Create system_settings table if not exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(100) NOT NULL UNIQUE,
        setting_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    // Insert default VAWC PIN if not exists
    $stmt = $pdo->prepare("INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES ('vawc_security_pin', '2024')");
    $stmt->execute();
} catch(PDOException $e) {
    // Table might already exist
}

// Get current PIN
$stmt = $pdo->query("SELECT setting_value FROM system_settings WHERE setting_key = 'vawc_security_pin'");
$current = $stmt->fetch();
$current_pin = $current ? $current['setting_value'] : '2024';

// Update PIN
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_pin'])) {
    $new_pin = $_POST['vawc_pin'];
    if(strlen($new_pin) == 4 && is_numeric($new_pin)) {
        $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES ('vawc_security_pin', ?) 
                               ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$new_pin, $new_pin]);
        $success = "VAWC Security PIN updated successfully!";
        $current_pin = $new_pin;
    } else {
        $error = "PIN must be exactly 4 digits.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VAWC Security Settings - Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 10px; }
        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-icon i { font-size: 1.2rem; color: var(--accent); }
        .logo-text h1 { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.6rem; color: var(--gray-500); }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--gray-500);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
        }
        .nav-item i { width: 20px; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        .top-bar {
            background: var(--white);
            padding: 12px 20px;
            border-radius: var(--radius-lg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
        }
        .page-title h1 { font-size: 1.3rem; font-weight: 600; color: var(--gray-800); }
        .page-title p { font-size: 0.7rem; color: var(--gray-500); margin-top: 2px; }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            background: var(--gray-50);
            padding: 6px 12px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 500; }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .settings-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        }
        .card-header {
            background: var(--gray-50);
            padding: 20px 24px;
            border-bottom: 1px solid var(--gray-200);
            text-align: center;
        }
        .card-header i {
            font-size: 2.5rem;
            color: var(--secondary);
            margin-bottom: 8px;
        }
        .card-header h2 {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--gray-800);
        }
        .card-header p {
            font-size: 0.7rem;
            color: var(--gray-500);
        }
        .card-body {
            padding: 24px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-600);
            margin-bottom: 6px;
        }
        .form-group label i {
            margin-right: 6px;
            color: var(--secondary);
        }
        input {
            width: 100%;
            padding: 12px 14px;
            border: 1.5px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        input:focus {
            border-color: var(--accent);
            outline: none;
            box-shadow: 0 0 0 3px rgba(245,176,66,0.15);
        }
        input:disabled {
            background: var(--gray-50);
            color: var(--gray-500);
        }
        .btn-primary {
            width: 100%;
            background: var(--primary);
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }
        .alert {
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85rem;
        }
        .alert-success {
            background: #ECFDF5;
            border-left: 4px solid #059669;
            color: #065F46;
        }
        .alert-danger {
            background: #FEF2F2;
            border-left: 4px solid var(--secondary);
            color: #991B1B;
        }
        .info-box {
            background: #FFF9EF;
            border-left: 4px solid var(--accent);
            padding: 16px;
            border-radius: var(--radius-lg);
            margin-top: 20px;
        }
        .info-box p {
            font-size: 0.75rem;
            color: #7B5E2A;
            margin-bottom: 8px;
        }
        hr {
            margin: 20px 0;
            border: 0;
            height: 1px;
            background: var(--gray-200);
        }
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.7rem;
            color: var(--gray-600);
            text-decoration: none;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        @media (max-width: 768px) {
            .main-content { padding: 20px; }
            .card-header { padding: 16px; }
            .card-body { padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-hand-holding-heart"></i></div>
                <div class="logo-text"><h1>MSWDO Portal</h1><p>Administrator</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="../modules/manage_users.php" class="nav-item"><i class="fas fa-users-cog"></i> User Management</a>
                <a href="../modules/admin_household.php" class="nav-item"><i class="fas fa-home"></i> All Households</a>
                <a href="../modules/admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="../modules/admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i> Poverty Analysis</a>
                <a href="recycle_bin.php" class="nav-item"><i class="fas fa-trash-restore"></i> Recycle Bin</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Security</div>
                <a href="admin_vawc_settings.php" class="nav-item active"><i class="fas fa-shield-alt"></i> VAWC Security Settings</a>
            </div>
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../modules/admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>VAWC Security Settings</h1>
                <p>Manage the secure access PIN for the VAWC confidential module</p>
            </div>
            <a href="../modules/admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <div class="container">
            <div class="settings-card">
                <div class="card-header">
                    <i class="fas fa-shield-alt"></i>
                    <h2>VAWC Module Security PIN</h2>
                    <p>This PIN is required to access the confidential VAWC application form</p>
                </div>
                <div class="card-body">
                    <?php if($success): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <?php endif; ?>
                    <?php if($error): ?>
                        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="form-group">
                            <label><i class="fas fa-lock"></i> Current VAWC Security PIN</label>
                            <input type="text" value="<?php echo $current_pin; ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-key"></i> New VAWC Security PIN (4 digits)</label>
                            <input type="password" name="vawc_pin" maxlength="4" pattern="[0-9]{4}" required placeholder="Enter 4-digit PIN">
                            <div class="info-text" style="font-size: 0.7rem; color: var(--gray-500); margin-top: 4px;">PIN must be exactly 4 numeric digits</div>
                        </div>
                        <button type="submit" name="update_pin" class="btn-primary"><i class="fas fa-save"></i> Update Security PIN</button>
                    </form>

                    <hr>

                    <div class="info-box">
                        <p><i class="fas fa-info-circle"></i> <strong>Important Information:</strong></p>
                        <p>• Share this PIN only with authorized VAWC social workers and officers.</p>
                        <p>• The PIN is required to access the confidential VAWC application module.</p>
                        <p>• Change the PIN regularly for better security.</p>
                        <p>• If the PIN is lost or forgotten, you can reset it here.</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="../modules/manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="../modules/admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="../modules/admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="admin_vawc_settings.php" class="nav-item active"><i class="fas fa-shield-alt"></i><span>VAWC Settings</span></a>
        <a href="../modules/admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };
    </script>
</body>
</html>