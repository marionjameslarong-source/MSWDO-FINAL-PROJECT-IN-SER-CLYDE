<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$full_name = $_SESSION['full_name'];
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];

// Get deleted count for badge display
$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
$total_deleted_global = $stmt->fetch()['total'];

// Handle restore
if(isset($_GET['restore_id'])) {
    $restore_id = $_GET['restore_id'];
    
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("SELECT * FROM deleted_households WHERE id = ? AND permanent_deleted_at IS NULL");
        $stmt->execute([$restore_id]);
        $deleted_household = $stmt->fetch();
        
        if($deleted_household) {
            $stmt = $pdo->prepare("SELECT id FROM households WHERE id = ?");
            $stmt->execute([$deleted_household['original_id']]);
            $existing = $stmt->fetch();
            
            if($existing) {
                $stmt = $pdo->prepare("INSERT INTO households 
                    (head_first_name, head_last_name, barangay, address, 
                     monthly_income, total_members, is_4ps_beneficiary, 
                     gps_latitude, gps_longitude, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->execute([
                    $deleted_household['head_first_name'],
                    $deleted_household['head_last_name'],
                    $deleted_household['barangay'],
                    $deleted_household['address'],
                    $deleted_household['monthly_income'],
                    $deleted_household['total_members'],
                    $deleted_household['is_4ps_beneficiary'],
                    $deleted_household['gps_latitude'],
                    $deleted_household['gps_longitude']
                ]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO households 
                    (id, head_first_name, head_last_name, barangay, address, 
                     monthly_income, total_members, is_4ps_beneficiary, 
                     gps_latitude, gps_longitude, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $deleted_household['original_id'],
                    $deleted_household['head_first_name'],
                    $deleted_household['head_last_name'],
                    $deleted_household['barangay'],
                    $deleted_household['address'],
                    $deleted_household['monthly_income'],
                    $deleted_household['total_members'],
                    $deleted_household['is_4ps_beneficiary'],
                    $deleted_household['gps_latitude'],
                    $deleted_household['gps_longitude'],
                    $deleted_household['created_at']
                ]);
            }
            
            $stmt = $pdo->prepare("UPDATE deleted_households SET restored_at = NOW(), restored_by = ? WHERE id = ?");
            $stmt->execute([$user_id, $restore_id]);
        }
        
        $pdo->commit();
        header("Location: recycle_bin.php?restored=1");
        exit();
        
    } catch(Exception $e) {
        $pdo->rollBack();
        header("Location: recycle_bin.php?error=1");
        exit();
    }
}

// Handle permanent delete
if(isset($_GET['permanent_delete_id'])) {
    $delete_id = $_GET['permanent_delete_id'];
    
    try {
        $stmt = $pdo->prepare("UPDATE deleted_households SET permanent_deleted_at = NOW() WHERE id = ?");
        $stmt->execute([$delete_id]);
        header("Location: recycle_bin.php?permanent_deleted=1");
        exit();
    } catch(Exception $e) {
        header("Location: recycle_bin.php?error=1");
        exit();
    }
}

// Handle bulk restore
if(isset($_POST['bulk_restore']) && isset($_POST['selected_ids'])) {
    $selected_ids = $_POST['selected_ids'];
    $success_count = 0;
    
    try {
        $pdo->beginTransaction();
        
        foreach($selected_ids as $restore_id) {
            $stmt = $pdo->prepare("SELECT * FROM deleted_households WHERE id = ? AND permanent_deleted_at IS NULL");
            $stmt->execute([$restore_id]);
            $deleted_household = $stmt->fetch();
            
            if($deleted_household) {
                $stmt = $pdo->prepare("INSERT INTO households 
                    (id, head_first_name, head_last_name, barangay, address, 
                     monthly_income, total_members, is_4ps_beneficiary, 
                     gps_latitude, gps_longitude, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE 
                    head_first_name = VALUES(head_first_name),
                    head_last_name = VALUES(head_last_name),
                    barangay = VALUES(barangay),
                    address = VALUES(address),
                    monthly_income = VALUES(monthly_income),
                    total_members = VALUES(total_members),
                    is_4ps_beneficiary = VALUES(is_4ps_beneficiary),
                    gps_latitude = VALUES(gps_latitude),
                    gps_longitude = VALUES(gps_longitude)");
                $stmt->execute([
                    $deleted_household['original_id'],
                    $deleted_household['head_first_name'],
                    $deleted_household['head_last_name'],
                    $deleted_household['barangay'],
                    $deleted_household['address'],
                    $deleted_household['monthly_income'],
                    $deleted_household['total_members'],
                    $deleted_household['is_4ps_beneficiary'],
                    $deleted_household['gps_latitude'],
                    $deleted_household['gps_longitude'],
                    $deleted_household['created_at']
                ]);
                
                $stmt = $pdo->prepare("UPDATE deleted_households SET restored_at = NOW(), restored_by = ? WHERE id = ?");
                $stmt->execute([$user_id, $restore_id]);
                $success_count++;
            }
        }
        
        $pdo->commit();
        header("Location: recycle_bin.php?bulk_restored=" . $success_count);
        exit();
        
    } catch(Exception $e) {
        $pdo->rollBack();
        header("Location: recycle_bin.php?error=1");
        exit();
    }
}

// Handle bulk permanent delete
if(isset($_POST['bulk_permanent_delete']) && isset($_POST['selected_ids'])) {
    $selected_ids = $_POST['selected_ids'];
    
    try {
        $pdo->beginTransaction();
        $placeholders = implode(',', array_fill(0, count($selected_ids), '?'));
        $stmt = $pdo->prepare("UPDATE deleted_households SET permanent_deleted_at = NOW() WHERE id IN ($placeholders)");
        $stmt->execute($selected_ids);
        $pdo->commit();
        header("Location: recycle_bin.php?bulk_permanent_deleted=" . count($selected_ids));
        exit();
        
    } catch(Exception $e) {
        $pdo->rollBack();
        header("Location: recycle_bin.php?error=1");
        exit();
    }
}

// Get search and filter parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$barangay_filter = isset($_GET['barangay']) ? trim($_GET['barangay']) : '';

// Build query
$query = "SELECT * FROM deleted_households WHERE permanent_deleted_at IS NULL";
$params = [];

if(!empty($search)) {
    $query .= " AND (head_first_name LIKE ? OR head_last_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if(!empty($barangay_filter)) {
    $query .= " AND barangay = ?";
    $params[] = $barangay_filter;
}

$query .= " ORDER BY deleted_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$deleted_households = $stmt->fetchAll();

// Get statistics
$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NULL");
$total_deleted = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE restored_at IS NOT NULL");
$total_restored = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM deleted_households WHERE permanent_deleted_at IS NOT NULL");
$total_permanently_deleted = $stmt->fetch()['total'];

// Get unique barangays from deleted households
$stmt = $pdo->query("SELECT DISTINCT barangay FROM deleted_households WHERE barangay IS NOT NULL AND barangay != '' AND permanent_deleted_at IS NULL ORDER BY barangay");
$barangays = $stmt->fetchAll();

// Get message variables
$restored = isset($_GET['restored']);
$permanent_deleted = isset($_GET['permanent_deleted']);
$error = isset($_GET['error']);
$bulk_restored = isset($_GET['bulk_restored']) ? $_GET['bulk_restored'] : false;
$bulk_permanent_deleted = isset($_GET['bulk_permanent_deleted']) ? $_GET['bulk_permanent_deleted'] : false;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Recycle Bin - Admin | MSWDO Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
     <?= renderPwaMetaTags() ?>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #F8FAFC;
            color: #334155;
            padding-bottom: 75px;
        }
        :root {
            --primary: #1E4A8C;
            --primary-dark: #0A2F6C;
            --secondary: #D32F2F;
            --accent: #F5B042;
            --success: #059669;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --radius-md: 0.75rem;
            --radius-lg: 1rem;
            --radius-xl: 1.5rem;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: var(--white);
            border-right: 1px solid var(--gray-200);
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar.open { transform: translateX(0); }
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }
        .sidebar-overlay.active { display: block; }
        .sidebar-header { padding: 20px; border-bottom: 1px solid var(--gray-200); }
        .logo { display: flex; align-items: center; gap: 10px; }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: #FFFFFF;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(30, 74, 140, 0.15);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            flex-shrink: 0;
        }
        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 2px;
        }
        .logo-text h1 { font-size: 1rem; font-weight: 700; color: var(--primary); }
        .logo-text p { font-size: 0.6rem; color: var(--gray-500); }
        .nav-menu { padding: 20px 12px; }
        .nav-section { margin-bottom: 24px; }
        .nav-label {
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--gray-500);
            margin-bottom: 8px;
            padding-left: 12px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius-md);
            color: var(--gray-600);
            text-decoration: none;
            font-size: 0.85rem;
        }
        .nav-item i { width: 20px; color: var(--gray-400); }
        .nav-item:hover { background: var(--gray-100); color: var(--primary); }
        .nav-item.active { background: var(--primary); color: white; }
        .nav-item.active i { color: white; }
        .main-content {
            width: 100%;
            min-height: 100vh;
            padding: 16px;
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); width: 260px; }
            .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 24px 32px; }
            .menu-toggle { display: none; }
        }
        
        /* Top Bar */
        .top-bar {
            background: var(--white);
            padding: 12px 20px;
            border-radius: var(--radius-lg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .menu-toggle {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            padding: 8px;
            color: var(--gray-600);
        }
        .page-title h1 { 
            font-size: 1.3rem; 
            font-weight: 600; 
            color: var(--gray-800); 
        }
        .page-title p { 
            font-size: 0.7rem; 
            color: var(--gray-500); 
            margin-top: 2px; 
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            background: var(--gray-50);
            padding: 6px 12px;
            border-radius: 40px;
            text-decoration: none;
            color: inherit;
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .user-avatar i { color: var(--accent); font-size: 0.9rem; }
        .user-details span { font-size: 0.8rem; font-weight: 500; }
        .user-details small { font-size: 0.6rem; color: var(--gray-400); }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: white;
            padding: 16px;
            border-radius: var(--radius-lg);
            text-align: center;
            border: 1px solid var(--gray-200);
        }
        .stat-card i { font-size: 1.8rem; margin-bottom: 8px; }
        .stat-card .stat-number { font-size: 1.6rem; font-weight: 700; color: var(--gray-800); }
        .stat-card .stat-label { font-size: 0.7rem; color: var(--gray-500); }
        
        /* Filter Section */
        .filter-section {
            background: white;
            border-radius: var(--radius-xl);
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid var(--gray-200);
        }
        .filter-row {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        .filter-group {
            flex: 1;
            min-width: 150px;
        }
        .filter-group label {
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--gray-500);
            margin-bottom: 4px;
            display: block;
        }
        .filter-group input, .filter-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 0.8rem;
        }
        .btn-filter {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
        }
        .btn-reset {
            background: var(--gray-100);
            color: var(--gray-600);
            border: 1px solid var(--gray-200);
            padding: 8px 20px;
            border-radius: var(--radius-md);
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
        }
        
        /* Alerts */
        .alert-success {
            background: #D1FAE5;
            color: #065F46;
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            border-left: 4px solid var(--success);
        }
        .alert-error {
            background: #FEE2E2;
            color: #991B1B;
            padding: 12px 16px;
            border-radius: var(--radius-lg);
            margin-bottom: 20px;
            border-left: 4px solid var(--secondary);
        }
        
        /* Bulk Actions */
        .bulk-actions {
            background: white;
            border-radius: var(--radius-xl);
            padding: 15px 20px;
            margin-bottom: 20px;
            border: 1px solid var(--gray-200);
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }
        .btn-bulk-restore {
            background: var(--success);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 600;
        }
        .btn-bulk-delete {
            background: #FEE2E2;
            color: var(--secondary);
            border: 1px solid var(--secondary);
            padding: 8px 20px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 600;
        }
        
        /* Table */
        .table-container {
            background: white;
            border-radius: var(--radius-xl);
            border: 1px solid var(--gray-200);
            overflow-x: auto;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.8rem;
            min-width: 900px;
        }
        .table th {
            padding: 12px 16px;
            background: var(--gray-50);
            font-weight: 600;
            border-bottom: 2px solid var(--accent);
            text-align: left;
        }
        .table td {
            padding: 10px 16px;
            border-bottom: 1px solid var(--gray-200);
        }
        .checkbox-col { width: 40px; text-align: center; }
        .checkbox-col input { width: 18px; height: 18px; cursor: pointer; }
        .btn-restore {
            background: var(--success);
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            text-decoration: none;
            font-size: 0.7rem;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .btn-permanent-delete {
            background: #FEE2E2;
            color: var(--secondary);
            padding: 6px 12px;
            border-radius: 20px;
            border: none;
            font-size: 0.7rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-left: 8px;
        }
        .btn-permanent-delete:hover { background: var(--secondary); color: white; }
        .deleted-info { font-size: 0.65rem; color: var(--gray-500); margin-top: 4px; }
        .empty-state { text-align: center; padding: 60px 20px; color: var(--gray-500); }
        .empty-state i { font-size: 3rem; margin-bottom: 16px; opacity: 0.5; }
        
        /* Bottom Navigation */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--white);
            display: flex;
            justify-content: space-around;
            padding: 8px 16px 12px;
            border-top: 1px solid var(--gray-200);
            z-index: 100;
        }
        .bottom-nav .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.7rem;
            color: var(--gray-600);
            text-decoration: none;
            position: relative;
        }
        .bottom-nav .nav-item i { font-size: 1.2rem; margin-bottom: 4px; }
        .bottom-nav .nav-item.active { color: var(--primary); }
        .nav-badge {
            position: absolute;
            top: -8px;
            right: -12px;
            background: var(--secondary);
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.6rem;
        }
        @media (min-width: 992px) { .bottom-nav { display: none; } }
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .filter-row { flex-direction: column; }
        }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <div class="logo-icon">
                    <img src="../assets/img/mswdo_logo.jpg" alt="MSWDO Logo">
                </div>
                <div class="logo-text"><h1>MSWDO Cantilan</h1><p>Administrator</p></div>
            </div>
        </div>
        <nav class="nav-menu">
            <!-- MAIN SECTION -->
            <div class="nav-section">
                <div class="nav-label">Main</div>
                <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-chart-line"></i> Dashboard</a>
                <a href="../modules/manage_users.php" class="nav-item"><i class="fas fa-users-cog"></i> User Management</a>
                <a href="../modules/admin_household.php" class="nav-item"><i class="fas fa-home"></i> All Households</a>
            </div>
            <!-- SYSTEM SECTION -->
            <div class="nav-section">
                <div class="nav-label">System</div>
                <a href="../modules/admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i> Poverty Analysis</a>
                <a href="../modules/admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i> Reports</a>
                <a href="recycle_bin.php" class="nav-item active"><i class="fas fa-trash-restore"></i> Recycle Bin</a>
            </div>
            <!-- ACCOUNT SECTION -->
            <div class="nav-section">
                <div class="nav-label">Account</div>
                <a href="../modules/admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i> Profile</a>
                <a href="../logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
            <div class="page-title">
                <h1>Recycle Bin</h1>
                <p>Restore or permanently delete deleted household records</p>
            </div>
            <a href="../modules/admin_profile.php" class="user-menu">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-details">
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                    <small>Administrator</small>
                </div>
                <i class="fas fa-chevron-right" style="font-size: 0.7rem; color: var(--gray-400);"></i>
            </a>
        </div>

        <!-- Alert Messages -->
        <?php if($restored): ?>
        <div class="alert-success"><i class="fas fa-check-circle"></i> Household record successfully restored.</div>
        <?php endif; ?>
        <?php if($bulk_restored): ?>
        <div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo $bulk_restored; ?> household(s) successfully restored.</div>
        <?php endif; ?>
        <?php if($permanent_deleted): ?>
        <div class="alert-success"><i class="fas fa-check-circle"></i> Household record permanently deleted.</div>
        <?php endif; ?>
        <?php if($bulk_permanent_deleted): ?>
        <div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo $bulk_permanent_deleted; ?> household(s) permanently deleted.</div>
        <?php endif; ?>
        <?php if($error): ?>
        <div class="alert-error"><i class="fas fa-exclamation-circle"></i> An error occurred. Please try again.</div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card"><i class="fas fa-trash" style="color: var(--secondary);"></i><div class="stat-number"><?php echo $total_deleted; ?></div><div class="stat-label">In Recycle Bin</div></div>
            <div class="stat-card"><i class="fas fa-undo-alt" style="color: var(--success);"></i><div class="stat-number"><?php echo $total_restored; ?></div><div class="stat-label">Restored</div></div>
            <div class="stat-card"><i class="fas fa-trash-alt" style="color: var(--secondary);"></i><div class="stat-number"><?php echo $total_permanently_deleted; ?></div><div class="stat-label">Permanently Deleted</div></div>
            <div class="stat-card"><i class="fas fa-calendar-week" style="color: var(--accent);"></i><div class="stat-number"><?php echo date('M d, Y'); ?></div><div class="stat-label">Current Date</div></div>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <form method="GET" class="filter-row">
                <div class="filter-group">
                    <label>Search by Name</label>
                    <input type="text" name="search" placeholder="Search deleted households..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-group">
                    <label>Barangay</label>
                    <select name="barangay">
                        <option value="">All Barangays</option>
                        <?php foreach($barangays as $b): ?>
                            <option value="<?php echo htmlspecialchars($b['barangay']); ?>" <?php echo $barangay_filter == $b['barangay'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($b['barangay']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-group">
                    <button type="submit" class="btn-filter">Apply Filter</button>
                    <?php if($search || $barangay_filter): ?>
                        <a href="recycle_bin.php" class="btn-reset">Clear</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Bulk Actions -->
        <?php if(count($deleted_households) > 0): ?>
        <form method="POST" id="bulkActionForm">
            <div class="bulk-actions">
                <i class="fas fa-check-double"></i>
                <span><span id="selectedCount">0</span> item(s) selected</span>
                <button type="button" class="btn-bulk-restore" onclick="submitBulkAction('restore')"><i class="fas fa-undo-alt"></i> Restore Selected</button>
                <button type="button" class="btn-bulk-delete" onclick="submitBulkAction('delete')"><i class="fas fa-trash-alt"></i> Permanently Delete Selected</button>
                <button type="button" class="btn-reset" onclick="toggleAllCheckboxes(this)">Select All</button>
            </div>
        <?php endif; ?>

        <!-- Table -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <?php if(count($deleted_households) > 0): ?>
                            <th class="checkbox-col"><input type="checkbox" id="selectAllCheckbox" onclick="toggleSelectAll()"></th>
                        <?php endif; ?>
                        <th>Household Head</th>
                        <th>Barangay</th>
                        <th>Members</th>
                        <th>Monthly Income</th>
                        <th>Deleted By</th>
                        <th>Date Deleted</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($deleted_households) > 0): ?>
                        <?php foreach($deleted_households as $hh): ?>
                        <tr>
                            <td class="checkbox-col"><input type="checkbox" name="selected_ids[]" value="<?php echo $hh['id']; ?>" class="item-checkbox" onclick="updateSelectedCount()"></td>
                            <td><strong><?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($hh['barangay'] ?? 'N/A'); ?></td>
                            <td><?php echo $hh['total_members'] ?? 1; ?></td>
                            <td>₱ <?php echo number_format($hh['monthly_income'] ?? 0, 2); ?></td>
                            <td><?php echo htmlspecialchars($hh['deleted_by_name']); ?><div class="deleted-info">ID: <?php echo $hh['deleted_by']; ?></div></td>
                            <td><?php echo date('M d, Y h:i A', strtotime($hh['deleted_at'])); ?></td>
                            <td>
                                <a href="?restore_id=<?php echo $hh['id']; ?>" class="btn-restore" onclick="return confirm('Restore this household? It will be moved back to active households.')"><i class="fas fa-undo-alt"></i> Restore</a>
                                <button onclick="confirmPermanentDelete(<?php echo $hh['id']; ?>, '<?php echo htmlspecialchars($hh['head_first_name'] . ' ' . $hh['head_last_name']); ?>')" class="btn-permanent-delete"><i class="fas fa-trash-alt"></i> Delete Permanently</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="empty-state"><i class="fas fa-trash-restore"></i><p>Recycle bin is empty.</p><p style="font-size:0.75rem;">Deleted households will appear here.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if(count($deleted_households) > 0): ?>
        </form>
        <?php endif; ?>
    </main>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="../dashboards/admin_dashboard.php" class="nav-item"><i class="fas fa-home"></i><span>Home</span></a>
        <a href="../modules/manage_users.php" class="nav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="../modules/admin_household.php" class="nav-item"><i class="fas fa-home"></i><span>Households</span></a>
        <a href="../modules/admin_reports.php" class="nav-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
        <a href="../modules/admin_povertyanalysis.php" class="nav-item"><i class="fas fa-chart-line"></i><span>Poverty</span></a>
        <a href="../modules/admin_profile.php" class="nav-item"><i class="fas fa-user-cog"></i><span>Profile</span></a>
    </div>

    <script>
        // Sidebar toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if(menuToggle) menuToggle.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('active'); };
        if(overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('active'); };

        function confirmPermanentDelete(id, name) {
            if(confirm(`⚠️ PERMANENT DELETION WARNING ⚠️\n\nAre you sure you want to permanently delete "${name}"?\n\nThis action CANNOT be undone!`)) {
                window.location.href = `?permanent_delete_id=${id}`;
            }
        }
        
        function updateSelectedCount() {
            const checkboxes = document.querySelectorAll('.item-checkbox');
            const checked = Array.from(checkboxes).filter(cb => cb.checked).length;
            document.getElementById('selectedCount').innerText = checked;
            const selectAll = document.getElementById('selectAllCheckbox');
            if(selectAll) {
                if(checked === 0) { selectAll.checked = false; selectAll.indeterminate = false; }
                else if(checked === checkboxes.length) { selectAll.checked = true; selectAll.indeterminate = false; }
                else { selectAll.checked = false; selectAll.indeterminate = true; }
            }
        }
        
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAllCheckbox');
            document.querySelectorAll('.item-checkbox').forEach(cb => cb.checked = selectAll.checked);
            updateSelectedCount();
        }
        
        function toggleAllCheckboxes(btn) {
            const checkboxes = document.querySelectorAll('.item-checkbox');
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            checkboxes.forEach(cb => cb.checked = !allChecked);
            updateSelectedCount();
            btn.innerHTML = allChecked ? '<i class="fas fa-square"></i> Select All' : '<i class="fas fa-square-check"></i> Deselect All';
        }
        
        function submitBulkAction(action) {
            const selected = document.querySelectorAll('.item-checkbox:checked');
            if(selected.length === 0) { alert('Please select at least one item.'); return; }
            let msg = action === 'restore' ? `Restore ${selected.length} household(s)?` : `⚠️ PERMANENTLY DELETE ${selected.length} household(s)? This cannot be undone!`;
            if(confirm(msg)) {
                const form = document.getElementById('bulkActionForm');
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = action === 'restore' ? 'bulk_restore' : 'bulk_permanent_delete';
                input.value = '1';
                form.appendChild(input);
                form.submit();
            }
        }
        
        document.addEventListener('DOMContentLoaded', updateSelectedCount);
    </script>

<?= renderPwaServiceWorker() ?>
</body>
</html>