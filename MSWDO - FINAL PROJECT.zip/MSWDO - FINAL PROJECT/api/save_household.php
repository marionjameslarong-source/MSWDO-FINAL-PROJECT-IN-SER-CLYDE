<?php
// ============================================================
// api/save_household.php
// Receives household form data from the offline sync queue
// and inserts it into the database.
// ============================================================

session_start();
header('Content-Type: application/json');

// --- Auth ---
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST only']);
    exit;
}

// --- Load DB ($pdo becomes available) ---
require_once __DIR__ . '/../config/database.php';

// --- Read JSON body ---
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}

$user_id = (int) $_SESSION['user_id'];

// --- Validate required fields ---
$required = ['head_first_name', 'head_last_name', 'address', 'barangay'];
$missing = [];
foreach ($required as $f) {
    if (empty($data[$f])) $missing[] = $f;
}
if ($missing) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Missing: ' . implode(', ', $missing)]);
    exit;
}

// --- Compute poverty status (same as household_form.php) ---
$monthly_income = (float) ($data['monthly_income'] ?? 0);
if ($monthly_income < 5000) $poverty_status = 'Extremely Poor';
elseif ($monthly_income <= 10000) $poverty_status = 'Poor';
elseif ($monthly_income <= 15000) $poverty_status = 'Low Income';
elseif ($monthly_income <= 25000) $poverty_status = 'Lower Middle';
else $poverty_status = 'Middle Income and Above';

$members = is_array($data['members'] ?? null) ? $data['members'] : [];
$total_members = count($members);

try {
    $pdo->beginTransaction();

    // --- Insert household ---
    $stmt = $pdo->prepare("
        INSERT INTO households (
            user_id, head_first_name, head_last_name, head_middle_name,
            relation_to_head, contact_number, email,
            address, barangay, city_municipality, province, zip_code,
            total_members, monthly_income, is_4ps_beneficiary,
            poverty_status, verification_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_review', NOW())
    ");
    $stmt->execute([
        $user_id,
        $data['head_first_name'],
        $data['head_last_name'],
        $data['head_middle_name'] ?? '',
        $data['relation_to_head'] ?? 'Self',
        $data['contact_number'] ?? '',
        $data['email'] ?? '',
        $data['address'],
        $data['barangay'],
        'Cantilan',
        'Surigao del Sur',
        $data['zip_code'] ?? '8317',
        $total_members,
        $monthly_income,
        !empty($data['is_4ps_beneficiary']) ? 1 : 0,
        $poverty_status,
    ]);
    $household_id = (int) $pdo->lastInsertId();

    // --- Insert members ---
    if ($total_members > 0) {
        $memStmt = $pdo->prepare("
            INSERT INTO household_members
                (household_id, first_name, last_name, relationship, age, gender, occupation, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        foreach ($members as $m) {
            $full = trim($m['full_name'] ?? '');
            if ($full === '') continue;

            // Split "First Last" — same as household_form.php
            $parts = explode(' ', $full, 2);
            $first = $parts[0];
            $last  = $parts[1] ?? '';

            $memStmt->execute([
                $household_id,
                $first,
                $last,
                $m['relationship'] ?? '',
                (int) ($m['age'] ?? 0),
                $m['gender'] ?? '',
                $m['occupation'] ?? '',
            ]);
        }
    }

    $pdo->commit();

    echo json_encode([
        'success'        => true,
        'household_id'   => $household_id,
        'message'        => 'Household saved successfully',
    ]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[save_household API] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage(),
    ]);
}